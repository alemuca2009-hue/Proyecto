"""Legacy-output parity, module isolation, configuration and cache boundaries."""
import importlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from conversion_engine import (ResourcePack, SurfaceSettings, convert_file,
                               engine_metadata, load_settings, model_slug)
from conversion_engine.control import ConversionCancelled
from compare_engine_v244 import snapshot

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT/'tests/fixtures/legacy244_fan.jar'
GOLDEN = json.loads((ROOT/'tests/fixtures/legacy244_fan_golden.json').read_text())
MODEL = 'test:block/fan'


class EngineTests(unittest.TestCase):
    def test_original_244_golden_matches_surface_and_diagnostic_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            for mode in ('surface', 'exact'):
                result = convert_file(FIXTURE, MODEL, Path(tmp)/mode, mesh_mode=mode, settings=SurfaceSettings(refinement_passes=0))
                self.assertEqual(snapshot(result.directory), GOLDEN[mode]['files'])
                self.assertEqual(len(result.target_ir['faces']), GOLDEN[mode]['target_faces'])
                self.assertEqual(result.report['conversion_engine']['algorithm_version'], '2.5.0')

    def test_old_import_paths_share_the_actual_engine_including_private_functions(self):
        for name in ('geometry', 'mesh_surface', 'surface_contours', 'surface_adapter',
                     'resources', 'sprites', 'vanilla', 'water_wheel', 'palettes',
                     'control', 'pack', 'editable', 'model_profile'):
            self.assertIs(importlib.import_module('bridge.'+name),
                          importlib.import_module('conversion_engine.'+name))
        from bridge.mesh_surface import _patch
        from conversion_engine.mesh_surface import _patch as actual
        self.assertIs(_patch, actual)

    def test_copying_only_engine_supports_cli_and_bundled_resources(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            shutil.copytree(ROOT/'conversion_engine', root/'conversion_engine',
                            ignore=shutil.ignore_patterns('__pycache__'))
            config = root/'conversion_engine/settings.json'
            values = json.loads(config.read_text()); values['refinement_passes'] = 0
            config.write_text(json.dumps(values))
            env = dict(os.environ)
            # Retain explicit dependency environments, but never use the app
            # checkout as a fallback for this standalone copy.
            env['PYTHONPATH'] = os.pathsep.join(p for p in env.get('PYTHONPATH', '').split(os.pathsep)
                if p and Path(p).resolve() not in (ROOT, ROOT.parent))
            smoke = subprocess.run([sys.executable, '-c',
                "import sys, conversion_engine; from conversion_engine.vanilla import bundled_resource_path; "
                "assert bundled_resource_path().is_file(); "
                "assert not any(n == 'app' or n.startswith('bridge') for n in sys.modules)"],
                cwd=root, env=env, text=True, capture_output=True)
            self.assertEqual(smoke.returncode, 0, smoke.stderr)
            listed = subprocess.run([sys.executable, '-m', 'conversion_engine', '--input', str(FIXTURE), '--list'],
                                    cwd=root, env=env, text=True, capture_output=True)
            self.assertEqual(listed.returncode, 0, listed.stderr)
            self.assertIn(MODEL, json.loads(listed.stdout))
            converted = subprocess.run([sys.executable, '-m', 'conversion_engine', '--input', str(FIXTURE),
                '--model', MODEL, '--output', str(root/'out')], cwd=root, env=env, text=True, capture_output=True)
            self.assertEqual(converted.returncode, 0, converted.stderr)
            self.assertEqual(snapshot(root/'out'), GOLDEN['surface']['files'])
            config = root/'conversion_engine/settings.json'
            settings = json.loads(config.read_text()); settings['rectangle_budget'] = 4
            config.write_text(json.dumps(settings))
            custom = subprocess.run([sys.executable, '-m', 'conversion_engine', '--input', str(FIXTURE),
                '--model', MODEL, '--output', str(root/'custom')], cwd=root, env=env, text=True, capture_output=True)
            self.assertEqual(custom.returncode, 0, custom.stderr)
            self.assertEqual(len(json.loads((root/'custom/ir_bedrock.json').read_text())['faces']), 4)

    def test_settings_file_has_exact_legacy_defaults(self):
        self.assertEqual(load_settings(), SurfaceSettings())
        self.assertEqual(load_settings().to_dict(), {'pixels_per_unit':4, 'max_atlas':4096,
            'contour_tolerance':1/32, 'rectangle_budget':3500, 'max_slices':128, 'minimum_coverage':.99,'refinement_passes':2,'refinement_rectangle_budget':12000,'refinement_max_slices':512})

    def test_setting_override_reaches_conversion_and_provenance(self):
        with tempfile.TemporaryDirectory() as tmp:
            settings = SurfaceSettings(rectangle_budget=4, minimum_coverage=.95, refinement_passes=0)
            result = convert_file(FIXTURE, MODEL, Path(tmp)/'out', settings=settings)
            self.assertEqual(len(result.target_ir['faces']), 4)
            report = json.loads((result.directory/'surface_report.json').read_text())
            self.assertEqual(report['contour_refinement']['masked_fallback_polygon_count'], 4)
            self.assertTrue(any('95 %' in warning for warning in result.report['warnings']))
            self.assertEqual(result.report['conversion_engine'], engine_metadata(settings))
            self.assertNotEqual(engine_metadata()['signature'], engine_metadata(settings)['signature'])
            self.assertNotEqual(engine_metadata()['signature'], engine_metadata(mesh_mode='exact')['signature'])

    def test_bad_settings_and_modes_fail_without_partial_conversion(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for payload in ([], {'typo':1}, {'pixels_per_unit':float('nan')},
                            {'rectangle_budget':True}, {'max_atlas':15}, {'minimum_coverage':1.1}):
                p = root/'bad.json'; p.write_text(json.dumps(payload))
                with self.assertRaises(ValueError): load_settings(p)
            with self.assertRaises(ValueError):
                convert_file(FIXTURE, MODEL, root/'out', mesh_mode='invalid')
            self.assertFalse((root/'out').exists())

    def test_output_directory_is_never_silently_reused(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root/'sentinel').write_bytes(b'keep')
            with self.assertRaisesRegex(ValueError, 'no est'):
                convert_file(FIXTURE, MODEL, root)
            self.assertEqual(list(root.iterdir()), [root/'sentinel'])
            self.assertEqual((root/'sentinel').read_bytes(), b'keep')

    def test_cancellation_is_not_converted_to_a_surface_warning(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ConversionCancelled):
                convert_file(FIXTURE, MODEL, Path(tmp)/'start', cancel=lambda:True)
            self.assertFalse((Path(tmp)/'start').exists())
            with patch('conversion_engine.surface_adapter.adapt_surface', side_effect=ConversionCancelled('stop')):
                with self.assertRaises(ConversionCancelled):
                    convert_file(FIXTURE, MODEL, Path(tmp)/'surface')

    def test_failed_surface_retains_the_exact_diagnostic_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch('conversion_engine.mesh_surface.convert_mesh_surface', side_effect=ValueError('fixture failure')):
                result = convert_file(FIXTURE, MODEL, Path(tmp)/'out')
            self.assertEqual(result.report['target_kind'], 'experimental_poly_mesh')
            self.assertTrue(any('fixture failure' in w for w in result.report['warnings']))
            self.assertEqual(snapshot(result.directory), GOLDEN['exact']['files'])

    def test_lazy_worker_refreshes_old_algorithm_and_changed_modes(self):
        import render_worker
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cached = convert_file(FIXTURE, MODEL, root/'cached')
            original_report = json.loads((cached.directory/'report.json').read_text())
            for label, stale, mode in [('reuse', False, 'surface'), ('old_algorithm', True, 'surface'),
                                       ('different_settings', False, 'surface'), ('different_mode', False, 'exact')]:
                with self.subTest(label=label):
                    report = dict(original_report)
                    if stale: report.pop('conversion_engine')
                    if label == 'different_settings':
                        report['conversion_engine'] = engine_metadata(SurfaceSettings(rectangle_budget=4))
                    (cached.directory/'report.json').write_text(json.dumps(report))
                    run = root/label; run.mkdir()
                    config = {'run':str(run), 'java':str(FIXTURE), 'dependencies':[],
                        'available_models':{MODEL:{'name':'fan', 'modeldir':str(cached.directory)}},
                        'selection':{'mesh_mode':mode,
                            'profiles':[{'id':'p','name':'p','views':['frontal'],'modes':['texture'],
                                         'size':64,'representation':'translated'}],
                            'models':[{'id':MODEL,'profile_ids':['p']}]}}
                    path = run/'config.json'; path.write_text(json.dumps(config))
                    self.assertEqual(render_worker.main(path), 0)
                    completion = json.loads((run/'completion.json').read_text())
                    self.assertTrue(completion['ok'])
                    self.assertEqual(completion['result']['failed'], 0)
                    prepared = run/'prepared_models'/model_slug(MODEL)
                    self.assertEqual(prepared.exists(), label != 'reuse')
                    if prepared.exists():
                        self.assertEqual(snapshot(prepared), snapshot(cached.directory) if mode=='surface' else GOLDEN[mode]['files'])


if __name__ == '__main__':
    unittest.main()
