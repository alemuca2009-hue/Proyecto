"""Independent contract fixtures derived from geometry specification conventions.

These expected numbers are literals or analytic trigonometry, never obtained by
calling the converter's inverse. This suite supplements (not replaces) an
external check in Blockbench and Minecraft Bedrock.
"""
from __future__ import annotations
import copy
import itertools
import json
import math
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from bridge.geometry import convert_model, decode_bedrock
from bridge.resources import ResourcePack
from bridge.rendering import compare_geometry, combined_bounds, image_metrics, render_view

FACES = ('north', 'east', 'south', 'west', 'up', 'down')


class SpecificationContractTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.assets = self.root / 'input' / 'assets' / 'fixture'
        (self.assets / 'models' / 'block').mkdir(parents=True)
        (self.assets / 'textures' / 'block').mkdir(parents=True)
        yy, xx = np.indices((64, 32))
        self.rgba = np.stack((xx * 7, yy * 3, (xx * 5 + yy * 11) % 256,
                              np.full_like(xx, 255)), axis=-1).astype(np.uint8)
        Image.fromarray(self.rgba, 'RGBA').save(self.assets / 'textures' / 'block' / 'asymmetric.png')

    def tearDown(self):
        self.temp.cleanup()

    def model(self, element=None):
        return {'textures': {'t': 'fixture:block/asymmetric'},
                'elements': [element or {'from': [1, 2, 3], 'to': [5, 9, 14],
                    'faces': {d: {'texture': '#t', 'uv': [2, 3, 10, 13]} for d in FACES}}]}

    def convert(self, model):
        path = self.assets / 'models' / 'block' / 'sample.json'
        path.write_text(json.dumps(model), encoding='utf-8')
        with ResourcePack(self.root / 'input') as pack:
            report = convert_model(pack, 'fixture:block/sample', self.root / 'output')
        if 'geometry' not in report['paths']:
            self.fail(f"Fixture unexpectedly produced no geometry: {report}")
        geo = json.loads(Path(report['paths']['geometry']).read_text())
        source = json.loads(Path(report['paths']['ir_original']).read_text())
        target = decode_bedrock(geo, report['paths']['atlas'])
        return report, geo, source, target

    def test_asymmetric_coordinate_golden(self):
        report, geo, source, target = self.convert(self.model())
        cube = geo['minecraft:geometry'][0]['bones'][0]['cubes'][0]
        self.assertEqual(cube['origin'], [3, 2, -5])
        self.assertEqual(cube['size'], [4, 7, 11])
        self.assertEqual(source['bounds'], [[-7, 2, -5], [-3, 9, 6]])
        self.assertEqual(target['bounds'], [[-7, 2, -5], [-3, 9, 6]])
        self.assertTrue(report['metrics']['static_equivalence_passed'])
        # A symmetric 16x16 cube cannot catch an accidental X reflection.
        vertices = {tuple(p) for f in target['faces'] for p in f['vertices']}
        expected = set(itertools.product((-7, -3), (2, 9), (-5, 6)))
        self.assertEqual(vertices, expected)

    def test_up_down_uv_golden_and_signed_rectangles(self):
        _, geo, _, target = self.convert(self.model())
        cube = geo['minecraft:geometry'][0]['bones'][0]['cubes'][0]
        for direction in ('north', 'east', 'south', 'west'):
            self.assertEqual(cube['uv'][direction], {'uv': [4, 12], 'uv_size': [16, 40]})
        for direction in ('up', 'down'):
            self.assertEqual(cube['uv'][direction], {'uv': [20, 52], 'uv_size': [-16, -40]})
        for face in target['faces']:
            self.assertEqual(face['uv'], [[4, 12], [4, 52], [20, 52], [20, 12]])
        # Positive U/V sizes must not be forced on an intentionally mirrored UV.
        model = self.model()
        model['elements'][0]['faces']['up']['uv'] = [10, 13, 2, 3]
        _, geo, _, _ = self.convert(model)
        self.assertEqual(geo['minecraft:geometry'][0]['bones'][0]['cubes'][0]['uv']['up'],
                         {'uv': [4, 12], 'uv_size': [16, 40]})

    def test_uv_rotation_and_missing_faces(self):
        model = self.model()
        model['elements'][0]['faces'] = {
            'north': {'texture': '#t', 'uv': [2, 3, 10, 13], 'rotation': 90},
            'up': {'texture': '#t', 'uv': [2, 3, 10, 13], 'rotation': 270}}
        _, geo, _, target = self.convert(model)
        uv = geo['minecraft:geometry'][0]['bones'][0]['cubes'][0]['uv']
        self.assertEqual(set(uv), {'north', 'up'})
        self.assertEqual(uv['north']['uv_rotation'], 90)
        self.assertEqual(uv['up']['uv_rotation'], 270)
        by_face = {f['direction']: f for f in target['faces']}
        self.assertEqual(by_face['north']['uv'], [[4, 52], [20, 52], [20, 12], [4, 12]])
        self.assertEqual(by_face['up']['uv'], [[20, 12], [4, 12], [4, 52], [20, 52]])

    def test_external_pivot_rotation_matches_analytic_vertices(self):
        model = self.model()
        model['elements'][0]['rotation'] = {'origin': [4, 5, 6], 'axis': 'x', 'angle': 22.5}
        _, geo, _, target = self.convert(model)
        cube = geo['minecraft:geometry'][0]['bones'][0]['cubes'][0]
        self.assertEqual(cube['pivot'], [4, 5, -2])
        self.assertEqual(cube['rotation'], [-22.5, 0, 0])
        c, s = math.cos(math.pi / 8), math.sin(math.pi / 8)
        expected = []
        for x, y, z in itertools.product((1, 5), (2, 9), (3, 14)):
            expected.append([x - 8, 5 + c * (y - 5) - s * (z - 6),
                             -2 + s * (y - 5) + c * (z - 6)])
        actual = np.asarray([p for f in target['faces'] for p in f['vertices']])
        for point in expected:
            self.assertLess(np.linalg.norm(actual - point, axis=1).min(), 1e-10)

    def test_rescale_45_preserves_analytic_cube_size(self):
        model = self.model()
        model['elements'][0]['rotation'] = {'origin': [4, 5, 6], 'axis': 'y', 'angle': 45, 'rescale': True}
        _, geo, _, target = self.convert(model)
        cube = geo['minecraft:geometry'][0]['bones'][0]['cubes'][0]
        np.testing.assert_allclose(cube['size'], [4 * math.sqrt(2), 7, 11 * math.sqrt(2)], atol=1e-10)
        # With perpendicular scale sqrt(2) and 45-degree Y rotation:
        # x' = pX + (x-pX)+(z-pZ), z' = pZ-(x-pX)+(z-pZ).
        expected = [[4 + (x - 4) + (z - 6) - 8, y, 6 - (x - 4) + (z - 6) - 8]
                    for x, y, z in itertools.product((1, 5), (2, 9), (3, 14))]
        actual = np.asarray([p for f in target['faces'] for p in f['vertices']])
        for point in expected:
            self.assertLess(np.linalg.norm(actual - point, axis=1).min(), 1e-10)

    def test_target_geometry_mutation_is_detected(self):
        report, geo, source, _ = self.convert(self.model())
        geo['minecraft:geometry'][0]['bones'][0]['cubes'][0]['origin'][0] += 0.25
        damaged = decode_bedrock(geo, report['paths']['atlas'])
        result = compare_geometry(source, damaged)
        self.assertFalse(result['surface_geometry_equal'])
        self.assertAlmostEqual(result['bounds_max_absolute_error'], 0.25)
        bounds = combined_bounds(source, damaged)
        a = render_view(source, 'frontal', 128, bounds)
        b = render_view(damaged, 'frontal', 128, bounds)
        self.assertFalse(image_metrics(a, b)['pixel_identical'])

    def test_target_uv_mutation_is_detected_without_geometry_change(self):
        report, geo, source, _ = self.convert(self.model())
        geo['minecraft:geometry'][0]['bones'][0]['cubes'][0]['uv']['north']['uv'][0] += 2
        damaged = decode_bedrock(geo, report['paths']['atlas'])
        result = compare_geometry(source, damaged)
        self.assertTrue(result['surface_geometry_equal'])
        self.assertFalse(result['texture_sample_check_passed'])
        bounds = combined_bounds(source, damaged)
        a = render_view(source, 'frontal', 128, bounds)
        b = render_view(damaged, 'frontal', 128, bounds)
        self.assertGreater(image_metrics(a, b)['mismatch_pixels'], 0)

    def test_lossless_transparency_including_hidden_rgb(self):
        rgba = self.rgba.copy()
        rgba[::4, :, 3] = 0
        rgba[1::4, :, 3] = 64
        rgba[2::4, :, 3] = 128
        file = self.assets / 'textures' / 'block' / 'asymmetric.png'
        Image.fromarray(rgba, 'RGBA').save(file)
        original_bytes = file.read_bytes()
        report, _, _, _ = self.convert(self.model())
        with Image.open(report['paths']['atlas']) as atlas:
            np.testing.assert_array_equal(np.asarray(atlas), rgba)
        source_copy = self.root / 'output' / 'originals' / 'assets' / 'fixture' / 'textures' / 'block' / 'asymmetric.png'
        self.assertEqual(source_copy.read_bytes(), original_bytes)
        self.assertTrue(report['metrics']['rgba_texels_preserved'])

    def test_excess_size_is_retained_and_block_rejected(self):
        model = self.model()
        model['elements'][0]['from'] = [-10, 0, 0]
        model['elements'][0]['to'] = [21, 16, 16]
        report, geo, _, _ = self.convert(model)
        self.assertFalse(report['metrics']['block_compatible'])
        self.assertEqual(report['target_kind'], 'entity_geometry')
        self.assertEqual(geo['minecraft:geometry'][0]['bones'][0]['cubes'][0]['size'], [31, 16, 16])
        self.assertEqual(report['status'], 'review')


if __name__ == '__main__':
    unittest.main()
