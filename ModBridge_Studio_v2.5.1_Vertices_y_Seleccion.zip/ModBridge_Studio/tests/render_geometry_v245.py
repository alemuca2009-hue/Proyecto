"""Render exact decoded wire edges, with one shared camera per before/after row.

This intentionally ignores preview-only wire_edges. Every polygon edge in the
decoded destination is shown, including strip seams and otherwise masked planes.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFont


ROWS = [
    ('track/bogey/bogey_drive_wheel_pin', 'Pasadores: el caso de las dos piezas cubicas'),
    ('chain_conveyor/item', 'Transportador'),
    ('flywheel/block', 'Volante'),
    ('large_water_wheel/block', 'Rueda de agua grande'),
    ('copper_valve_handle', 'Valvula: bordes oblicuos'),
    ('mechanical_roller/wheel', 'Rodillo'),
]


def wire(ir, bounds, size=500):
    im = Image.new('RGB', (size, size), '#101c28')
    draw = ImageDraw.Draw(im)
    center = np.mean(bounds, axis=0)
    right = np.array([1., 0., -1.]) / np.sqrt(2)
    up = np.array([-1., 2., -1.]) / np.sqrt(6)
    camera = np.array([1., 1., 1.]) / np.sqrt(3)
    basis = np.array([right, up, camera])
    all_points = np.array([p for f in ir['faces'] for p in f['vertices']])
    extent = max(np.max(np.array(bounds)[1]-np.array(bounds)[0]), 1e-9)
    scale = size * .60 / extent
    edges = {}
    for face in ir['faces']:
        v = np.array(face['vertices'])
        for a, b in zip(v, np.roll(v, -1, axis=0)):
            key = tuple(sorted([tuple(np.round(a, 7)), tuple(np.round(b, 7))]))
            edges[key] = (a, b)
    # Far lines first; this is X-ray wire geometry, not surface visibility.
    ordered = sorted(edges.values(), key=lambda pair: float(np.mean(pair, axis=0) @ camera))
    for a, b in ordered:
        points = (np.array([a, b])-center) @ basis.T
        xy = [(size/2+p[0]*scale, size/2-p[1]*scale) for p in points]
        draw.line(xy, fill='#b7d996', width=1)
    return im


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--before', required=True, type=Path)
    parser.add_argument('--after', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from bridge.pipeline import model_slug
    from bridge.rendering import combined_bounds
    fontpath = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    try:
        title = ImageFont.truetype(fontpath, 28)
        label = ImageFont.truetype(fontpath, 22)
        small = ImageFont.truetype(fontpath, 18)
    except OSError:
        title = label = small = ImageFont.load_default()
    width, height = 1560, 180 + len(ROWS)*580
    sheet = Image.new('RGB', (width, height), '#f6f8fa')
    draw = ImageDraw.Draw(sheet)
    draw.text((30, 22), 'ModBridge 2.4.5 | Comparacion de la geometria exportada', font=title, fill='#18343d')
    draw.text((30, 70), 'Misma escala y camara. Todas las aristas del JSON decodificado; no oculta divisiones ni usa mascaras.', font=small, fill='#435e68')
    for col, name in enumerate(['Fuente Java', 'Destino 2.4.4', 'Destino 2.4.5']):
        draw.text((30+col*510, 116), name, font=label, fill='#18343d')
    for row, (model, caption) in enumerate(ROWS):
        slug = model_slug('create:block/'+model)
        original = json.loads((args.before/'models'/slug/'ir_original.json').read_text())
        before = json.loads((args.before/'models'/slug/'ir_bedrock.json').read_text())
        after = json.loads((args.after/'models'/slug/'ir_bedrock.json').read_text())
        bounds = combined_bounds(original, before, after)
        top = 165+row*580
        draw.text((30, top), caption, font=label, fill='#18343d')
        for col, ir in enumerate([original, before, after]):
            sheet.paste(wire(ir, bounds), (30+col*510, top+38))
            draw.text((30+col*510, top+544), f"{len(ir['faces'])} caras", font=small, fill='#435e68')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(args.output)


if __name__ == '__main__':
    main()
