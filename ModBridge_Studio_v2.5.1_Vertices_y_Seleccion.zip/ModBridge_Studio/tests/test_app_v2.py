import io
import json
import tempfile
import threading
import time
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
from app import Studio


def fixture(path, namespace='test'):
    with zipfile.ZipFile(path, 'w') as z:
        z.writestr(f'assets/{namespace}/models/block/a.json', json.dumps({'parent':'minecraft:block/cube_all','textures':{'all':'minecraft:block/stone'}}))
    return path


class ProjectRevisionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.java=fixture(self.root/'original.jar')
        self.studio=Studio(self.root/'workspace',java=self.java)
        self.studio.result={'archive':'old.zip','reports':[],'download_url':'/download/result.zip'}
        self.studio.run=self.root/'old_run'
        self.studio.job={'state':'done','result_url':'/download/result.zip'}

    def tearDown(self):
        self.studio.cancel();self.temp.cleanup()

    def assert_invalidated(self):
        self.assertIsNone(self.studio.result);self.assertIsNone(self.studio.run)
        self.assertEqual(self.studio.job['state'],'idle')
        self.assertNotIn('result_url',self.studio.job)
        self.assertEqual(self.studio.project['revision'],1)
        self.assertIsNone(self.studio.status()['result'])

    def test_dependency_invalidates_result_and_keeps_primary(self):
        dep=fixture(self.root/'dependency.jar','dep')
        self.studio.replace_input('dependency',dep)
        self.assertEqual(self.studio.java,str(self.java));self.assertEqual(self.studio.dependencies,[str(dep)])
        self.assert_invalidated()

    def test_reference_invalidates_result(self):
        path=self.root/'reference.mcaddon'
        with zipfile.ZipFile(path,'w') as z:z.writestr('RP/manifest.json','{}')
        self.studio.replace_input('reference',path)
        self.assertEqual(self.studio.reference,str(path));self.assert_invalidated()

    def test_java_invalidates_result_and_clears_old_dependencies(self):
        self.studio.dependencies=['old.jar']
        path=fixture(self.root/'new.jar','new')
        self.studio.replace_input('java',path)
        self.assertEqual(self.studio.java,str(path));self.assertEqual(self.studio.dependencies,[])
        self.assertEqual(self.studio.project['models'],[{'id':'new:block/a'}]);self.assert_invalidated()

    def test_failed_reindex_rolls_back_entire_current_state(self):
        prior=(self.studio.java,self.studio.reference,list(self.studio.dependencies),self.studio.project,self.studio.result,self.studio.run,dict(self.studio.job),self.studio.revision)
        path=fixture(self.root/'good.jar','extra')
        with patch.object(self.studio,'build_project',side_effect=ValueError('index failed')):
            with self.assertRaisesRegex(ValueError,'index failed'):self.studio.replace_input('dependency',path)
        after=(self.studio.java,self.studio.reference,self.studio.dependencies,self.studio.project,self.studio.result,self.studio.run,self.studio.job,self.studio.revision)
        self.assertEqual(prior,after)

    def test_invalid_upload_preserves_results(self):
        bad=self.root/'invalid.jar';bad.write_text('not a zip')
        with self.assertRaises(zipfile.BadZipFile):self.studio.replace_input('java',bad)
        self.assertEqual(self.studio.result['archive'],'old.zip');self.assertEqual(self.studio.revision,0)

    def test_running_job_rejects_new_inputs(self):
        self.studio.job['state']='running'
        with self.assertRaisesRegex(ValueError,'termine'):self.studio.replace_input('dependency',self.java)
        self.assertEqual(self.studio.dependencies,[])

    def test_invalid_mesh_mode_does_not_mutate_old_result(self):
        with self.assertRaisesRegex(ValueError,'Modo de malla'):self.studio.start({'mesh_mode':'invented'})
        self.assertEqual(self.studio.result['archive'],'old.zip');self.assertEqual(self.studio.job['state'],'done')

    def test_mesh_mode_forwarded_and_defaults_to_surface(self):
        for mode in [None,'exact','surface']:
            self.studio.start({'render_size':64, **({} if mode is None else {'mesh_mode':mode})})
            deadline=time.monotonic()+8
            while self.studio.worker is not None and time.monotonic()<deadline:time.sleep(.02)
            self.assertEqual(self.studio.job['state'],'done',self.studio.job)
            config=json.loads((self.studio.workrun/'config.json').read_text())
            self.assertEqual(config['mesh_mode'],mode or 'surface')

    def test_status_reports_are_compact(self):
        self.studio.result={'reports':[{'id':'test:a','slug':'a','status':'review','metrics':{'huge':list(range(1000))}}]}
        report=self.studio.status()['result']['reports'][0]
        self.assertEqual(set(report),{'id','slug','status','extended3d','analysis','requires_surface_review'})
        self.assertIs(report['extended3d'],False)
        self.assertNotIn('metrics',report)
