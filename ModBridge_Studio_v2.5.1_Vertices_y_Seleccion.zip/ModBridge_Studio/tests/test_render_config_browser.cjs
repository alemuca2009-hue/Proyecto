/* Real browser -> HTTP -> worker -> PNG -> downloadable ZIP integration.
   Development only: Node, Playwright and Chromium. No mocked render routes. */
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const crypto=require('node:crypto');
const {spawn,spawnSync}=require('node:child_process');
const {chromium}=require('playwright');

(async()=>{
  const root=path.resolve(__dirname,'..');
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'modbridge-renders-browser-'));
  const source=path.join(root,'examples/Demostracion_ModBridge.jar');
  const sourceHash=crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex');
  const server=spawn(process.env.PYTHON||'python3',['-u','app.py','serve','--no-browser','--port','0',
    '--workspace',temp,'--input',source],{cwd:root});
  let browser;
  const checks=[];
  try {
    const origin=await new Promise((resolve,reject)=>{
      let output='';const timer=setTimeout(()=>reject(new Error('Server did not start')),15000);
      server.stdout.on('data',chunk=>{output+=chunk.toString();const match=output.match(/http:\/\/127\.0\.0\.1:\d+/);if(match){clearTimeout(timer);resolve(match[0]);}});
      server.once('exit',code=>{clearTimeout(timer);reject(new Error('Server exited: '+code));});
    });
    browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE||undefined,
      args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
    const page=await browser.newPage({viewport:{width:1440,height:1100},acceptDownloads:true});
    const errors=[];page.on('pageerror',e=>errors.push(e.message));
    const first='demo:block/asimetrico', second='demo:block/fuera_del_bloque';
    const model=id=>page.locator(`#render-models input[data-model-id="${id}"]:not([data-model-profile])`);
    const assigned=(id,p)=>page.locator(`#render-models input[data-model-profile][data-model-id="${id}"][data-profile-id="${p}"]`);
    const metric=async key=>Number((await page.locator(`[data-summary-count="${key}"] strong`).innerText()).replaceAll('.',''));
    const expectMetric=async(key,value)=>{
      await page.waitForFunction(({key,value})=>Number(document.querySelector(`[data-summary-count="${key}"] strong`).textContent.replaceAll('.',''))===value,{key,value});
      assert.equal(await metric(key),value);
    };
    const checkedPlan=()=>page.waitForFunction(()=>document.querySelector('#render-plan-status').textContent==='Configuración comprobada');
    await page.goto(origin);
    await page.waitForFunction(()=>document.querySelectorAll('.model-open').length===6);
    assert.equal(await page.locator('#advanced-options').evaluate(e=>e.open),false);
    await page.locator('#advanced-options summary').click();
    await page.waitForFunction(()=>document.querySelectorAll('#advanced-geometry input').length>0);
    await page.locator('#advanced-options summary').click();
    assert.equal(await page.locator('#advanced-options').evaluate(e=>e.open),false);
    await page.locator(`#model-list input[data-id="${first}"]`).check();
    await page.locator(`#model-list input[data-id="${second}"]`).check();
    await page.locator('#advanced-options summary').click();
    if(process.env.QA_SCREENSHOTS)await page.screenshot({path:path.join(process.env.QA_SCREENSHOTS,'advanced-desktop.png'),fullPage:true});
    await page.locator('#open-render-dialog').click();
    assert.equal(await page.locator('#render-dialog').evaluate(e=>e.open),true);
    assert.equal(await page.locator('#render-models input[data-model-id]:not([data-model-profile])').count(),2);
    await expectMetric('model_count',2);await expectMetric('image_count',2);
    await page.locator('#render-models-none').click();await expectMetric('model_count',0);
    assert.equal(await page.locator('#render-start').isDisabled(),true);
    await page.locator('#render-models-all').click();await expectMetric('model_count',2);
    checks.push('Avanzados starts collapsed and toggles; modal receives exactly main-selected models; all/none works');

    await page.locator('#render-profile-name').fill('Mecánica completa');
    await page.locator('#render-resolution').fill('64');
    await page.locator('#render-views-none').click();await expectMetric('image_count',0);
    await page.locator('#render-views-all').click();await expectMetric('view_count',6);
    await page.locator('#render-modes input[value=wireframe]').check();
    await page.locator('#render-modes input[value=solid]').check();
    await page.locator('#render-three-combinations').check();
    await expectMetric('image_count',108);
    assert.equal(await page.locator('#render-xray').isDisabled(),true);
    assert.equal(await page.locator('#render-normals').isDisabled(),true);
    await page.locator('#render-add-profile').click();
    await page.locator('#render-profile-name').fill('Textura limpia');
    await page.locator('#render-resolution').fill('64');
    await expectMetric('image_count',110);await expectMetric('profile_count',2);
    const profiles=await page.locator('#render-profile-list [data-profile-id]').evaluateAll(nodes=>nodes.map(n=>n.dataset.profileId));
    await page.locator('#render-duplicate-profile').click();await expectMetric('image_count',110);
    assert.match(await page.locator('#render-duplicate-note').innerText(),/^2 imágenes repetidas/);
    await page.locator('#render-remove-profile').click();await expectMetric('profile_count',2);
    await assigned(second,profiles[1]).uncheck();await expectMetric('image_count',109);
    await model(second).uncheck();await expectMetric('image_count',55);
    await model(second).check();await expectMetric('image_count',109);
    await page.locator(`#render-models input[data-master-for="${first}"]`).fill('../Maestra Uno:*?');
    await page.locator(`#render-models input[data-master-for="${second}"]`).fill('Maestra Dos');
    await checkedPlan();
    checks.push('Six views, three independent modes, exactly three parameter combinations; independent profiles; dynamic counts; per-model assignment; deduplication');
    for(const width of [1440,768,390]){
      await page.setViewportSize({width,height:1100});
      const layout=await page.locator('#render-dialog').evaluate(e=>({width:e.getBoundingClientRect().width,scroll:e.scrollWidth,client:e.clientWidth,right:e.getBoundingClientRect().right}));
      assert.ok(layout.right<=width+1,`Modal exceeds viewport at ${width}`);
      assert.ok(layout.scroll<=layout.client+1,`Modal horizontally scrolls at ${width}`);
      if(process.env.QA_SCREENSHOTS)await page.screenshot({path:path.join(process.env.QA_SCREENSHOTS,`render-modal-${width}.png`),fullPage:true});
    }
    await page.setViewportSize({width:1440,height:1100});
    const requestPromise=page.waitForRequest(r=>r.url().endsWith('/api/renders/start')&&r.method()==='POST');
    await page.locator('#render-start').click();
    const sent=(await requestPromise).postDataJSON();
    assert.equal(sent.models.length,2);assert.equal(sent.profiles.length,2);
    assert.equal(sent.models.find(m=>m.id===second).profile_ids.length,1);
    assert.equal(await page.locator('#render-configuration').evaluate(e=>e.disabled),true);
    await page.locator('#render-close').click();
    assert.equal(await page.locator('#convert-button').isDisabled(),true);
    await page.locator('#open-render-dialog').click();
    await page.waitForFunction(()=>!document.querySelector('#render-download').hidden,{},{timeout:60000});
    assert.match(await page.locator('#render-result').innerText(),/109 imágenes/);
    assert.match(await page.locator('#render-current').innerText(),/Modelo:.*Perfil:/);
    const downloadPromise=page.waitForEvent('download');
    await page.locator('#render-download').click();
    const download=await downloadPromise;const archive=path.join(temp,'rendered.zip');await download.saveAs(archive);
    const inspected=spawnSync(process.env.PYTHON||'python3',['-c',
      `import hashlib,io,json,sys,zipfile\nfrom pathlib import PurePosixPath\nfrom PIL import Image\nwith zipfile.ZipFile(sys.argv[1]) as z:\n assert z.testzip() is None\n names=z.namelist();pngs=[p for p in names if p.endswith('.png')]\n assert len(pngs)==109,len(pngs)\n assert len(names)==len(set(p.casefold() for p in names))\n assert all(len(PurePosixPath(p).parts)==5 and p.startswith('RENDERS_EXPORTADOS/') and '..' not in PurePosixPath(p).parts and ' ' not in p for p in pngs)\n assert len({PurePosixPath(p).parts[1] for p in pngs})==2\n pixels=set()\n for name in pngs:\n  with Image.open(io.BytesIO(z.read(name))) as im:\n   assert im.size==(64,64)\n   pixels.add(hashlib.sha256(im.tobytes()).hexdigest())\n assert len(pixels)>12,len(pixels)\n print(json.dumps({'pngs':len(pngs),'unique_pixel_buffers':len(pixels)}))`,archive],{encoding:'utf8'});
    assert.equal(inspected.status,0,inspected.stderr||inspected.stdout);
    checks.push('Actual 109-PNG downloadable ZIP; two maestras/models and independent profiles; valid safe names; real distinct pixels; progress and busy lock');
    await page.locator('#render-views-none').click();
    assert.equal(await page.locator('#render-download').isVisible(),true);
    assert.match(await page.locator('#render-result').innerText(),/última exportación/);
    await page.locator('#render-views-all').click();
    await page.locator('#render-resolution').fill('512');
    await checkedPlan();await page.locator('#render-start').click();
    await page.locator('#render-cancel').click();
    await page.waitForFunction(()=>document.querySelector('#render-result').textContent.includes('Generación detenida'),{},{timeout:15000});
    assert.equal(await page.locator('#render-configuration').evaluate(e=>e.disabled),false);
    checks.push('Existing ZIP stays available after edits; next render can be cancelled without blocking the UI');
    let status=await(await page.request.get(origin+'/api/status?compact=1')).json();
    assert.equal(status.ready_models.length,0);
    await page.locator('#render-close').click();
    await page.locator('#render-size').selectOption('128');
    await page.locator('#convert-button').click();
    await page.waitForFunction(()=>document.querySelector('#job-title').textContent==='Conversión terminada',{},{timeout:30000});
    status=await(await page.request.get(origin+'/api/status?compact=1')).json();
    assert.equal(status.ready_models.length,2);
    const filters=await(await page.request.get(origin+'/api/analysis-filters')).json();
    for(const category of ['geometry','textures']){
      assert.deepEqual(await page.locator(`#advanced-${category} input`).evaluateAll(nodes=>nodes.map(n=>n.value)),
        (filters.filters||filters)[category].map(f=>f.id));
    }
    const count=()=>page.locator('#model-count').innerText();
    await page.locator('#advanced-geometry input[value=unreviewed]').check();
    assert.equal(await count(),'4');
    await page.locator('#advanced-textures input[value=pixels_preserved]').check();
    assert.equal(await count(),'0');
    await page.locator('#advanced-geometry input[value=matching]').check();
    assert.equal(await count(),'2');
    await page.locator('#advanced-geometry input[value=unreviewed]').uncheck();
    assert.equal(await count(),'2');
    await page.locator('#clear-advanced-filters').click();assert.equal(await count(),'6');
    checks.push('Actual conversion still works after export/cancel; existing analysis states match server; geometry OR options and texture AND intersection update results');
    assert.equal(crypto.createHash('sha256').update(fs.readFileSync(source)).digest('hex'),sourceHash);
    assert.deepEqual(errors,[]);
    console.log(JSON.stringify({ok:true,browser:browser.version(),checks,archive:JSON.parse(inspected.stdout)},null,2));
  }finally{
    if(browser)await browser.close();server.kill('SIGINT');
    await new Promise(resolve=>{if(server.exitCode!==null)resolve();else server.once('exit',resolve);});
    fs.rmSync(temp,{recursive:true,force:true});
  }
})().catch(error=>{console.error(error);process.exitCode=1;});
