import hashlib,io,json,tempfile,unittest,zipfile
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from PIL import Image
from bridge.palettes import apply_palette,build_paletted_resources


def png(values):
    im=Image.fromarray(np.array(values,dtype=np.uint8));b=io.BytesIO();im.save(b,format='PNG');return b.getvalue()

class PaletteTests(unittest.TestCase):
    def test_official_alpha_rgb_rules(self):
        source=np.array([[[10,20,30,128],[10,20,30,0],[50,60,70,255],[90,91,92,64]]],dtype=np.uint8)
        keys=np.array([[[10,20,30,15],[50,60,70,0]]],dtype=np.uint8)
        values=np.array([[[200,100,30,64],[0,0,0,255]]],dtype=np.uint8)
        expected=np.array([[[200,100,30,32],[10,20,30,0],[50,60,70,255],[90,91,92,64]]],dtype=np.uint8)
        actual=apply_palette(source,keys,values)
        np.testing.assert_array_equal(actual,expected)
        self.assertEqual(source[0,0,3],128)

    def test_duplicate_rgb_key_last_nontransparent_wins(self):
        source=np.array([[[1,2,3,255]]],dtype=np.uint8)
        keys=np.array([[[1,2,3,255],[1,2,3,2],[1,2,3,0]]],dtype=np.uint8)
        values=np.array([[[10,20,30,255],[40,50,60,128],[99,99,99,255]]],dtype=np.uint8)
        np.testing.assert_array_equal(apply_palette(source,keys,values),[[[40,50,60,128]]])

    def test_palette_lengths_must_match_but_shape_can_differ(self):
        source=np.zeros((1,1,4),dtype=np.uint8)
        with self.assertRaises(ValueError):apply_palette(source,np.zeros((1,2,4),dtype=np.uint8),np.zeros((1,1,4),dtype=np.uint8))
        apply_palette(source,np.zeros((1,2,4),dtype=np.uint8),np.zeros((2,1,4),dtype=np.uint8))

    def test_resource_stacks_merge_and_provenance_is_precise(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);high=root/'mod.zip';low=root/'base.zip'
            key='assets/minecraft/textures/key.png';palette='assets/minecraft/textures/red.png'
            template='assets/demo/textures/shape.png';atlas='assets/minecraft/atlases/blocks.json'
            def rule(texture,suffix):return {'type':'paletted_permutations','palette_key':'minecraft:key','textures':[texture],'permutations':{suffix:'minecraft:red'}}
            low_atlas=json.dumps({'sources':[rule('demo:low','a')]})
            high_atlas=json.dumps({'sources':[rule('demo:shape','b')]})
            with zipfile.ZipFile(low,'w') as z:
                z.writestr(key,png([[[10,20,30,255]]]))
                z.writestr(palette,png([[[200,80,30,128]]]))
                z.writestr('assets/demo/textures/low.png',png([[[10,20,30,255]]]))
                z.writestr(atlas,low_atlas)
            with zipfile.ZipFile(high,'w') as z:
                z.writestr(template,png([[[10,20,30,127]]]))
                z.writestr(atlas,high_atlas)
            sources=[zipfile.ZipFile(high),zipfile.ZipFile(low)]
            index={}
            for i,z in enumerate(sources):
                for p in z.namelist():index.setdefault(p,i)
            pack=SimpleNamespace(_sources=sources,_index=index,paths=[high,low],warnings=[])
            resources,meta=build_paletted_resources(pack)
            self.assertIn('assets/demo/textures/low_a.png',resources)
            name='assets/demo/textures/shape_b.png';self.assertIn(name,resources)
            with Image.open(io.BytesIO(resources[name])) as im:self.assertEqual(im.getpixel((0,0)),(200,80,30,63))
            self.assertEqual(meta[name]['atlas_source_index'],0)
            self.assertEqual(meta['assets/demo/textures/low_a.png']['atlas_source_index'],1)
            self.assertEqual(meta[name]['atlas_sha256'],hashlib.sha256(high_atlas.encode()).hexdigest())
            self.assertEqual(set(meta[name]['dependencies']),{template,key,palette,atlas})
            self.assertFalse(pack.warnings)
            for z in sources:z.close()

    def test_invalid_resource_identifiers_are_not_extracted(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);p=root/'assets/demo/atlases';p.mkdir(parents=True)
            (p/'bad.json').write_text(json.dumps({'sources':[{'type':'paletted_permutations','palette_key':'demo:../../escape','textures':[],'permutations':{}}]}))
            pack=SimpleNamespace(_sources=[root],_index={},paths=[root],warnings=[])
            virtual,_=build_paletted_resources(pack)
            self.assertFalse(virtual);self.assertTrue(pack.warnings)

if __name__=='__main__':unittest.main()
