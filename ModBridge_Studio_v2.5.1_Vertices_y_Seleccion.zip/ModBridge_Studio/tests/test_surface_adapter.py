"""Adapter errors must retain the original diagnostic geometry/atlas pair."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from PIL import Image
from bridge.surface_adapter import adapt_surface


class SurfaceAdapterTests(unittest.TestCase):
    def files(self, root):
        Image.new('RGBA',(16,16),(23,54,85,127)).save(root/'atlas.png')
        (root/'model.geo.json').write_text('{"original_mesh": true}')
        (root/'ir_bedrock.json').write_text(json.dumps({'faces':[],'textures':{'atlas':str(root/'atlas.png')}}))
        (root/'atlas_map.json').write_text('{"original_mapping": true}')
        return {p.name:p.read_bytes() for p in root.iterdir() if p.is_file()}

    def test_conversion_failure_does_not_move_or_replace_original_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);before=self.files(root)
            with patch('bridge.mesh_surface.convert_mesh_surface',side_effect=ValueError('budget')):
                with self.assertRaisesRegex(ValueError,'budget'):
                    adapt_surface({'metrics':{},'paths':{},'warnings':[]},{},root,'test')
            for name,value in before.items():self.assertEqual((root/name).read_bytes(),value)
            self.assertFalse((root/'atlas_original_map.json').exists())

    def test_legacy_sampled_metrics_and_original_backups_are_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);before=self.files(root)
            source={'faces':[{'vertices':[[0,0,0],[4,0,0],[4,4,0],[0,4,0]],
                              'uv':[[0,0],[16,0],[16,16],[0,16]],'texture':'t'}],
                    'textures':{'t':str(root/'atlas.png')}}
            report,target=adapt_surface({'metrics':{},'paths':{},'warnings':[]},source,root,'test')
            self.assertEqual(report['status'],'review')
            self.assertEqual(report['target_kind'],'surface_approximation')
            self.assertFalse(report['metrics']['static_equivalence_passed'])
            self.assertFalse(report['metrics']['rgba_texels_preserved'])
            self.assertEqual((root/'source_mesh_atlas.png').read_bytes(),before['atlas.png'])
            self.assertEqual((root/'experimental.poly_mesh.json').read_bytes(),before['model.geo.json'])
            self.assertEqual((root/'atlas_original_map.json').read_bytes(),before['atlas_map.json'])
            self.assertFalse(json.loads((root/'atlas_map.json').read_text())['lossless_rgba_copy'])
            self.assertEqual(target['textures'],{'atlas':str(root/'atlas.png')})

if __name__=='__main__':unittest.main()
