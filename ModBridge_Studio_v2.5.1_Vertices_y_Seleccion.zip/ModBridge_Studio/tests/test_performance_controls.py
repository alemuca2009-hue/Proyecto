"""Behavioral regressions: bounded resources, cancellation, live views and restart."""
import io, json, tempfile, time, unittest, zipfile
from pathlib import Path
from unittest.mock import patch
import numpy as np
from PIL import Image
from app import Studio
from bridge.control import cancellation, checkpoint, ConversionCancelled
from bridge.resources import ResourcePack
from bridge.rendering import render_view, compare_views
from bridge.pipeline import run_conversion
from bridge.preview import build_preview, MAX_PREVIEW_FACES


def make_workload(path,layers=500):
    texture=io.BytesIO();Image.new('RGBA',(16,16),(95,200,180,90)).save(texture,'PNG')
    faces={side:{'texture':'#all'} for side in ['north','south','up','down','east','west']}
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('assets/test/textures/block/glass.png',texture.getvalue())
        z.writestr('assets/test/models/block/a_small.json',json.dumps({'parent':'minecraft:block/cube_all','textures':{'all':'minecraft:block/stone'}}))
        z.writestr('assets/test/models/block/z_heavy.json',json.dumps({'textures':{'all':'test:block/glass'},'elements':[{'from':[0,0,i*.02],'to':[16,16,i*.02+.01],'faces':faces} for i in range(layers)]}))
    return path


def wait_until(predicate, timeout=12):
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        if predicate():return
        time.sleep(.015)
    raise AssertionError('Timed out waiting for worker state')


class ResponsiveWorkerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.jar=make_workload(self.root/'test.jar')
        self.studio=Studio(self.root/'workspace',java=self.jar)
    def tearDown(self):
        self.studio.cancel();wait_until(lambda:self.studio.worker is None);self.temp.cleanup()

    def test_stop_during_heavy_model_keeps_ready_views_export_and_restart(self):
        self.studio.start({'models':['test:block/a_small','test:block/z_heavy'],'render_size':256})
        wait_until(lambda:'test:block/a_small' in self.studio.status()['ready_models'][0]['id'] if self.studio.status()['ready_models'] else False)
        self.assertEqual(self.studio.job['state'],'running')
        light=self.studio.model('test:block/a_small')
        self.assertNotIn('original_ir',light)  # Six-view mode never downloads entire meshes.
        modeldir=self.studio.run/'models'/light['report']['slug']
        for view in ['superior','frontal','inferior','trasera','izquierda','derecha']:
            for kind in ['original','traducido','diferencia']:
                with Image.open(modeldir/'vistas'/view/(kind+'.png')) as im:self.assertEqual(im.size,(256,256))
        process=self.studio.worker
        start=time.monotonic();self.studio.cancel();wait_until(lambda:self.studio.worker is None,2)
        self.assertLess(time.monotonic()-start,2)
        self.assertIsNotNone(process.poll());self.assertEqual(self.studio.job['state'],'cancelled')
        self.assertFalse((self.studio.run/'resultado.zip').exists())
        self.assertIsNone(self.studio.result)
        self.assertGreater(len(self.studio.model('test:block/a_small',True)['original_ir']['faces']),0)
        # Inspecting another model must not change the original batch's planned total.
        self.studio.start({'models':['test:block/a_small'],'render_size':64},operation='preview')
        wait_until(lambda:self.studio.worker is None)
        self.assertTrue(self.studio.status()['can_export_partial'])
        self.studio.start({},operation='export');wait_until(lambda:self.studio.worker is None)
        self.assertEqual(self.studio.job['state'],'done',self.studio.job)
        self.assertTrue(self.studio.result['summary']['cancelled'])
        self.assertEqual(self.studio.result['summary']['total'],1)
        with zipfile.ZipFile(self.studio.result['archive']) as z:
            self.assertIsNone(z.testzip());self.assertIn('ABRIR_COMPARACION.html',z.namelist())
        self.studio.start({'models':['test:block/a_small'],'render_size':64})
        wait_until(lambda:self.studio.worker is None)
        self.assertEqual(self.studio.job['state'],'done',self.studio.job)
        self.assertEqual(self.studio.result['summary']['total'],1)

    def test_single_preview_does_not_export_and_compact_status_omits_catalogue(self):
        self.studio.start({'models':['test:block/a_small'],'render_size':64},operation='preview')
        wait_until(lambda:self.studio.worker is None)
        self.assertEqual(self.studio.job['state'],'done',self.studio.job)
        self.assertIsNone(self.studio.result);self.assertIsNone(self.studio.run)
        self.assertEqual(len(self.studio.status()['ready_models']),1)
        self.assertNotIn('models',self.studio.status(compact=True)['project'])
        self.assertFalse(list(self.studio.workrun.glob('*.zip')))
        self.assertEqual(self.studio.model('test:block/a_small',True)['original_ir']['face_count'],6)

    def test_immediate_cancel_and_input_lock(self):
        self.studio.start({'models':['test:block/z_heavy']})
        with self.assertRaises(ValueError):self.studio.replace_input('java',self.jar)
        self.studio.cancel();wait_until(lambda:self.studio.worker is None,2)
        self.assertEqual(self.studio.job['state'],'cancelled')
        self.assertFalse(self.studio.status()['can_export_partial'])


class BoundedMemoryTests(unittest.TestCase):
    def test_transparency_budget_preserves_every_pixel_and_layer(self):
        tex=np.array([[[200,30,40,80],[20,210,200,255]],[[50,200,120,0],[0,0,255,180]]],dtype=np.uint8)
        faces=[{'vertices':[[-8,0,i*.01],[8,0,i*.01],[8,16,i*.01],[-8,16,i*.01]],'uv':[[0,0],[2,0],[2,2],[0,2]],'texture':'a'} for i in range(12)]
        ir={'faces':faces,'textures':{'a':tex}}
        # Large region and tightly bounded tiles must give identical order and RGBA.
        with patch('bridge.rendering.TRANSPARENCY_FRAGMENT_BUDGET',10**8):whole=np.asarray(render_view(ir,'frontal',64))
        stats={}
        with patch('bridge.rendering.TRANSPARENCY_FRAGMENT_BUDGET',500):tiled=np.asarray(render_view(ir,'frontal',64,_stats=stats))
        np.testing.assert_array_equal(whole,tiled)
        self.assertLessEqual(stats['peak_transparent_fragments'],500);self.assertGreater(stats['tiles'],1)

    def test_resource_lru_is_bounded_and_eviction_preserves_data(self):
        with tempfile.TemporaryDirectory() as td:
            jar=Path(td)/'models.jar'
            with zipfile.ZipFile(jar,'w') as z:
                for i in range(300):z.writestr(f'assets/test/models/{i}.json',json.dumps({'value':i,'data':'x'*1000}))
            with ResourcePack(jar) as pack:
                for i in range(300):self.assertEqual(pack.read_json(f'assets/test/models/{i}.json')['value'],i)
                self.assertLessEqual(len(pack._json_cache),pack.json_cache_entries)
                self.assertLessEqual(pack._json_cache_bytes,pack.json_cache_limit)
                self.assertEqual(pack.read_json('assets/test/models/0.json')['value'],0)

    def test_texture_decode_is_reused_for_geometry_validation(self):
        from bridge import rendering
        tex=np.full((2,2,4),255,dtype=np.uint8)
        ir={'faces':[{'vertices':[[0,0,0],[1,0,0],[1,1,0],[0,1,0]],'uv':[[0,0],[2,0],[2,2],[0,2]],'texture':'a'}],'textures':{'a':tex}}
        with tempfile.TemporaryDirectory() as td,patch('bridge.rendering._load_textures',wraps=rendering._load_textures) as load:
            result=compare_views(ir,ir,td,size=64)
            self.assertEqual(load.call_count,2);self.assertTrue(result['all_views_pixel_identical'])

    def test_cooperative_cancellation_propagates_and_does_not_write_zip(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);jar=make_workload(root/'input.jar',1)
            stopped=[False]
            def progress(_):stopped[0]=True
            with self.assertRaises(ConversionCancelled):
                run_conversion(jar,root/'out',size=64,cancel=lambda:stopped[0],progress=progress)
            self.assertFalse((root/'out'/'resultado.zip').exists())
        with cancellation(lambda:True):
            with self.assertRaises(ConversionCancelled):checkpoint()
        checkpoint()  # Context reset, next conversion not poisoned.

    def test_surface_budget_is_visible_without_dropping_faces(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)
            faces=[{'vertices':[[i,0,0],[i+1,0,0],[i+1,1,0],[i,1,0]]} for i in range(12000)]
            (path/'ir_bedrock.json').write_text(json.dumps({'faces':faces}))
            result=build_preview(path)['bedrock_ir']
            self.assertFalse(result['preview_simplified'])
            self.assertEqual(len(result['faces']),len(faces))
            self.assertEqual(result['faces'][-1]['vertices'],faces[-1]['vertices'])

    def test_browser_preview_is_bounded_and_leaves_source_untouched(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td);faces=[{'vertices':[[0,0,0],[1,0,0],[1,1,0],[0,1,0]]} for _ in range(MAX_PREVIEW_FACES+1)]
            original=json.dumps({'faces':faces});(path/'ir_original.json').write_text(original)
            result=build_preview(path)
            self.assertTrue(result['original_ir']['preview_simplified'])
            self.assertLessEqual(len(result['original_ir']['faces']),MAX_PREVIEW_FACES)
            self.assertEqual(result['original_ir']['face_count'],MAX_PREVIEW_FACES+1)
            self.assertEqual((path/'ir_original.json').read_text(),original)

if __name__=='__main__':unittest.main()
