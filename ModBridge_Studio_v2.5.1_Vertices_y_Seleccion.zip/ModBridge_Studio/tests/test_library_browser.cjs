/* Real HTTP/worker integration plus deterministic UI edge cases.
   Development only: Node, Playwright and Chromium (CHROMIUM_EXECUTABLE optional). */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {spawn} = require('node:child_process');
const {chromium} = require('playwright');
const library = require('../web/library.js');

(async () => {
  const root=path.resolve(__dirname,'..');
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'modbridge-library-'));
  const server=spawn(process.env.PYTHON || 'python3',['-u','app.py','serve','--no-browser','--port','0',
    '--workspace',temp,'--input','examples/Demostracion_ModBridge.jar'],{cwd:root});
  let browser;
  const checks=[];
  try {
    const origin=await new Promise((resolve,reject)=>{
      let output='';const timer=setTimeout(()=>reject(new Error('Server did not start')),15000);
      server.stdout.on('data',data=>{output+=data.toString();const m=output.match(/http:\/\/127\.0\.0\.1:\d+/);if(m){clearTimeout(timer);resolve(m[0]);}});
      server.once('exit',code=>{clearTimeout(timer);reject(new Error('Server exited: '+code));});
    });
    browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE || undefined,
      args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
    const page=await browser.newPage({viewport:{width:1440,height:1100}});
    const errors=[];page.on('pageerror',error=>errors.push(error.message));
    const rowIds=()=>page.locator('.model-open').evaluateAll(rows=>rows.map(row=>row.dataset.id));
    const count=()=>page.locator('#model-count').innerText();
    const done=()=>page.waitForFunction(()=>document.querySelector('#job-title').textContent==='Conversión terminada',{},{timeout:30000});
    await page.goto(origin);await page.waitForFunction(()=>document.querySelectorAll('.model-open').length===6);
    assert.equal(await page.locator('[data-result-group]').count(),4);
    assert.equal(await page.locator('[data-result-group]:disabled').count(),4);
    assert.equal(await page.locator('#extended3d-filter').isDisabled(),true);
    assert.equal(await page.locator('#sort-models-az').isEnabled(),true);
    const initial=await rowIds();await page.locator('#sort-models-az').check();
    assert.deepEqual(await rowIds(),library.visibleModels(initial.map(id=>({id})),[],{sortAZ:true}).map(m=>m.id));
    await page.locator('#sort-models-az').uncheck();assert.deepEqual(await rowIds(),initial);
    checks.push('Four filters disabled before results; A-Z available before conversion');

    await page.locator('#render-size').selectOption('128');
    await page.locator('#convert-button').click();await done();
    const status=await (await page.request.get(origin+'/api/status?compact=1')).json();
    assert.equal(status.ready_models.length,6);
    assert.ok(status.ready_models.every(r=>typeof r.extended3d==='boolean'));
    const byId=new Map(status.ready_models.map(r=>[r.id,r]));
    assert.equal(byId.get('demo:block/fuera_del_bloque').extended3d,true);
    assert.equal(byId.get('demo:block/fuera_del_bloque').status,'verified_static');
    assert.equal(byId.get('demo:block/asimetrico').extended3d,false);
    // Real worker result: a formerly reviewed extended model moves to green,
    // remains available under the size filter, and exposes the matching cards.
    await page.locator('[data-result-group=verified]').click();
    await page.locator('#extended3d-filter').check();
    assert.deepEqual(await rowIds(),['demo:block/fuera_del_bloque']);
    await page.locator('.model-open[data-id="demo:block/fuera_del_bloque"]').click();
    await page.waitForFunction(()=>document.querySelector('#metric-geometry').textContent==='Coincidente'
      && document.querySelector('#metric-textures').textContent==='Píxeles conservados');
    await page.locator('[data-result-group=review]').click();
    assert.deepEqual(await rowIds(),[]);
    await page.locator('#extended3d-filter').uncheck();
    await page.locator('#clear-color-filter').click();
    checks.push('Extended matching model automatically verified; metric cards agree; absent from Review');
    for(const group of ['verified','review','failed','template']) {
      await page.locator(`[data-result-group=${group}]`).click();
      const expected=status.ready_models.filter(r=>library.resultGroup(r)===group).map(r=>r.id).sort();
      assert.deepEqual((await rowIds()).sort(),expected);
      assert.equal(Number(await count()),expected.length);
      assert.equal(await page.locator('[data-result-group][aria-pressed=true]').count(),1);
    }
    await page.locator('#clear-color-filter').click();assert.equal(Number(await count()),6);
    await page.locator('[data-result-group=review]').click();await page.locator('[data-result-group=review]').click();
    assert.equal(Number(await count()),6);
    checks.push('Real conversion through browser, worker and compact API; exclusive colors and counters');

    await page.locator('#extended3d-filter').check();
    assert.ok((await rowIds()).every(id=>byId.get(id).extended3d));
    await page.locator('#model-search').fill('FUERA_DEL_BLOQUE');assert.equal(Number(await count()),1);
    await page.locator('#select-all').check();await page.locator('#extended3d-filter').uncheck();
    await page.locator('#model-search').fill('asimetrico');
    assert.match(await page.locator('#selected-count').innerText(),/1 ocultos/);
    const selectedRequest=page.waitForRequest(r=>r.url().endsWith('/api/convert') && r.method()==='POST');
    await page.locator('#convert-button').click();
    assert.deepEqual((await selectedRequest).postDataJSON().models,['demo:block/fuera_del_bloque']);await done();
    checks.push('Extended + search intersection; hidden explicit selections preserved');

    await page.locator('#model-search').fill('');
    await page.locator('input[data-id="demo:block/fuera_del_bloque"]').uncheck();
    await page.locator('#extended3d-filter').check();
    const filteredRequest=page.waitForRequest(r=>r.url().endsWith('/api/convert') && r.method()==='POST');
    await page.locator('#convert-button').click();
    const payload=(await filteredRequest).postDataJSON();
    assert.deepEqual(payload.models,['demo:block/fuera_del_bloque']);assert.equal(payload.filter,'');await done();
    await page.locator('[data-result-group=review]').click();
    assert.equal(Number(await count()),0);assert.equal(await page.locator('#convert-button').isDisabled(),true);
    await page.locator('#file-java').setInputFiles(path.join(root,'examples/Demostracion_ModBridge.jar'));
    await page.waitForFunction(()=>document.querySelectorAll('[data-result-group]:disabled').length===4);
    assert.equal(Number(await count()),6);assert.equal(await page.locator('#extended3d-filter').isChecked(),false);
    checks.push('Filtered conversion submits exact IDs; empty lists cannot launch all models; input change resets result filters');

    // Populate all four categories and more than two pages without rendering 245 fixtures.
    const models=Array.from({length:245},(_,i)=>({id:`fixture:block/model_${String(244-i).padStart(3,'0')}`}));
    const states=['verified_static','review','unsupported','error','no_renderable'];
    const reports=models.map((m,i)=>({...m,slug:`fixture_${i}`,status:states[i%5],extended3d:i%3===0}));
    const snapshot={project:{name:'catalogue.jar',revision:100,models},job:{state:'running',progress:200,total:245},
      result:{reports:reports.slice(0,120)},ready_models:reports.slice(120),can_export_partial:true};
    await page.route('**/api/status?compact=1',route=>route.fulfill({json:{...snapshot,project:{name:snapshot.project.name,revision:snapshot.project.revision}}}));
    await page.route('**/api/inventory',route=>route.fulfill({json:snapshot.project}));
    await page.route('**/api/model?*',route=>{
      const id=new URL(route.request().url()).searchParams.get('id');
      return route.fulfill({json:{report:reports.find(r=>r.id===id)}});
    });
    await page.reload();await page.waitForFunction(()=>document.querySelector('#model-count').textContent==='245');
    assert.equal((await rowIds()).length,100);await page.locator('#page-next').click();await page.locator('#page-next').click();
    assert.equal((await rowIds()).length,45);
    await page.locator('[data-result-group=template]').click();
    assert.equal(Number(await count()),49);assert.match(await page.locator('#page-info').innerText(),/^1 \/ 1/);
    assert.ok((await rowIds()).every(id=>reports.find(r=>r.id===id).status==='no_renderable'));
    await page.locator('[data-result-group=failed]').click();assert.equal(Number(await count()),98);
    await page.locator('#clear-color-filter').click();await page.locator('#extended3d-filter').check();
    const previousCount=Number(await count());reports[0].extended3d=false;
    await page.waitForFunction(expected=>Number(document.querySelector('#model-count').textContent)===expected,previousCount-1);
    checks.push('All four groups; 245-model pagination; counter and same-count flag updates; compact report merging');

    snapshot.job.state='done';await page.waitForFunction(()=>document.querySelector('#convert-button').disabled===false);
    for(const width of [1440,1120,900,768,660,520,390,360]) {
      await page.setViewportSize({width,height:1100});
      const layout=await page.evaluate(()=>{
        const selectors=['.result-filters','.library-options','#library-filter-help','#library-result-count','.list-tools'];
        const boxes=selectors.map(s=>document.querySelector(s).getBoundingClientRect());
        return {overflow:document.documentElement.scrollWidth>innerWidth+1,
          intersect:boxes.some((a,i)=>boxes.slice(i+1).some(b=>Math.min(a.right,b.right)-Math.max(a.left,b.left)>1 && Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top)>1))};
      });
      assert.equal(layout.overflow,false,`Horizontal overflow at ${width}`);
      assert.equal(layout.intersect,false,`Overlapping filters at ${width}`);
      if(process.env.QA_SCREENSHOTS && [1440,390].includes(width))
        await page.screenshot({path:path.join(process.env.QA_SCREENSHOTS,`library-${width}.png`),fullPage:true});
    }
    checks.push('No overlaps or horizontal overflow at eight viewport widths');
    assert.deepEqual(errors,[]);
    console.log(JSON.stringify({ok:true,checks},null,2));
  } finally {
    if(browser)await browser.close();server.kill('SIGINT');
    await new Promise(resolve=>{if(server.exitCode!==null)resolve();else server.once('exit',resolve);});
    fs.rmSync(temp,{recursive:true,force:true});
  }
})().catch(error=>{console.error(error);process.exitCode=1;});
