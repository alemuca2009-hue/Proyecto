"""Regression contracts for size flags across real worker and export boundaries."""
import copy
import json
import subprocess
import sys
import tempfile
import time
import unittest
import zipfile
from pathlib import Path

from app import Studio
from bridge import __version__
from bridge.catalog import compact_report, is_extended3d
from bridge.model_profile import size_profile
from bridge.pipeline import export_result, run_conversion
from bridge.resources import asset_path
from test_pipeline import make_fixture


ROOT = Path(__file__).resolve().parents[1]
NORMAL = 'fixture:block/sample'
LARGE = 'fixture:block/large'


def wait_worker(studio):
    deadline = time.monotonic() + 20
    while studio.worker is not None and time.monotonic() < deadline:
        time.sleep(.015)
    if studio.worker is not None:
        studio.cancel()
        raise AssertionError('Worker did not finish')


class CatalogueTests(unittest.TestCase):
    def test_extended_size_and_position_are_separate_from_conversion_status(self):
        cases = [([[-8,0,-8],[8,16,8]],False),
                 ([[-15,0,-15],[15,30,15]],False),
                 ([[-16,0,-16],[16,16,16]],True),
                 ([[31,0,0],[32,1,1]],True),
                 ([[-8,0,-8],[8,0,8]],False)]
        for bounds,expected in cases:
            for side in ('source','target'):
                for status in ('verified_static','review','unsupported'):
                    with self.subTest(bounds=bounds,side=side,status=status):
                        report={'status':status,'model_profile':{side:size_profile(bounds)}}
                        self.assertIs(is_extended3d(report),expected)

    def test_missing_or_invalid_measurements_do_not_mark_extended(self):
        for profile in ({},None,[],{'source':{'valid':False,'reasons':['extent_over_30']}},
                        {'source':size_profile([[0,0,0],[float('nan'),16,16]])}):
            self.assertIs(is_extended3d({'model_profile':profile}),False)

    def test_compact_report_keeps_small_facets_and_real_booleans(self):
        for value in (True,False):
            report={'id':'fixture:a','slug':'a','status':'review','extended3d':value,
                    'metrics':{'large':list(range(1000))},'run':'private/path'}
            compact=compact_report(report)
            self.assertEqual(set(compact),{'id','slug','status','extended3d','analysis','requires_surface_review'})
            self.assertIs(compact['extended3d'],value)
            self.assertEqual(compact_report(compact),compact)
        self.assertIs(compact_report({'extended3d':'false'})['extended3d'],False)

    def test_compaction_recovers_size_from_legacy_full_report(self):
        report={'id':'fixture:a','slug':'a','status':'review',
                'model_profile':{'source':size_profile([[-39,0,-39],[39,19,39]])}}
        before=copy.deepcopy(report)
        self.assertIs(compact_report(report)['extended3d'],True)
        self.assertEqual(report,before)


class WorkerCatalogueTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.jar=self.root/'fixture.jar';make_fixture(self.jar)
        faces={d:{'texture':'#all','uv':[0,0,16,16]} for d in ('north','south','east','west','up','down')}
        model={'textures':{'all':'fixture:block/asymmetric'},'elements':[
            {'from':[-31,-1.5,-31],'to':[47,17.5,47],'faces':faces}]}
        with zipfile.ZipFile(self.jar,'a') as z:z.writestr(asset_path(LARGE),json.dumps(model))
        self.studio=Studio(self.root/'workspace',java=self.jar)

    def tearDown(self):
        self.studio.cancel();wait_worker(self.studio);self.temp.cleanup()

    def assert_catalogue(self,reports):
        by_id={r['id']:r for r in reports}
        self.assertEqual(set(by_id),{NORMAL,LARGE})
        for mid,expected in ((NORMAL,False),(LARGE,True)):
            self.assertIs(by_id[mid]['extended3d'],expected)
            self.assertEqual(by_id[mid]['status'],'verified_static')
            self.assertEqual(set(by_id[mid]),{'id','slug','status','extended3d','analysis','requires_surface_review'})

    def test_worker_to_application_full_compact_and_partial_exports(self):
        self.studio.start({'models':[NORMAL,LARGE],'render_size':64})
        wait_worker(self.studio)
        self.assertEqual(self.studio.job['state'],'done',self.studio.job)
        run=self.studio.run
        completion=json.loads((run/'completion.json').read_text())
        self.assert_catalogue(completion['result']['reports'])
        self.assert_catalogue([json.loads(line) for line in (run/'ready.ndjson').read_text().splitlines()])
        self.assert_catalogue([json.loads(p.read_text()) for p in (run/'models').glob('*/ready.json')])
        for compact in (False,True):
            status=self.studio.status(compact=compact)
            self.assert_catalogue(status['ready_models'])
            self.assert_catalogue(status['result']['reports'])
            self.assertEqual('models' in status['project'],not compact)
        for mid,expected in ((NORMAL,False),(LARGE,True)):
            self.assertIs(self.studio.model(mid)['report']['extended3d'],expected)
        for report in json.loads((run/'result.json').read_text())['reports']:
            self.assertIs(report['extended3d'],report['id']==LARGE)
        self.studio.start({},operation='export');wait_worker(self.studio)
        self.assertEqual(self.studio.job['state'],'done',self.studio.job)
        self.assert_catalogue(self.studio.status(compact=True)['result']['reports'])
        with zipfile.ZipFile(self.studio.result['archive']) as z:
            self.assertIsNone(z.testzip())
            self.assertEqual(json.loads(z.read('reportes/resumen.json'))['version'],'2.5.1')
            for name in z.namelist():
                if name.startswith('reportes/modelos/') and name.endswith('.json'):
                    report=json.loads(z.read(name));self.assertIs(report['extended3d'],report['id']==LARGE)
                if name.endswith('/model.geo.json'):
                    self.assertEqual(json.loads(z.read(name))['format_version'],'1.21.0')

    def test_individual_preview_retains_extended_flag_without_export(self):
        self.studio.start({'models':[LARGE],'render_size':64},operation='preview');wait_worker(self.studio)
        self.assertEqual(self.studio.job['state'],'done',self.studio.job)
        self.assertIs(self.studio.status(compact=True)['ready_models'][0]['extended3d'],True)
        self.assertEqual(self.studio.status(compact=True)['ready_models'][0]['status'],'verified_static')
        self.assertEqual(self.studio.model(LARGE)['report']['status'],'verified_static')
        self.assertIsNone(self.studio.result)
        self.assertFalse(list(self.studio.workrun.glob('*.zip')))

    def test_legacy_reexport_adds_flag_without_changing_model_or_source_report(self):
        run=self.root/'legacy';result=run_conversion(self.jar,run,models=[LARGE],size=64)
        report=copy.deepcopy(result['reports'][0]);report.pop('extended3d')
        geometry=run/'models'/report['slug']/'model.geo.json';before=geometry.read_bytes()
        exported=export_result(run,[report],{},planned_total=2,export_name='exportacion_parcial')
        self.assertIs(exported['reports'][0]['extended3d'],True)
        self.assertNotIn('extended3d',report)
        self.assertEqual(geometry.read_bytes(),before)
        self.assertTrue(exported['summary']['cancelled'])

    def test_existing_cli_arguments_and_geometry_format_stay_supported(self):
        self.assertEqual(__version__,'2.5.1')
        for mode in ('surface','exact'):
            output=self.root/('cli_'+mode)
            process=subprocess.run([sys.executable,'app.py','convert','--input',str(self.jar),
                '--output',str(output),'--model',LARGE,'--filter','large','--size','64',
                '--mesh-mode',mode,'--dependency',str(self.jar)],cwd=ROOT,capture_output=True,text=True,timeout=20)
            self.assertEqual(process.returncode,0,process.stderr)
            result=json.loads((output/'result.json').read_text())
            self.assertEqual(result['summary']['version'],'2.5.1')
            self.assertIs(result['reports'][0]['extended3d'],True)
            self.assertEqual(result['reports'][0]['status'],'verified_static')


if __name__=='__main__':unittest.main()
