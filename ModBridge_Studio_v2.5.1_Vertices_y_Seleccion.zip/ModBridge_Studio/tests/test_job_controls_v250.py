import hashlib
import http.client
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
import zipfile
from app import Studio,make_handler
from bridge.pack import write_json
from test_pipeline import make_fixture


class JobControlTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.jar=self.root/'fixture.jar';make_fixture(self.jar)
        self.studio=Studio(self.root/'workspace',java=self.jar)
        self.models=['fixture:block/base','fixture:block/sample']

    def tearDown(self):
        self.studio.cancel();self.studio.render_jobs.cancel()
        end=time.monotonic()+5
        while self.studio.worker is not None and time.monotonic()<end:time.sleep(.02)
        self.temp.cleanup()

    def wait(self,condition,timeout=20):
        end=time.monotonic()+timeout
        while not condition() and time.monotonic()<end:time.sleep(.02)
        self.assertTrue(condition(),self.studio.status()['job'])

    def start(self,operation='convert',models=None):
        self.studio.start({'models':models or self.models,'render_size':64,'mesh_mode':'surface','filter':'ignored' if operation=='restart' else ''},operation)

    def test_pause_really_stops_progress_and_resume_finishes_same_worker(self):
        self.start();process=self.studio.worker;run=self.studio.workrun
        self.studio.pause();self.wait(lambda:self.studio.job['state']=='paused')
        snapshot=(self.studio.job['progress'],self.studio.batch_completed)
        time.sleep(.25)
        self.assertEqual((self.studio.job['progress'],self.studio.batch_completed),snapshot)
        self.assertIs(self.studio.worker,process);self.assertIsNone(process.poll())
        with self.assertRaises(ValueError):self.studio.replace_input('java',self.jar)
        with self.assertRaises(ValueError):self.start('restart',[self.models[0]])
        self.studio.pause(False);self.wait(lambda:self.studio.worker is None)
        self.assertEqual(self.studio.job['state'],'done');self.assertEqual(self.studio.run,run)
        self.assertEqual(set(self.studio.ready),set(self.models))
        with zipfile.ZipFile(self.studio.result['archive']) as z:self.assertIsNone(z.testzip())

    def test_cancel_from_pause_releases_worker_and_allows_next_job(self):
        self.start();self.studio.pause();self.wait(lambda:self.studio.job['state']=='paused')
        self.studio.cancel();self.wait(lambda:self.studio.worker is None)
        self.assertEqual(self.studio.job['state'],'cancelled')
        self.start();self.wait(lambda:self.studio.worker is None)
        self.assertEqual(self.studio.job['state'],'done')

    def test_restart_reconverts_only_selected_and_preserves_other_models_and_source(self):
        before=hashlib.sha256(self.jar.read_bytes()).hexdigest()
        self.start();self.wait(lambda:self.studio.worker is None)
        old_run=self.studio.run;kept=self.models[1]
        for mid in self.models:
            md=Path(self.studio.ready[mid]['run'])/'models'/self.studio.ready[mid]['slug']
            report=json.loads((md/'report.json').read_text());report['retention_test_marker']=mid
            write_json(md/'report.json',report)
        old_md=old_run/'models'/self.studio.ready[kept]['slug']
        old_bytes={n:(old_md/n).read_bytes() for n in ('atlas.png','model.geo.json')}
        self.start('restart',[self.models[0]]);run=self.studio.workrun
        self.assertTrue(self.studio.status()['result_is_previous'])
        config=json.loads((run/'config.json').read_text())
        self.assertEqual(config['models'],[self.models[0]]);self.assertEqual(config['filter'],'')
        self.assertEqual(set(config['retained_models']),{kept})
        self.wait(lambda:self.studio.worker is None)
        self.assertEqual(self.studio.job['state'],'done');self.assertEqual(set(self.studio.ready),set(self.models))
        self.assertFalse(self.studio.status()['result_is_previous'])
        new=self.studio.model(self.models[0],geometry=True)['report']
        retained=self.studio.model(kept,geometry=True)['report']
        self.assertNotIn('retention_test_marker',new);self.assertEqual(retained['retention_test_marker'],kept)
        new_md=run/'models'/self.studio.ready[kept]['slug']
        for n,value in old_bytes.items():
            self.assertEqual((new_md/n).read_bytes(),value);self.assertEqual((old_md/n).read_bytes(),value)
        self.assertEqual(hashlib.sha256(self.jar.read_bytes()).hexdigest(),before)
        with zipfile.ZipFile(self.studio.result['archive']) as z:
            summary=json.loads(z.read('reportes/resumen.json'))
            self.assertEqual(summary['total'],2);self.assertFalse(summary['cancelled'])

    def test_previous_zip_label_survives_preview_or_partial_export_attempt(self):
        self.start();self.wait(lambda:self.studio.worker is None)
        old_run=self.studio.run
        self.studio.run=self.root/'next_run'
        for operation in ('restart','preview','export'):
            self.studio.operation=operation
            self.studio.job['state']='cancelled'
            self.assertTrue(self.studio.status()['result_is_previous'])
        self.studio.run=old_run
        self.assertFalse(self.studio.status()['result_is_previous'])

    def test_empty_invalid_duplicate_restart_is_rejected_before_writing(self):
        for models in (None,[],['missing:block/x'],[self.models[0]]*2,[{}]):
            with self.subTest(models=models):
                with self.assertRaises(ValueError):self.studio.start({'models':models},'restart')
                self.assertIsNone(self.studio.worker);self.assertIsNone(self.studio.run)
        self.assertFalse((self.studio.workspace/'runs').exists())
        with self.assertRaisesRegex(ValueError,'Ocupas seleccionar modelos'):
            self.studio.start({'models':[]},'restart')

    def test_selected_only_conversion_rejects_empty_and_converts_only_explicit_ids(self):
        for models in (None,[],['missing:block/x'],[self.models[0]]*2):
            with self.assertRaises(ValueError):
                self.studio.start({'models':models,'selection_only':True})
        self.assertFalse((self.studio.workspace/'runs').exists())
        self.studio.start({'models':[self.models[1]],'selection_only':True,'render_size':64})
        self.wait(lambda:self.studio.worker is None)
        self.assertEqual(self.studio.job['state'],'done')
        self.assertEqual(set(self.studio.ready),{self.models[1]})
        self.assertEqual(self.studio.result['summary']['total'],1)

    def test_selected_only_endpoint_cannot_disable_required_selection(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.studio))
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            for data in ({},{'models':[],'selection_only':False},{'models':['missing:block/x']},[]):
                connection=http.client.HTTPConnection('127.0.0.1',server.server_port)
                connection.request('POST','/api/convert-selected',body=json.dumps(data),headers={'Content-Type':'application/json','X-Bridge-Token':self.studio.token})
                response=connection.getresponse();self.assertEqual(response.status,400)
                response.read();connection.close()
            self.assertIsNone(self.studio.worker)
            self.assertFalse((self.studio.workspace/'runs').exists())
        finally:server.shutdown();server.server_close();thread.join()

    def test_new_endpoints_require_token_and_report_selection_error(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.studio))
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            for route in ('pause','resume','restart','convert-selected'):
                connection=http.client.HTTPConnection('127.0.0.1',server.server_port)
                connection.request('POST','/api/'+route,body='{}',headers={'Content-Type':'application/json'})
                response=connection.getresponse();self.assertEqual(response.status,403);response.read();connection.close()
            connection=http.client.HTTPConnection('127.0.0.1',server.server_port)
            connection.request('POST','/api/restart',body='{"models":[]}',headers={'Content-Type':'application/json','X-Bridge-Token':self.studio.token})
            response=connection.getresponse();self.assertEqual(response.status,400)
            self.assertIn('Ocupas seleccionar modelos',json.loads(response.read())['error']);connection.close()
        finally:server.shutdown();server.server_close();thread.join()


if __name__=='__main__':unittest.main()
