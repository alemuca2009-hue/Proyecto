"""Pixel-level regressions for real profile renders, independently of the UI."""
import copy
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
from PIL import Image

from bridge.render_modes import ProfileRenderer, render_profile_view, FRONT_COLOR, BACK_COLOR
from bridge.rendering import VIEWS, render_view
from bridge.control import cancellation, ConversionCancelled


def plane(z, radius=2, texture='red', reverse=False):
    vertices=[[-radius,-radius,z],[-radius,radius,z],[radius,radius,z],[radius,-radius,z]]
    if reverse:vertices.reverse()
    return {'vertices':vertices,'uv':[[0,0],[0,1],[1,1],[1,0]],'texture':texture}


def layer_model():
    return {'faces':[plane(0),plane(1,1,'blue',True)],
            'textures':{'red':np.array([[[255,0,0,255]]],dtype=np.uint8),
                        'blue':np.array([[[0,0,255,255]]],dtype=np.uint8)}}


def colored_cube():
    points={
        'frontal':[[-1,-1,-1],[-1,1,-1],[1,1,-1],[1,-1,-1]],
        'trasera':[[1,-1,1],[1,1,1],[-1,1,1],[-1,-1,1]],
        'izquierda':[[-1,-1,1],[-1,1,1],[-1,1,-1],[-1,-1,-1]],
        'derecha':[[1,-1,-1],[1,1,-1],[1,1,1],[1,-1,1]],
        'superior':[[-1,1,-1],[-1,1,1],[1,1,1],[1,1,-1]],
        'inferior':[[-1,-1,1],[-1,-1,-1],[1,-1,-1],[1,-1,1]],
    }
    colors={'frontal':(255,0,0),'trasera':(0,0,255),'izquierda':(0,255,0),
            'derecha':(255,255,0),'superior':(255,0,255),'inferior':(0,255,255)}
    return {'faces':[{'vertices':v,'uv':[[0,0],[0,1],[1,1],[1,0]],'texture':name} for name,v in points.items()],
            'textures':{name:np.array([[list(rgb)+[255]]],dtype=np.uint8) for name,rgb in colors.items()}},colors


class ProfileRenderTests(unittest.TestCase):
    def test_texture_profile_is_identical_to_existing_six_view_renderer(self):
        ir,_=colored_cube()
        for view in VIEWS:
            np.testing.assert_array_equal(np.asarray(render_view(ir,view,128)),
                                          np.asarray(render_profile_view(ir,view,128)))

    def test_all_six_perspectives_face_the_correct_world_direction(self):
        ir,colors=colored_cube()
        renderer=ProfileRenderer(ir)
        for view,rgb in colors.items():
            self.assertEqual(tuple(np.asarray(renderer.render(view,128))[64,64]),tuple(rgb)+(255,),view)

    def test_three_modes_produce_distinct_geometry_images(self):
        ir=layer_model()
        images={mode:np.asarray(render_profile_view(ir,'frontal',128,mode=mode))
                for mode in ('wireframe','solid','texture')}
        self.assertTrue(all(np.any(a[:,:,3]) for a in images.values()))
        self.assertFalse(np.array_equal(images['solid'],images['texture']))
        self.assertEqual(images['wireframe'][64,64,3],0)
        self.assertEqual(images['solid'][64,64,3],255)
        self.assertEqual(tuple(images['texture'][64,64,:3]),(255,0,0))

    def test_wireframe_has_no_fan_diagonal(self):
        ir={'faces':[plane(0)],'textures':{}}
        image=np.asarray(render_profile_view(ir,'frontal',128,mode='wireframe'))
        self.assertEqual(image[64,64,3],0)
        self.assertGreater(np.count_nonzero(image[:,:,3]),100)

    def test_wireframe_uses_actual_contour_edges_when_provided(self):
        ir={'faces':[{**plane(0),'wire_edges':[]}],'textures':{}}
        self.assertFalse(np.any(np.asarray(render_profile_view(ir,'frontal',64,mode='wireframe'))[:,:,3]))
        self.assertTrue(np.any(np.asarray(render_profile_view(ir,'frontal',64,mode='solid'))[:,:,3]))

    def test_xray_reveals_hidden_wire_edges_only_when_enabled(self):
        ir=layer_model()
        plain=np.asarray(render_profile_view(ir,'frontal',128,mode='wireframe'))
        xray=np.asarray(render_profile_view(ir,'frontal',128,mode='wireframe',xray=True))
        # Inner back square projects near x=90; front perimeter is near x=117.
        self.assertFalse(np.any(plain[55:75,89:92,3]))
        self.assertTrue(np.any(xray[55:75,89:92,3]))
        self.assertGreater(np.count_nonzero(xray[:,:,3]),np.count_nonzero(plain[:,:,3]))

    def test_xray_blends_real_front_and_hidden_texture_layers(self):
        ir=layer_model()
        ordinary=np.asarray(render_profile_view(ir,'frontal',128,mode='texture'))[64,64]
        xray=np.asarray(render_profile_view(ir,'frontal',128,mode='texture',xray=True))[64,64]
        self.assertEqual(tuple(ordinary),(255,0,0,255))
        self.assertGreater(xray[0],0);self.assertGreater(xray[2],0)
        self.assertGreater(xray[3],0);self.assertLess(xray[3],255)

    def test_normals_follow_vertex_winding_and_camera_side(self):
        ir={'faces':[plane(0)],'textures':{}}
        front=np.asarray(render_profile_view(ir,'frontal',128,mode='solid',normals=True))[64,64]
        back=np.asarray(render_profile_view(ir,'trasera',128,mode='solid',normals=True))[64,64]
        self.assertEqual(tuple(front[:3]),FRONT_COLOR)
        self.assertEqual(tuple(back[:3]),BACK_COLOR)
        # A forged shading normal must not overwrite geometric face winding.
        ir['faces'][0]['normal']=[0,0,1]
        actual=np.asarray(render_profile_view(ir,'frontal',128,mode='texture',normals=True))[64,64]
        np.testing.assert_array_equal(actual,front)

    def test_xray_and_normals_apply_simultaneously(self):
        ir=layer_model()
        normal=np.asarray(render_profile_view(ir,'frontal',128,mode='solid',normals=True))[64,64]
        both=np.asarray(render_profile_view(ir,'frontal',128,mode='solid',normals=True,xray=True))[64,64]
        self.assertEqual(tuple(normal[:3]),FRONT_COLOR)
        self.assertGreater(both[0],normal[0]);self.assertLess(both[2],normal[2])
        self.assertLess(both[3],255)

    def test_missing_textures_fail_only_modes_that_need_them(self):
        ir={'faces':[plane(0)],'textures':{}}
        with self.assertRaisesRegex(ValueError,'faltan texturas'):
            render_profile_view(ir,'frontal',64,mode='texture')
        for mode,normal in [('solid',False),('wireframe',False),('texture',True)]:
            self.assertIsInstance(render_profile_view(ir,'frontal',64,mode=mode,normals=normal),Image.Image)

    def test_context_reuses_decoded_textures_without_changing_ir(self):
        with tempfile.TemporaryDirectory() as td:
            image=Path(td)/'source.png';Image.new('RGBA',(3,7),(22,133,210,177)).save(image)
            ir={'faces':[plane(0)],'textures':{'red':str(image)}}
            original=copy.deepcopy(ir)
            renderer=ProfileRenderer(ir)
            from bridge import render_modes
            with patch('bridge.render_modes._load_textures',wraps=render_modes._load_textures) as loader:
                for mode,xray in [('texture',False),('solid',True),('texture',True)]:
                    renderer.render('frontal',128,mode=mode,xray=xray)
                self.assertEqual(loader.call_count,1)
            self.assertEqual(ir,original)
            self.assertEqual(Image.open(image).getpixel((0,0)),(22,133,210,177))

    def test_resolution_validation_and_cooperative_cancel(self):
        ir=layer_model()
        for options in ({'size':12},{'size':128.5},{'mode':'fake'},{'xray':'yes'},{'opacity':float('nan')}):
            with self.assertRaises(ValueError):render_profile_view(ir,'frontal',**options)
        with cancellation(lambda:True),self.assertRaises(ConversionCancelled):
            render_profile_view(ir,'frontal')

    def test_png_is_real_rgba_at_requested_resolution(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'render.png';render_profile_view(layer_model(),'frontal',256,mode='solid',xray=True).save(p)
            with Image.open(p) as opened:
                self.assertEqual(opened.size,(256,256));self.assertEqual(opened.mode,'RGBA')
                self.assertGreater(np.count_nonzero(np.asarray(opened)[:,:,3]),0)

if __name__=='__main__':unittest.main()
