"""Golden checks against exact original 1.21.1 assets, not hand-built templates."""
import hashlib
import unittest
import zipfile
from bridge.vanilla import builtin_model, bundled_resource_path, provenance, OFFICIAL_CLIENT_SHA1


class VanillaOriginalTests(unittest.TestCase):
    def test_official_download_identity(self):
        data = provenance()
        self.assertTrue(data['available'])
        self.assertEqual(data['version']['id'], '1.21.1')
        self.assertEqual(data['client']['sha1'], OFFICIAL_CLIENT_SHA1)
        self.assertEqual(data['verified_sha1'], OFFICIAL_CLIENT_SHA1)
        self.assertEqual(data['client']['size'], 26836906)
        self.assertTrue(data['client']['url'].startswith('https://piston-data.mojang.com/'))

    def test_original_parent_bytes_have_expected_hashes(self):
        golden = {
            'slab':'bd869ebe3ba380d46349e5c6e988b9b1ccf1ab25212ab1de66e2fdcc067edc1d',
            'stairs':'962dc154fd3337d6b7e165e2b734e171c4b3595c2b838a5da1e01f5bdcdcae3b',
            'inner_stairs':'fcb56ce59da95e5c1a77e49149caa3c72c18195141554a2c063d24b7962648d8',
            'template_wall_side':'748b2ee6eadcc6771e3702afaee8f296562c60a13931dd98c1baa1390cff484e',
        }
        with zipfile.ZipFile(bundled_resource_path()) as archive:
            for name, digest in golden.items():
                self.assertEqual(hashlib.sha256(archive.read('assets/minecraft/models/block/'+name+'.json')).hexdigest(), digest)
            self.assertFalse(any(name.endswith('.class') for name in archive.namelist()))
            self.assertIn('assets/minecraft/textures/block/oak_planks.png', archive.namelist())
            self.assertIn('assets/minecraft/textures/block/water_still.png.mcmeta', archive.namelist())

    def test_all_eighteen_missing_parents_are_real_resources(self):
        names = ['block/slab','block/stairs','block/slab_top','block/inner_stairs','block/outer_stairs',
                 'block/template_wall_post','block/template_wall_side','block/template_wall_side_tall',
                 'block/wall_inventory','block/cube_column_horizontal','block/thin_block','item/barrier',
                 'block/air','block/template_glass_pane_noside','block/template_glass_pane_noside_alt',
                 'block/template_glass_pane_post','block/template_glass_pane_side','block/template_glass_pane_side_alt']
        for name in names:
            with self.subTest(name=name):
                self.assertIsInstance(builtin_model('minecraft:'+name), dict)

    def test_slab_geometry_and_uv_golden(self):
        model = builtin_model('minecraft:block/slab')
        elem = model['elements'][0]
        self.assertEqual(elem['from'], [0,0,0]); self.assertEqual(elem['to'], [16,8,16])
        self.assertEqual(elem['faces']['north']['uv'], [0,8,16,16])
        self.assertEqual(elem['faces']['up']['uv'], [0,0,16,16])
        self.assertNotIn('cullface', elem['faces']['up'])
        self.assertEqual(builtin_model('minecraft:block/slab_top')['elements'][0]['from'], [0,8,0])

    def test_stairs_have_no_extra_internal_bottom_face(self):
        model = builtin_model('minecraft:block/stairs')
        self.assertEqual(len(model['elements']), 2)
        top = model['elements'][1]
        self.assertEqual(top['from'], [8,8,0]);self.assertEqual(top['to'], [16,16,16])
        self.assertNotIn('down', top['faces'])
        self.assertEqual(top['faces']['north']['uv'], [0,0,8,8])
        inner = builtin_model('minecraft:block/inner_stairs')
        self.assertEqual(len(inner['elements']), 3)
        self.assertEqual(inner['elements'][2]['from'], [0,8,8])
        self.assertNotIn('east', inner['elements'][2]['faces'])

    def test_wall_and_empty_resources_are_not_invented(self):
        side = builtin_model('minecraft:block/template_wall_side')['elements'][0]
        self.assertEqual(side['from'], [5,0,0]);self.assertEqual(side['to'], [11,14,8])
        self.assertNotIn('south', side['faces'])
        self.assertNotIn('elements', builtin_model('minecraft:block/thin_block'))
        self.assertFalse(builtin_model('minecraft:block/air').get('elements'))

    def test_isolation_and_safe_lookup(self):
        first = builtin_model('minecraft:block/slab');first['elements'][0]['from'][0] = 999
        self.assertEqual(builtin_model('minecraft:block/slab')['elements'][0]['from'], [0,0,0])
        self.assertIsNone(builtin_model('minecraft:block/not_a_real_parent'))
        self.assertIsNone(builtin_model('minecraft:../../secrets'))
        self.assertIsNone(builtin_model('other:block/slab'))

if __name__ == '__main__': unittest.main()
