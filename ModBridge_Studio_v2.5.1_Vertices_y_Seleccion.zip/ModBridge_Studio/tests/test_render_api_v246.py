"""Real HTTP -> render worker -> PNG/ZIP tests for the profile exporter.

Uses small generated Java resources; no game engine, browser screenshot, or
mock renderer participates in the export assertions.
"""
from __future__ import annotations

import copy
import hashlib
import http.client
import io
import json
from pathlib import Path, PurePosixPath
import tempfile
import threading
import time
import unittest
from http.server import ThreadingHTTPServer
import zipfile

from PIL import Image


def make_render_fixture(path):
    texture = Image.new('RGBA', (8, 8))
    texture.putdata([(30+x*25, 20+y*27, 200-x*13, 255) for y in range(8) for x in range(8)])
    buffer = io.BytesIO(); texture.save(buffer, format='PNG')
    faces = {side: {'texture': '#all', 'uv': [0, 0, 16, 16]}
             for side in ('north', 'south', 'up', 'down', 'east', 'west')}
    entries = {
        'assets/qa/textures/block/color.png': buffer.getvalue(),
        'assets/qa/models/block/uno.json': json.dumps({'textures': {'all': 'qa:block/color'},
            'elements': [{'from': [1, 1, 1], 'to': [12, 14, 9], 'faces': faces},
                         {'from': [4, 4, 10], 'to': [15, 11, 15], 'faces': faces}]}).encode(),
        'assets/qa/models/block/dos.json': json.dumps({'textures': {'all': 'qa:block/color'},
            'elements': [{'from': [3, 2, 5], 'to': [14, 13, 11], 'faces': faces}]}).encode(),
        'assets/qa/models/block/no_soportado.json': b'{"loader":"qa:unknown_runtime"}',
    }
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, data in entries.items(): archive.writestr(name, data)
    return entries


def profile(profile_id='p1', **changes):
    value = {'id': profile_id, 'name': profile_id, 'views': ['frontal'],
             'modes': ['texture'], 'xray': False, 'normals': False,
             'three_combinations': False, 'opacity': .35, 'size': 64,
             'representation': 'translated'}
    value.update(changes)
    return value


class RenderProfileHTTPTests(unittest.TestCase):
    def setUp(self):
        from app import Studio, make_handler
        self.temp = tempfile.TemporaryDirectory(); self.root = Path(self.temp.name)
        self.jar = self.root/'maestra_fuente.jar'; self.originals = make_render_fixture(self.jar)
        self.original_hash = hashlib.sha256(self.jar.read_bytes()).hexdigest()
        self.studio = Studio(self.root/'workspace', java=self.jar)
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(self.studio))
        self.thread = threading.Thread(target=lambda: self.server.serve_forever(poll_interval=.01), daemon=True)
        self.thread.start()

    def tearDown(self):
        try: self.request('POST', '/api/renders/cancel', {}, authorized=True)
        except (OSError, TimeoutError): pass
        self.studio.cancel()
        self.server.shutdown(); self.server.server_close(); self.thread.join(timeout=3)
        self.temp.cleanup()

    def request(self, method, path, data=None, authorized=False, headers=None):
        headers = dict(headers or {})
        if authorized: headers['X-Bridge-Token'] = self.studio.token
        body = json.dumps(data).encode() if data is not None else None
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=15)
        try:
            connection.request(method, path, body=body, headers=headers)
            response = connection.getresponse()
            payload = response.read()
            return response.status, dict(response.getheaders()), payload
        finally: connection.close()

    def json_request(self, method, path, data=None, authorized=False, headers=None):
        status, response_headers, body = self.request(method, path, data, authorized, headers)
        return status, response_headers, json.loads(body)

    def wait_render(self, timeout=40):
        deadline = time.monotonic()+timeout; snapshots=[]
        while time.monotonic() < deadline:
            status, _, payload = self.json_request('GET', '/api/renders/status')
            self.assertEqual(status, 200, payload); snapshots.append(payload)
            if payload['state'] not in ('running', 'stopping'):
                return payload, snapshots
            time.sleep(.05)
        self.fail('Render worker timeout: '+repr(snapshots[-1:]))

    def run_export(self, config):
        status, _, payload = self.json_request('POST', '/api/renders/plan', config, authorized=True)
        self.assertEqual(status, 200, payload)
        plan = payload['plan']
        status, _, payload = self.json_request('POST', '/api/renders/start', config, authorized=True)
        self.assertEqual(status, 202, payload)
        final, progress = self.wait_render()
        self.assertEqual(final['state'], 'done', final)
        self.assertIsInstance(final['result'], dict)
        self.assertEqual(final['result']['download_url'], '/download/renders.zip')
        status, headers, content = self.request('GET', '/download/renders.zip')
        self.assertEqual(status, 200, content[:300]); self.assertIn('attachment', headers['Content-Disposition'])
        return plan, final, zipfile.ZipFile(io.BytesIO(content)), progress

    def assert_safe_archive(self, archive):
        self.assertIsNone(archive.testzip())
        names=archive.namelist(); self.assertEqual(len(names),len(set(n.casefold() for n in names)))
        for name in names:
            self.assertNotIn('\\',name); self.assertNotIn(' ',name)
            path=PurePosixPath(name)
            self.assertFalse(path.is_absolute()); self.assertNotIn('..',path.parts)
            self.assertEqual(path.parts[0],'RENDERS_EXPORTADOS')
            if name.endswith('.png'):
                self.assertEqual(len(path.parts),5,name)
                self.assertNotRegex(name,r'[<>:"|?*]')
        for name in names:
            if name.endswith('.json'):
                self.assertNotIn(str(self.root),archive.read(name).decode())

    def test_two_unprocessed_models_two_profiles_real_zip_and_source_unchanged(self):
        profiles=[profile('p1',name='Mecánica completa',views=['superior','frontal'],
                          modes=['wireframe','solid'],three_combinations=True),
                  profile('p2',name='Textura limpia',views=['derecha'])]
        config={'profiles':profiles,'models':[
            {'id':'qa:block/uno','profile_ids':['p1','p2'],'master':'Maestra Uno'},
            {'id':'qa:block/dos','profile_ids':['p1','p2'],'master':'Maestra Dos'}]}
        self.assertEqual(self.studio.ready,{})
        plan, final, archive, snapshots = self.run_export(config)
        with archive:
            pngs=[n for n in archive.namelist() if n.endswith('.png')]
            self.assertEqual(plan['image_count'],26); self.assertEqual(len(pngs),26)
            self.assertEqual(final['result']['generated'],26)
            self.assert_safe_archive(archive)
            self.assertEqual(len({PurePosixPath(n).parts[1] for n in pngs}),2)
            self.assertEqual(len({PurePosixPath(n).parts[2] for n in pngs}),2)
            self.assertEqual(len({PurePosixPath(n).parts[3] for n in pngs}),2)
            modes=set(); pixel_hashes=set()
            for name in pngs:
                self.assertTrue('uno' in name or 'dos' in name)
                self.assertTrue('rayosx' in name and 'normales' in name)
                with Image.open(io.BytesIO(archive.read(name))) as im:
                    self.assertEqual(im.size,(64,64)); self.assertIsNotNone(im.getbbox())
                    pixel_hashes.add(hashlib.sha256(im.tobytes()).hexdigest())
                modes.update(mode for mode in ('alambre','solido','texturas') if mode in name)
            self.assertEqual(modes,{'alambre','solido','texturas'})
            self.assertGreater(len(pixel_hashes),6,'Modes/parameters must produce actual different pixels')
        self.assertEqual(self.studio.ready,{},'Render preparation must not replace the main library result')
        self.assertIsNone(self.studio.result)
        self.assertEqual(hashlib.sha256(self.jar.read_bytes()).hexdigest(),self.original_hash)
        self.assertTrue(any(x.get('total',0)>0 for x in snapshots))

    def test_identical_profile_combinations_have_one_owner_and_no_empty_folders(self):
        a=profile('primero',modes=['wireframe','solid','texture'],opacity=.1)
        b=profile('duplicado',modes=['wireframe','solid','texture'],opacity=.9)
        config={'profiles':[a,b,profile('no_elegido')],
                'models':[{'id':'qa:block/uno','profile_ids':['primero','duplicado']}]}
        plan, final, archive, _ = self.run_export(config)
        with archive:
            pngs=[n for n in archive.namelist() if n.endswith('.png')]
            self.assertEqual(plan['image_count'],3); self.assertEqual(len(pngs),3)
            self.assertEqual(len({PurePosixPath(n).parts[3] for n in pngs}),1)
            self.assertFalse(any('no_elegido/' in n for n in archive.namelist()))
            self.assertFalse(any(n.endswith('/') for n in archive.namelist()))

    def test_one_failed_model_does_not_abort_other_model(self):
        config={'profiles':[profile()], 'models':[
            {'id':'qa:block/no_soportado','profile_ids':['p1']},
            {'id':'qa:block/uno','profile_ids':['p1']}]}
        plan, final, archive, _ = self.run_export(config)
        with archive:
            pngs=[n for n in archive.namelist() if n.endswith('.png')]
            self.assertEqual(plan['image_count'],2)
            self.assertEqual(len(pngs),1)
            self.assertIn('uno',pngs[0]); self.assertTrue(final['result']['errors'])
            self.assertGreater(final['result']['failed'],0)

    def test_invalid_selections_and_unauthorized_requests_do_not_start_jobs(self):
        good={'profiles':[profile()], 'models':[{'id':'qa:block/uno','profile_ids':['p1']}]}
        cases=[]
        for field,value in [('models',[]),('profiles',[])]:
            item=copy.deepcopy(good);item[field]=value;cases.append(item)
        for field,value in [('views',[]),('modes',[]),('modes',['inventado']),('views',['../frontal'])]:
            item=copy.deepcopy(good);item['profiles'][0][field]=value;cases.append(item)
        item=copy.deepcopy(good);item['models'][0]['id']='../../private';cases.append(item)
        item=copy.deepcopy(good);item['models'][0]['profile_ids']=['missing'];cases.append(item)
        for case in cases:
            with self.subTest(case=case):
                status,_,body=self.json_request('POST','/api/renders/start',case,authorized=True)
                self.assertEqual(status,400,body)
        for headers in ({},{'X-Bridge-Token':'invalid'},
                        {'X-Bridge-Token':self.studio.token,'Origin':'https://evil.example'}):
            status,_,_=self.request('POST','/api/renders/start',good,headers=headers)
            self.assertEqual(status,403)
        status,_,state=self.json_request('GET','/api/renders/status')
        self.assertEqual(status,200); self.assertEqual(state['state'],'idle')
        self.assertEqual(hashlib.sha256(self.jar.read_bytes()).hexdigest(),self.original_hash)

    def test_original_conversion_remains_available_after_render_export(self):
        config={'profiles':[profile(representation='original')],
                'models':[{'id':'qa:block/uno','profile_ids':['p1']}]}
        _,_,archive,_=self.run_export(config);archive.close()
        status,_,payload=self.json_request('POST','/api/convert',
            {'models':['qa:block/uno'],'render_size':64},authorized=True)
        self.assertEqual(status,202,payload)
        deadline=time.monotonic()+20
        while self.studio.worker is not None and time.monotonic()<deadline:time.sleep(.02)
        self.assertEqual(self.studio.job['state'],'done',self.studio.job)
        status,_,content=self.request('GET','/download/result.zip');self.assertEqual(status,200)
        with zipfile.ZipFile(io.BytesIO(content)) as z:
            self.assertIn('ABRIR_COMPARACION.html',z.namelist())
            self.assertTrue(any(n.endswith('model.geo.json') for n in z.namelist()))

    def test_existing_conversion_files_and_reports_are_unchanged_by_render_export(self):
        status,_,payload=self.json_request('POST','/api/convert',
            {'models':['qa:block/uno','qa:block/dos'],'render_size':64},authorized=True)
        self.assertEqual(status,202,payload)
        deadline=time.monotonic()+20
        while self.studio.worker is not None and time.monotonic()<deadline:time.sleep(.05)
        self.assertEqual(self.studio.job['state'],'done',self.studio.job)
        original_ready=copy.deepcopy(self.studio.ready)
        original_result=copy.deepcopy(self.studio.result)
        files=[]
        for entry in self.studio.ready.values():
            files.extend(p for p in (Path(entry['run'])/'models'/entry['slug']).rglob('*') if p.is_file())
        files.append(Path(self.studio.result['archive']))
        hashes={p:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
        config={'profiles':[profile(views=['superior','inferior','izquierda','derecha','frontal','trasera'],
                                      modes=['wireframe','solid','texture'],xray=True,normals=True)],
                'models':[{'id':'qa:block/uno','profile_ids':['p1']},
                          {'id':'qa:block/dos','profile_ids':['p1']}]}
        plan,_,archive,_=self.run_export(config)
        with archive:
            self.assertEqual(plan['image_count'],36)
            self.assertEqual(len([p for p in archive.namelist() if p.endswith('.png')]),36)
            self.assert_safe_archive(archive)
        self.assertEqual(self.studio.ready,original_ready)
        self.assertEqual(self.studio.result,original_result)
        self.assertEqual({p:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},hashes)
        self.assertEqual(hashlib.sha256(self.jar.read_bytes()).hexdigest(),self.original_hash)

    def test_invalid_selection_preserves_last_completed_zip(self):
        config={'profiles':[profile()], 'models':[{'id':'qa:block/uno','profile_ids':['p1']}]}
        _,_,archive,_=self.run_export(config);archive.close()
        status,_,before=self.request('GET','/download/renders.zip');self.assertEqual(status,200)
        config['profiles'][0]['views']=[]
        status,_,_=self.json_request('POST','/api/renders/start',config,authorized=True)
        self.assertEqual(status,400)
        status,_,after=self.request('GET','/download/renders.zip');self.assertEqual(status,200)
        self.assertEqual(hashlib.sha256(before).digest(),hashlib.sha256(after).digest())
        _,_,state=self.json_request('GET','/api/renders/status');self.assertEqual(state['state'],'done')

    def test_active_render_blocks_conflicting_work_and_can_be_cancelled(self):
        config={'profiles':[profile(size=512,three_combinations=True,
                    views=['superior','inferior','izquierda','derecha','frontal','trasera'],
                    modes=['wireframe','solid','texture'])],
                'models':[{'id':'qa:block/uno','profile_ids':['p1']},
                          {'id':'qa:block/dos','profile_ids':['p1']}]}
        status,_,payload=self.json_request('POST','/api/renders/start',config,authorized=True)
        self.assertEqual(status,202,payload)
        for endpoint,data in [('/api/renders/start',config),
                              ('/api/convert',{'models':['qa:block/uno'],'render_size':64})]:
            status,_,payload=self.json_request('POST',endpoint,data,authorized=True)
            self.assertEqual(status,400,payload)
        status,_,payload=self.json_request('POST','/api/renders/cancel',{},authorized=True)
        self.assertIn(status,(200,202),payload)
        final,_=self.wait_render()
        self.assertEqual(final['state'],'cancelled',final)
        self.assertIsNone(final['result'])
        status,_,_=self.request('GET','/download/renders.zip');self.assertEqual(status,400)
        self.assertEqual(self.studio.ready,{})
        self.assertEqual(hashlib.sha256(self.jar.read_bytes()).hexdigest(),self.original_hash)


if __name__=='__main__':unittest.main()
