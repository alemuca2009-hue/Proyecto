"""Compare all six real orthographic solid renders before/after geometry changes.

Consumes run_geometry_v247.py summaries. Uses the full decoded IR with shared
camera bounds. Pixel silhouette equality is evidence at one resolution, never
proof of exact geometry or in-game behavior.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys


REPRESENTATIVES = [
    'create:block/black_valve_handle', 'create:block/chain_conveyor/wheel',
    'create:block/crushing_wheel/block', 'create:block/flywheel/block',
    'create:block/large_water_wheel/block', 'create:block/track/bogey/bogey_drive_wheel',
    'create:block/water_wheel/wheel', 'create:block/mechanical_roller/wheel',
]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--before',type=Path,required=True)
    parser.add_argument('--after',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--size',type=int,default=192)
    parser.add_argument('--models',nargs='+')
    args=parser.parse_args();root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
    import numpy as np
    from PIL import Image,ImageDraw
    from bridge.render_modes import ProfileRenderer
    from bridge.rendering import VIEWS,combined_bounds
    from bridge.pipeline import model_slug
    before={r['id']:r for r in json.loads(args.before.read_text())['rows']}
    after={r['id']:r for r in json.loads(args.after.read_text())['rows']}
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=True);rows=[];tiles=[];texture_tiles=[]
    def contact_tile(mid,view,pictures,mode):
        tile=Image.new('RGB',(args.size*3+24,args.size+58),(24,34,43));draw=ImageDraw.Draw(tile)
        draw.text((8,5),mid,fill='white');draw.text((8,20),'Vista: '+view+' | '+mode,fill=(190,202,210))
        for index,(key,label) in enumerate([('source','Java original'),('before','Bedrock 2.4.6'),('after','Bedrock 2.4.7')]):
            x=8+index*args.size;draw.text((x,36),label,fill='white');tile.paste(pictures[key],(x,54),pictures[key])
        return tile
    for mid in args.models or REPRESENTATIVES:
        source=json.loads((Path(after[mid]['directory'])/'ir_original.json').read_text())
        old=json.loads((Path(before[mid]['directory'])/'ir_bedrock.json').read_text())
        new=json.loads((Path(after[mid]['directory'])/'ir_bedrock.json').read_text())
        bounds=combined_bounds(source,old,new)
        renderers={k:ProfileRenderer(ir,bounds) for k,ir in [('source',source),('before',old),('after',new)]}
        row={'id':mid,'views':{}}
        best=None
        for view in VIEWS:
            pictures={k:renderer.render(view,args.size,mode='solid') for k,renderer in renderers.items()}
            arrays={k:np.asarray(im) for k,im in pictures.items()};masks={k:a[:,:,3]>0 for k,a in arrays.items()}
            metrics={'source_coverage_pixels':int(masks['source'].sum())}
            for side in ('before','after'):
                metrics[side]={'missing_pixels':int((masks['source']&~masks[side]).sum()),
                               'extra_pixels':int((~masks['source']&masks[side]).sum()),
                               'different_rgba_pixels':int(np.any(arrays['source']!=arrays[side],axis=2).sum()),
                               'pixel_identical':bool(np.array_equal(arrays['source'],arrays[side]))}
            row['views'][view]=metrics
            slug=model_slug(mid)
            for side,im in pictures.items():
                folder=out/slug/view;folder.mkdir(parents=True,exist_ok=True);im.save(folder/(side+'.png'))
            if best is None or metrics['source_coverage_pixels']>best[0]:
                best=(metrics['source_coverage_pixels'],view,{k:im.copy() for k,im in pictures.items()})
            for im in pictures.values():im.close()
        row['before_missing_pixels']=sum(v['before']['missing_pixels'] for v in row['views'].values())
        row['after_missing_pixels']=sum(v['after']['missing_pixels'] for v in row['views'].values())
        tiles.append(contact_tile(mid,best[1],best[2],'Solido'))
        for im in best[2].values():im.close()
        textured={k:renderer.render(best[1],args.size,mode='texture') for k,renderer in renderers.items()}
        arrays={k:np.asarray(im) for k,im in textured.items()}
        row['texture_view']={'view':best[1]}
        for side in ('before','after'):
            row['texture_view'][side]={'different_rgba_pixels':int(np.any(arrays['source']!=arrays[side],axis=2).sum()),
                                      'rgba_mae':float(np.abs(arrays['source'].astype(float)-arrays[side]).mean()),
                                      'pixel_identical':bool(np.array_equal(arrays['source'],arrays[side]))}
        for side,im in textured.items():
            folder=out/model_slug(mid)/'texturas'/best[1];folder.mkdir(parents=True,exist_ok=True);im.save(folder/(side+'.png'))
        texture_tiles.append(contact_tile(mid,best[1],textured,'Texturas'))
        for im in textured.values():im.close()
        rows.append(row);print(mid,row['before_missing_pixels'],'->',row['after_missing_pixels'],flush=True)
    for images,filename in [(tiles,'comparacion_geometria_v247.png'),(texture_tiles,'comparacion_texturas_v247.png')]:
        columns=min(2,len(images));width=images[0].width; height=images[0].height
        sheet=Image.new('RGB',(width*columns,height*((len(images)+columns-1)//columns)),(24,34,43))
        for index,tile in enumerate(images):sheet.paste(tile,((index%columns)*width,(index//columns)*height));tile.close()
        sheet.save(out/filename);sheet.close()
    (out/'render_comparison.json').write_text(json.dumps({'size':args.size,'mode':'solid','runtime_tested':False,
        'scope':'Six orthographic PNG silhouettes and RGBA comparison, not geometric proof.','rows':rows},ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()
