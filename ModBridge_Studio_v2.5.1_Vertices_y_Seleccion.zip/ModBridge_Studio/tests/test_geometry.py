"""Regression fixtures for nonstandard signed cubes and animated texture framing."""
import itertools
import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
from PIL import Image
from bridge.resources import ResourcePack
from bridge.geometry import convert_model, decode_bedrock
from bridge.rendering import compare_geometry


class IrregularGeometryTests(unittest.TestCase):
    def make_pack(self, root, element, animation=None):
        model_dir=root/'assets/demo/models/block'; model_dir.mkdir(parents=True)
        texture_dir=root/'assets/demo/textures/block'; texture_dir.mkdir(parents=True)
        pixels=np.zeros((32,32,4),dtype=np.uint8)
        for y in range(32):
            for x in range(32):
                pixels[y,x]=[(x*7)%256,(y*13)%256,((x+y)*11)%256,255 if x%3 else 71]
        Image.fromarray(pixels).save(texture_dir/'pattern.png')
        if animation is not None:
            (texture_dir/'pattern.png.mcmeta').write_text(json.dumps({'animation':animation}))
        model={'textures':{'base':'demo:block/pattern'},'elements':[element]}
        (model_dir/'test.json').write_text(json.dumps(model))
        return ResourcePack(root)

    def test_all_sign_combinations_keep_surfaces_normals_uv(self):
        for signs in itertools.product((-1,1),repeat=3):
            with self.subTest(signs=signs), tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp)
                a=[3,5,7]; b=[a[i]+signs[i]*[4,6,8][i] for i in range(3)]
                element={'from':a,'to':b,'rotation':{'axis':'y','angle':22.5,'origin':[11,2,-3],'rescale':True},
                         'faces':{d:{'texture':'#base','uv':[13,2,3,11],'rotation':r}
                                  for d,r in zip(('north','east','south','west','up','down'),(0,90,180,270,90,270))}}
                with self.make_pack(root/'pack',element) as pack:
                    r=convert_model(pack,'demo:block/test',root/'out')
                self.assertNotEqual(r['status'],'error',r['warnings'])
                self.assertTrue(r['metrics']['static_equivalence_passed'],r)
                geometry=json.loads(Path(r['paths']['geometry']).read_text())
                for bone in geometry['minecraft:geometry'][0]['bones']:
                    for cube in bone['cubes']:
                        self.assertTrue(all(x>=0 for x in cube['size']))
                original=json.loads(Path(r['paths']['ir_original']).read_text())
                converted=json.loads(Path(r['paths']['ir_bedrock']).read_text())
                comparison=compare_geometry(original,converted)
                self.assertTrue(comparison['surface_geometry_equal'],comparison)
                self.assertTrue(comparison['texture_sample_check_passed'],comparison)

    def test_animation_first_explicit_frame_retains_full_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            element={'from':[0,0,0],'to':[16,16,16], 'faces':{'north':{'texture':'#base'}}}
            with self.make_pack(root/'pack',element,{'width':16,'height':16,'frames':[3,1,0]}) as pack:
                r=convert_model(pack,'demo:block/test',root/'out')
            self.assertEqual(r['status'],'review')
            original=json.loads(Path(r['paths']['ir_original']).read_text())
            meta=original['texture_metadata']['demo:block/pattern']
            self.assertEqual(meta['preview_frame'],3)
            with Image.open(root/'pack/assets/demo/textures/block/pattern.png') as full:
                expected=full.crop((16,16,32,32)).tobytes()
                self.assertEqual(full.size,(32,32))
            with Image.open(original['textures']['demo:block/pattern']) as frame:
                self.assertEqual(frame.size,(16,16))
                self.assertEqual(frame.tobytes(),expected)
            self.assertEqual((root/'pack/assets/demo/textures/block/pattern.png').read_bytes(),
                             (root/'out/originals/assets/demo/textures/block/pattern.png').read_bytes())

    def test_omitted_default_cube_pivot_rotates_around_center(self):
        with tempfile.TemporaryDirectory() as tmp:
            texture=Path(tmp)/'a.png'; Image.new('RGBA',(16,16),'white').save(texture)
            geo={'format_version':'1.21.0','minecraft:geometry':[{'description':{'texture_width':16,'texture_height':16},
                'bones':[{'name':'root','cubes':[{'origin':[3,2,-5],'size':[4,7,11], 'rotation':[0,0,90],
                'uv':{'north':{'uv':[0,0],'uv_size':[16,16]}}}]}]}]}
            ir=decode_bedrock(geo,texture)
            # Canonical center =[-5,5.5,0.5]; 90 Z turns X extent4/Y extent7 to X7/Y4.
            bounds=np.asarray(ir['bounds'])
            self.assertAlmostEqual(bounds[1,0]-bounds[0,0],7)
            self.assertAlmostEqual(bounds[1,1]-bounds[0,1],4)
            self.assertTrue(np.allclose((bounds[0]+bounds[1])/2,[-5,5.5,-5]))


if __name__=='__main__':
    unittest.main()
