"""Independent decoded-polygon containment audit (optional Shapely dependency).

Usage: python tests/audit_containment_v245.py --run audit --output containment.json
Install Shapely only for this development audit; ModBridge does not require it.
Area is planar union area, not volume. Overlapping multiplicity and orientation
are checked separately by bridge.rendering's surface equivalence comparison.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
import numpy as np


def plane(vertices):
    vertices = np.asarray(vertices, float)
    n = sum(np.cross(a, b) for a, b in zip(vertices, np.roll(vertices, -1, axis=0)))
    length = np.linalg.norm(n)
    if length < 1e-10:
        return None
    n = n/length
    axis = int(np.argmax(np.abs(n)))
    if n[axis] < 0: n = -n
    return n, float(vertices[0] @ n), axis


def audit(source, target, tolerance=1e-5):
    from shapely.geometry import Polygon
    from shapely.ops import unary_union
    from bridge.rendering import _triangulate
    groups = []
    invalid = []
    triangles = []
    for idx, face in enumerate(source.get('faces', [])):
        vertices = np.asarray(face['vertices'], float)
        for indices in _triangulate(vertices):
            triangles.append((idx, vertices[list(indices)]))
    for idx, vertices in triangles:
        p = plane(vertices)
        if p is None:
            invalid.append({'side': 'source', 'face': idx}); continue
        n, d, axis = p
        group = next((g for g in groups if min(np.linalg.norm(g['normal']-n), np.linalg.norm(g['normal']+n))<1e-8
                      and np.max(np.abs(vertices @ g['normal']-g['distance']))<1e-8), None)
        if group is None:
            group = {'normal': n, 'distance': d, 'axis': axis, 'source': [], 'source_vertices': [], 'target': []}
            groups.append(group)
        polygon = Polygon(np.delete(vertices, group['axis'], axis=1))
        if not polygon.is_valid:
            invalid.append({'side': 'source', 'face': idx}); continue
        group['source'].append(polygon)
        group['source_vertices'].append(vertices)
    for group in groups:
        group['union'] = unary_union(group['source'])
        group['tolerant_union'] = group['union'].buffer(tolerance)
    normals = np.asarray([g['normal'] for g in groups])
    distances = np.asarray([g['distance'] for g in groups])
    outside = 0.
    outside_faces = []
    missing_planes = []
    for idx, face in enumerate(target.get('faces', [])):
        vertices = np.array(face['vertices'], float)
        p = plane(vertices)
        if p is None:
            invalid.append({'side': 'target', 'face': idx}); continue
        n, d, axis = p
        angular = np.minimum(np.linalg.norm(normals-n, axis=1), np.linalg.norm(normals+n, axis=1)) if groups else np.array([])
        indices = np.flatnonzero(angular < tolerance)
        residual = np.max(np.abs(vertices @ normals[indices].T-distances[indices]), axis=0) if len(indices) else np.array([])
        indices = indices[residual < tolerance]
        matches = [groups[i] for i in indices]
        group = min(matches, key=lambda g: np.max(np.abs(vertices @ g['normal']-g['distance']))
                    + min(np.linalg.norm(g['normal']-n), np.linalg.norm(g['normal']+n))) if matches else None
        if group is None:
            missing_planes.append(idx); continue
        polygon = Polygon(np.delete(vertices, group['axis'], axis=1))
        if not polygon.is_valid:
            invalid.append({'side': 'target', 'face': idx}); continue
        group['target'].append(polygon)
        # Multiple source triangles may differ by sub-tolerance source rounding.
        # Their common near-plane union is admissible at the declared tolerance.
        if len(matches) == 1:
            allowed = group['tolerant_union']
        else:
            allowed = unary_union([Polygon(np.delete(v, group['axis'], axis=1))
                                   for g in matches for v in g['source_vertices']]).buffer(tolerance)
        excess = polygon.difference(allowed).area / abs(group['normal'][group['axis']])
        if excess > tolerance*tolerance:
            outside += excess
            outside_faces.append({'face': idx, 'outside_area': excess})
    source_union_area = 0.
    omitted_union_area = 0.
    for group in groups:
        scale = 1 / abs(group['normal'][group['axis']])
        source_union_area += group['union'].area*scale
        target_union = unary_union(group['target'])
        omitted_union_area += group['union'].difference(target_union).area*scale
    return {'passed_no_overhang': bool(source.get('faces') and target.get('faces')) and not outside_faces and not missing_planes and not invalid,
            'tolerance_model_units': tolerance,
            'outside_area_beyond_tolerance': outside,
            'outside_faces': outside_faces, 'target_faces_without_source_plane': missing_planes,
            'invalid_faces': invalid, 'source_planar_union_area': source_union_area,
            'omitted_planar_union_area': omitted_union_area,
            'oriented_multiplicity_checked': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    import shapely
    rows = []
    for directory in sorted((args.run/'models').iterdir()):
        if not (directory/'ready.json').exists(): continue
        files = [directory/name for name in ['ir_original.json', 'ir_bedrock.json', 'report.json']]
        if not all(p.exists() for p in files): continue
        source, target, report = [json.loads(p.read_text(encoding='utf-8')) for p in files]
        row = {'id': report['id'], **audit(source, target)}
        rows.append(row)
        print(report['id'], row['passed_no_overhang'], row['outside_area_beyond_tolerance'], flush=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({
        'method': 'independent_shapely_difference_against_coplanar_source_unions',
        'shapely_version': shapely.__version__, 'model_count': len(rows),
        'all_passed_no_overhang': bool(rows) and all(r['passed_no_overhang'] for r in rows),
        'runtime_tested': False,
        'scope': 'Decoded target polygons must lie within source coplanar polygon unions, with 1e-5 model-unit boundary tolerance; source overlap multiplicity is tested separately.',
        'rows': rows,
    }, indent=2, ensure_ascii=False), encoding='utf-8')


if __name__ == '__main__':
    main()
