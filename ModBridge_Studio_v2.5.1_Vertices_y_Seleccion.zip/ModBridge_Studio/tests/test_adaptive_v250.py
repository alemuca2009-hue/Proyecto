import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from PIL import Image
from conversion_engine import SurfaceSettings, convert_file
from conversion_engine.adaptive import convert_with_refinement, improves
from conversion_engine.mesh_surface import convert_mesh_surface
from conversion_engine.rectangle_recovery import recover_rectangles
from conversion_engine.geometry import decode_bedrock
from conversion_engine.control import ConversionCancelled
from bridge.rendering import compare_geometry


def fan():
    points=[[0,0,0],[8,0,0],[8,8,0],[0,8,0],[4,4,0]]
    return [{'vertices':[points[j] for j in (i,(i+1)%4,4)],
             'uv':[[points[j][0],points[j][1]] for j in (i,(i+1)%4,4)],'texture':'t','normal':[0,0,1]} for i in range(4)]


class AdaptiveTests(unittest.TestCase):
    def source(self,root,faces):
        image=Image.new('RGBA',(16,16),(142,85,36,255));image.save(root/'texture.png')
        return {'id':'test:surface','faces':faces,'textures':{'t':str(root/'texture.png')}}

    def test_proven_fan_becomes_one_rectangle_with_original_uv_and_source_unchanged(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source=self.source(root,fan());before=copy.deepcopy(source)
            result=convert_with_refinement(source,root/'out',SurfaceSettings())
            target=decode_bedrock(result['geometry'],result['atlas_path'])
            self.assertEqual(source,before);self.assertEqual(len(target['faces']),1)
            self.assertTrue(compare_geometry(source,target)['surface_geometry_equal'])
            audit=result['report']['adaptive_refinement']
            self.assertTrue(audit['geometry_coincident']);self.assertEqual(audit['selected_pass'],1)
            self.assertEqual(audit['stop_reason'],'geometry_coincident')
            self.assertFalse(result['report']['rgba_texels_preserved'])

    def test_duplicate_layers_are_not_collapsed(self):
        faces=fan()*2;result,report=recover_rectangles(faces)
        self.assertEqual(len(result),2)
        self.assertEqual(sorted(len(f['source_indices']) for f in result),[4,4])
        self.assertTrue(compare_geometry({'faces':faces,'textures':{}},{'faces':result,'textures':{}})['surface_geometry_equal'])

    def test_uv_discontinuities_and_holes_are_not_filled(self):
        faces=fan();faces[0]['uv'][2][0]+=.25
        result,report=recover_rectangles(faces)
        self.assertEqual(len(result),4)
        # Four rectangular arms surrounding an empty centre; reject the ring.
        rings=[[(0,0),(6,0),(6,2),(0,2)],[(0,4),(6,4),(6,6),(0,6)],
               [(0,2),(2,2),(2,4),(0,4)],[(4,2),(6,2),(6,4),(4,4)]]
        faces=[{'vertices':[[x,y,0] for x,y in ring],'uv':ring,'texture':'t'} for ring in rings]
        result,report=recover_rectangles(faces)
        self.assertEqual(len(result),4);self.assertFalse(report['fills_holes'])

    def test_oblique_triangle_improves_but_is_never_labeled_coincident(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);faces=[{'vertices':[[0,0,0],[8,0,0],[0,8,0]],'uv':[[0,0],[16,0],[0,16]],'texture':'t'}]
            source=self.source(root,faces)
            result=convert_with_refinement(source,root/'out',SurfaceSettings())
            audit=result['report']['adaptive_refinement']
            self.assertLessEqual(audit['passes_performed'],2)
            self.assertGreater(audit['selected_pass'],0)
            self.assertLess(audit['selected_quality']['omitted_area'],audit['baseline_quality']['omitted_area'])
            self.assertFalse(audit['geometry_coincident'])
            self.assertFalse(compare_geometry(source,decode_bedrock(result['geometry'],result['atlas_path']))['surface_geometry_equal'])

    def test_already_coincident_surface_does_not_retry(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source=self.source(root,[{'vertices':[[0,0,0],[4,0,0],[4,4,0],[0,4,0]],'uv':[[0,0],[4,0],[4,4],[0,4]],'texture':'t'}])
            with patch('conversion_engine.mesh_surface.convert_mesh_surface',wraps=convert_mesh_surface) as convert:
                result=convert_with_refinement(source,root/'out',SurfaceSettings())
                self.assertEqual(convert.call_count,1)
            self.assertEqual(result['report']['adaptive_refinement']['passes_performed'],0)

    def test_failed_repasses_preserve_baseline_atlas_and_geometry(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source=self.source(root,fan())
            baseline=convert_mesh_surface(source,root/'base')
            count=0
            def fail_later(*args,**kwargs):
                nonlocal count
                count+=1
                if count>1:raise ValueError('candidate failure')
                return convert_mesh_surface(*args,**kwargs)
            with patch('conversion_engine.mesh_surface.convert_mesh_surface',side_effect=fail_later):
                result=convert_with_refinement(source,root/'out',SurfaceSettings())
            self.assertEqual(result['geometry'],baseline['geometry'])
            self.assertEqual(Path(result['atlas_path']).read_bytes(),Path(baseline['atlas_path']).read_bytes())
            self.assertEqual(result['report']['adaptive_refinement']['selected_pass'],0)

    def test_no_trade_of_missing_surface_or_texture_density_for_another_score(self):
        old={'omitted_area':1.,'outside_area':10.,'density':4.}
        for candidate in [{'omitted_area':2.,'outside_area':0.,'density':4.},
                          {'omitted_area':0.,'outside_area':11.,'density':4.},
                          {'omitted_area':0.,'outside_area':0.,'density':3.}]:
            self.assertFalse(improves(old,candidate))
        self.assertTrue(improves(old,{'omitted_area':.5,'outside_area':8.,'density':4.}))

    def test_cancellation_during_recovery_remains_cancellation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source=self.source(root,fan())
            with patch('conversion_engine.adaptive.recover_rectangles',side_effect=ConversionCancelled('stop')):
                with self.assertRaises(ConversionCancelled):convert_with_refinement(source,root/'out',SurfaceSettings())


if __name__=='__main__':unittest.main()
