"""Audit every model selected in a ModBridge render manifest against source geometry.

Requires the caller's original JAR and optional Shapely (development only).
The uploaded renders identify models; they are not used as source geometry.
Each model is converted independently. Geometry-only audits can reuse identical
coordinate fingerprints; source/atlas files and texture transfer remain per-model.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import time


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def geometry_key(ir):
    return hashlib.sha256(json.dumps([f['vertices'] for f in ir.get('faces', [])],
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def precise_plane(vertices):
    """Stable audit plane for tiny positive-area output rectangles.

    The v245 audit's absolute 1e-10 normal threshold excluded thin but valid
    rectangles. Translate to a local origin before summing cross products;
    retain all positive-area planes above 1e-20, without changing the independent
    1e-5 coplanarity/containment tolerance used by the Shapely difference test.
    """
    import numpy as np
    vertices=np.asarray(vertices,float);local=vertices-vertices[0]
    normal=sum(np.cross(a,b) for a,b in zip(local,np.roll(local,-1,axis=0)))
    length=float(np.linalg.norm(normal))
    if length<=1e-20:return None
    normal=normal/length;axis=int(np.argmax(np.abs(normal)))
    if normal[axis]<0:normal=-normal
    return normal,float(vertices[0]@normal),axis


def positive_surfaces(ir):
    """Exclude explicitly recorded zero-area faces from a surface-area oracle.

    Such faces have no drawable area and remain unchanged in the source/target
    files. Do not confuse a zero normal of a bow-tie polygon with zero triangle
    area: only actual zero-area triangles qualify for this exclusion.
    """
    import numpy as np
    from bridge.rendering import _triangulate
    faces=[];excluded=[]
    for index,face in enumerate(ir.get('faces',[])):
        vertices=np.asarray(face['vertices'],float)
        area=sum(float(np.linalg.norm(np.cross(vertices[b]-vertices[a],vertices[c]-vertices[a])))/2
                 for a,b,c in _triangulate(vertices))
        if area<=1e-20:excluded.append(index)
        else:faces.append(face)
    return {**ir,'faces':faces},excluded


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--program-root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--reuse-run', action='append', type=Path, default=[])
    parser.add_argument('--models', nargs='+')
    parser.add_argument('--full-verifier', action='store_true')
    parser.add_argument('--no-containment', action='store_true')
    parser.add_argument('--resume', action='store_true')
    args=parser.parse_args()
    sys.path.insert(0, str(args.program_root.resolve()))
    from bridge import __version__
    from bridge.geometry import convert_model
    from bridge.resources import ResourcePack
    from bridge.surface_adapter import adapt_surface
    from bridge.pipeline import model_slug
    from bridge.rendering import compare_geometry
    from bridge.verification import final_status
    from run_geometry_v245 import planar_metrics
    import audit_containment_v245
    audit_containment_v245.plane=precise_plane
    audit=audit_containment_v245.audit
    source_file=args.input.resolve()
    source_hash=hashlib.sha256(source_file.read_bytes()).hexdigest()
    selected=[m['id'] for m in load(args.manifest)['models']]
    if args.models:
        missing=set(args.models)-set(selected)
        if missing:raise SystemExit('Models absent from manifest: '+str(sorted(missing)))
        selected=[mid for mid in selected if mid in args.models]
    reuse={}
    for run in args.reuse_run:
        for md in (run/'models').glob('*'):
            p=md/'report.json'
            if p.is_file():
                report=load(p)
                if report.get('id'):reuse[report['id']]=md
    out=args.output.resolve();out.mkdir(parents=True, exist_ok=True)
    cache={};rows=[];started=time.monotonic()
    with ResourcePack(source_file) as pack:
        for index,mid in enumerate(selected,1):
            rowfile=out/'rows'/(model_slug(mid)+'.json')
            if args.resume and rowfile.exists():
                row=load(rowfile);rows.append(row);print(f'[{index}/{len(selected)}] reused completed {mid}',flush=True);continue
            start=time.monotonic();md=reuse.get(mid)
            try:
                if md:
                    report=load(md/'report.json');source=load(md/'ir_original.json');target=load(md/'ir_bedrock.json')
                else:
                    md=out/'models'/model_slug(mid)
                    report=convert_model(pack,mid,md)
                    source=load(md/'ir_original.json')
                    if report.get('target_kind')=='experimental_poly_mesh':
                        report,target=adapt_surface(report,source,md,model_slug(mid))
                    else:target=load(md/'ir_bedrock.json')
                    save(md/'report.json',report)
                surface=load(md/'surface_report.json') if (md/'surface_report.json').exists() else {}
                transfer=surface.get('texture_transfer',{})
                row={'id':mid,'directory':str(md),'target_kind':report.get('target_kind'),
                     'status':final_status(report),
                     'source':planar_metrics(source),'target':planar_metrics(target),
                     'planner_exact_geometry':surface.get('exact_geometry'),
                     'sampled_rectangles':transfer.get('sampled_rectangles'),
                     'direct_uv_rectangles':transfer.get('direct_uv_rectangles'),
                     'rgba_texels_preserved':report.get('metrics',{}).get('rgba_texels_preserved'),
                     'reconstruction':surface.get('rectangle_reconstruction'),
                     'region_reconstruction':surface.get('coplanar_regions',surface.get('coplanar_reconstruction')),
                     'geometry_sha256':{'source':geometry_key(source),'target':geometry_key(target)},
                     'original_files_sha256':{p.relative_to(md/'originals').as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                                              for p in sorted((md/'originals').rglob('*')) if p.is_file()}}
                row['area_coverage_ratio']=row['target']['area']/row['source']['area'] if row['source']['area'] else None
                key=(row['geometry_sha256']['source'],row['geometry_sha256']['target'])
                if not args.no_containment:
                    if key in cache:row['containment']={**cache[key], 'cache_reused':True}
                    else:
                        source_surface,zero_source=positive_surfaces(source)
                        target_surface,zero_target=positive_surfaces(target)
                        measured=audit(source_surface,target_surface)
                        # Keep counts and scalars, not thousands of per-face arrays.
                        row['containment']={k:v for k,v in measured.items() if k not in ('outside_faces','target_faces_without_source_plane','invalid_faces')}
                        row['containment'].update(outside_face_count=len(measured['outside_faces']),
                                                 missing_plane_count=len(measured['target_faces_without_source_plane']),
                                                 invalid_face_count=len(measured['invalid_faces']),
                                                 excluded_zero_area_faces={'source':zero_source,'target':zero_target})
                        cache[key]=dict(row['containment'])
                if args.full_verifier:
                    independent=compare_geometry(source,target)
                    row['independent']={k:v for k,v in independent.items() if not isinstance(v,(dict,list))}
                row['elapsed_seconds']=round(time.monotonic()-start,3)
                save(rowfile,row);rows.append(row)
                print(f"[{index}/{len(selected)}] {mid} faces {row['target']['face_count']} coverage {row['area_coverage_ratio']:.9f} seconds {row['elapsed_seconds']}",flush=True)
            except Exception as error:
                row={'id':mid,'error':type(error).__name__+': '+str(error)}
                save(rowfile,row);rows.append(row);print(f'[{index}/{len(selected)}] ERROR {mid}: {error}',flush=True)
    result={'version':__version__,'source':{'filename':source_file.name,'sha256':source_hash},
            'manifest_sha256':hashlib.sha256(args.manifest.read_bytes()).hexdigest(),
            'model_count':len(rows),'error_count':sum('error' in r for r in rows),
            'decoded_geometry_audit':not args.no_containment,'full_verifier':args.full_verifier,
            'runtime_tested':False,'elapsed_seconds':round(time.monotonic()-started,3),'rows':rows}
    assert hashlib.sha256(source_file.read_bytes()).hexdigest()==source_hash
    save(out/'regression.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='rows'},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
