/* Execute the actual UI handlers against controlled DOM/network adapters. */
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const source=fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8');

function harness(){
  const elements={},requests=[],toasts=[];
  const element=id=>elements[id] ||= {disabled:false,hidden:false,attributes:{},classes:new Set(),value:'192',
    setAttribute(k,v){this.attributes[k]=v},removeAttribute(k){delete this.attributes[k]},
    querySelector(){return this.child ||= {}},addEventListener(event,callback){this[event]=callback},
    classList:{toggle(name,on){if(on)element(id).classes.add(name);else element(id).classes.delete(name)}}};
  element('mesh-mode').value='surface';
  const state={models:[{id:'one'},{id:'two'}],selected:new Set(),job:{state:'idle'},ready:[],result:null};
  const context={state,$:element,document:{querySelectorAll:()=>[]},visibleModels:()=>state.models,
    library:require('../web/library.js'),allReports:()=>[],currentLibraryOptions:()=>({}),resetResultFilters:()=>{},
    localURL:value=>value||null,request:async(url,options)=>requests.push({url,options}),
    poll:async()=>{},toast:(...args)=>toasts.push(args),clearInspector:()=>{},renderLibrary:()=>{}};
  context.renderJob=()=>context.update();vm.createContext(context);
  const actions=source.slice(source.indexOf('  function isRunning()'),source.indexOf('  function renderProject()'));
  const conversion=source.slice(source.indexOf('  async function convert('),source.indexOf('  function clearInspector()'));
  const handlers=source.slice(source.indexOf("  $('convert-button').addEventListener"),source.indexOf("  $('cancel-button').addEventListener"));
  vm.runInContext(actions+'\nglobalThis.update=updateActions;\n'+conversion+handlers,context);
  return {context,state,elements,element,requests,toasts,update:context.update};
}

test('pause is grey action; paused and pausing show enabled Continue and block other jobs',()=>{
  const h=harness();h.state.job.state='running';h.update();
  assert.equal(h.element('pause-button').disabled,false);assert.equal(h.element('pause-label').textContent,'Pausar');
  for(const state of['pausing','paused']){
    h.state.job.state=state;h.update();
    assert.equal(h.element('pause-label').textContent,'Continuar');assert.ok(h.element('pause-button').classes.has('button-continue'));
    assert.equal(h.element('convert-button').disabled,true);assert.equal(h.element('restart-button').disabled,true);
    assert.equal(h.element('cancel-button').hidden,false);assert.equal(h.element('open-render-dialog').disabled,true);
  }
});

test('no selection gives exact tooltip and cannot restart all models',async()=>{
  const h=harness();h.update();assert.equal(h.element('restart-button').disabled,true);
  assert.equal(h.element('restart-control').title,'Ocupas seleccionar modelos');
  assert.equal(h.element('restart-help').textContent,'Ocupas seleccionar modelos');
  await h.element('restart-button').click();assert.equal(h.requests.length,0);
  assert.equal(h.toasts[0][0],'Ocupas seleccionar modelos');
});

test('restart payload uses only checked valid IDs and preserves existing results',async()=>{
  const h=harness();h.state.selected=new Set(['two','stale']);h.state.result={download_url:'/download/result.zip'};h.update();
  assert.equal(h.element('restart-button').disabled,false);
  await h.element('restart-button').click();assert.equal(h.requests.length,1);
  assert.equal(h.requests[0].url,'/api/restart');assert.deepEqual(JSON.parse(h.requests[0].options.body).models,['two']);
  assert.equal(h.state.result.download_url,'/download/result.zip');assert.equal(h.state.job.operation,'restart');
});

test('pause and continue dispatch different endpoints and serialize clicks',async()=>{
  const h=harness();h.state.job.state='running';
  await h.element('pause-button').click();assert.equal(h.requests[0].url,'/api/pause');
  h.state.job.state='paused';await h.element('pause-button').click();assert.equal(h.requests[1].url,'/api/resume');
  h.state.pauseBusy=true;await h.element('pause-button').click();assert.equal(h.requests.length,2);
});

test('restart is blocked while paused and after server errors existing data remains',async()=>{
  const h=harness();h.state.selected.add('one');h.state.job.state='paused';
  await h.element('restart-button').click();assert.equal(h.requests.length,0);
  h.state.job.state='done';h.state.result={download_url:'/old.zip'};
  h.context.request=async()=>{throw Error('fixture error')};
  await h.element('restart-button').click();assert.equal(h.state.result.download_url,'/old.zip');
  assert.equal(h.state.job.state,'done');assert.equal(h.toasts[0][0],'fixture error');
});

test('a previous ZIP does not hide partial export after an interrupted restart',()=>{
  const h=harness();h.state.job.state='cancelled';h.state.canExportPartial=true;
  h.state.result={download_url:'/download/result.zip'};h.state.resultIsPrevious=true;h.update();
  assert.equal(h.element('export-partial').hidden,false);
  assert.equal(h.element('export-partial').disabled,false);
  assert.equal(h.element('download-button').child.textContent,'Descargar ZIP anterior');
  h.state.resultIsPrevious=false;h.update();
  assert.equal(h.element('export-partial').hidden,true);
  assert.equal(h.element('download-button').child.textContent,'Descargar ZIP');
});

test('Convert selected never falls back to all models without valid checked IDs',async()=>{
  const h=harness();h.update();assert.equal(h.element('convert-selected-button').disabled,true);
  await h.element('convert-selected-button').click();
  h.state.selected.add('stale');await h.element('convert-selected-button').click();
  assert.equal(h.requests.length,0);assert.equal(h.toasts[0][0],'Ocupas seleccionar modelos');
});

test('Convert selected sends exactly valid checked IDs regardless of visible filters',async()=>{
  const h=harness();h.state.selected=new Set(['two','stale']);
  h.context.visibleModels=()=>[h.state.models[0]];
  h.context.allReports=()=>{throw Error('Selected conversion must not use filter fallback')};
  h.update();assert.equal(h.element('convert-selected-button').disabled,false);
  await h.element('convert-selected-button').click();
  assert.equal(h.requests[0].url,'/api/convert-selected');
  assert.deepEqual(JSON.parse(h.requests[0].options.body).models,['two']);
  assert.equal(h.state.job.total,1);assert.equal(h.state.job.state,'running');
});

test('Both convert buttons serialize clicks and recover after a failed request',async()=>{
  const h=harness();h.state.selected.add('one');h.state.result={download_url:'/old.zip'};
  let release;h.context.request=()=>new Promise((resolve,reject)=>{release=()=>reject(Error('network error'))});
  const pending=h.element('convert-selected-button').click();
  assert.equal(h.element('convert-selected-button').disabled,true);
  assert.equal(h.element('convert-button').disabled,true);
  await h.element('convert-button').click();
  release();await pending;
  assert.equal(h.state.convertBusy,false);assert.equal(h.state.result.download_url,'/old.zip');
  assert.equal(h.element('convert-selected-button').disabled,false);
  for(const state of ['running','paused','pausing','stopping']){
    h.state.job.state=state;h.update();assert.equal(h.element('convert-selected-button').disabled,true);
  }
});

test('The existing conversion button retains its unselected library behavior',async()=>{
  const h=harness();await h.element('convert-button').click();
  assert.equal(h.requests[0].url,'/api/convert');
  assert.deepEqual(JSON.parse(h.requests[0].options.body).models,['one','two']);
});
