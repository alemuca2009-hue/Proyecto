/* Exercise the actual metric renderer and library filters against real conversions.
   No DOM/browser dependency: only the four metric elements are stubbed. */
const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const {execFileSync} = require('node:child_process');
const library = require('../web/library.js');

test('real displayed metrics put normal and extended matching models in Verified', () => {
  const root=path.resolve(__dirname,'..');
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'modbridge-cards-'));
  try {
    execFileSync(process.env.PYTHON || 'python3',['app.py','convert','--input',
      'examples/Demostracion_ModBridge.jar','--output',temp,'--size','64'],
      {cwd:root,stdio:'pipe',timeout:30000});
    const reports=JSON.parse(fs.readFileSync(path.join(temp,'result.json'),'utf8')).reports;
    const source=fs.readFileSync(path.join(root,'web/app.js'),'utf8');
    const start=source.indexOf('  function findValue(');
    const end=source.indexOf('\n  function ',source.indexOf('  function renderMetrics(')+10);
    assert.ok(start>=0 && end>start);
    const cards={};
    const context={numeric:v=>typeof v==='number'&&Number.isFinite(v),pretty:String,node:()=>({}),
      document:{createTextNode:v=>v},
      SIDE_NAMES:{superior:1,frontal:1,inferior:1,trasera:1,izquierda:1,derecha:1},
      $:id=>cards[id] ||= {replaceChildren(){}}};
    vm.createContext(context);
    vm.runInContext(source.slice(start,end)+'\nglobalThis.show=renderMetrics;',context);
    let matching=0;
    for(const report of reports) {
      context.show(report);
      const match=cards['metric-geometry'].textContent==='Coincidente'
        && cards['metric-textures'].textContent==='Píxeles conservados';
      if(match) {
        matching++;
        assert.equal(report.status,'verified_static');
        assert.equal(library.resultGroup(report),'verified');
        const models=[{id:report.id}];
        assert.equal(library.visibleModels(models,[report],{group:'review'}).length,0);
        assert.equal(library.visibleModels(models,[report],{group:'verified',extendedOnly:report.extended3d}).length,1);
      } else assert.equal(report.status,'review');
    }
    assert.equal(matching,5);
    const large=reports.find(r=>r.id==='demo:block/fuera_del_bloque');
    assert.equal(large.extended3d,true);
    assert.equal(large.status,'verified_static');
    assert.equal(reports.find(r=>r.id==='demo:block/plano').status,'verified_static');
  } finally {fs.rmSync(temp,{recursive:true,force:true});}
});

function metricRenderer() {
  const source=fs.readFileSync(path.resolve(__dirname,'../web/app.js'),'utf8');
  const start=source.indexOf('  function findValue(');
  const end=source.indexOf('\n  function ',source.indexOf('  function renderMetrics(')+10);
  const cards={};
  const context={numeric:v=>typeof v==='number'&&Number.isFinite(v),pretty:String,
    node:(tag,className,textContent)=>({tag,className,textContent}),
    document:{createTextNode:v=>v},
    SIDE_NAMES:{superior:1,frontal:1,inferior:1,trasera:1,izquierda:1,derecha:1},
    $:id=>cards[id] ||= {replaceChildren(...children){this.children=children;}}};
  vm.createContext(context);
  vm.runInContext(source.slice(start,end)+'\nglobalThis.show=renderMetrics;',context);
  return {cards,show:context.show};
}

test('compared views are not presented as passed, and UV is separate from texel copying', () => {
  const {cards,show}=metricRenderer();
  show({status:'review',metrics:{
    geometry_independent:{surface_geometry_equal:true,tessellation_equal:false},
    rgba_texels_preserved:true,uv_mapping_preserved:false,
    six_views:{size:256,views:Object.fromEntries(
      ['superior','frontal','inferior','trasera','izquierda','derecha'].map(side=>[side,{pixel_identical:false}]))}
  }});
  assert.equal(cards['metric-views'].children[1].textContent,'/ 6 comparadas');
  assert.match(cards['metric-views'].title,/0 de 6 vistas con píxeles idénticos a 256 × 256 px/);
  assert.equal(cards['metric-geometry'].textContent,'Coincidente');
  assert.match(cards['metric-geometry'].title,/división en caras es diferente/);
  assert.equal(cards['metric-textures'].textContent,'Píxeles conservados');
  assert.match(cards['metric-textures'].title,/UV contiene aproximaciones/);
});

test('an explicit surface mismatch cannot be colored green by a zero vertex error', () => {
  const {cards,show}=metricRenderer();
  show({status:'review',metrics:{geometry_independent:{surface_geometry_equal:false,max_vertex_error:0}}});
  assert.equal(cards['metric-geometry'].textContent,'Diferencias detectadas');
  assert.equal(cards['metric-geometry'].className,'warning');
  assert.match(cards['metric-views'].title,/0 de 0 vistas/);
});

test('independent UV/material mismatch vetoes a green texture card despite copied texels', () => {
  const {cards,show}=metricRenderer();
  show({status:'review',metrics:{
    geometry_independent:{surface_geometry_equal:true,uv_mapping_check_passed:false},
    rgba_texels_preserved:true,uv_mapping_preserved:true
  }});
  assert.equal(cards['metric-textures'].textContent,'Diferencias UV/material');
  assert.equal(cards['metric-textures'].className,'warning');
});

test('sampled previews use the supplied per-model limits and never claim a complete viewer mesh', () => {
  const source=fs.readFileSync(path.resolve(__dirname,'../web/app.js'),'utf8');
  const start=source.indexOf('  function previewCompleteness(');
  const end=source.indexOf('\n  function ',start+10);
  const context={};
  vm.createContext(context);
  vm.runInContext(source.slice(start,end)+'\nglobalThis.describe=previewCompleteness;',context);
  const text=context.describe({original_ir:{preview_simplified:true,preview_face_limit:6500},
    bedrock_ir:{preview_simplified:true,preview_face_limit:12000}});
  assert.match(text,/^Vista aligerada/);
  assert.match(text,/Original: máximo 6[.,]?500 caras/);
  assert.match(text,/Traducido: máximo 12[.,]?000 caras/);
  assert.match(context.describe({bedrock_ir:{preview_simplified:true}}),/12[.,]?000 caras/);
  assert.equal(context.describe({original_ir:{preview_simplified:false},bedrock_ir:{preview_simplified:false}}),'Geometría completa');
});

test('reconstructed surfaces are labeled explicitly without needing nested metrics', () => {
  const source=fs.readFileSync(path.resolve(__dirname,'../web/app.js'),'utf8');
  const start=source.indexOf('  function renderInspector(');
  const end=source.indexOf('\n  function ',start+10);
  const elements={};
  const context={state:{model:{report:{target_kind:'surface_reconstructed',status:'review'}}},
    STATUS_NAMES:{review:'Requiere revisión'},$:id=>elements[id] ||= {},
    renderViews(){},renderReport(){},renderMetrics(){},drawCanvases(){}};
  vm.createContext(context);
  vm.runInContext(source.slice(start,end)+'\nrenderInspector();',context);
  assert.equal(elements['target-view-label'].textContent,'Superficies · reconstruidas');
  assert.equal(elements['target-canvas-label'].textContent,'Superficies · reconstruidas');
  assert.equal(elements['diagnostic-warning'].hidden,false);
  assert.match(elements['diagnostic-warning'].textContent,/SUPERFICIES RECONSTRUIDAS/);
});

test('large per-face metadata stays outside the normal report DOM and raw JSON loads on demand', () => {
  const source=fs.readFileSync(path.resolve(__dirname,'../web/app.js'),'utf8');
  const start=source.indexOf('  function tableRow(');
  const end=source.indexOf('\n  function switchPanel(',start);
  const makeNode=(tag,className='',textContent='')=>({tag,className,textContent,children:[],handlers:{},
    append(...children){this.children.push(...children);},
    replaceChildren(...children){this.children=children;},
    addEventListener(name,handler){this.handlers[name]=handler;}});
  const content=makeNode('div');
  let visits=0;
  const huge={toJSON(){visits++;return {secret:'PER_FACE_DETAIL',rows:Array(12000).fill([1,2,3,4])};}};
  const report={id:'test:complex',status:'review',target_kind:'surface_approximation',metrics:{
    surface:{contour_refinement:{per_face:huge},texture_transfer:{direct_uv_rectangles:828,sampled_rectangles:0},exact_geometry:false},
    textures:{rgba_texels_preserved:true,transfer:huge},source_mesh_diagnostic:huge,
    additional_nested_metric:{faces:huge},scalar_metric:42
  }};
  const context={state:{activeId:'test:complex'},STATUS_NAMES:{review:'Requiere revisión'},
    SIDE_NAMES:{},node:makeNode,icon:name=>makeNode('svg','',name),
    document:{createDocumentFragment:()=>makeNode('fragment'),createTextNode:value=>value},
    numeric:v=>typeof v==='number'&&Number.isFinite(v),
    pretty:value=>value && typeof value==='object'?JSON.stringify(value):String(value),
    findValue:(object,keys)=>keys.map(key=>object?.[key]).find(value=>value!==undefined),
    $:()=>content,report};
  vm.createContext(context);
  vm.runInContext(source.slice(start,end)+'\nrenderReport(report);',context);
  const flatten=node=>typeof node==='string'?node:[node.textContent,...node.children.map(flatten)].join(' ');
  const before=flatten(content);
  assert.equal(visits,0,'normal inspection must not serialize per-face arrays');
  assert.ok(before.length<10000,'normal report remains bounded');
  assert.ok(!before.includes('PER_FACE_DETAIL'));
  assert.match(before,/surface_report.json/);
  assert.match(before,/1 campos · consultar reporte JSON/);
  const raw=content.children[0].children.find(node=>node.tag==='details'&&node.className==='report-raw');
  raw.open=true;raw.handlers.toggle();
  assert.ok(visits>0,'full JSON remains available on demand');
  assert.match(flatten(raw),/PER_FACE_DETAIL/);
  const alreadyVisited=visits;
  raw.handlers.toggle();
  assert.equal(visits,alreadyVisited,'opening an existing JSON body does not serialize it again');
  assert.strictEqual(report.metrics.surface.contour_refinement.per_face,huge,'source report is unchanged');
});

test('a skipped UV proof is disclosed without claiming a measured distortion', () => {
  const {cards,show}=metricRenderer();
  show({status:'review',metrics:{geometry_independent:{
    surface_geometry_equal:false,uv_mapping_check_passed:false,uv_mapping_check_performed:false
  },rgba_texels_preserved:true}});
  assert.equal(cards['metric-textures'].textContent,'UV sin verificar');
  assert.equal(cards['metric-textures'].className,'warning');
  assert.match(cards['metric-textures'].title,/No se ha medido una distorsión UV/);
});
