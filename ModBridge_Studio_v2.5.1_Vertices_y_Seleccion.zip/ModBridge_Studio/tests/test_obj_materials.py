"""Regression from NeoForge1.21.1 ObjModel.ModelMesh.addQuads/bake:
https://github.com/neoforged/NeoForge/blob/1.21.1/src/main/java/net/neoforged/neoforge/client/model/obj/ObjModel.java
An OBJ mesh whose material is null produces no baked quads.
"""
import io,json,tempfile,unittest,zipfile
from pathlib import Path
from PIL import Image
from bridge.resources import ResourcePack
from bridge.geometry import _Scene

class ObjMaterialsTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.texture=io.BytesIO();Image.new('RGBA',(16,16),(12,34,56,255)).save(self.texture,format='PNG')
    def tearDown(self):self.temp.cleanup()
    def scene(self,obj):
        jar=self.root/'fixture.jar'
        with zipfile.ZipFile(jar,'w') as z:
            z.writestr('assets/demo/models/block/mesh.obj',obj)
            z.writestr('assets/demo/models/block/mesh.mtl','newmtl visible\nmap_Kd #surface\n')
            z.writestr('assets/demo/textures/block/surface.png',self.texture.getvalue())
        pack=ResourcePack(jar);self.addCleanup(pack.close)
        scene=_Scene(pack,self.root/'out');scene.destination.mkdir(exist_ok=True)
        scene.add_obj({'loader':'neoforge:obj','model':'demo:models/block/mesh.obj','textures':{'surface':'demo:block/surface'}})
        return scene,jar
    def test_unassigned_helpers_are_not_missing_material_geometry(self):
        obj='''mtllib mesh.mtl
o Bounding
v 1000 1000 0
v 1001 1000 0
v 1000 1001 0
v 0 0 0
v 1 0 0
v 0 1 0
vt 0 0
vt 1 0
vt 0 1
f 1/1 2/2 3/3
o Visible
usemtl visible
f 4/1 5/2 6/3
'''
        scene,jar=self.scene(obj)
        self.assertEqual(len(scene.faces),1)
        self.assertFalse(scene.unresolved)
        self.assertEqual(set(scene.images),{'demo:block/surface'})
        self.assertLess(max(v[0] for f in scene.faces for v in f['vertices']),100)
        self.assertTrue(any('1 caras sin material' in w for w in scene.warnings))
        with zipfile.ZipFile(jar) as z:self.assertEqual(z.read('assets/demo/models/block/mesh.obj').decode(),obj)
    def test_material_persists_between_objects(self):
        obj='''mtllib mesh.mtl
v 0 0 0
v 1 0 0
v 0 1 0
vt 0 0
vt 1 0
vt 0 1
usemtl visible
o First
f 1/1 2/2 3/3
o Second
f 1/1 2/2 3/3
'''
        scene,_=self.scene(obj)
        self.assertEqual(len(scene.faces),2)
        self.assertFalse(scene.unresolved)
    def test_all_unassigned_faces_are_empty_visible_mesh(self):
        scene,_=self.scene('mtllib mesh.mtl\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 2 3\n')
        self.assertEqual(scene.faces,[])
        self.assertEqual(scene.images,{})
        self.assertFalse(scene.unresolved)

if __name__=='__main__':unittest.main()
