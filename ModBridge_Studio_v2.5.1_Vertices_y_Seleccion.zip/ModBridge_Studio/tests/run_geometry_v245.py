"""Reproducible real-asset regression for the nine families in the supplied PDFs.

The Create JAR is supplied by the caller and is never downloaded or redistributed
by this script. Screenshots are family references, not uniquely identified models.
Usage: python tests/run_geometry_v245.py --input create.jar --output audit --size 64
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import time


FAMILIES = {
    'valvulas': ['valve_handle'] + [f'{c}_valve_handle' for c in (
        'copper', 'white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime',
        'pink', 'gray', 'light_gray', 'cyan', 'purple', 'blue', 'brown', 'green', 'red', 'black')],
    'fuego': ['blaze_burner/block_with_fire', 'blaze_burner/block_with_soul_fire', 'blaze_burner/flame'],
    'protecciones': ['chain_conveyor/guard'],
    'transportador': ['chain_conveyor/item', 'chain_conveyor/wheel'],
    'trituradoras': ['crushing_wheel/block', 'crushing_wheel/item'],
    'volantes': ['flywheel/block', 'flywheel/item'],
    'ruedas_agua': ['large_water_wheel/block', 'large_water_wheel/block_extension',
                    'water_wheel/item', 'water_wheel/wheel', 'modbridge:block/water_wheel/assembled'],
    'rodillos': ['mechanical_roller/item', 'mechanical_roller/wheel'],
    'bogeys': ['track/bogey/bogey_drive', 'track/bogey/bogey_drive_piston',
               'track/bogey/bogey_drive_wheel', 'track/bogey/bogey_drive_wheel_pin',
               'track/bogey/bogey_frame', 'track/bogey/bogey_wheel'],
}
REPRESENTATIVES = ['copper_valve_handle', 'blaze_burner/block_with_fire', 'chain_conveyor/guard',
                   'chain_conveyor/item', 'crushing_wheel/block', 'flywheel/block',
                   'large_water_wheel/block', 'mechanical_roller/wheel',
                   'track/bogey/bogey_drive_wheel_pin', 'track/bogey/bogey_drive_wheel']
PDF_FAMILY_SCREENSHOTS = {'valvulas': 35, 'fuego': 3, 'protecciones': 1,
                         'transportador': 3, 'trituradoras': 3, 'volantes': 3,
                         'ruedas_agua': 8, 'rodillos': 3, 'bogeys': 6}


def resource_id(value):
    return value if ':' in value else 'create:block/' + value


def planar_metrics(ir):
    import numpy as np
    from bridge.rendering import _triangulate
    points = [p for f in ir.get('faces', []) for p in f['vertices']]
    area = 0.
    for face in ir.get('faces', []):
        v = np.asarray(face['vertices'], float)
        for a, b, c in _triangulate(v):
            area += float(np.linalg.norm(np.cross(v[b] - v[a], v[c] - v[a]))) / 2
    return {'face_count': len(ir.get('faces', [])), 'area': area,
            'bounds': [np.min(points, axis=0).tolist(), np.max(points, axis=0).tolist()] if points else None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--size', type=int, default=64)
    parser.add_argument('--representatives', action='store_true')
    parser.add_argument('--models', nargs='+')
    parser.add_argument('--recheck', action='store_true', help='Recheck existing decoded IR with the current verifier; keep rendered image evidence.')
    parser.add_argument('--program-root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    sys.path.insert(0, str(args.program_root.resolve()))
    from bridge import __version__
    from bridge.pipeline import run_conversion
    from bridge.resources import ResourcePack

    candidates = args.models or (REPRESENTATIVES if args.representatives else sum(FAMILIES.values(), []))
    selected = list(dict.fromkeys(resource_id(x) for x in candidates))
    family_for = {resource_id(x): family for family, names in FAMILIES.items() for x in names}
    with ResourcePack(args.input) as pack:
        available = set(pack.models())
    missing = [x for x in selected if x not in available]
    if missing:
        raise SystemExit('Missing required resources: ' + ', '.join(missing))
    start = time.monotonic()
    def progress(item):
        if item.get('message', '').startswith('Convirtiendo'):
            print(f"[{item['progress']+1}/{item['total']}] {item['current']}", flush=True)
    if args.recheck:
        from bridge.rendering import compare_geometry
        from bridge.verification import final_status
        result = json.loads((args.output/'result.json').read_text(encoding='utf-8'))
        for index, report in enumerate(result['reports']):
            directory = args.output/'models'/report['slug']
            print(f"Recheck [{index+1}/{len(result['reports'])}] {report['id']}", flush=True)
            source = json.loads((directory/'ir_original.json').read_text(encoding='utf-8'))
            target = json.loads((directory/'ir_bedrock.json').read_text(encoding='utf-8'))
            geometry = compare_geometry(source, target)
            report.setdefault('metrics', {})['geometry_independent'] = geometry
            report['metrics'].setdefault('six_views', {})['geometry'] = geometry
            report['status'] = final_status(report)
            (directory/'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
            views_file = directory/'vistas'/'comparacion.json'
            if views_file.exists():
                views = json.loads(views_file.read_text(encoding='utf-8')); views['geometry'] = geometry
                views_file.write_text(json.dumps(views, ensure_ascii=False, indent=2), encoding='utf-8')
        (args.output/'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    else:
        result = run_conversion(args.input, args.output, models=selected, size=args.size,
                                mesh_mode='surface', make_export=False, progress=progress)
    rows = []
    for report in result['reports']:
        directory = args.output / 'models' / report['slug']
        row = {'id': report['id'], 'family': family_for.get(report['id'], 'additional'),
               'status': report['status'], 'target_kind': report.get('target_kind'),
               'warnings': report.get('warnings', [])}
        for kind, name in [('source', 'ir_original.json'), ('target', 'ir_bedrock.json')]:
            path = directory / name
            if path.exists():
                row[kind] = planar_metrics(json.loads(path.read_text(encoding='utf-8')))
        metrics = report.get('metrics', {})
        geometry = metrics.get('geometry_independent', {})
        views = metrics.get('six_views', {})
        row.update(surface_geometry_equal=geometry.get('surface_geometry_equal'),
                   tessellation_equal=geometry.get('tessellation_equal'),
                   texture_sample_check_passed=geometry.get('texture_sample_check_passed'),
                   uv_mapping_check_passed=geometry.get('uv_mapping_check_passed'),
                   rgba_texels_preserved=metrics.get('rgba_texels_preserved'),
                   six_views_identical=views.get('all_views_pixel_identical'),
                   equal_views=sum(v.get('pixel_identical', False) for v in views.get('views', {}).values()),
                   rgba_mae_mean=views.get('rgba_mae_mean'), geometry=geometry)
        surface_file = directory / 'surface_report.json'
        if surface_file.exists(): row['surface_report'] = json.loads(surface_file.read_text(encoding='utf-8'))
        rows.append(row)
    data = {
        'program_version': __version__, 'source_file': args.input.name,
        'source_sha256': hashlib.sha256(args.input.read_bytes()).hexdigest(),
        'runtime_tested': False, 'view_size': args.size, 'model_count': len(rows),
        'families': sorted(set(x['family'] for x in rows)),
        'elapsed_seconds': round(time.monotonic()-start, 2),
        'source_screenshots': 65, 'source_pdf_pages': 29,
        'pdf_family_screenshots': PDF_FAMILY_SCREENSHOTS,
        'identification_limit': 'Resources are candidates identified by family; PDF crops omit model IDs. 65 screenshots are not 65 unique models.',
        'rows': rows,
    }
    output = args.output / 'regression.json'
    output.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps({k: v for k, v in data.items() if k != 'rows'}, ensure_ascii=False), flush=True)
    print('report:', output, flush=True)


if __name__ == '__main__':
    main()
