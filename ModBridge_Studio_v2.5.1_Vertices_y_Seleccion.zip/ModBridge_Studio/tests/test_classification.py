import json,tempfile,unittest,zipfile
from pathlib import Path
from bridge.resources import ResourcePack
from bridge.classification import classify_unconverted,model_catalogue

class ClassificationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'models.jar'
    def tearDown(self):self.tmp.cleanup()
    def pack(self,models,states=None):
        with zipfile.ZipFile(self.path,'w') as z:
            for name,obj in models.items():z.writestr('assets/test/models/'+name+'.json',json.dumps(obj))
            for name,obj in (states or {}).items():z.writestr('assets/test/blockstates/'+name+'.json',json.dumps(obj))
        p=ResourcePack(self.path);self.addCleanup(p.close);return p
    def surface(self):return {'elements':[{'from':[0,0,0],'to':[16,16,16],'faces':{'north':{'texture':'#side'}}}]}
    def test_template_links_concrete_descendants(self):
        p=self.pack({'base':self.surface(),'middle':{'parent':'test:base'},'instance':{'parent':'test:middle','textures':{'side':'test:block/red'}}})
        r=classify_unconverted(p,'test:base')
        self.assertEqual(r['kind'],'abstract_template');self.assertTrue(r['not_renderable_asset']);self.assertFalse(r['conversion_success'])
        self.assertEqual(r['evidence']['concrete_descendants'],['test:instance'])
        self.assertEqual(r['evidence']['direct_children'],['test:middle'])
    def test_unbound_unknown_is_not_excluded(self):
        p=self.pack({'unbound':self.surface()});r=classify_unconverted(p,'test:unbound')
        self.assertEqual(r['kind'],'missing_texture_binding');self.assertTrue(r['coverage_eligible'])
    def test_blank_parent_has_concrete_child(self):
        p=self.pack({'base':{'display':{}},'instance':dict(self.surface(),parent='test:base',textures={'side':'test:red'})})
        r=classify_unconverted(p,'test:base');self.assertEqual(r['kind'],'abstract_template')
    def test_empty_used_by_blockstate_stays_runtime_pending(self):
        p=self.pack({'blank':{'elements':[],'textures':{'particle':'test:water'}}},{'water':{'variants':{'':{'model':'test:blank'}}}})
        r=classify_unconverted(p,'test:blank');self.assertEqual(r['kind'],'runtime_renderer');self.assertTrue(r['coverage_eligible'])
    def test_explicit_unused_empty_separate_from_unknown(self):
        p=self.pack({'empty':{'elements':[]},'unknown':{'textures':{'particle':'test:x'}}})
        self.assertEqual(classify_unconverted(p,'test:empty')['kind'],'empty_resource')
        self.assertEqual(classify_unconverted(p,'test:unknown')['kind'],'unresolved_resource')
    def test_dependency_failure_is_not_abstract(self):
        p=self.pack({'base':{'parent':'missing:shape'},'child':{'parent':'test:base','textures':{'side':'test:x'}}})
        r=classify_unconverted(p,'test:base');self.assertEqual(r['kind'],'missing_dependency');self.assertTrue(r['coverage_eligible'])
    def test_cycles_terminate_and_catalogue_cached(self):
        p=self.pack({'a':{'parent':'test:b'},'b':{'parent':'test:a'}})
        r=classify_unconverted(p,'test:a');self.assertEqual(r['evidence']['descendant_models'],['test:b'])
        self.assertIs(model_catalogue(p),model_catalogue(p))
    def test_direct_item_override_means_use_site_not_abstract(self):
        p=self.pack({'blank':{'elements':[]},'item':{'overrides':[{'predicate':{'damaged':1},'model':'test:blank'}]}})
        self.assertEqual(classify_unconverted(p,'test:blank')['kind'],'runtime_renderer')

    def test_inherited_air_is_intentionally_invisible_even_in_blockstate(self):
        with zipfile.ZipFile(self.path,'w') as z:
            z.writestr('assets/minecraft/models/block/air.json','{}')
            z.writestr('assets/test/models/hidden.json',json.dumps({'parent':'minecraft:block/air'}))
            z.writestr('assets/test/models/descendant.json',json.dumps({'parent':'test:hidden'}))
            z.writestr('assets/test/blockstates/hidden.json',json.dumps({'variants':{'':{'model':'test:descendant'}}}))
        with ResourcePack(self.path) as p:
            r=classify_unconverted(p,'test:descendant')
        self.assertEqual(r['kind'],'intentionally_empty')
        self.assertTrue(r['not_renderable_asset']);self.assertFalse(r['coverage_eligible'])
        self.assertFalse(r['conversion_success'])
        self.assertEqual(r['evidence']['parent_chain'],['test:descendant','test:hidden','minecraft:block/air'])
        self.assertEqual(r['evidence']['invisible_parent']['path'],'assets/minecraft/models/block/air.json')
        self.assertEqual(len(r['evidence']['invisible_parent']['sha256']),64)
        self.assertTrue(r['evidence']['blockstate_references'])

    def test_air_child_with_added_geometry_is_not_ignored(self):
        data=dict(self.surface(),parent='minecraft:block/air')
        p=self.pack({'visible':data})
        r=classify_unconverted(p,'test:visible')
        self.assertNotEqual(r['kind'],'intentionally_empty');self.assertTrue(r['coverage_eligible'])

    def test_air_override_with_runtime_loader_is_not_treated_as_invisible(self):
        with zipfile.ZipFile(self.path,'w') as z:
            z.writestr('assets/minecraft/models/block/air.json',json.dumps({'loader':'custom:dynamic'}))
            z.writestr('assets/test/models/hidden.json',json.dumps({'parent':'minecraft:block/air'}))
        with ResourcePack(self.path) as p:r=classify_unconverted(p,'test:hidden')
        self.assertEqual(r['kind'],'runtime_renderer');self.assertTrue(r['coverage_eligible'])

if __name__=='__main__':unittest.main()
