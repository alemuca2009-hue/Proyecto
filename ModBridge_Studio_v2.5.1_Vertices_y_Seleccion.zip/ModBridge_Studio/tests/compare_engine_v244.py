"""Compare restored output with an untouched 2.4.4 checkout in separate processes.

python tests/compare_engine_v244.py --legacy-root ../original/ModBridge_Studio \
    --input create.jar --manifest models.json --output ../parity

The manifest is {"models": [{"id": "namespace:block/model"}, ...]}.
No renderer or geometry repair is involved. Differences fail the command.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def snapshot(directory):
    # Reports add provenance in the new API; geometry, texture bytes, original
    # assets and all decoded IR must match. Normalize only output-directory paths.
    names = ['model.geo.json', 'atlas.png', 'atlas_map.json', 'atlas_original_map.json',
             'experimental.poly_mesh.json', 'source_mesh_atlas.png',
             'surface_report.json', 'ir_original.json', 'ir_bedrock.json',
             'ir_source_mesh.json', 'surface/surface_atlas.png']
    names += [p.relative_to(directory).as_posix() for p in (directory/'originals').rglob('*') if p.is_file()]
    def normalize(value):
        if isinstance(value, dict): return {key:normalize(item) for key,item in value.items()}
        if isinstance(value, list): return [normalize(item) for item in value]
        if isinstance(value, str):
            return value.replace(str(directory), '<MODEL>').replace(directory.as_posix(), '<MODEL>')
        return value
    hashes = {}
    for name in sorted(names):
        path = directory/name
        if not path.is_file():
            continue
        data = path.read_bytes()
        if name.endswith('.json') and not name.startswith('originals/'):
            # Canonical JSON retains numbers/arrays/UV/vertices/wire edges exactly.
            payload = normalize(read(path))
            text = json.dumps(payload, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
            data = text.encode()
        hashes[name] = sha(data)
    return hashes


def worker(args):
    sys.path.insert(0, str(args.program_root.resolve()))
    if args.worker == 'legacy':
        from bridge.geometry import convert_model
        from bridge.surface_adapter import adapt_surface
        from bridge.resources import ResourcePack
        from bridge.pipeline import model_slug
        from bridge.model_profile import finalize_model_profile
    else:
        from conversion_engine import ResourcePack, convert_in_pack, model_slug, SurfaceSettings
    models = [row['id'] for row in read(args.manifest)['models']]
    rows = []
    with ResourcePack(args.input.resolve()) as pack:
        for mode in args.modes:
            for mid in models:
                start = time.monotonic()
                md = args.output.resolve()/mode/model_slug(mid)
                if args.worker == 'legacy':
                    report = convert_model(pack, mid, md)
                    source = read(md/'ir_original.json')
                    if mode == 'surface' and report.get('target_kind') == 'experimental_poly_mesh':
                        report, _ = adapt_surface(report, source, md, model_slug(mid))
                    # The original 2.4.4 pipeline finalizes culling metadata after
                    # conversion. This now belongs to the standalone API too.
                    report['id'] = mid
                    finalize_model_profile(report, source, read(md/'ir_bedrock.json'), md)
                else:
                    report = convert_in_pack(pack, mid, md, mesh_mode=mode, settings=SurfaceSettings(refinement_passes=0)).report
                row = {'id': mid, 'mode': mode, 'target_kind': report['target_kind'],
                       'source_faces': len(read(md/'ir_original.json')['faces']),
                       'target_faces': len(read(md/'ir_bedrock.json')['faces']),
                       'files': snapshot(md), 'seconds': round(time.monotonic()-start, 3)}
                rows.append(row)
                print(f"{args.worker} {mode} {mid}: {row['target_faces']} faces", flush=True)
    save(args.output/'snapshot.json', rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--legacy-root', type=Path)
    parser.add_argument('--program-root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--modes', nargs='+', choices=['surface', 'exact'], default=['surface', 'exact'])
    parser.add_argument('--worker', choices=['legacy', 'modular'], help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        worker(args)
        return
    if not args.legacy_root:
        parser.error('--legacy-root is required')
    if args.output.exists() and any(args.output.iterdir()):
        parser.error('--output must be a new/empty directory')
    source_hash = sha(args.input.read_bytes())
    for label, root in [('legacy', args.legacy_root), ('modular', args.program_root)]:
        subprocess.run([sys.executable, str(Path(__file__).resolve()), '--worker', label,
                        '--program-root', str(root.resolve()), '--input', str(args.input.resolve()),
                        '--manifest', str(args.manifest.resolve()), '--output', str((args.output/label).resolve()),
                        '--modes', *args.modes], check=True)
    old, new = [read(args.output/label/'snapshot.json') for label in ('legacy', 'modular')]
    comparisons = []
    for a, b in zip(old, new):
        assert (a['id'], a['mode']) == (b['id'], b['mode'])
        different = [name for name in sorted(set(a['files']) | set(b['files']))
                     if a['files'].get(name) != b['files'].get(name)]
        comparisons.append({'id': a['id'], 'mode': a['mode'], 'source_faces': a['source_faces'],
                            'target_faces': b['target_faces'], 'files_checked': len(a['files']),
                            'identical': not different and a['target_kind'] == b['target_kind'],
                            'different_files': different, 'legacy_sha256': a['files'],
                            'modular_sha256': b['files']})
    result = {'algorithm_version': '2.4.4', 'source': args.input.name, 'source_sha256': source_hash,
              'source_unchanged': sha(args.input.read_bytes()) == source_hash,
              'model_count': len(read(args.manifest)['models']), 'comparison_count': len(comparisons),
              'all_identical': len(old) == len(new) and all(r['identical'] for r in comparisons),
              'normalization': 'Only output-directory paths and JSON formatting/key order; PNG and original assets are byte-for-byte.',
              'runtime_tested': False, 'rows': comparisons}
    save(args.output/'comparison.json', result)
    print(json.dumps({k:v for k,v in result.items() if k != 'rows'}, indent=2))
    if not result['all_identical'] or not result['source_unchanged']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
