"""Model-only export boundaries, source scale and metadata preservation."""
import copy
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from bridge.model_profile import describe_model, size_profile, refresh_visible_bounds
from bridge.geometry import decode_bedrock
from bridge.pipeline import run_conversion, export_result
from bridge.resources import ResourcePack, asset_path
from bridge.water_wheel import ASSEMBLED_ID
from bridge.reference import ReferenceAddon
from test_pipeline import make_fixture


class ModelOnlyTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()

    def test_block_size_profile_is_not_a_one_block_clamp(self):
        self.assertTrue(size_profile([[-10,0,-10],[10,20,10]])['block_compatible'])
        self.assertTrue(size_profile([[-15,0,-15],[15,30,15]])['block_compatible'])
        p=size_profile([[-39,-1.5,-39],[39,17.5,39]])
        self.assertFalse(p['block_compatible'])
        self.assertEqual(p['dimensions_blocks'],[4.875,1.1875,4.875])
        for bad in (None,[],[0,0],[[0,0,0],[float('nan'),1,1]],[[0,0,0],[-1,1,1]]):
            self.assertFalse(size_profile(bad)['valid'])

    def test_profile_only_recommends_geometry_usage(self):
        ir={'bounds':[[-39,-1.5,-39],[39,17.5,39]],'faces':[{}]}
        report={'id':'fixture:block/large','status':'review','target_kind':'surface_approximation'}
        p=describe_model(report,ir,ir)
        self.assertEqual(p['geometry_usage'],'entity_geometry')
        self.assertEqual(p['global_scale'],1)
        self.assertFalse(p['creates_game_content'])
        for r,source in [(dict(report,target_kind='experimental_poly_mesh'),ir),
                         (report,dict(ir,texture_metadata={'missing':{'missing':True}}))]:
            self.assertEqual(describe_model(r,source,ir)['geometry_usage'],'diagnostic_only')

    def test_visibility_updates_only_description_and_reverses_x_offset(self):
        geometry={'minecraft:geometry':[{'description':{'identifier':'geometry.fixture','texture_width':16,'texture_height':16},
            'bones':[{'name':'root','pivot':[0,8,0],'cubes':[{'origin':[2,3,4],'size':[8,9,10],'uv':[0,0]}]}]}]}
        before=copy.deepcopy(geometry)
        result=refresh_visible_bounds(geometry,[[10,-20,-40],[90,20,40]])
        self.assertEqual(geometry['minecraft:geometry'][0]['bones'],before['minecraft:geometry'][0]['bones'])
        self.assertEqual(result,{'visible_bounds_width':6.0,'visible_bounds_height':3.5,'visible_bounds_offset':[-3.125,0.0,0.0]})
        self.assertEqual(geometry['minecraft:geometry'][0]['description']['texture_width'],16)

    def test_large_geometry_roundtrip_preserves_pixels_and_has_no_runtime_pack(self):
        jar=self.root/'test.jar';source=make_fixture(jar)
        large={'textures':{'t':'fixture:block/asymmetric'},'elements':[{'from':[-31,-1.5,-31],'to':[47,17.5,47],
               'faces':{d:{'texture':'#t','uv':[0,0,16,16]} for d in ('north','south','east','west','up','down')}}]}
        with zipfile.ZipFile(jar,'a') as z:z.writestr(asset_path('fixture:block/large'),json.dumps(large))
        result=run_conversion(jar,self.root/'run',models=['fixture:block/large'],size=64)
        r=result['reports'][0];md=self.root/'run/models'/r['slug']
        source_ir=json.loads((md/'ir_original.json').read_text())
        geo=json.loads((md/'model.geo.json').read_text())
        target=decode_bedrock(geo,md/'atlas.png')
        self.assertEqual(source_ir['bounds'],target['bounds'])
        self.assertEqual(r['model_profile']['target']['dimensions_pixels'],[78,19,78])
        self.assertEqual(r['model_profile']['geometry_usage'],'entity_geometry')
        self.assertTrue(r['metrics']['six_views']['all_views_pixel_identical'])
        self.assertEqual(len(geo['minecraft:geometry'][0]['bones']),1)
        self.assertNotIn('bedrock_integration',r)
        with zipfile.ZipFile(result['archive']) as z:
            self.assertIsNone(z.testzip())
            self.assertFalse(any(n.endswith(('.mcaddon','.mcpack','.js')) for n in z.namelist()))
            self.assertFalse(any('/entities/' in n or '/animations/' in n or n.endswith('manifest.json') for n in z.namelist()))
            self.assertEqual(z.read('modelos_originales/assets/fixture/textures/block/asymmetric.png'),source['assets/fixture/textures/block/asymmetric.png'])

    def test_reexport_and_partial_export_cannot_leak_old_gameplay_files(self):
        jar=self.root/'test.jar';make_fixture(jar)
        run=self.root/'run';result=run_conversion(jar,run,models=['fixture:block/sample'],size=64)
        # Simulate a previous release's generated files and cached report fields.
        old=Path(result['export_dir'])/'paquete_bedrock/anclajes';old.mkdir(parents=True)
        (old/'main.js').write_text('obsolete gameplay')
        stale=copy.deepcopy(result['reports']);stale[0].pop('model_profile')
        stale[0]['bedrock_integration']={'enabled':True,'strategy':'block_anchor_entity'}
        for name in ('exportacion','exportacion_parcial'):
            exported=export_result(run,stale,{},planned_total=2,export_name=name)
            self.assertTrue(exported['summary']['cancelled'])
            self.assertFalse((Path(exported['export_dir'])/'paquete_bedrock').exists())
            self.assertNotIn('bedrock_integration',exported['reports'][0])
            self.assertEqual(exported['reports'][0]['model_profile']['scope'],'models_only')
            with zipfile.ZipFile(exported['archive']) as z:
                self.assertFalse(any(n.endswith(('.js','.mcaddon','.mcpack')) for n in z.namelist()))

    def test_assembly_is_an_extra_static_model_and_keeps_sources(self):
        jar=self.root/'test.jar';make_fixture(jar)
        base={'elements':[{'from':[0,0,0],'to':[16,16,16],'faces':{}}]}
        rotor={'loader':'neoforge:obj','model':'create:models/block/water_wheel/water_wheel.obj'}
        with zipfile.ZipFile(jar,'a') as z:
            z.writestr(asset_path('create:block/water_wheel/block'),json.dumps(base))
            z.writestr(asset_path('create:block/water_wheel/wheel'),json.dumps(rotor))
        with ResourcePack(jar) as pack:
            before=pack.read_bytes(asset_path('create:block/water_wheel/block'))
            self.assertIn(ASSEMBLED_ID,pack.models())
            self.assertEqual(pack.read_json(asset_path(ASSEMBLED_ID))['children']['rotor'],'create:block/water_wheel/wheel')
            self.assertEqual(pack.read_bytes(asset_path('create:block/water_wheel/block')),before)
            self.assertFalse(pack._virtual_attempted)

    def test_reference_extracts_geometry_and_texture_aliases_without_behavior(self):
        addon=self.root/'reference.mcaddon'
        def geo(name,size):return {'description':{'identifier':name},'bones':[{'name':'root','cubes':[{'origin':[-8,0,-8],'size':size}]}]}
        records={
          'BP/blocks/water_wheel.json':{'minecraft:block':{'description':{'identifier':'create:water_wheel'},'components':{'minecraft:geometry':'geometry.base'}}},
          'RP/entity/water_wheel.json':{'minecraft:client_entity':{'description':{'identifier':'create:water_wheel_entity',
            'geometry':{'default':'geometry.rotor'},'textures':{'oak':'textures/oak','mangrove':'textures/oak'},'render_controllers':['controller.wood']}}},
          'RP/models/water_wheel.json':{'minecraft:geometry':[geo('geometry.base',[16,16,16]),geo('geometry.rotor',[32,32,16])]},
          'RP/render_controllers/water_wheel.json':{'render_controllers':{'controller.wood':{'arrays':{'textures':{'Array.wood':['Texture.oak','Texture.mangrove']}}}}}}
        with zipfile.ZipFile(addon,'w') as z:
            for name,value in records.items():z.writestr(name,json.dumps(value))
        audit=ReferenceAddon(addon).water_wheels;r=audit['wheels'][0]
        self.assertEqual(r['unique_variant_textures'],1)
        self.assertEqual(r['geometries']['entity']['profile']['dimensions_pixels'],[32,32,16])
        self.assertEqual(audit['scope'],'geometry_reference_only')
        self.assertNotIn('entity_components',r)
        self.assertNotIn('script_evidence',audit)


if __name__=='__main__':unittest.main()
