"""Actual metric-card states and reconstructed-review classification, 2.4.6."""
import copy
import http.client
import json
import tempfile
import threading
import unittest
import zipfile
from pathlib import Path
from http.server import ThreadingHTTPServer
from unittest.mock import patch

from app import Studio, make_handler, read_json
from bridge.analysis_states import ANALYSIS_FILTERS, analysis_states
from bridge.catalog import compact_report
from bridge.pipeline import run_conversion, export_result
from bridge.verification import final_status, has_reconstructed_surface_notice
from test_pipeline import make_fixture


def report(**extra):
    return {'id':'fixture:block/sample','slug':'sample','status':'review',
            'metrics':{'geometry_independent':{'surface_geometry_equal':True},
                       'rgba_texels_preserved':True},**extra}


class ReconstructedReviewTests(unittest.TestCase):
    def test_both_banner_paths_demote_without_mutating_evidence(self):
        for kind in ('surface_reconstructed','surface_approximation'):
            item=report(status='verified_static',target_kind=kind)
            item['metrics']['surface']={'exact_geometry':True,'original_data':[1,2,3]}
            before=copy.deepcopy(item)
            self.assertTrue(has_reconstructed_surface_notice(item))
            self.assertEqual(final_status(item),'review')
            compact=compact_report(item)
            self.assertEqual(compact['status'],'review')
            self.assertTrue(compact['requires_surface_review'])
            self.assertIn('surface_reconstructed',compact['analysis']['geometry'])
            self.assertEqual(compact_report(compact),compact)
            self.assertEqual(item,before)

    def test_native_exact_and_nonexact_approximation_do_not_trigger_banner_rule(self):
        for kind,exact in [('entity_geometry',True),('block_or_entity_geometry',True),
                           ('surface_approximation',False),('surface_approximation','true')]:
            item=report(target_kind=kind)
            item['metrics']['surface']={'exact_geometry':exact}
            self.assertFalse(has_reconstructed_surface_notice(item))
            self.assertEqual(final_status(item),'verified_static')

    def test_http_status_hydrates_legacy_compact_entries_without_rewriting_sources(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);jar=root/'fixture.jar';make_fixture(jar)
            studio=Studio(root/'workspace',java=jar)
            run=studio.workspace/'runs'/'legacy';studio.run=run
            source_entries=[];protected={}
            for name,kind in [('sample','surface_reconstructed'),('base','surface_approximation'),('missing','entity_geometry')]:
                detailed=report(id='fixture:block/'+name,slug=name,status='verified_static',target_kind=kind)
                detailed['metrics']['surface']={'exact_geometry':True}
                md=run/'models'/name;md.mkdir(parents=True)
                path=md/'report.json';path.write_text(json.dumps(detailed,indent=2))
                protected[path]=(path.read_bytes(),path.stat().st_mtime_ns)
                legacy={key:detailed[key] for key in ('id','slug','status')}
                legacy['extended3d']=False;source_entries.append(legacy)
            studio.result={'reports':copy.deepcopy(source_entries)}
            studio.ready[source_entries[0]['id']]={**source_entries[0],'run':str(run)}
            original_result=copy.deepcopy(studio.result);original_ready=copy.deepcopy(studio.ready)
            server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(studio))
            thread=threading.Thread(target=lambda:server.serve_forever(poll_interval=.01),daemon=True);thread.start()
            def get(path):
                connection=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=5)
                try:
                    connection.request('GET',path);response=connection.getresponse()
                    self.assertEqual(response.status,200)
                    return json.loads(response.read())
                finally:connection.close()
            try:
                with patch('app.read_json',wraps=read_json) as reads:
                    for path in ('/api/status','/api/status?compact=1'):
                        payload=get(path)
                        reports=payload['result']['reports']
                        self.assertEqual([r['status'] for r in reports],['review','review','verified_static'])
                        self.assertEqual(payload['ready_models'][0],reports[0])
                        self.assertTrue(all('surface_reconstructed' in r['analysis']['geometry'] for r in reports[:2]))
                        self.assertTrue(all(r['analysis']['textures']==['pixels_preserved'] for r in reports))
                        self.assertEqual(payload['render_job']['state'],'idle')
                        self.assertNotIn(str(studio.workspace),json.dumps(payload))
                    self.assertEqual(reads.call_count,3,'Each legacy full report is hydrated once, including shared ready/result entries')
                self.assertEqual(get('/api/analysis-filters'),ANALYSIS_FILTERS)
                self.assertEqual(studio.result,original_result);self.assertEqual(studio.ready,original_ready)
                for path,(data,mtime) in protected.items():
                    self.assertEqual(path.read_bytes(),data);self.assertEqual(path.stat().st_mtime_ns,mtime)
            finally:
                server.shutdown();server.server_close();thread.join(timeout=3)

    def test_legacy_model_read_and_reexport_preserve_all_original_bytes(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);jar=root/'fixture.jar';make_fixture(jar)
            run=root/'run';result=run_conversion(jar,run,models=['fixture:block/sample'],size=64)
            old=copy.deepcopy(result['reports'][0]);old.update(target_kind='surface_reconstructed',status='verified_static')
            md=run/'models'/old['slug']
            (md/'report.json').write_text(json.dumps(old))
            protected={p:p.read_bytes() for p in md.rglob('*') if p.is_file()}
            studio=Studio(root/'workspace',java=jar)
            studio.ready[old['id']]={**compact_report(old),'run':str(run)}
            self.assertEqual(studio.model(old['id'])['report']['status'],'review')
            self.assertEqual(studio.status()['ready_models'][0]['status'],'review')
            exported=export_result(run,[old],{},export_name='exportacion')
            self.assertEqual(exported['summary']['statuses'],{'review':1})
            with zipfile.ZipFile(exported['archive']) as archive:
                saved=json.loads(archive.read('reportes/modelos/'+old['slug']+'.json'))
                self.assertEqual(saved['status'],'review')
                self.assertEqual(saved['metrics'],old['metrics'])
                for name in ('model.geo.json','atlas.png','atlas_map.json'):
                    self.assertEqual(archive.read('modelos_traducidos/'+old['slug']+'/'+name),protected[md/name])
            for path,data in protected.items():self.assertEqual(path.read_bytes(),data)


class AnalysisStateTests(unittest.TestCase):
    def test_geometry_card_states_and_existing_target_kinds(self):
        cases=[({'surface_geometry_equal':True},'matching'),
               ({'surface_geometry_equal':False},'different'),
               ({'max_vertex_error':0},'vertex_error'), ({},'report')]
        for metrics,expected in cases:
            item=report(metrics={'geometry_independent':metrics})
            self.assertEqual(analysis_states(item)['geometry'],[expected])
        self.assertEqual(analysis_states(report(status='verified_static',metrics={}))['geometry'],['verified'])
        self.assertEqual(analysis_states(None)['geometry'],['unreviewed'])
        for kind in ('experimental_poly_mesh','surface_approximation','block_or_entity_geometry','entity_geometry'):
            self.assertIn(kind,analysis_states(report(target_kind=kind))['geometry'])

    def test_texture_card_precedence_and_all_eight_states(self):
        examples=[(None,'unreviewed'),
            (report(metrics={'six_views':{'missing_textures':{'original':['x']}}}),'missing'),
            (report(metrics={'geometry_independent':{'uv_mapping_check_passed':False,'uv_mapping_check_performed':False}}),'uv_unverified'),
            (report(metrics={'geometry_independent':{'uv_mapping_check_passed':False}}),'uv_difference'),
            (report(metrics={'rgba_texels_preserved':True}),'pixels_preserved'),
            (report(metrics={'rgba_texels_preserved':False}),'different'),
            (report(status='verified_static',metrics={}),'verified'),
            (report(metrics={}),'report')]
        for item,expected in examples:
            self.assertEqual(analysis_states(item)['textures'],[expected])
        item=report(metrics={'rgba_texels_preserved':True,
            'geometry_independent':{'uv_mapping_check_passed':False},
            'six_views':{'missing_textures':{'translated':['atlas']}}})
        self.assertEqual(analysis_states(item)['textures'],['missing'])

    def test_alias_precedence_and_strict_boolean_behavior(self):
        item=report(metrics={'surface_geometry_equal':True,'rgba_texels_preserved':True,
                             'geometry_independent':{},'textures':{}})
        self.assertEqual(analysis_states(item),{'geometry':['report'],'textures':['report']})
        for value in ('true',1,None):
            item=report(metrics={'surface_geometry_equal':value,'rgba_texels_preserved':value})
            self.assertEqual(analysis_states(item),{'geometry':['report'],'textures':['report']})
        item=report(metrics={'max_vertex_error_pixels':None,'geometry_independent':{'max_vertex_error':.2}})
        self.assertEqual(analysis_states(item)['geometry'],['vertex_error'])

    def test_stale_compact_flag_preserves_review_filter_and_cleans_invalid_facets(self):
        item={'status':'verified_static','requires_surface_review':True,
              'analysis':{'geometry':['matching','matching',{},'invented'],'textures':None}}
        before=copy.deepcopy(item)
        compact=compact_report(item)
        self.assertEqual(compact['status'],'review')
        self.assertEqual(compact['analysis'],{'geometry':['matching','surface_reconstructed'],'textures':[]})
        self.assertEqual(compact_report(compact),compact)
        self.assertEqual(item,before)

    def test_facet_metadata_and_compact_projection_are_bounded(self):
        for category,options in ANALYSIS_FILTERS.items():
            self.assertEqual(len(options),len({item['id'] for item in options}))
            self.assertTrue(all(item['label'] and item['source'] for item in options))
        item=report(metrics={'surface':{'large':[{'x':list(range(10))}]*12000}})
        compact=compact_report(item)
        self.assertLess(len(json.dumps(compact)),350)
        self.assertNotIn('metrics',compact)
        self.assertEqual(compact_report(compact),compact)


if __name__=='__main__':unittest.main()
