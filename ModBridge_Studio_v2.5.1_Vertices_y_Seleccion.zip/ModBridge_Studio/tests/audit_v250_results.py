"""Reprocess the actual exported IR/textures from a user's result ZIP.

python tests/audit_v250_results.py --results ModBridge_resultado.zip --output audit
Optional --renders selects the models named in an exported render ZIP.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import posixpath
import sys
import time
import zipfile

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from conversion_engine.adaptive import convert_with_refinement
from conversion_engine.settings import load_settings
from conversion_engine.geometry import decode_bedrock
from conversion_engine.pack import write_json
from bridge.rendering import compare_geometry


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results',required=True,type=Path)
    parser.add_argument('--renders',type=Path)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--models',nargs='+')
    args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    selected=set(args.models or [])
    if args.renders:
        with zipfile.ZipFile(args.renders) as z:
            selected.update(r['id'] for r in json.loads(z.read('RENDERS_EXPORTADOS/manifiesto.json'))['models'])
    rows=[];settings=load_settings()
    with zipfile.ZipFile(args.results) as z:
        reports=[json.loads(z.read(n)) for n in z.namelist() if n.startswith('reportes/modelos/') and n.endswith('.json')]
        reports=[r for r in reports if (r['id'] in selected if selected else r.get('target_kind')=='surface_approximation')]
        for index,report in enumerate(reports,1):
            start=time.monotonic();slug=report['slug'];md=out/'models'/slug
            row={'id':report['id'],'source_kind':report.get('target_kind'),'before_geometry_coincident':report.get('metrics',{}).get('geometry_independent',{}).get('surface_geometry_equal')}
            try:
                ir_name='intermedio/'+slug+'/ir_original.json'
                source=json.loads(z.read(ir_name))
                for key,relative in list(source['textures'].items()):
                    name=posixpath.normpath(posixpath.join(posixpath.dirname(ir_name),relative))
                    if name.startswith('../') or PurePosixPath(name).is_absolute():raise ValueError('Unsafe texture path')
                    data=z.read(name);dest=md/'textures'/(hashlib.sha256(name.encode()).hexdigest()[:12]+'.png')
                    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);source['textures'][key]=str(dest)
                write_json(md/'source_ir.json',source)
                if report.get('target_kind')!='surface_approximation':
                    row['skipped']='Native geometry; retained for separate diagnosis.'
                else:
                    result=convert_with_refinement(source,md/'surface',settings)
                    target=decode_bedrock(result['geometry'],result['atlas_path'])
                    for face,edges in zip(target['faces'],result['wire_edges']):face['wire_edges']=edges
                    write_json(md/'model.geo.json',result['geometry']);write_json(md/'target_ir.json',target)
                    write_json(md/'surface_report.json',result['report'])
                    independent=compare_geometry(source,target)
                    write_json(md/'independent.json',independent)
                    adaptive=result['report']['adaptive_refinement']
                    row.update(after_geometry_coincident=independent['surface_geometry_equal'],
                               adaptive=adaptive,source_faces=len(source['faces']),target_faces=len(target['faces']))
            except Exception as error:row['error']=type(error).__name__+': '+str(error)
            row['seconds']=round(time.monotonic()-start,3);rows.append(row)
            write_json(out/'audit.json',{'rows':rows,'complete':False})
            print(f"[{index}/{len(reports)}] {row['id']} pass={row.get('adaptive',{}).get('selected_pass')} coincident={row.get('after_geometry_coincident')} {row.get('error','')} ({row['seconds']}s)",flush=True)
    write_json(out/'audit.json',{'complete':True,'models':len(rows),'errors':sum('error' in r for r in rows),
        'improved_models':sum(r.get('adaptive',{}).get('selected_pass',0)>0 for r in rows),
        'geometry_coincident':sum(r.get('after_geometry_coincident') is True for r in rows),'rows':rows})

if __name__=='__main__':main()
