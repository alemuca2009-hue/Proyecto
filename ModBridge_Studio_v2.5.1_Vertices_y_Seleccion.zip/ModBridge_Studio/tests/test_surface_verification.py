"""Independent acceptance of exact retessellation, not masked bounds or raster similarity."""
import copy
import unittest
import numpy as np
from bridge.rendering import compare_geometry


def polygon(points, uv=None, normal=(0,0,1)):
    return {'vertices':[[x,y,0] for x,y in points], 'normal':list(normal),
            'uv':uv or [list(p) for p in points], 'texture':'t'}


def mesh(faces):
    yy,xx=np.indices((8,8))
    texture=np.dstack((xx*31,yy*29,(xx+yy)*17,np.full_like(xx,255))).astype('uint8')
    return {'faces':faces,'textures':{'t':texture}}


class SurfaceVerificationTests(unittest.TestCase):
    def test_two_triangles_and_one_rectangle_have_equal_surface_not_tessellation(self):
        source=mesh([polygon([(0,0),(4,0),(4,4)]),polygon([(0,0),(4,4),(0,4)])])
        target=mesh([polygon([(0,0),(4,0),(4,4),(0,4)])])
        report=compare_geometry(source,target)
        self.assertTrue(report['surface_geometry_equal'],report)
        self.assertFalse(report['tessellation_equal'])
        self.assertEqual(report['unmatched_boundary_length_model_units'],0)

    def test_collinear_split_edges_cancel_for_three_strips(self):
        source=mesh([polygon([(0,0),(6,0),(6,4),(0,4)])])
        target=mesh([polygon([(x,0),(x+2,0),(x+2,4),(x,4)]) for x in (0,2,4)])
        self.assertTrue(compare_geometry(source,target)['surface_geometry_equal'])

    def test_hole_is_not_filled_by_equal_bounding_box(self):
        outer=polygon([(0,0),(6,0),(6,6),(0,6)])
        source=mesh([polygon([(0,0),(6,0),(6,2),(0,2)]),polygon([(0,4),(6,4),(6,6),(0,6)]),
                     polygon([(0,2),(2,2),(2,4),(0,4)]),polygon([(4,2),(6,2),(6,4),(4,4)])])
        self.assertFalse(compare_geometry(source,mesh([outer]))['surface_geometry_equal'])

    def test_missing_corner_not_hidden_by_same_total_area_and_bounds(self):
        source=mesh([polygon([(0,0),(4,0),(0,4)])])
        target=mesh([polygon([(0,0),(4,0),(4,4)])])
        report=compare_geometry(source,target)
        self.assertEqual(report['source_surface_area'],report['target_surface_area'])
        self.assertEqual(report['bounds_max_absolute_error'],0)
        self.assertFalse(report['surface_geometry_equal'])

    def test_duplicate_coplanar_face_multiplicity_not_erased(self):
        face=polygon([(0,0),(4,0),(4,4),(0,4)])
        self.assertFalse(compare_geometry(mesh([face]),mesh([face,copy.deepcopy(face)]))['surface_geometry_equal'])

    def test_opposite_normal_duplicates_do_not_cancel(self):
        face=polygon([(0,0),(4,0),(4,4),(0,4)])
        reverse=copy.deepcopy(face);reverse['normal']=[0,0,-1]
        self.assertFalse(compare_geometry(mesh([face]),mesh([face,reverse]))['surface_geometry_equal'])

    def test_degenerate_surface_cannot_certify_itself(self):
        source=mesh([polygon([(0,0),(1,0),(2,0)])])
        report=compare_geometry(source,source)
        self.assertFalse(report['surface_geometry_equal'])
        self.assertTrue(report['invalid_surface_faces']['original'])

    def test_nonplanar_polygon_cannot_certify_itself(self):
        source=mesh([polygon([(0,0),(4,0),(4,4),(0,4)])])
        source['faces'][0]['vertices'][2][2]=.5
        self.assertFalse(compare_geometry(source,source)['surface_geometry_equal'])

    def test_retessellation_of_rotated_surface(self):
        source=mesh([polygon([(0,0),(4,0),(4,4)]),polygon([(0,0),(4,4),(0,4)])])
        target=mesh([polygon([(0,0),(4,0),(4,4),(0,4)])])
        rot=np.array([[.36,-.48,.8],[.8,.6,0],[-.48,.64,.6]])
        for ir in (source,target):
            for f in ir['faces']:
                f['vertices']=(np.asarray(f['vertices'])@rot.T+np.array([17,-3,8])).tolist()
                f['normal']=(np.asarray(f['normal'])@rot.T).tolist()
        self.assertTrue(compare_geometry(source,target)['surface_geometry_equal'])

    def test_uv_proof_passes_exact_merge_and_original_texture_tile(self):
        source=mesh([polygon([(0,0),(4,0),(4,4)]),polygon([(0,0),(4,4),(0,4)])])
        target=mesh([polygon([(0,0),(4,0),(4,4),(0,4)])])
        atlas=np.zeros((16,24,4),dtype=np.uint8)
        atlas[3:11,7:15]=source['textures']['t']
        target['textures']={'t':atlas}
        target['faces'][0]['uv']=[[u+7,v+3] for u,v in target['faces'][0]['uv']]
        report=compare_geometry(source,target)
        self.assertTrue(report['uv_mapping_check_passed'],report)
        self.assertEqual(report['uv_mapping_texture_tiles_checked'],1)

    def test_uv_proof_rejects_wrong_mapping_even_if_texture_file_copied(self):
        source=mesh([polygon([(0,0),(4,0),(4,4),(0,4)])])
        target=copy.deepcopy(source)
        target['faces'][0]['uv']=list(reversed(target['faces'][0]['uv']))
        report=compare_geometry(source,target)
        self.assertTrue(report['surface_geometry_equal'])
        self.assertFalse(report['uv_mapping_check_passed'])

    def test_uv_proof_checks_unsampled_transparent_rgb(self):
        source=mesh([polygon([(0,0),(4,0),(4,4),(0,4)])])
        target=copy.deepcopy(source)
        source['textures']['t'][7,7,3]=0
        target['textures']['t'][7,7]=[2,3,4,0]
        report=compare_geometry(source,target)
        self.assertTrue(report['texture_sample_check_passed'])
        self.assertFalse(report['uv_mapping_check_passed'])

    def test_uv_proof_rejects_missing_material_region_with_same_geometry(self):
        source=mesh([polygon([(0,0),(4,0),(4,4)]),polygon([(0,0),(4,4),(0,4)])])
        source['faces'][1]['uv']=[[u+3,v] for u,v in source['faces'][1]['uv']]
        target=mesh([polygon([(0,0),(4,0),(4,4),(0,4)])])
        report=compare_geometry(source,target)
        self.assertTrue(report['surface_geometry_equal'])
        self.assertFalse(report['uv_mapping_check_passed'])

    def test_source_uv_outside_texture_cannot_certify_atlas_clamping(self):
        source=mesh([polygon([(0,0),(4,0),(4,4),(0,4)])])
        source['faces'][0]['uv'][0]=[-2,0]
        report=compare_geometry(source,source)
        self.assertFalse(report['uv_mapping_check_passed'])

    def test_area_mismatch_fast_failure_does_not_invent_boundary_measurement(self):
        source=mesh([polygon([(0,0),(4,0),(4,4),(0,4)])])
        target=mesh([polygon([(0,0),(4,0),(4,3),(0,3)])])
        report=compare_geometry(source,target)
        self.assertFalse(report['surface_geometry_equal'])
        self.assertEqual(report['surface_comparison_method'],'surface_area_mismatch')
        self.assertFalse(report['surface_boundary_check_performed'])
        self.assertIsNone(report['unmatched_boundary_length_model_units'])
        self.assertEqual(report['surface_area_absolute_error'],4)
        self.assertFalse(report['uv_mapping_check_performed'])


if __name__=='__main__': unittest.main()
