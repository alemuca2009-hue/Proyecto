/* 2.4.7 master control: real browser, server, renderer and ZIP download. */
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {spawn,spawnSync}=require('node:child_process');
const {chromium}=require('playwright');
(async()=>{
  const root=path.resolve(__dirname,'..'),temp=fs.mkdtempSync(path.join(os.tmpdir(),'modbridge-master-'));
  const server=spawn(process.env.PYTHON||'python3',['-u','app.py','serve','--no-browser','--port','0','--workspace',temp,'--input','examples/Demostracion_ModBridge.jar'],{cwd:root});
  let browser;
  try{
    const origin=await new Promise((resolve,reject)=>{let output='';const timer=setTimeout(()=>reject(Error('Server timeout')),15000);server.stdout.on('data',c=>{output+=c;const m=output.match(/http:\/\/127\.0\.0\.1:\d+/);if(m){clearTimeout(timer);resolve(m[0]);}});server.once('exit',c=>{clearTimeout(timer);reject(Error('Server exit '+c));});});
    browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE||undefined,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
    const page=await browser.newPage({viewport:{width:1440,height:1100},acceptDownloads:true});const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.goto(origin);await page.waitForFunction(()=>document.querySelectorAll('.model-open').length===6);
    const first='demo:block/asimetrico',second='demo:block/fuera_del_bloque';
    for(const id of[first,second])await page.locator(`#model-list input[data-id="${id}"]`).check();
    await page.locator('#advanced-options summary').click();await page.locator('#open-render-dialog').click();
    assert.equal(await page.locator('#render-master-scope').inputValue(),'all');
    await page.locator('#render-add-profile').click();
    await page.locator('#render-master-edit-source').click();
    await page.locator('#render-profile-name').fill('Ajustes maestros');await page.locator('#render-resolution').fill('64');
    await page.locator('#render-views-all').click();await page.locator('#render-modes input[value=texture]').uncheck();
    await page.locator('#render-modes input[value=wireframe]').check();await page.locator('#render-modes input[value=solid]').check();await page.locator('#render-three-combinations').check();
    const ids=await page.locator('#render-profile-list [data-profile-id]').evaluateAll(nodes=>nodes.map(n=>n.dataset.profileId));
    const selected=id=>page.locator(`#render-models input[data-model-id="${id}"]:not([data-model-profile])`);
    const assigned=id=>page.locator(`#render-models input[data-model-profile][data-model-id="${id}"]`).evaluateAll(nodes=>nodes.filter(n=>n.checked).map(n=>n.dataset.profileId));
    await selected(second).uncheck();await page.locator('#render-master-scope').selectOption('selected');
    await page.locator('#render-master-assign').uncheck();await page.locator('#render-master-copy-settings').check();
    await page.locator('#render-master-profiles-none').click();await page.locator(`#render-master-profiles input[data-master-profile="${ids[0]}"]`).check();
    assert.match(await page.locator('#render-master-preview').innerText(),/1 de 2/);assert.match(await page.locator('#render-master-preview').innerText(),/1 copias/);
    await page.locator('#render-master-apply').click();
    const afterFirst=await assigned(first),afterSecond=await assigned(second);
    assert.ok(afterFirst.some(id=>id.includes('_maestro_')));assert.deepEqual(afterSecond,ids);assert.equal(await page.locator('#render-profile-list [data-profile-id]').count(),3);
    await page.locator('#render-master-undo').click();assert.deepEqual(await assigned(first),ids);assert.deepEqual(await assigned(second),ids);assert.equal(await page.locator('#render-profile-list [data-profile-id]').count(),2);
    await page.locator('#render-master-scope').selectOption('all');await page.locator('#render-master-assign').check();
    await page.locator('#render-master-profiles-all').click();await page.locator('#render-master-set-name').check();await page.locator('#render-master-name').fill('Maestra global');
    assert.match(await page.locator('#render-master-preview').innerText(),/2 de 2/);await page.locator('#render-master-apply').click();
    assert.equal(await selected(second).isChecked(),false);
    for(const id of[first,second])assert.equal(await page.locator(`#render-models input[data-master-for="${id}"]`).inputValue(),'Maestra global');
    assert.equal(await page.locator('#render-profile-list [data-profile-id]').count(),2);
    await selected(second).check();assert.equal(await page.locator('#render-master-undo').isDisabled(),true,'A later individual edit invalidates undo');
    await page.waitForFunction(()=>document.querySelector('#render-plan-status').textContent==='Configuración comprobada');
    assert.equal(await page.locator('[data-summary-count=image_count] strong').innerText(),'72');
    for(const width of[1440,390]){await page.setViewportSize({width,height:1100});const layout=await page.locator('#render-dialog').evaluate(e=>({right:e.getBoundingClientRect().right,scroll:e.scrollWidth,client:e.clientWidth}));assert.ok(layout.right<=width+1&&layout.scroll<=layout.client+1);await page.locator('#render-dialog').evaluate(e=>{e.scrollTop=0;});if(process.env.QA_SCREENSHOTS)await page.screenshot({path:path.join(process.env.QA_SCREENSHOTS,`master-${width}.png`),fullPage:true});}
    await page.setViewportSize({width:1440,height:1100});await page.locator('#render-start').click();
    await page.waitForFunction(()=>!document.querySelector('#render-download').hidden,{},{timeout:60000});assert.match(await page.locator('#render-result').innerText(),/72 imágenes/);
    const downloadPromise=page.waitForEvent('download');await page.locator('#render-download').click();const download=await downloadPromise;const archive=path.join(temp,'master.zip');await download.saveAs(archive);
    const check=spawnSync(process.env.PYTHON||'python3',['-c',`import json,sys,zipfile\nwith zipfile.ZipFile(sys.argv[1]) as z:\n assert z.testzip() is None\n pngs=[n for n in z.namelist() if n.endswith('.png')]\n assert len(pngs)==72\n assert len({n.split('/')[1] for n in pngs})==1\n d=json.loads(z.read('RENDERS_EXPORTADOS/manifiesto.json'))\n assert all(m['master']=='Maestra global' for m in d['models'])\n assert d['summary']['generated']==72\n assert d['summary']['duplicates_skipped']==72\n print(json.dumps({'pngs':len(pngs),'masters':1,'duplicates_skipped':72}))`,archive],{encoding:'utf8'});assert.equal(check.status,0,check.stderr||check.stdout);
    assert.deepEqual(errors,[]);console.log(JSON.stringify({ok:true,browser:browser.version(),checks:['All-model control updates selected and unchecked model configurations without changing export selection','Selected scope isolates shared profiles and preserves models outside scope','Undo restores profile assignments and cloned definitions','Subsequent individual editing remains functional and invalidates stale undo','Master-edited configuration exports 72 real PNGs with correct grouping and deduplication','No horizontal overflow at 1440 and 390 pixels'],archive:JSON.parse(check.stdout)},null,2));
  }finally{if(browser)await browser.close();server.kill('SIGINT');await new Promise(resolve=>{if(server.exitCode!==null)resolve();else server.once('exit',resolve);});fs.rmSync(temp,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
