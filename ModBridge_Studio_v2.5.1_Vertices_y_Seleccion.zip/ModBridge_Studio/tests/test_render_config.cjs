const {test} = require('node:test');
const assert = require('node:assert/strict');
const render = require('../web/render_config.js');
const profile = (id = 'p1', patch = {}) => ({...render.createProfile(id, id), ...patch});
const config = (profiles, models = [{id: 'mod:block/cogwheel', profile_ids: profiles.map(p => p.id)}]) => ({profiles, models});

test('defaults request one actual front texture render and the six labeled directions are fixed', () => {
  const p = render.createProfile('one', 'Perfil 1');
  assert.deepEqual(p.views, ['frontal']);
  assert.deepEqual(p.modes, ['texture']);
  assert.equal(p.size, 192);
  assert.equal(p.representation, 'translated');
  assert.deepEqual(render.VIEWS.map(v => v.label), ['Arriba', 'Abajo', 'Izquierda', 'Derecha', 'Enfrente', 'Atrás']);
  assert.deepEqual(render.MODES.map(m => m.id), ['wireframe', 'solid', 'texture']);
  assert.equal(render.planSummary(config([p])).image_count, 1);
});
test('parameter selection produces exactly one pair; selecting both is one simultaneous variant', () => {
  for (const xray of [false, true]) for (const normals of [false, true]) {
    assert.deepEqual(render.parameterVariants({xray, normals}), [{xray, normals}]);
    assert.equal(render.planSummary(config([profile('p', {xray, normals})])).image_count, 1);
  }
});
test('three combinations yields exactly X-ray, normals, and both without a baseline fourth image', () => {
  const variants = render.parameterVariants({three_combinations: true, xray: true, normals: true});
  assert.deepEqual(variants, [{xray: true, normals: false}, {xray: false, normals: true}, {xray: true, normals: true}]);
  const summary = render.planSummary(config([profile('p', {three_combinations: true})]));
  assert.equal(summary.image_count, 3);
  assert.equal(summary.combination_count, 3);
});
test('each selected perspective, mode and parameter pair is a separate image', () => {
  const p = profile('p', {views: render.VIEWS.map(v => v.id), modes: render.MODES.map(m => m.id), three_combinations: true});
  const summary = render.planSummary(config([p]));
  assert.deepEqual(summary.errors, []);
  assert.equal(summary.image_count, 54);
  assert.equal(summary.view_count, 6);
  assert.equal(summary.mode_count, 3);
  assert.equal(summary.combination_count, 3);
});
test('overlapping profiles assign unique renders to the first selected profile for each model', () => {
  const p1 = profile('first', {views: ['frontal', 'superior']});
  const p2 = profile('second', {views: ['frontal', 'inferior']});
  const p3 = profile('duplicate', {views: ['superior']});
  const summary = render.planSummary(config([p1, p2, p3]));
  assert.equal(summary.image_count, 3);
  assert.equal(summary.requested_image_count, 5);
  assert.equal(summary.duplicate_count, 2);
  assert.deepEqual(summary.assignments.map(a => [a.profile_id, a.image_count, a.duplicate_count]), [
    ['first', 2, 0], ['second', 1, 1], ['duplicate', 0, 1]
  ]);
  const reordered = render.planSummary(config([p1, p2], [{id: 'm', profile_ids: ['second', 'first']}]));
  assert.equal(reordered.assignments[0].profile_id, 'second');
  assert.equal(reordered.assignments[0].image_count, 2);
  assert.equal(reordered.assignments[1].image_count, 1);
});
test('profiles are assigned independently per model and are never deduplicated across models', () => {
  const ps = [profile('p1'), profile('p2', {size: 256})];
  const summary = render.planSummary(config(ps, [
    {id: 'm1', master: 'Maestra 1', profile_ids: ['p1', 'p2']},
    {id: 'm2', master: 'Maestra 2', profile_ids: ['p1']}
  ]));
  assert.equal(summary.image_count, 3);
  assert.equal(summary.profile_count, 2);
  assert.equal(summary.model_count, 2);
  assert.equal(summary.assignments.length, 3);
});
test('size, representation and effective X-ray opacity contribute to distinct renders', () => {
  const ps = [profile('base'), profile('size', {size: 256}),
    profile('original', {representation: 'original'}), profile('unusedOpacity', {opacity: 0.8}),
    profile('xray1', {xray: true, opacity: 0.2}), profile('xray2', {xray: true, opacity: 0.8})];
  const summary = render.planSummary(config(ps));
  assert.equal(summary.image_count, 5);
  assert.equal(summary.duplicate_count, 1);
});
test('duplicate checkbox selections are canonicalized without creating images twice', () => {
  const p = profile('p', {views: ['frontal', 'frontal'], modes: ['texture', 'texture']});
  const summary = render.planSummary(config([p], [{id: 'm', profile_ids: ['p', 'p']}]));
  assert.equal(summary.image_count, 1);
  assert.equal(summary.requested_image_count, 1);
  assert.equal(summary.assignments.length, 1);
});
test('invalid selections are reported instead of silently planning an export', () => {
  for (const input of [null, {}, {profiles: [], models: []},
    config([profile()], [{id: 'm', profile_ids: []}]),
    config([profile()], [{id: 'm', profile_ids: ['missing']}]),
    config([profile('p', {views: []})]), config([profile('p', {modes: []})]),
    config([profile('p', {views: ['invented']})]), config([profile('p', {modes: ['invented']})]),
    config([profile('same'), profile('same')]),
    config([profile()], [{id: 'm', profile_ids: ['p1']}, {id: 'm', profile_ids: ['p1']}])]) {
    assert.ok(render.planSummary(input).errors.length > 0, JSON.stringify(input));
  }
});
test('unused draft profiles need not have perspectives or modes', () => {
  const summary = render.planSummary(config([profile('ready'), profile('draft', {views: [], modes: []})],
    [{id: 'm', profile_ids: ['ready']}]));
  assert.deepEqual(summary.errors, []);
  assert.equal(summary.profile_count, 1);
  assert.equal(summary.image_count, 1);
});
test('strict booleans, finite opacity, supported representation and bounded integer size are required', () => {
  for (const patch of [{xray: 'false'}, {normals: 1}, {three_combinations: 'true'},
    {opacity: NaN}, {opacity: 0}, {opacity: 1}, {opacity: '0.35'},
    {size: 63}, {size: 513}, {size: 192.5}, {size: '192'}, {representation: 'fake'}]) {
    assert.ok(render.planSummary(config([profile('bad', patch)])).errors.length > 0);
  }
  for (const size of [64, 128, 192, 256, 512])
    assert.deepEqual(render.planSummary(config([profile('p', {size})])).errors, []);
});
test('summary, parameter variants and profile copies do not mutate source data', () => {
  const p = profile('p', {views: ['frontal', 'superior'], three_combinations: true});
  const input = config([p]), before = structuredClone(input);
  const summary = render.planSummary(input);
  render.parameterVariants(p)[0].normals = true;
  const copy = render.cloneProfile(p, 'copy', 'Copia');
  copy.views.push('inferior');
  assert.equal(copy.id, 'copy');
  assert.equal(copy.name, 'Copia');
  assert.deepEqual(input, before);
  assert.equal(summary.images, summary.image_count);
  assert.equal(summary.duplicates, summary.duplicate_count);
  assert.equal(summary.rows, summary.assignments);
});
test('oversized batches are rejected with an actionable message', () => {
  const profiles = Array.from({length: 33}, (_, i) => profile(`p${i}`));
  assert.ok(render.planSummary(config(profiles)).errors.some(error => error.includes('32 perfiles')));
  const p = profile('p', {views: render.VIEWS.map(v => v.id), modes: render.MODES.map(m => m.id), three_combinations: true});
  const models = Array.from({length: 1852}, (_, i) => ({id: `model${i}`, profile_ids: ['p']}));
  const summary = render.planSummary(config([p], models));
  assert.ok(summary.errors.some(error => error.includes('100000 combinaciones')));
  assert.ok(summary.requested_image_count <= render.MAX_CANDIDATE_IMAGES);
});

test('master applies profiles and one maestra to every model without changing selection or sources', () => {
  const input={profiles:[profile('a'),profile('b')],models:[
    {id:'one',name:'Uno',selected:true,master:'old1',profile_ids:['a']},
    {id:'two',name:'Dos',selected:false,master:'old2',profile_ids:['a']}]};
  const before=structuredClone(input);
  const result=render.masterUpdate(input,{scope:'all',assign:true,assignment_mode:'replace',profile_ids:['b'],set_master:true,master:' Común '});
  assert.deepEqual(result.errors,[]); assert.equal(result.model_count,2);assert.equal(result.changed_model_count,2);
  for(const m of result.models){assert.deepEqual(m.profile_ids,['b']);assert.equal(m.master,'Común');}
  assert.equal(result.models[1].selected,false);assert.equal(result.models[1].name,'Dos');assert.deepEqual(input,before);
});
test('master selected scope leaves unchecked models unchanged and supports add/remove', () => {
  const input={profiles:[profile('a'),profile('b')],models:[{id:'one',selected:true,profile_ids:['a']},{id:'two',selected:false,profile_ids:['a']}]};
  const added=render.masterUpdate(input,{scope:'selected',assign:true,assignment_mode:'add',profile_ids:['b','b']});
  assert.deepEqual(added.models[0].profile_ids,['a','b']);assert.deepEqual(added.models[1],input.models[1]);
  const removed=render.masterUpdate(added,{scope:'selected',assign:true,assignment_mode:'remove',profile_ids:['a']});
  assert.deepEqual(removed.models[0].profile_ids,['b']);assert.deepEqual(removed.models[1],input.models[1]);
});
test('master copies every render setting but preserves profile identities and names for all-model scope', () => {
  const input={profiles:[profile('source',{views:['superior','inferior'],modes:['wireframe','solid'],xray:true,normals:true,three_combinations:true,opacity:.55,size:256,representation:'original'}),profile('target')],models:[{id:'one',selected:true,profile_ids:['target']},{id:'two',selected:false,profile_ids:['target']}]};
  const result=render.masterUpdate(input,{scope:'all',copy_settings:true,source_profile_id:'source',profile_ids:['target']});
  assert.deepEqual(result.errors,[]);assert.equal(result.settings_profile_count,1);assert.equal(result.cloned_profile_count,0);
  assert.deepEqual(result.profiles[1],{...input.profiles[0],id:'target',name:input.profiles[1].name});
  assert.deepEqual(result.models,input.models);
});
test('master isolates shared profile settings for selected models with one shared clone', () => {
  const input={profiles:[profile('source',{modes:['solid'],size:256}),profile('target')],models:[{id:'one',selected:true,profile_ids:['target']},{id:'two',selected:true,profile_ids:['target']},{id:'three',selected:false,profile_ids:['target']}]};
  const result=render.masterUpdate(input,{scope:'selected',copy_settings:true,source_profile_id:'source',profile_ids:['target']});
  assert.deepEqual(result.errors,[]);assert.equal(result.cloned_profile_count,1);assert.equal(result.profiles.length,3);
  assert.deepEqual(result.models[0].profile_ids,result.models[1].profile_ids);assert.notEqual(result.models[0].profile_ids[0],'target');
  assert.deepEqual(result.models[2],input.models[2]);assert.deepEqual(result.profiles[1],input.profiles[1]);
  assert.deepEqual(result.profiles[2].modes,['solid']);assert.equal(result.profiles[2].size,256);
});
test('master does not create copies for unchanged settings or unused profiles', () => {
  const input={profiles:[profile('a'),profile('b'),profile('unused',{modes:['solid']})],models:[{id:'one',selected:true,profile_ids:['b']},{id:'two',selected:false,profile_ids:['b']}]};
  const result=render.masterUpdate(input,{scope:'selected',copy_settings:true,source_profile_id:'a',profile_ids:['b','unused']});
  assert.equal(result.settings_profile_count,0);assert.equal(result.cloned_profile_count,0);assert.deepEqual(result.models,input.models);assert.deepEqual(result.profiles,input.profiles);
});
test('master validates actions and rolls back all planned edits if isolated copies exceed the cap', () => {
  const input={profiles:Array.from({length:32},(_,i)=>profile('p'+i,{size:i===0?256:192})),models:[{id:'one',selected:true,master:'old',profile_ids:['p1']},{id:'two',selected:false,profile_ids:['p1']}]};
  const opts={scope:'selected',assign:true,assignment_mode:'add',profile_ids:['p1'],set_master:true,master:'new',copy_settings:true,source_profile_id:'p0'};
  const result=render.masterUpdate(input,opts);assert.ok(result.errors.some(e=>e.includes('32')));assert.deepEqual(result.models,input.models);assert.deepEqual(result.profiles,input.profiles);
  for(const patch of [{scope:'unknown'},{master:''},{profile_ids:['absent']},{source_profile_id:'missing'},{assignment_mode:'invalid'}])assert.ok(render.masterUpdate(input,{...opts,...patch}).errors.length);
  assert.ok(render.masterUpdate(input,{scope:'all'}).errors.length);
});
test('master can clear assignments explicitly and generated IDs stay valid without collisions', () => {
  const id='p'.repeat(80),existing='p'.repeat(60)+'_maestro_1';
  const input={profiles:[profile('source',{size:256}),profile(id),profile(existing)],models:[{id:'one',selected:true,profile_ids:[id]},{id:'two',selected:false,profile_ids:[id]}]};
  const copied=render.masterUpdate(input,{scope:'selected',copy_settings:true,source_profile_id:'source',profile_ids:[id]});
  assert.equal(copied.errors.length,0);assert.ok(copied.clones[0].id.length<=80);assert.notEqual(copied.clones[0].id,existing);
  const cleared=render.masterUpdate(input,{scope:'all',assign:true,assignment_mode:'replace',profile_ids:[]});
  assert.equal(cleared.errors.length,0);assert.ok(cleared.models.every(m=>m.profile_ids.length===0));
});

test('comparison expands every view, mode and parameter into Java and Bedrock PNGs', () => {
  const p=profile('pair',{representation:'comparison',views:render.VIEWS.map(v=>v.id),modes:render.MODES.map(m=>m.id),three_combinations:true});
  const summary=render.planSummary(config([p],[{id:'one',profile_ids:['pair']},{id:'two',profile_ids:['pair']}]));
  assert.deepEqual(summary.errors,[]);assert.equal(summary.image_count,216);
  assert.equal(summary.requested_image_count,216);assert.equal(summary.comparison_pair_count,108);
  assert.equal(summary.view_count,6);assert.equal(summary.mode_count,3);assert.equal(summary.combination_count,3);
});
test('comparison deduplicates each side against ordinary and repeated comparison profiles', () => {
  const input=config([profile('java',{representation:'original'}),profile('comparison',{representation:'comparison'}),profile('bedrock'),profile('comparison2',{representation:'comparison'})]);
  const before=structuredClone(input),summary=render.planSummary(input);
  assert.deepEqual(summary.errors,[]);assert.equal(summary.image_count,2);
  assert.equal(summary.requested_image_count,6);assert.equal(summary.duplicate_count,4);assert.equal(summary.comparison_pair_count,2);
  assert.deepEqual(summary.assignments.map(row=>[row.image_count,row.duplicate_count]),[[1,0],[1,1],[0,1],[0,2]]);
  assert.deepEqual(input,before);
});
test('comparison counts both representations toward the batch image limit', () => {
  const p=profile('pair',{representation:'comparison',views:render.VIEWS.map(v=>v.id),modes:render.MODES.map(m=>m.id),three_combinations:true});
  const models=Array.from({length:926},(_,i)=>({id:'m'+i,profile_ids:['pair']}));
  const summary=render.planSummary(config([p],models));
  assert.ok(summary.errors.some(error=>error.includes('100000 combinaciones')));
  assert.equal(summary.requested_image_count,99900);
  assert.equal(summary.comparison_pair_count,49950);
});
test('master applies comparison to chosen profiles without mutating models outside scope', () => {
  const input={profiles:[profile('source',{representation:'comparison'}),profile('destination')],models:[{id:'one',selected:true,profile_ids:['destination']},{id:'two',selected:false,profile_ids:['destination']}]};
  const result=render.masterUpdate(input,{scope:'selected',copy_settings:true,source_profile_id:'source',profile_ids:['destination']});
  assert.deepEqual(result.errors,[]);assert.equal(result.cloned_profile_count,1);
  assert.equal(result.profiles.find(p=>p.id===result.models[0].profile_ids[0]).representation,'comparison');
  assert.equal(result.profiles.find(p=>p.id==='destination').representation,'translated');
  const summary=render.planSummary({profiles:result.profiles,models:result.models});
  assert.equal(summary.image_count,3);assert.equal(summary.comparison_pair_count,1);
});
