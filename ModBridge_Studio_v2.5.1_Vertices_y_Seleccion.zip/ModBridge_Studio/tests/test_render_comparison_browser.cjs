/* Comparison profiles: real browser, lazy conversion, renderer and ZIP download. */
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const {spawn,spawnSync}=require('node:child_process');
const {chromium}=require('playwright');
(async()=>{
  const root=path.resolve(__dirname,'..'),temp=fs.mkdtempSync(path.join(os.tmpdir(),'modbridge-comparison-'));
  const jar=path.join(root,'examples/Demostracion_ModBridge.jar');
  const sourceHash=()=>crypto.createHash('sha256').update(fs.readFileSync(jar)).digest('hex'),beforeHash=sourceHash();
  const server=spawn(process.env.PYTHON||'python3',['-u','app.py','serve','--no-browser','--port','0','--workspace',temp,'--input',jar],{cwd:root});
  let browser;
  try{
    const origin=await new Promise((resolve,reject)=>{let output='';const timer=setTimeout(()=>reject(Error('Server timeout')),15000);server.stdout.on('data',c=>{output+=c;const m=output.match(/http:\/\/127\.0\.0\.1:\d+/);if(m){clearTimeout(timer);resolve(m[0]);}});server.once('exit',c=>{clearTimeout(timer);reject(Error('Server exit '+c));});});
    browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE||undefined,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
    const page=await browser.newPage({viewport:{width:1440,height:1100},acceptDownloads:true}),errors=[];
    page.on('pageerror',e=>errors.push(e.message));
    await page.goto(origin);await page.waitForFunction(()=>document.querySelectorAll('.model-open').length===6);
    for(const id of['demo:block/asimetrico','demo:block/fuera_del_bloque'])await page.locator(`#model-list input[data-id="${id}"]`).check();
    await page.locator('#advanced-options summary').click();await page.locator('#open-render-dialog').click();
    await page.locator('#render-representation').selectOption('comparison');
    await page.locator('#render-profile-name').fill('Comparación completa');await page.locator('#render-resolution').fill('64');
    await page.locator('#render-views input[value=superior]').check();
    for(const mode of['wireframe','solid'])await page.locator(`#render-modes input[value=${mode}]`).check();
    await page.locator('#render-three-combinations').check();
    await page.locator('#render-duplicate-profile').click();await page.locator('#render-representation').selectOption('original');
    const ids=await page.locator('#render-profile-list [data-profile-id]').evaluateAll(nodes=>nodes.map(n=>n.dataset.profileId));
    assert.equal(ids.length,2);await page.locator(`#render-profile-list [data-profile-id="${ids[0]}"]`).click();
    await page.locator('#render-master-copy-settings').check();await page.locator('#render-master-profiles-all').click();await page.locator('#render-master-apply').click();
    await page.waitForFunction(()=>document.querySelector('#render-plan-status').textContent==='Configuración comprobada');
    assert.equal(await page.locator('[data-summary-count=image_count] strong').innerText(),'72');
    assert.equal(await page.locator('[data-summary-count=comparison_pair_count] strong').innerText(),'72');
    assert.match(await page.locator('#render-duplicate-note').innerText(),/72 imágenes repetidas/);
    assert.match(await page.locator('#render-comparison-note').innerText(),/_java\.png y _bedrock\.png/);
    assert.equal(await page.locator('#render-profile-list').getByText(/Comparación \(Java \+ Bedrock\)/).count(),2);
    for(const width of[1440,390]){await page.setViewportSize({width,height:1100});const layout=await page.locator('#render-dialog').evaluate(e=>({right:e.getBoundingClientRect().right,scroll:e.scrollWidth,client:e.clientWidth}));assert.ok(layout.right<=width+1&&layout.scroll<=layout.client+1);}
    await page.setViewportSize({width:1440,height:1100});await page.locator('#render-start').click();
    await page.waitForFunction(()=>!document.querySelector('#render-download').hidden,{},{timeout:60000});assert.match(await page.locator('#render-result').innerText(),/72 imágenes/);
    const downloadPromise=page.waitForEvent('download');await page.locator('#render-download').click();const download=await downloadPromise,archive=path.join(temp,'comparison.zip');await download.saveAs(archive);
    const check=spawnSync(process.env.PYTHON||'python3',['-c',`
import collections,io,json,sys,zipfile
from PIL import Image
with zipfile.ZipFile(sys.argv[1]) as z:
 assert z.testzip() is None
 pngs=[n for n in z.namelist() if n.endswith('.png')]
 assert len(pngs)==72 and len(set(n.casefold() for n in pngs))==72
 assert all(n.endswith(('_java.png','_bedrock.png')) for n in pngs)
 assert all(len(n.split('/'))==5 for n in pngs)
 d=json.loads(z.read('RENDERS_EXPORTADOS/manifiesto.json'))
 assert d['summary']['generated']==72 and d['summary']['duplicates_skipped']==72
 assert d['summary']['comparison_pair_count']==72
 assert all(p['representation']=='comparison' for p in d['profiles'])
 assert collections.Counter(i['representation'] for i in d['images'])=={'original':36,'translated':36}
 assert len(d['comparison_pairs'])==72
 for pair in d['comparison_pairs']:
  assert pair['status']=='complete'
  assert pair['java_path'] in pngs and pair['bedrock_path'] in pngs
  assert pair['java_path']!=pair['bedrock_path']
 for n in pngs:
  with Image.open(io.BytesIO(z.read(n))) as image:
   assert image.size==(64,64)
 assert set((i['xray'],i['normals']) for i in d['images'])=={(True,False),(False,True),(True,True)}
 print(json.dumps({'pngs':72,'comparison_pairs':72,'java':36,'bedrock':36,'duplicates_skipped':72,'size':64}))
`,archive],{encoding:'utf8'});assert.equal(check.status,0,check.stderr||check.stdout);
    assert.equal(sourceHash(),beforeHash);assert.deepEqual(errors,[]);
    console.log(JSON.stringify({ok:true,browser:browser.version(),checks:['Comparison is selectable and summarized with both actual representations','Master copying comparison updates all chosen profiles','Local and server counts include both sides and omit duplicate images','Two models, two perspectives, all three modes and all three parameter combinations export through a real worker','Manifest pairs reference separately named Java and Bedrock PNGs','Original JAR remains byte-identical; responsive layout has no horizontal overflow'],archive:JSON.parse(check.stdout)},null,2));
  }finally{if(browser)await browser.close();server.kill('SIGINT');await new Promise(resolve=>{if(server.exitCode!==null)resolve();else server.once('exit',resolve);});fs.rmSync(temp,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
