import copy
import json
import math
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from bridge.rendering import compare_geometry, compare_views, image_metrics, render_view, _triangulate


def face(vertices, texture='texture', uv=None, normal=None):
    n = len(vertices)
    if uv is None:
        uv = [[0, 0], [8, 0], [8, 8], [0, 8]][:n]
    result = {'vertices': vertices, 'uv': uv, 'texture': texture}
    if normal is not None:
        result['normal'] = normal
    return result


def plane(z=0, texture='texture', normal=(0, 0, -1)):
    return face([[-4, 0, z], [4, 0, z], [4, 8, z], [-4, 8, z]], texture=texture, normal=list(normal))


class RenderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        # Deliberately asymmetric data: reflections and rotations are visible.
        yy, xx = np.indices((8, 8))
        pixels = np.dstack((xx * 31, yy * 29, (xx + yy) * 17, np.full_like(xx, 255))).astype('uint8')
        self.texture = self.root / 'pattern.png'
        Image.fromarray(pixels, 'RGBA').save(self.texture)
        self.ir = {'faces': [plane()], 'textures': {'texture': str(self.texture)}}

    def tearDown(self):
        self.temp.cleanup()

    def test_six_aligned_exports(self):
        output = self.root / 'views'
        result = compare_views(self.ir, copy.deepcopy(self.ir), output, size=64)
        self.assertTrue(result['all_views_pixel_identical'])
        self.assertTrue(result['geometry']['surface_geometry_equal'])
        self.assertEqual(len(result['views']), 6)
        for side in ('frontal', 'trasera', 'izquierda', 'derecha', 'superior', 'inferior'):
            for name in ('original', 'traducido', 'diferencia'):
                with Image.open(output / side / (name + '.png')) as im:
                    self.assertEqual(im.size, (64, 64))
        self.assertTrue((output / 'comparacion_seis_vistas.png').exists())
        self.assertEqual(json.loads((output / 'comparacion.json').read_text())['size'], 64)

    def test_different_geometry_not_certified_by_empty_edge_views(self):
        changed = copy.deepcopy(self.ir)
        changed['faces'][0]['vertices'][1][0] += 1
        result = compare_geometry(self.ir, changed)
        self.assertFalse(result['surface_geometry_equal'])
        self.assertGreater(result['bounds_max_absolute_error'], 0)
        top_a = render_view(self.ir, 'superior', 64)
        top_b = render_view(changed, 'superior', 64)
        self.assertTrue(image_metrics(top_a, top_b)['pixel_identical'])

    def test_orientation_uv_mutation_detected(self):
        changed = copy.deepcopy(self.ir)
        changed['faces'][0]['uv'] = list(reversed(changed['faces'][0]['uv']))
        result = compare_geometry(self.ir, changed)
        self.assertTrue(result['surface_geometry_equal'])
        self.assertGreater(result['texture_samples_different'], 0)
        images = [render_view(ir, 'frontal', 64) for ir in (self.ir, changed)]
        self.assertFalse(image_metrics(*images)['pixel_identical'])

    def test_offset_atlas_keeps_texels(self):
        atlas = Image.new('RGBA', (24, 16))
        with Image.open(self.texture) as texture:
            atlas.paste(texture, (8, 4))
        atlas_path = self.root / 'atlas.png'
        atlas.save(atlas_path)
        changed = copy.deepcopy(self.ir)
        changed['textures']['texture'] = str(atlas_path)
        changed['faces'][0]['uv'] = [[u + 8, v + 4] for u, v in changed['faces'][0]['uv']]
        result = compare_geometry(self.ir, changed)
        self.assertTrue(result['texture_sample_check_passed'])
        self.assertTrue(image_metrics(render_view(self.ir, 'frontal', 64), render_view(changed, 'frontal', 64))['pixel_identical'])

    def test_reordered_vertices_match_geometry_and_uv(self):
        changed = copy.deepcopy(self.ir)
        changed['faces'][0]['vertices'] = changed['faces'][0]['vertices'][2:] + changed['faces'][0]['vertices'][:2]
        changed['faces'][0]['uv'] = changed['faces'][0]['uv'][2:] + changed['faces'][0]['uv'][:2]
        report = compare_geometry(self.ir, changed)
        self.assertTrue(report['surface_geometry_equal'])
        self.assertTrue(report['texture_sample_check_passed'])

    def test_normals_are_independent_requirement(self):
        changed = copy.deepcopy(self.ir)
        changed['faces'][0]['normal'] = [0, 0, 1]
        self.assertFalse(compare_geometry(self.ir, changed)['surface_geometry_equal'])
        self.assertEqual(compare_geometry(self.ir, changed)['changed_normals'], 1)

    def test_rotated_plane_six_nonempty_axial_views(self):
        rotated = copy.deepcopy(self.ir)
        a, b = math.radians(25), math.radians(35)
        rx = np.array([[1,0,0],[0,math.cos(a),-math.sin(a)],[0,math.sin(a),math.cos(a)]])
        ry = np.array([[math.cos(b),0,math.sin(b)],[0,1,0],[-math.sin(b),0,math.cos(b)]])
        for f in rotated['faces']:
            f['vertices'] = (np.asarray(f['vertices']) @ rx.T @ ry.T).tolist()
            f['normal'] = (np.asarray(f['normal']) @ rx.T @ ry.T).tolist()
        for view in ('frontal', 'trasera', 'izquierda', 'derecha', 'superior', 'inferior'):
            self.assertGreater(np.asarray(render_view(rotated, view, 64))[:, :, 3].sum(), 0)

    def test_translucent_layers_are_depth_sorted(self):
        red, blue = self.root / 'red.png', self.root / 'blue.png'
        Image.new('RGBA', (8, 8), (255, 0, 0, 128)).save(red)
        Image.new('RGBA', (8, 8), (0, 0, 255, 128)).save(blue)
        ir = {'faces': [plane(z=-1, texture='red'), plane(z=1, texture='blue')],
              'textures': {'red': str(red), 'blue': str(blue)}}
        original = render_view(ir, 'frontal', 64)
        reverse = copy.deepcopy(ir)
        reverse['faces'].reverse()
        self.assertTrue(image_metrics(original, render_view(reverse, 'frontal', 64))['pixel_identical'])
        rgba = np.asarray(original)[32,32]
        self.assertGreater(rgba[0], rgba[2])
        self.assertIn(int(rgba[3]), (191,192))
        # Shared triangle diagonal is not alpha-composited twice.
        self.assertLessEqual(int(np.asarray(original)[:,:,3].max()),192)

    def test_cutout_reveals_rear_surface(self):
        transparent, solid = self.root / 'clear.png', self.root / 'solid.png'
        Image.new('RGBA', (8,8), (100,0,0,0)).save(transparent)
        Image.new('RGBA', (8,8), (10,200,30,255)).save(solid)
        ir = {'faces': [plane(z=-1, texture='front'), plane(z=1, texture='rear')],
              'textures': {'front': str(transparent), 'rear': str(solid)}}
        self.assertEqual(np.asarray(render_view(ir, 'frontal', 64))[32,32].tolist(), [10,200,30,255])

    def test_missing_texture_cannot_pass(self):
        ir = copy.deepcopy(self.ir)
        ir['textures']['texture'] = str(self.root / 'missing.png')
        report = compare_views(ir, ir, self.root / 'missing', 32)
        self.assertFalse(report['all_views_pixel_identical'])
        self.assertFalse(report['geometry']['texture_sample_check_passed'])

    def test_existing_diagnostic_texture_is_not_verifiable(self):
        ir = copy.deepcopy(self.ir)
        ir['texture_metadata'] = {'texture': {'missing': True}}
        report = compare_views(ir, ir, self.root / 'diagnostic', 32)
        self.assertFalse(report['all_views_pixel_identical'])
        self.assertFalse(report['geometry']['texture_sample_check_passed'])
        self.assertEqual(report['missing_textures']['original'], ['texture'])

    def test_concave_polygon_triangulates_area(self):
        vertices = np.array([[0,0,0],[2,0,0],[2,1,0],[1,1,0],[1,2,0],[0,2,0]], dtype=float)
        triangles = _triangulate(vertices)
        self.assertEqual(len(triangles), 4)
        area = sum(np.linalg.norm(np.cross(vertices[b]-vertices[a],vertices[c]-vertices[a]))/2 for a,b,c in triangles)
        self.assertAlmostEqual(area,3)

    def test_empty_ir_does_not_count_texture_proof(self):
        ir = {'faces': [], 'textures': {}}
        report = compare_geometry(ir, ir)
        self.assertEqual(report['source_face_count'], 0)
        self.assertFalse(report['texture_sample_check_passed'])

if __name__ == '__main__':
    unittest.main()
