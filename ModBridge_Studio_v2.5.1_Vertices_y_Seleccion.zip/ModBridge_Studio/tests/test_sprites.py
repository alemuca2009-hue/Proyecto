import unittest
from PIL import Image
import numpy as np
from bridge.sprites import generated_elements


class GeneratedSpriteTests(unittest.TestCase):
    def model(self, **textures):
        return {'_generated':'minecraft:builtin/generated','textures':textures or {'layer0':'demo:item/sprite'}}

    def test_full_sprite_has_front_back_and_four_boundary_spans(self):
        elements,warnings=generated_elements(self.model(),lambda _:Image.new('RGBA',(16,16),(20,40,80,255)))
        self.assertEqual(len(elements),5)
        self.assertEqual(sum(len(e['faces']) for e in elements),6)
        body=elements[0]
        self.assertEqual(body['from'],[0,0,7.5]);self.assertEqual(body['to'],[16,16,8.5])
        self.assertEqual(body['faces']['north']['uv'],[16,0,0,16])
        self.assertEqual(body['faces']['south']['uv'],[0,0,16,16])
        self.assertEqual(warnings,[])

    def test_asymmetric_single_texel_golden_rectangles(self):
        image=Image.new('RGBA',(4,8));image.putpixel((1,2),(10,20,30,128))
        elements,_=generated_elements(self.model(),lambda _:image)
        by_name={e['name'].split('_')[2]:e for e in elements[1:]}
        self.assertEqual(by_name['up']['from'],[4,12,7.5]);self.assertEqual(by_name['up']['to'],[8,12,8.5])
        self.assertEqual(by_name['up']['faces']['up']['uv'],[4,4,8,6])
        self.assertEqual(by_name['down']['from'],[4,10,7.5])
        self.assertEqual(by_name['left']['from'],[4,12,7.5]);self.assertEqual(by_name['left']['to'],[4,10,8.5])
        self.assertEqual(by_name['left']['faces']['east']['uv'],[4,6,8,4])
        self.assertEqual(by_name['right']['from'],[8,12,7.5]);self.assertEqual(by_name['right']['faces']['west']['uv'],[4,6,8,4])

    def test_cutout_keeps_inner_edges_and_does_not_fill_pixel_grid(self):
        image=Image.new('RGBA',(3,3),(1,2,3,255));image.putpixel((1,1),(1,2,3,0))
        elements,_=generated_elements(self.model(),lambda _:image)
        self.assertEqual(len(elements),9) # continuous front/back + four outer and four hole sides
        self.assertEqual(sum(len(e['faces']) for e in elements),10)
        self.assertTrue(any(e['from'][1]==16-2*16/3 and 'up' in e['faces'] for e in elements))

    def test_same_anchor_merges_disconnected_spans_like_java(self):
        image=Image.new('RGBA',(4,1));image.putpixel((0,0),(1,2,3,255));image.putpixel((3,0),(1,2,3,255))
        elements,_=generated_elements(self.model(),lambda _:image)
        ups=[e for e in elements if 'up' in e['faces']]
        self.assertEqual(len(ups),1)
        self.assertEqual(ups[0]['from'][0],0);self.assertEqual(ups[0]['to'][0],16)
        # Empty gap is transparent, not converted to opaque texels.
        self.assertEqual(image.getpixel((1,0))[3],0)

    def test_alpha_one_counts_as_present_alpha_zero_does_not(self):
        image=Image.new('RGBA',(2,1));image.putpixel((0,0),(255,90,10,1))
        elements,_=generated_elements(self.model(),lambda _:image)
        self.assertEqual(len(elements),5)
        self.assertEqual(elements[0]['faces']['south']['tintindex'],0)

    def test_multiple_layers_and_aliases_preserve_tint_index(self):
        seen=[]
        def load(identifier):seen.append(identifier);return Image.new('RGBA',(2,2),(10,20,30,255))
        elements,_=generated_elements(self.model(layer0='#base',base='demo:item/a',layer1='demo:item/b'),load)
        self.assertEqual(seen,['demo:item/a','demo:item/b'])
        self.assertEqual(len(elements),10)
        self.assertEqual(elements[5]['faces']['south']['tintindex'],1)

    def test_stops_at_first_gap_and_does_not_extrude_builtin_entity(self):
        seen=[]
        def load(name):seen.append(name);return Image.new('RGBA',(1,1),'white')
        generated_elements(self.model(layer0='demo:item/a',layer2='demo:item/b'),load)
        self.assertEqual(seen,['demo:item/a'])
        with self.assertRaises(ValueError):generated_elements({'_generated':'minecraft:builtin/entity','textures':{'layer0':'demo:item/a'}},load)

    def test_missing_layer_and_alias_cycles_are_explicit(self):
        with self.assertRaises(ValueError):generated_elements({'textures':{}},lambda _:Image.new('RGBA',(1,1)))
        with self.assertRaises(ValueError):generated_elements(self.model(layer0='#a',a='#layer0'),lambda _:Image.new('RGBA',(1,1)))

    def test_animation_frames_union_has_extra_boundaries(self):
        first=Image.new('RGBA',(2,2));first.putpixel((0,0),(1,2,3,255))
        second=Image.new('RGBA',(2,2));second.putpixel((1,1),(1,2,3,255))
        first.info['modbridge_frames']=[first,second]
        elements,_=generated_elements(self.model(),lambda _:first)
        self.assertEqual(len(elements),9)

    def test_source_texture_bytes_unchanged(self):
        image=Image.fromarray(np.random.default_rng(5).integers(0,256,(8,16,4),dtype=np.uint8))
        before=image.tobytes()
        generated_elements(self.model(),lambda _:image)
        self.assertEqual(image.tobytes(),before)

if __name__=='__main__':unittest.main()
