"""2.4.3 acceptance: the two displayed metrics decide review promotion."""
import copy
import csv
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from app import Studio
from bridge.catalog import compact_report
from bridge.pipeline import export_result, run_conversion
from bridge.verification import final_status
from test_pipeline import make_fixture


def matching_report(**extra):
    return {'id':'fixture:block/sample', 'slug':'sample', 'status':'review',
            'metrics':{'geometry_independent':{'surface_geometry_equal':True},
                       'rgba_texels_preserved':True}, **extra}


class ReviewPromotionTests(unittest.TestCase):
    def test_matching_models_promote_regardless_of_size_type_or_warnings(self):
        for extended in (False, True):
            for kind in ('block_geometry', 'entity_geometry', 'surface_approximation', None):
                with self.subTest(extended=extended, kind=kind):
                    report=matching_report(extended3d=extended, target_kind=kind,
                                           warnings=['Diagnóstico conservado'], runtime_tested=False)
                    report['metrics']['six_views']={'all_views_pixel_identical':False}
                    before=copy.deepcopy(report)
                    self.assertEqual(final_status(report),'verified_static')
                    self.assertEqual(compact_report(report)['status'],'verified_static')
                    self.assertEqual(report,before)

    def test_both_metrics_require_explicit_true_booleans(self):
        for value in (False, None, 'true', 'false', 1, 0, [], {}):
            for field in ('geometry', 'textures'):
                report=matching_report()
                if field=='geometry':report['metrics']['geometry_independent']['surface_geometry_equal']=value
                else:report['metrics']['rgba_texels_preserved']=value
                with self.subTest(value=value,field=field):
                    self.assertEqual(final_status(report),'review')
        for metrics in ({}, None, {'rgba_texels_preserved':True},
                        {'geometry_independent':{'surface_geometry_equal':True}}):
            self.assertEqual(final_status(matching_report(metrics=metrics)),'review')

    def test_missing_textures_in_either_view_prevent_promotion(self):
        for side in ('original','translated'):
            report=matching_report()
            report['metrics']['six_views']={'missing_textures':{side:['missing.png']}}
            self.assertEqual(final_status(report),'review')

    def test_other_statuses_are_unchanged_even_with_matching_metrics(self):
        for status in ('unsupported','error','no_renderable','pending','verified_static',None):
            self.assertEqual(final_status(matching_report(status=status)),status)

    def test_metric_aliases_and_precedence_match_the_cards(self):
        for geom in ('surface_geometry_equal','equivalent','geometry_equal','geometry_match','geometry_exact','same_geometry'):
            for tex in ('rgba_texels_preserved','texels_equal','textures_equal','texture_pixels_equal','texture_match','pixel_exact','texture_exact'):
                for container in ('geometry_independent','geometry',None):
                    metrics={container:{geom:True}} if container else {geom:True}
                    metrics['textures']={tex:True}
                    self.assertEqual(final_status(matching_report(metrics=metrics)),'verified_static')
        for extra in ({'geometry_independent':{}}, {'textures':{}},
                      {'geometry_independent':{'surface_geometry_equal':False,'equivalent':True}},
                      {'textures':{'rgba_texels_preserved':None,'textures_equal':True}}):
            metrics={**matching_report()['metrics'],**extra}
            self.assertEqual(final_status(matching_report(metrics=metrics)),'review')

    def test_low_vertex_error_or_matching_renders_alone_are_not_enough(self):
        report=matching_report(metrics={'max_vertex_error_pixels':0, 'rgba_texels_preserved':True,
                                        'six_views':{'all_views_pixel_identical':True}})
        self.assertEqual(final_status(report),'review')

    def test_explicit_independent_uv_failure_blocks_promotion_and_stale_verified(self):
        for status in ('review','verified_static'):
            report=matching_report(status=status)
            report['metrics']['geometry_independent']['uv_mapping_check_passed']=False
            self.assertEqual(final_status(report),'review')
        report=matching_report()
        report['metrics']['geometry_independent']['uv_mapping_check_passed']=True
        self.assertEqual(final_status(report),'verified_static')


class ReexportPromotionTests(unittest.TestCase):
    def test_legacy_review_promotes_in_full_partial_exports_and_model_api(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);jar=root/'fixture.jar';make_fixture(jar)
            run=root/'run'
            result=run_conversion(jar,run,models=['fixture:block/sample'],size=64)
            old=copy.deepcopy(result['reports'][0]);old['status']='review'
            old['warnings'].append('Aviso previo conservado')
            before=copy.deepcopy(old);md=run/'models'/old['slug']
            files={name:(md/name).read_bytes() for name in ('model.geo.json','atlas.png','atlas_map.json')}
            (md/'report.json').write_text(json.dumps(old),encoding='utf-8')
            studio=Studio(root/'workspace',java=jar)
            studio.ready[old['id']]={**compact_report(old),'run':str(run)}
            self.assertEqual(studio.model(old['id'])['report']['status'],'verified_static')
            for name in ('exportacion','exportacion_parcial'):
                exported=export_result(run,[old],{},planned_total=2,export_name=name)
                self.assertEqual(exported['reports'][0]['status'],'verified_static')
                self.assertEqual(exported['summary']['statuses'],{'verified_static':1})
                self.assertTrue(exported['summary']['cancelled'])
                with zipfile.ZipFile(exported['archive']) as z:
                    self.assertIsNone(z.testzip())
                    report=json.loads(z.read('reportes/modelos/'+old['slug']+'.json'))
                    self.assertEqual(report['status'],'verified_static')
                    self.assertEqual(report['metrics'],old['metrics'])
                    self.assertEqual(report['warnings'],old['warnings'])
                    self.assertFalse(report['runtime_tested'])
                    summary=json.loads(z.read('reportes/resumen.json'))
                    self.assertEqual(summary['statuses'],{'verified_static':1})
                    rows=list(csv.DictReader(io.StringIO(z.read('reportes/resumen.csv').decode('utf-8-sig'))))
                    self.assertEqual(rows[0]['estado'],'verified_static')
                    self.assertIn('Verificado estático',z.read('ABRIR_COMPARACION.html').decode())
                    self.assertIn('Estado: verified_static',z.read('comparaciones/'+old['slug']+'/LEER_ESTADO.txt').decode())
                    for filename,content in files.items():
                        self.assertEqual(z.read('modelos_traducidos/'+old['slug']+'/'+filename),content)
            self.assertEqual(old,before)
            self.assertEqual(json.loads((md/'report.json').read_text()),before)


if __name__=='__main__':unittest.main()
