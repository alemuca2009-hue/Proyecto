import copy
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

from PIL import Image, ImageChops

from bridge.render_annotations import count_vertices, annotate_vertex_count
from bridge.render_export import export_renders, ROOT_DIRECTORY, load_render_ir
from bridge.render_modes import ProfileRenderer
from bridge.rendering import combined_bounds
from test_render_export import cube, write_model, profile, config, hashes


class RenderAnnotationTests(unittest.TestCase):
    def test_unique_positions_count_shared_corners_once_without_rounding_or_uv_merging(self):
        ir = cube()
        ir['faces'] += copy.deepcopy(ir['faces'])
        ir['faces'].append({'vertices': [[1+1e-10,1,1], [1,1,1], [-1,-1,-1]]})
        before = copy.deepcopy(ir)
        self.assertEqual(count_vertices(ir), 9)
        self.assertEqual(ir, before)

    def test_badge_fits_supported_sizes_and_changes_only_its_top_right_rectangle(self):
        for size in (64,128,192,256,512):
            with self.subTest(size=size):
                image = Image.new('RGBA',(size,size),(50,90,130,255))
                before = image.copy()
                info = annotate_vertex_count(image, 1234567)
                left,top,right,bottom = info['bounds']
                self.assertEqual(info['text'],'VÉRTICES: 1234567')
                self.assertGreaterEqual(left,0);self.assertGreater(top,0)
                self.assertLess(right,size);self.assertLess(bottom,size//2)
                self.assertIn((255,255,255,255),set(image.crop(info['bounds']).getdata()))
                changed = ImageChops.difference(image,before).convert('RGB').getbbox()
                self.assertIsNotNone(changed)
                self.assertEqual(changed,tuple(info['bounds']))
                image.paste(before.crop(info['bounds']),(left,top))
                self.assertEqual(image.tobytes(),before.tobytes())

    def test_export_uses_each_representations_full_count_for_every_mode_and_view(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary);model = root/'model'
            descriptor = write_model(model)
            translated = cube()
            translated['faces'] = translated['faces'][:1]
            (model/'ir_bedrock.json').write_text(json.dumps(translated))
            before = hashes(model)
            selection = config([profile(representation='comparison',size=128,
                views=['frontal','superior'],modes=['wireframe','solid','texture'],three_combinations=True)])
            result = export_renders(selection,{'m':descriptor},root/'export')
            self.assertEqual((result['generated'],result['failed']),(36,0))
            irs = {r:load_render_ir(model,r) for r in ('original','translated')}
            bounds = combined_bounds(*irs.values())
            with zipfile.ZipFile(result['archive']) as archive:
                manifest = json.loads(archive.read(ROOT_DIRECTORY+'/manifiesto.json'))
                self.assertEqual(manifest['models'][0]['vertex_counts'],{'original':8,'translated':4})
                for row in manifest['images']:
                    count = 8 if row['representation']=='original' else 4
                    self.assertEqual(row['vertex_count'],count)
                    with Image.open(io.BytesIO(archive.read(row['path']))) as image:
                        self.assertEqual(image.info['VertexCount'],str(count))
                        self.assertEqual(image.info['Representation'],row['representation'])
                        # The unannotated renderer still has its original pixels/framing.
                        expected = ProfileRenderer(irs[row['representation']],bounds=bounds).render(
                            row['view'],size=row['size'],mode=row['mode'],xray=row['xray'],normals=row['normals'],opacity=row['opacity'])
                        bbox = row['vertex_annotation']['bounds']
                        restored = image.copy();restored.paste(expected.crop(bbox),tuple(bbox[:2]))
                        self.assertEqual(restored.tobytes(),expected.tobytes())
            self.assertEqual(hashes(model),before)


if __name__ == '__main__':unittest.main()
