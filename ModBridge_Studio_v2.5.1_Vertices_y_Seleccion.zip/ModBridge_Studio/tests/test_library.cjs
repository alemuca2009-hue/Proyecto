const {test} = require('node:test');
const assert = require('node:assert/strict');
const lib = require('../web/library.js');
const models = ['z:block/alpha','a:block/zeta','a:block/beta','x:block/base','x:block/damaged','x:block/template','x:block/pending'].map(id => ({id}));
const reports = [
  {id:models[0].id,status:'verified_static',extended3d:false},
  {id:models[1].id,status:'review',extended3d:true},
  {id:models[2].id,status:'review',extended3d:false},
  {id:models[3].id,status:'unsupported',extended3d:true},
  {id:models[4].id,status:'error',extended3d:false},
  {id:models[5].id,status:'no_renderable',extended3d:false}
];
const ids = options => lib.visibleModels(models,reports,options).map(m => m.id);

test('exactly four disjoint result groups; pending is not a fifth result', () => {
  const groups = ['verified','review','failed','template'];
  const matches = groups.flatMap(group => ids({group}));
  assert.equal(matches.length,6);assert.equal(new Set(matches).size,6);
  assert.deepEqual(ids({group:'failed'}),[models[3].id,models[4].id]);
  assert.equal(lib.resultGroup({status:'pending'}),null);
  assert.equal(lib.resultGroup({status:'constructor'}),null);
  assert.equal(ids({}).length,7);
});
test('no conversion data means no color or extended results', () => {
  assert.equal(lib.hasResults([]),false);
  assert.equal(lib.hasResults([{status:'pending'}]),false);
  assert.equal(lib.hasResults(reports),true);
  assert.equal(lib.visibleModels(models,[],{group:'review'}).length,0);
  assert.equal(lib.visibleModels(models,[],{extendedOnly:true}).length,0);
});
test('extended flag combines with color and text by intersection', () => {
  assert.deepEqual(ids({group:'review',extendedOnly:true}),[models[1].id]);
  assert.deepEqual(ids({extendedOnly:true,query:' X:BLOCK/ '}),[models[3].id]);
  assert.deepEqual(ids({group:'verified',extendedOnly:true}),[]);
});
test('a group replaces another group, rather than accumulating it', () => {
  const options={group:'review'};
  assert.equal(ids(options).length,2);options.group='verified';
  assert.deepEqual(ids(options),[models[0].id]);options.group='';
  assert.equal(ids(options).length,models.length);
});
test('A-Z works before conversion and leaves IDs and catalogue order intact', () => {
  const before=structuredClone(models);
  const sorted=lib.visibleModels(models,[],{sortAZ:true});
  assert.deepEqual(sorted.map(m=>m.id),[models[0].id,models[3].id,models[2].id,models[4].id,models[6].id,models[5].id,models[1].id]);
  assert.deepEqual(models,before);
  assert.deepEqual(lib.visibleModels(models,[],{sortAZ:false}),before);
});
test('equal displayed names use the full unchanged identifier as tie breaker', () => {
  const source=[{id:'z:block/wheel'},{id:'a:block/wheel'}];
  assert.deepEqual(lib.visibleModels(source,[],{sortAZ:true}).map(m=>m.id),['a:block/wheel','z:block/wheel']);
});
test('result count covers all matches, not only the first page', () => {
  const source=Array.from({length:245},(_,i)=>({id:`test:block/model_${i}`}));
  const ready=source.map((m,i)=>({...m,status:i%2?'review':'verified_static',extended3d:false}));
  const filtered=lib.visibleModels(source,ready,{group:'verified'});
  assert.equal(filtered.length,123);assert.equal(filtered.slice(100).length,23);
});
test('conversion without selection sends only the filtered identifiers', () => {
  assert.deepEqual(lib.conversionIds(models,reports,{group:'review',extendedOnly:true},new Set()),[models[1].id]);
  assert.deepEqual(lib.conversionIds(models,reports,{query:'absent'},new Set()),[]);
});
test('explicit hidden selections are retained and stale identifiers excluded', () => {
  assert.deepEqual(lib.conversionIds(models,reports,{group:'review'},new Set([models[0].id,'missing:model'])),[models[0].id]);
});
test('ready data overrides completion data including false, with no lost IDs', () => {
  const merged=lib.mergeReports([{id:'a',status:'review',extended3d:true},{id:'b',status:'error'}],
    [{id:'a',status:'verified_static',extended3d:false}]);
  assert.equal(merged.length,2);assert.equal(merged[0].extended3d,false);
  assert.deepEqual(lib.mergeReports(reports,[]),reports);
});
test('same-sized catalogues still detect status and extended flag updates', () => {
  const before=lib.reportSignature(reports), after=structuredClone(reports);
  after[0].extended3d=true;assert.notEqual(lib.reportSignature(after),before);
  after[0].extended3d=false;after[0].status='review';assert.notEqual(lib.reportSignature(after),before);
});
test('the extended filter requires a true boolean, not truthy data', () => {
  const source=[{id:'a'}];
  for(const value of ['true','false',1,undefined])
    assert.equal(lib.visibleModels(source,[{id:'a',status:'review',extended3d:value}],{extendedOnly:true}).length,0);
});

test('advanced facets combine OR within a category and AND across categories and existing filters', () => {
  const source=[{id:'a:block/a'},{id:'a:block/b'},{id:'a:block/c'},{id:'a:block/pending'}];
  const ready=[
    {id:source[0].id,status:'review',extended3d:true,analysis:{geometry:['matching','surface_reconstructed'],textures:['pixels_preserved']}},
    {id:source[1].id,status:'review',extended3d:false,analysis:{geometry:['different','surface_approximation'],textures:['uv_unverified']}},
    {id:source[2].id,status:'verified_static',extended3d:false,analysis:{geometry:['matching'],textures:['pixels_preserved']}}
  ];
  const ids=options=>lib.visibleModels(source,ready,options).map(x=>x.id);
  assert.deepEqual(ids({geometryStates:['matching','different']}),source.slice(0,3).map(x=>x.id));
  assert.deepEqual(ids({geometryStates:['matching','different'],textureStates:['uv_unverified']}),[source[1].id]);
  assert.deepEqual(ids({geometryStates:['matching'],textureStates:['pixels_preserved'],group:'review',extendedOnly:true}),[source[0].id]);
  assert.deepEqual(ids({geometryStates:['unreviewed'],textureStates:['unreviewed']}),[source[3].id]);
  assert.deepEqual(ids({geometryStates:['invented']}),[]);
  assert.deepEqual(ids({geometryStates:[],textureStates:[]}),source.map(x=>x.id));
  assert.deepEqual(lib.conversionIds(source,ready,{textureStates:['uv_unverified']},new Set()),[source[1].id]);
  assert.deepEqual(lib.conversionIds(source,ready,{textureStates:['uv_unverified']},new Set([source[0].id])),[source[0].id]);
});

test('reconstructed surfaces never remain in verified even in stale compact or full records', () => {
  for (const flags of [{requires_surface_review:true},{target_kind:'surface_reconstructed'},
      {target_kind:'surface_approximation',metrics:{surface:{exact_geometry:true}}}]) {
    assert.equal(lib.resultGroup({id:'x',status:'verified_static',...flags}),'review');
    assert.equal(lib.visibleModels([{id:'x'}],[{id:'x',status:'verified_static',...flags}],{group:'verified'}).length,0);
  }
});

test('facet-only updates invalidate the library signature without modifying reports', () => {
  const a=[{id:'x',status:'review',analysis:{geometry:['matching'],textures:['pixels_preserved']}}];
  const b=structuredClone(a);b[0].analysis.textures=['uv_difference'];
  assert.notEqual(lib.reportSignature(a),lib.reportSignature(b));
  const before=structuredClone(a);
  lib.visibleModels([{id:'x'}],a,{geometryStates:['matching']});
  assert.deepEqual(a,before);
});
