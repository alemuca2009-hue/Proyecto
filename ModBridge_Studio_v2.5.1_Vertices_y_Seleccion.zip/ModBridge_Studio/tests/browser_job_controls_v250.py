"""Real browser/server/worker checks. Optional dev dependency: Playwright/Chromium."""
import json
import os
from pathlib import Path
import queue
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import zipfile
from playwright.sync_api import sync_playwright, expect


def main():
    root=Path(__file__).resolve().parents[1]
    with tempfile.TemporaryDirectory(prefix='modbridge-browser250-') as tmp:
        temp=Path(tmp)
        server=subprocess.Popen([sys.executable,'-u','app.py','serve','--no-browser','--port','0',
            '--workspace',str(temp/'workspace'),'--input','examples/Demostracion_ModBridge.jar'],cwd=root,
            stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        lines=queue.Queue()
        def consume():
            for line in server.stdout:lines.put(line)
        threading.Thread(target=consume,daemon=True).start()
        try:
            origin=None;deadline=time.monotonic()+20
            while origin is None and time.monotonic()<deadline:
                try:line=lines.get(timeout=.2)
                except queue.Empty:continue
                match=re.search(r'http://127\.0\.0\.1:\d+',line)
                if match:origin=match.group(0)
            assert origin,'Server startup timeout'
            with sync_playwright() as playwright:
                browser=playwright.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_EXECUTABLE') or shutil.which('chromium'),
                    args=['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
                page=browser.new_page(viewport={'width':1440,'height':1100},accept_downloads=True)
                errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto(origin)
                page.wait_for_function("document.querySelectorAll('.model-open').length===6")
                expect(page.locator('#pause-button')).to_be_disabled()
                expect(page.locator('#restart-button')).to_be_disabled()
                page.locator('#restart-control').hover()
                expect(page.locator('#restart-help')).to_be_visible()
                expect(page.locator('#restart-help')).to_have_text('Ocupas seleccionar modelos')
                grey=page.locator('#pause-button').evaluate('(e)=>getComputedStyle(e).backgroundColor')
                assert grey=='rgb(81, 91, 91)',grey
                for width in (1440,390):
                    page.set_viewport_size({'width':width,'height':1100})
                    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
                page.set_viewport_size({'width':1440,'height':1100})
                page.locator('#select-all').check();page.locator('#render-size').select_option('192')
                page.locator('#convert-button').click()
                expect(page.locator('#pause-button')).to_be_enabled(timeout=10000)
                page.locator('#pause-button').click()
                expect(page.locator('#pause-label')).to_have_text('Continuar')
                page.wait_for_function("document.querySelector('#job-title').textContent==='Conversión en pausa'",timeout=15000)
                green=page.locator('#pause-button').evaluate('(e)=>getComputedStyle(e).backgroundColor')
                assert green in ('rgb(67, 157, 88)','rgb(52, 131, 71)'),green
                state=page.request.get(origin+'/api/status').json()
                assert state['job']['state']=='paused'
                time.sleep(.3)
                assert page.request.get(origin+'/api/status').json()['job']['progress']==state['job']['progress']
                screenshot=os.environ.get('QA_SCREENSHOTS')
                if screenshot:
                    Path(screenshot).mkdir(parents=True,exist_ok=True)
                    page.screenshot(path=str(Path(screenshot)/'paused-desktop.png'),full_page=True)
                page.locator('#pause-button').click()
                page.wait_for_function("document.querySelector('#download-button').getAttribute('aria-disabled')==='false'",timeout=90000)
                expect(page.locator('#pause-label')).to_have_text('Pausar')
                with page.expect_download() as download:page.locator('#download-button').click()
                before=temp/'before.zip';download.value.save_as(before)
                page.locator('#select-all').uncheck()
                mid='demo:block/asimetrico'
                page.locator(f'#model-list input[data-id="{mid}"]').check()
                expect(page.locator('#restart-button')).to_be_enabled()
                with page.expect_request(lambda request:request.url.endswith('/api/restart')) as requested:
                    page.locator('#restart-button').click()
                assert requested.value.post_data_json['models']==[mid]
                page.wait_for_function("document.querySelector('#download-button').getAttribute('aria-disabled')==='false'",timeout=90000)
                state=page.request.get(origin+'/api/status').json()
                assert state['job']['operation']=='restart' and state['job']['state']=='done'
                assert state['result']['summary']['total']==6
                with page.expect_download() as download:page.locator('#download-button').click()
                after=temp/'after.zip';download.value.save_as(after)
                with zipfile.ZipFile(before) as a,zipfile.ZipFile(after) as b:
                    unchanged=[name for name in a.namelist() if name.startswith('modelos_traducidos/') and (name.endswith('model.geo.json') or name.endswith('atlas.png')) and 'demo_block_asimetrico_' not in name]
                    assert unchanged
                    assert all(a.read(name)==b.read(name) for name in unchanged)
                page.set_viewport_size({'width':390,'height':1100})
                assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
                if screenshot:page.screenshot(path=str(Path(screenshot)/'controls-mobile.png'),full_page=True)
                assert not errors,errors
                print(json.dumps({'ok':True,'browser':browser.version,'grey_pause':grey,'green_continue':green,
                    'pause_freezes_progress':True,'resume_finishes_same_batch':True,'restart_selected_only':True,
                    'unselected_export_files_unchanged':len(unchanged),'tooltip_no_selection':True,
                    'viewport_widths':[1440,390],'javascript_errors':errors},indent=2))
                browser.close()
        finally:
            server.terminate()
            try:server.wait(timeout=5)
            except subprocess.TimeoutExpired:server.kill();server.wait(timeout=5)


if __name__=='__main__':main()
