/* Integration/pixel checks. Requires Node + Playwright with Chromium installed.
   Run: node tests/test_viewer_browser.cjs
   Optional: CHROMIUM_EXECUTABLE, PYTHON, QA_SCREENSHOTS. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {spawn} = require('node:child_process');
const {chromium} = require('playwright');

(async () => {
  const root = path.resolve(__dirname, '..');
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'modbridge-viewer-'));
  const server = spawn(process.env.PYTHON || 'python3', ['-u', 'app.py', 'serve', '--no-browser', '--port', '0',
    '--workspace', temp, '--input', 'examples/Demostracion_ModBridge.jar'], {cwd: root});
  let browser;
  try {
    const origin = await new Promise((resolve, reject) => {
      let output = '';
      const timer = setTimeout(() => reject(new Error('Server did not start')), 15000);
      server.stdout.on('data', (data) => {
        output += data.toString(); const match = output.match(/http:\/\/127\.0\.0\.1:\d+/);
        if (match) { clearTimeout(timer); resolve(match[0]); }
      });
      server.once('exit', (code) => { clearTimeout(timer); reject(new Error(`Server exited: ${code}`)); });
    });
    browser = await chromium.launch({headless: true, executablePath: process.env.CHROMIUM_EXECUTABLE || undefined,
      args: process.env.CHROMIUM_ARGS ? JSON.parse(process.env.CHROMIUM_ARGS) : ['--no-sandbox', '--disable-dev-shm-usage', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader']});
    const page = await browser.newPage({viewport: {width: 1440, height: 1100}});
    await page.route('**/test-*.png', async (route) => {
      const name = new URL(route.request().url()).pathname.slice(1);
      const allowed = ['test-red.png','test-blue.png','test-clear.png','test-half-red.png','test-quadrants.png'];
      if (!allowed.includes(name)) return route.abort();
      await route.fulfill({contentType:'image/png',body:fs.readFileSync(path.join(__dirname,'fixtures',name))});
    });
    const errors = [], textureRequests = [];
    page.on('pageerror', (error) => errors.push(error.message));
    page.on('console', (message) => { if (message.type() === 'error') errors.push(message.text()); });
    page.on('request', (request) => { if (request.url().includes('/api/texture?')) textureRequests.push(request.url()); });
    await page.goto(origin);
    await page.locator('.model-open[data-id="demo:block/asimetrico"]').click();
    await page.locator('#preview-button').click();
    await page.waitForFunction(() => document.querySelector('#paired-view').hidden === false, {timeout: 30000});
    assert.equal(textureRequests.length, 0, 'Six views must not load 3D textures');
    await page.locator('[data-panel="geometry"]').click();
    await page.waitForFunction(() => document.querySelector('#preview-detail').textContent.includes('Texturas visibles'));
    assert.ok(textureRequests.length > 0);
    assert.equal(await page.locator('[data-view-mode=texture]').getAttribute('aria-checked'), 'true');
    assert.equal(await page.locator('[data-view-mode]').count(), 3, 'Only the three requested shading modes');
    const source = page.locator('#original-canvas'), target = page.locator('#bedrock-canvas');
    const withTexture = await source.screenshot();
    if (process.env.QA_SCREENSHOTS) await page.screenshot({path: path.join(process.env.QA_SCREENSHOTS, 'viewer-textured.png'), fullPage: true});
    await page.locator('[data-view-mode=solid]').click();
    await page.waitForFunction(() => document.querySelector('#preview-detail').textContent.includes('Sólido'));
    const withoutTexture = await source.screenshot();
    assert.ok(!withTexture.equals(withoutTexture), 'Switch changes rendered pixels');
    const beforeRotate = await target.screenshot();
    await source.focus(); await page.keyboard.press('ArrowRight');
    assert.ok(!(await target.screenshot()).equals(beforeRotate), 'Other camera follows rotation');
    await page.locator('#reset-camera').click();
    const resetPixels = await source.screenshot();
    if(process.env.QA_SCREENSHOTS){fs.writeFileSync(path.join(process.env.QA_SCREENSHOTS,'solid-before.png'),withoutTexture);fs.writeFileSync(path.join(process.env.QA_SCREENSHOTS,'solid-reset.png'),resetPixels);}

    await page.locator('[data-view-mode=texture]').click();
    await page.waitForFunction(() => document.querySelector('#preview-detail').textContent.includes('Texturas visibles'));
    const restored = await source.screenshot();
    if(process.env.QA_SCREENSHOTS){fs.writeFileSync(path.join(process.env.QA_SCREENSHOTS,'texture-before.png'),withTexture);fs.writeFileSync(path.join(process.env.QA_SCREENSHOTS,'texture-restored.png'),restored);}
    const sameImage = async (before, after) => page.evaluate(async (urls) => {
      const arrays = [];
      for (const url of urls) {
        const image = new Image(); image.src = url; await image.decode();
        const canvas = document.createElement('canvas'); canvas.width = image.width; canvas.height = image.height;
        const ctx = canvas.getContext('2d'); ctx.drawImage(image,0,0);
        arrays.push(ctx.getImageData(0,0,canvas.width,canvas.height).data);
      }
      if (arrays[0].length !== arrays[1].length) return false;
      let changed=0;
      for(let i=0;i<arrays[0].length;i+=4){
        const d=Math.max(...[0,1,2].map((j)=>Math.abs(arrays[0][i+j]-arrays[1][i+j])));
        if(d>8)return false; if(d)changed++;
      }
      // Chromium's antialiasing may vary by a few values on subpixel edges
      // after scrolling a canvas into view; interior texels must stay exact.
      return changed/(arrays[0].length/4)<.001;
    }, [before,after].map((data)=>'data:image/png;base64,'+data.toString('base64')));
    const restoredPixels = await sameImage(withTexture,restored);
    assert.ok(await sameImage(withoutTexture,resetPixels), 'Reset restores the same framing');
    assert.ok(restoredPixels, 'Toggling restores original texture pixels');
    await page.locator('[data-view-mode=solid]').click();
    await page.reload(); await page.locator('[data-panel="geometry"]').click();
    assert.equal(await page.locator('[data-view-mode=solid]').getAttribute('aria-checked'), 'true', 'Choice survives reload');
    await page.waitForFunction(() => document.querySelector('#source-face-count').textContent.includes('caras') && !document.querySelector('#source-face-count').textContent.includes('—'));
    // Independent overlay toggles, opacity, keyboard controls and persistence.
    const solid = await source.screenshot();
    await page.locator('[data-view-mode=wireframe]').click();
    await page.waitForFunction(() => document.querySelector('#preview-detail').textContent.includes('Alambre'));
    assert.ok(!(await source.screenshot()).equals(solid), 'Wireframe shows actual perimeter edges');
    await page.locator('#xray-toggle').click();
    assert.equal(await page.locator('#xray-toggle').getAttribute('aria-checked'), 'true');
    assert.equal(await page.locator('#xray-opacity-control').isVisible(), true);
    const xray35 = await source.screenshot();
    await page.locator('#xray-opacity').fill('65');
    await page.waitForFunction(() => document.querySelector('#xray-opacity-value').textContent === '65%');
    assert.ok(!(await source.screenshot()).equals(xray35), 'Opacity affects hidden edges');
    await page.locator('label[for=normals-toggle]').click();
    assert.equal(await page.locator('#normals-toggle').isChecked(), true);
    assert.equal(await page.locator('#normals-state').textContent(), 'ON');
    assert.equal(await page.locator('#normals-legend').isVisible(), true);
    await page.locator('[data-view-mode=wireframe]').focus(); await page.keyboard.press('ArrowRight');
    assert.equal(await page.locator('[data-view-mode=solid]').getAttribute('aria-checked'), 'true');
    if(process.env.QA_SCREENSHOTS) await page.screenshot({path:path.join(process.env.QA_SCREENSHOTS,'viewer-v23-normals.png'),fullPage:true});
    await page.reload(); await page.locator('[data-panel=geometry]').click();
    assert.equal(await page.locator('#xray-toggle').getAttribute('aria-checked'), 'true');
    assert.equal(await page.locator('#normals-toggle').isChecked(), true);
    assert.equal(await page.locator('#xray-opacity').inputValue(), '65');
    // Check every control with both optional rows visible at desktop and phone widths.
    for(const width of [1440,1120,900,768,660,520,390,360]){
      await page.setViewportSize({width,height:1000});
      const layout=await page.evaluate(()=>{
        const canvasTop=document.querySelector('#original-canvas').getBoundingClientRect().top;
        const controls=[...document.querySelectorAll('#xray-toggle,[data-view-mode],.normals-switch,#reset-camera,.xray-opacity,.normals-legend,.camera-sync')].map(e=>({name:e.id||e.className,r:e.getBoundingClientRect()})).filter(e=>e.r.width&&e.r.height);
        const clashes=[];
        for(let i=0;i<controls.length;i++){
          const a=controls[i];if(a.r.bottom>canvasTop)clashes.push(a.name+' covers model');
          for(let j=i+1;j<controls.length;j++){const b=controls[j];if(Math.min(a.r.right,b.r.right)-Math.max(a.r.left,b.r.left)>1 && Math.min(a.r.bottom,b.r.bottom)-Math.max(a.r.top,b.r.top)>1)clashes.push(a.name+' / '+b.name);}
        }
        return {clashes,overflow:document.documentElement.scrollWidth>innerWidth};
      });
      assert.deepEqual(layout,{clashes:[],overflow:false}, 'Controls fit at '+width+' px');
    }
    await page.setViewportSize({width: 390, height: 844});
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, 'Mobile has no horizontal overflow');
    if (process.env.QA_SCREENSHOTS) await page.screenshot({path: path.join(process.env.QA_SCREENSHOTS, 'viewer-mobile.png'), fullPage: true});

    // Run renderer pixel checks in isolation from UI formatting, on the same origin.
    await page.setViewportSize({width: 800, height: 600});
    const pixels = await page.evaluate(async () => {
      const box = document.createElement('div'); box.style.cssText = 'position:fixed;inset:0;width:200px;height:200px;z-index:99999';
      const canvas = document.createElement('canvas'); canvas.style.cssText = 'width:200px;height:200px'; box.append(canvas); document.body.append(box);
      const viewer = new ModBridgeViewer(canvas);
      if (viewer.error) throw new Error(viewer.error);
      const camera = {yaw:0, pitch:0, zoom:1}, bounds = {center:[0,0,0],min:[-1,-1,-1],max:[1,1,1],span:3};
      const plane = (z, key, x0=-1, x1=1) => ({vertices:[[x0,-1,z],[x1,-1,z],[x1,1,z],[x0,1,z]],uv:[[0,1],[1,1],[1,0],[0,0]],texture:key});
      const load = async (faces, colors) => {
        // HTTP fixture images are routed by Playwright; no external data is used.
        viewer.setScene({faces,textures:colors}); viewer.render(camera,bounds,true);
        for (let i=0;i<200 && viewer.status().loading;i++) await new Promise((r)=>setTimeout(r,10));
        if (viewer.status().loading || viewer.status().failed) throw new Error('Fixture texture did not load');
        viewer.render(camera,bounds,true);
      };
      const pixel = (x=100,y=100,options=true) => {
        viewer.render(camera,bounds,options);
        const value = new Uint8Array(4); viewer.gl.readPixels(x,y,1,1,viewer.gl.RGBA,viewer.gl.UNSIGNED_BYTE,value); return [...value];
      };
      await load([plane(.5,'front'),plane(-.5,'back')],{front:'/test-red.png',back:'/test-blue.png'});
      const occlusion = pixel();
      await load([plane(-.5,'back'),plane(.5,'front')],{front:'/test-red.png',back:'/test-blue.png'});
      const reversed = pixel();
      await load([plane(.5,'front'),plane(-.5,'back')],{front:'/test-clear.png',back:'/test-blue.png'});
      const cutout = pixel();
      await load([plane(.5,'front'),plane(-.5,'back')],{front:'/test-half-red.png',back:'/test-blue.png'});
      const blend = pixel();
      const quad = plane(0,'quadrants'); quad.uv=[[0,3],[3,3],[3,0],[0,0]];
      await load([quad],{quadrants:'/test-quadrants.png'});
      const topLeft=pixel(60,140),topRight=pixel(140,140),bottomLeft=pixel(60,60),bottomRight=pixel(140,60);
      await load([plane(0,'front')],{front:'/test-red.png'});
      const normalFront = pixel(100,100,{mode:'solid',normals:true});
      camera.yaw=Math.PI;
      const normalInterior = pixel(100,100,{mode:'solid',normals:true}); camera.yaw=0;
      const inverted=plane(0,'front');inverted.vertices.reverse();
      await load([inverted],{front:'/test-red.png'});
      const normalInverted=pixel(100,100,{mode:'texture',normals:true});
      const normalOff=pixel(100,100,{mode:'texture',normals:false});
      await load([plane(0,'front')],{front:'/test-red.png'});
      const wireCenter=pixel(100,100,{mode:'wireframe'});
      const xrayLight=pixel(100,100,{mode:'solid',xray:true,opacity:.15});
      const xrayDense=pixel(100,100,{mode:'solid',xray:true,opacity:.85});
      const back=plane(-.5,'back');back.vertices=back.vertices.map(v=>[v[0]*.5,v[1]*.5,v[2]]);
      await load([plane(.5,'front'),back],{front:'/test-red.png',back:'/test-blue.png'});
      const edgeRegion=(xray)=>{
        viewer.render(camera,bounds,{mode:'wireframe',xray,opacity:.65});
        const values=new Uint8Array(4*5*5);viewer.gl.readPixels(70,98,5,5,viewer.gl.RGBA,viewer.gl.UNSIGNED_BYTE,values);
        return Math.max(...values.filter((_,i)=>i%4===1));
      };
      const edgeHidden=edgeRegion(false),edgeRevealed=edgeRegion(true);
      const glError=viewer.gl.getError(); viewer.releaseScene(); box.remove();
      return {occlusion,reversed,cutout,blend,topLeft,topRight,bottomLeft,bottomRight,normalFront,normalInterior,normalInverted,normalOff,wireCenter,xrayLight,xrayDense,edgeHidden,edgeRevealed,glError};
    });
    assert.deepEqual(pixels.occlusion,[255,0,0,255]);
    assert.deepEqual(pixels.reversed,pixels.occlusion,'Depth must not depend on face order');
    assert.deepEqual(pixels.cutout,[0,0,255,255],'Cutouts reveal the surface behind');
    assert.ok(Math.abs(pixels.blend[0]-128)<=1 && Math.abs(pixels.blend[2]-127)<=1,'Translucency blends both layers');
    assert.deepEqual(pixels.topLeft,[255,0,0,255]); assert.deepEqual(pixels.topRight,[0,255,0,255]);
    assert.deepEqual(pixels.bottomLeft,[0,0,255,255]); assert.deepEqual(pixels.bottomRight,[255,255,0,255]);
    assert.deepEqual(pixels.normalFront,[41,102,255,255],'Exterior must be blue');
    assert.deepEqual(pixels.normalInterior,[255,51,61,255],'Back of same face must be red');
    assert.deepEqual(pixels.normalInverted,pixels.normalInterior,'Reversed winding must not be auto-corrected');
    assert.deepEqual(pixels.normalOff,[255,0,0,255],'Normals OFF restores textures');
    assert.deepEqual(pixels.wireCenter,[19,28,23,255],'Wireframe is empty and has no triangulation diagonal');
    assert.ok(pixels.xrayDense[1]>pixels.xrayLight[1]+50,'X-ray surface opacity is adjustable');
    assert.ok(pixels.edgeRevealed>pixels.edgeHidden+40,'X-ray reveals occluded edges');
    assert.equal(pixels.glError,0);
    assert.deepEqual(errors,[],'No browser errors');
    console.log(JSON.stringify({ok:true,checks:['Three shading modes','texture pixels restored','synchronized rotation','reset framing','persistent choice','nonoverlapping controls at eight viewport sizes','x-ray toggle','opacity slider','independent normals switch','blue exterior and red interior','inverted winding','hidden edge reveal','perimeter-only wireframe','keyboard mode navigation','opaque depth order','alpha cutout','alpha blend','UV orientation','NPOT texture','WebGL errors'],pixels},null,2));
  } finally {
    if (browser) await browser.close();
    server.kill('SIGINT');
    await new Promise((resolve)=>{ if(server.exitCode!==null)resolve();else server.once('exit',resolve); });
    fs.rmSync(temp,{recursive:true,force:true});
  }
})().catch((error)=>{ console.error(error);process.exitCode=1; });
