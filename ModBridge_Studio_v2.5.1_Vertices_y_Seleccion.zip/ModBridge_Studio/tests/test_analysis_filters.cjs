/* Keep advanced facet options aligned with the actual inspector metric cards. */
const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const {execFileSync} = require('node:child_process');
const library = require('../web/library.js');

const root = path.resolve(__dirname, '..');
function prepareCases() {
  const raw = [
    {metrics: {geometry_independent: {surface_geometry_equal: true}, rgba_texels_preserved: true}},
    {metrics: {geometry_independent: {surface_geometry_equal: false}, rgba_texels_preserved: false}},
    {metrics: {max_vertex_error_pixels: .25}},
    {status: 'verified_static', metrics: {}},
    {metrics: {}},
    {metrics: {six_views: {missing_textures: {original: ['color']}}}},
    {metrics: {geometry_independent: {uv_mapping_check_passed: false, uv_mapping_check_performed: false}}},
    {metrics: {geometry_independent: {uv_mapping_check_passed: false}}},
    {target_kind: 'surface_reconstructed', status: 'verified_static', metrics: {surface_geometry_equal: true, rgba_texels_preserved: true}},
    {target_kind: 'surface_approximation', status: 'verified_static', metrics: {surface: {exact_geometry: true}}},
    {metrics: {geometry_independent: {}, textures: {}, surface_geometry_equal: true, rgba_texels_preserved: true}},
    {metrics: {geometry: {geometry_exact: true}, textures: {pixel_exact: true}}}
  ].map((item, i) => ({id: 'case:model/' + i, slug: 'model_' + i, status: 'review', ...item}));
  const python = [
    'import json,sys',
    'from bridge.analysis_states import ANALYSIS_FILTERS',
    'from bridge.catalog import compact_report',
    'from bridge.verification import final_status',
    'reports=json.load(sys.stdin)',
    'for report in reports: report["status"]=final_status(report)',
    'print(json.dumps({"reports":reports,"compact":[compact_report(r) for r in reports],"filters":ANALYSIS_FILTERS}))'
  ].join('\n');
  return JSON.parse(execFileSync(process.env.PYTHON || 'python3', ['-c', python], {
    cwd: root, input: JSON.stringify(raw), encoding: 'utf8', timeout: 10000
  }));
}

function metricRenderer() {
  const source = fs.readFileSync(path.join(root, 'web/app.js'), 'utf8');
  const start = source.indexOf('  function findValue(');
  const end = source.indexOf('\n  function ', source.indexOf('  function renderMetrics(') + 10);
  assert.ok(start >= 0 && end > start);
  const cards = {};
  const context = {numeric: value => typeof value === 'number' && Number.isFinite(value), pretty: String,
    node: () => ({}), document: {createTextNode: value => value},
    SIDE_NAMES: {superior: 1, inferior: 1, izquierda: 1, derecha: 1, frontal: 1, trasera: 1},
    $: id => cards[id] ||= {replaceChildren() {}}};
  vm.createContext(context);
  vm.runInContext(source.slice(start, end) + '\nglobalThis.show = renderMetrics;', context);
  return {show: context.show, cards};
}

test('server facet labels and matching selections agree with actual inspector cards', () => {
  const {reports, compact, filters} = prepareCases();
  const {show, cards} = metricRenderer();
  const models = reports.map(({id}) => ({id}));
  const covered = {geometry: new Set(), textures: new Set()};
  for (let index = 0; index < reports.length; index++) {
    show(reports[index]);
    for (const [category, optionKey] of [['geometry', 'geometryStates'], ['textures', 'textureStates']]) {
      const state = compact[index].analysis[category][0];
      const option = filters[category].find(item => item.id === state);
      assert.ok(option, category + ': missing option ' + state);
      covered[category].add(state);
      const displayed = cards['metric-' + category].textContent;
      if (state === 'vertex_error') assert.match(displayed, /^Error: .+ px$/);
      else assert.equal(option.label, displayed);
      const selected = library.visibleModels(models, compact, {[optionKey]: [state]});
      assert.ok(selected.some(item => item.id === reports[index].id));
      assert.deepEqual(selected.map(item => item.id), compact.filter(item => item.analysis[category].includes(state)).map(item => item.id));
    }
  }
  assert.deepEqual([...covered.geometry].sort(), ['different', 'matching', 'report', 'verified', 'vertex_error'].sort());
  assert.deepEqual([...covered.textures].sort(), ['different', 'missing', 'pixels_preserved', 'report', 'uv_difference', 'uv_unverified', 'verified'].sort());
  const reconstructed = library.visibleModels(models, compact, {group: 'review', geometryStates: ['surface_reconstructed']});
  assert.deepEqual(reconstructed.map(item => item.id), [reports[8].id, reports[9].id]);
  assert.equal(library.visibleModels(models, compact, {group: 'verified', geometryStates: ['surface_reconstructed']}).length, 0);
});
