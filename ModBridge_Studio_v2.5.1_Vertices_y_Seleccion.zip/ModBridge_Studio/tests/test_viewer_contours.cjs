const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const context={window:{}};vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname,'../web/viewer.js'),'utf8'),context);

function buffers(face) {
  const viewer=Object.create(context.window.ModBridgeViewer.prototype), uploaded=[];
  viewer.faces=[];viewer.textures=new Map();viewer.generation=0;
  viewer.gl={createBuffer:()=>({}),bindBuffer(){},deleteBuffer(){},
    bufferData:(_target,data)=>uploaded.push(Array.from(data))};
  viewer.setScene({faces:[face]});return {viewer,uploaded};
}
const quad={vertices:[[0,0,0],[4,0,0],[4,2,0],[0,2,0]]};

test('refined contour edges drive wireframe while all triangles remain rendered',()=>{
  const result=buffers({...quad,wire_edges:[[[1,2,0],[3,2,0]]]});
  assert.equal(result.viewer.faces[0].count,6);
  assert.equal(result.viewer.faces[0].edgeCount,2);
  assert.deepEqual(result.uploaded[1],[1,2,0,0,0,1,3,2,0,0,0,1]);
});
test('ordinary faces retain their complete original perimeter',()=>{
  assert.equal(buffers(quad).viewer.faces[0].edgeCount,8);
});
test('fully internal strips keep fill geometry but no artificial seams',()=>{
  const result=buffers({...quad,wire_edges:[]});
  assert.equal(result.viewer.faces[0].count,6);
  assert.equal(result.viewer.faces[0].edgeCount,0);
  assert.equal(result.uploaded[1].length,0);
});
