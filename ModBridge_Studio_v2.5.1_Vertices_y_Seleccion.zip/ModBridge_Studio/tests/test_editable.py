import tempfile, unittest
from pathlib import Path
from PIL import Image
from bridge.editable import export_editable_obj

class EditableTests(unittest.TestCase):
    def test_mesh_units_uv_and_normals(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp); Image.new('RGBA',(32,16)).save(p/'atlas.png')
            ir={'faces':[{'vertices':[[0,0,0],[16,0,0],[4,16,0]],'uv':[[0,0],[32,0],[8,16]],'normal':[0,0,1]}]}
            export_editable_obj(ir,p/'atlas.png',p)
            s=(p/'alternativa_editable.obj').read_text()
            self.assertIn('v 1 0 0',s);self.assertIn('v 0.25 1 0',s)
            self.assertIn('vt 0.25 0',s);self.assertIn('vn 0 0 1',s)
            self.assertIn('f 1/1/1 2/2/2 3/3/3',s)
            self.assertIn('map_Kd atlas.png',(p/'alternativa_editable.mtl').read_text())
            self.assertIn('NO debe',(p/'NO_COMPATIBLE.txt').read_text())
