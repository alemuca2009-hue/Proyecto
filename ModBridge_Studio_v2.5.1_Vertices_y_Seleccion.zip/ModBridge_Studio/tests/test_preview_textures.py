"""Textured preview data, relocation and local HTTP resource boundaries."""
import json
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import urlopen
from unittest.mock import patch

from PIL import Image
from app import Studio, make_handler
from bridge.preview import build_preview, read_preview, texture_path, PREVIEW_VERSION
from bridge.pack import write_json


class TexturedPreviewTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.studio = Studio(self.root / 'workspace')
        self.run = self.studio.workspace / 'runs' / 'job_test'
        self.md = self.run / 'models' / 'test_cube'
        self.md.mkdir(parents=True)
        self.texture = self.md / 'originals/assets/test/textures/color with space.png'
        self.texture.parent.mkdir(parents=True)
        Image.new('RGBA', (3, 5), (70, 120, 200, 90)).save(self.texture)
        Image.new('RGBA', (7, 9), (20, 200, 80, 255)).save(self.md / 'atlas.png')
        self.face = {'vertices': [[0, 0, 0], [8, 0, 0], [8, 16, 0], [0, 16, 0]],
                     'uv': [[3, 0], [3, 5], [0, 5], [0, 0]], 'texture': 'test:color #1'}
        self.source = {'faces': [self.face], 'textures': {'test:color #1': str(self.texture)}}
        (self.md / 'ir_original.json').write_text(json.dumps(self.source))
        (self.md / 'ir_bedrock.json').write_text(json.dumps({'faces': [{**self.face, 'texture': 'atlas'}],
                                                          'textures': {'atlas': str(self.md / 'atlas.png')}}))
        (self.md / 'report.json').write_text(json.dumps({'id': 'test:cube', 'status': 'review'}))
        self.studio.ready['test:cube'] = {'id': 'test:cube', 'slug': self.md.name, 'run': str(self.run)}

    def tearDown(self):
        self.temp.cleanup()

    def test_uvs_and_texture_references_survive_without_changing_sources(self):
        before = (self.md / 'ir_original.json').read_bytes()
        result = build_preview(self.md)
        self.assertEqual(result['original_ir']['faces'][0], self.face)
        self.assertEqual(result['original_ir']['textures']['test:color #1'], 'originals/assets/test/textures/color with space.png')
        self.assertEqual(result['bedrock_ir']['textures'], {'atlas': 'atlas.png'})
        self.assertEqual(result['preview_version'], PREVIEW_VERSION)
        self.assertEqual((self.md / 'ir_original.json').read_bytes(), before)

    def test_old_vertex_only_preview_is_regenerated(self):
        (self.md / 'preview.json').write_text('{"original_ir":{"faces":[]}}')
        result = read_preview(self.md)
        self.assertEqual(result['original_ir']['faces'][0]['uv'], self.face['uv'])
        self.assertEqual(read_preview(self.md), result)

    def test_windows_paths_survive_moving_the_project(self):
        old = 'C:\\Users\\Someone\\ModBridge\\workspace\\runs\\old\\models\\test_cube\\originals\\assets\\test\\textures\\color with space.png'
        self.assertEqual(texture_path(self.md, old), self.texture)
        self.source['textures']['test:color #1'] = old
        (self.md / 'ir_original.json').write_text(json.dumps(self.source))
        self.assertIn('test:color #1', build_preview(self.md)['original_ir']['textures'])

    def test_nonfinite_vertices_and_invalid_uv_are_not_sent_as_nan(self):
        self.source['faces'] = [self.face, {**self.face, 'vertices': [[float('nan'), 0, 0]] * 3},
                                {**self.face, 'uv': [[float('inf'), 0]] * 4}]
        (self.md / 'ir_original.json').write_text(json.dumps(self.source))
        result = build_preview(self.md)
        self.assertEqual(len(result['original_ir']['faces']), 2)
        self.assertNotIn('uv', result['original_ir']['faces'][1])
        json.dumps(result, allow_nan=False)

    def test_arbitrary_external_files_and_symlinks_are_rejected(self):
        external = self.root / 'private.png'
        Image.new('RGBA', (1, 1)).save(external)
        for value in (str(external), '../../../../../private.png', '/etc/passwd', 'https://example.com/a.png'):
            self.assertIsNone(texture_path(self.md, value))
        link = self.md / 'linked.png'
        try:
            link.symlink_to(external)
        except OSError:
            return  # Creating symlinks may require Windows Developer Mode.
        self.assertIsNone(texture_path(self.md, str(link)))

    def test_geometry_endpoint_returns_urls_not_host_paths(self):
        self.assertNotIn('original_ir', self.studio.model('test:cube'))
        model = self.studio.model('test:cube', geometry=True)
        url = model['original_ir']['textures']['test:color #1']
        self.assertTrue(url.startswith('/api/texture?'))
        self.assertNotIn(str(self.root), json.dumps(model))
        path, root = self.studio.preview_texture('test:cube', 'original_ir', 'test:color #1')
        self.assertEqual(path, self.texture)
        self.assertEqual(root, self.md)
        self.assertEqual(read_preview(self.md)['original_ir']['textures']['test:color #1'],
                         'originals/assets/test/textures/color with space.png')

    def test_http_serves_only_a_ready_models_declared_png(self):
        server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(self.studio))
        thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
        origin = 'http://127.0.0.1:' + str(server.server_port)
        try:
            model = self.studio.model('test:cube', geometry=True)
            with urlopen(origin + model['original_ir']['textures']['test:color #1']) as response:
                self.assertEqual(response.headers['Content-Type'], 'image/png')
                self.assertEqual(response.read(), self.texture.read_bytes())
            for params in ({'id': 'not_ready', 'side': 'original_ir', 'name': 'test:color #1'},
                           {'id': 'test:cube', 'side': 'original_ir', 'name': 'test:color #1', 'run': 'old_run'},
                           {'id': 'test:cube', 'side': '../original_ir', 'name': 'test:color #1'},
                           {'id': 'test:cube', 'side': 'original_ir', 'name': '../../private.png'}):
                with self.assertRaises(HTTPError):
                    urlopen(origin + '/api/texture?' + urlencode(params))
        finally:
            server.shutdown(); server.server_close(); thread.join()

    def test_transient_windows_replace_lock_does_not_kill_a_preview(self):
        path=self.md/'progress.json'
        write_json(path, {'progress': 1})
        replace=Path.replace
        attempts=[]
        def briefly_locked(source, target):
            attempts.append(source)
            if len(attempts)<3:
                self.assertEqual(json.loads(path.read_text()), {'progress': 1})
                raise PermissionError('WinError 5: Acceso denegado')
            return replace(source,target)
        with patch.object(Path,'replace',briefly_locked),patch('bridge.pack.time.sleep'):
            write_json(path, {'progress': 2})
        self.assertEqual(len(attempts),3)
        self.assertEqual(json.loads(path.read_text()), {'progress': 2})
        self.assertFalse(list(self.md.glob('progress.json.*.tmp')))

    def test_permanent_replace_error_is_reported_and_old_file_preserved(self):
        path=self.md/'progress.json'
        write_json(path, {'progress': 1})
        with patch.object(Path,'replace',side_effect=PermissionError('locked')),patch('bridge.pack.time.sleep'):
            with self.assertRaises(PermissionError):write_json(path, {'progress': 2})
        self.assertEqual(json.loads(path.read_text()), {'progress': 1})
        self.assertFalse(list(self.md.glob('progress.json.*.tmp')))


if __name__ == '__main__':
    unittest.main()
