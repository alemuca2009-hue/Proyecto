"""Regression for trapezoidal OBJ faces protruding like the valve-handle image."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
from PIL import Image

from bridge.geometry import decode_bedrock
from bridge.mesh_surface import convert_mesh_surface
from bridge.surface_contours import contour_rectangles, rectangle_outlines, refine_patches
from bridge.mesh_surface import _patch
from bridge.preview import build_preview, read_preview, PREVIEW_VERSION
from bridge.rendering import compare_geometry, render_view


class ContourTests(unittest.TestCase):
    def test_valve_trapezoid_has_no_protruding_vertices_and_low_area_loss(self):
        # Clockwise or anticlockwise winding must describe the same coverage.
        polygon=np.array([[-2.9,0],[-2.071,2],[2.071,2],[2.9,0]])
        for source in (polygon,polygon[::-1]):
            rectangles,stats=contour_rectangles(source)
            self.assertGreater(len(rectangles),1)
            self.assertGreater(stats['target_area']/stats['source_area'],.99)
            for x0,y0,x1,y1 in rectangles:
                for x,y in ((x0,y0),(x1,y0),(x0,y1),(x1,y1)):
                    self.assertGreaterEqual(y,-1e-10);self.assertLessEqual(y,2+1e-10)
                    self.assertLessEqual(abs(x),2.9-.829*y/2+1e-10)

    def test_concave_u_preserves_empty_middle_and_all_three_arms(self):
        p=[[0,0],[6,0],[6,5],[4,5],[4,2],[2,2],[2,5],[0,5]]
        rects,stats=contour_rectangles(p)
        self.assertAlmostEqual(stats['target_area'],24)
        self.assertAlmostEqual(stats['omitted_area'],0)
        for x0,y0,x1,y1 in rects:
            self.assertTrue(y1<=2 or x1<=2 or x0>=4)

    def test_rectangles_do_not_gain_subdivision_or_change_area(self):
        rects,stats=contour_rectangles([[0,3],[0,0],[7,0],[7,3]])
        self.assertEqual(rects,[(0,0,7,3)])
        self.assertEqual(stats['target_area'],21)

    def test_budget_preserves_mask_instead_of_cutting_away_large_surface(self):
        patches,_=_patch([[0,0,0],[10,0,0],[0,10,0]],[[0,0],[16,0],[0,16]],'t',0)
        output,edges,stats=refine_patches(patches*10,budget=10)
        self.assertEqual(len(output),10)
        self.assertEqual(stats['masked_fallback_polygon_count'],10)
        self.assertEqual(stats['area_coverage_ratio'],1)
        self.assertEqual(stats['omitted_planar_area'],0)
        self.assertGreater(stats['outside_source_area'],0)

    def test_budget_allocates_good_refinements_without_coarsening_others(self):
        patches,_=_patch([[0,0,0],[10,0,0],[0,10,0]],[[0,0],[16,0],[0,16]],'t',0)
        output,edges,stats=refine_patches(patches*5,budget=150)
        self.assertLessEqual(len(output),150)
        self.assertGreater(stats['refined_polygon_count'],0)
        self.assertGreater(stats['masked_fallback_polygon_count'],0)
        self.assertGreaterEqual(stats['area_coverage_ratio'],.99)

    def test_triangle_remains_inside_even_when_budget_limits_resolution(self):
        rects,stats=contour_rectangles([[0,0],[100,0],[0,80]],max_slices=8)
        self.assertLessEqual(len(rects),8)
        self.assertGreater(stats['omitted_area'],0)
        for x0,y0,x1,y1 in rects:self.assertLessEqual(x1/100+y1/80,1+1e-9)

    def test_outlines_remove_only_shared_internal_segments(self):
        rects=[(0,0,4,1),(1,1,3,2)]
        edges=[edge for group in rectangle_outlines(rects) for edge in group]
        length=sum(np.linalg.norm(np.array(b)-a) for a,b in edges)
        self.assertAlmostEqual(length,12)
        for a,b in edges:
            if a[1]==b[1]==1:
                self.assertTrue(max(a[0],b[0])<=1 or min(a[0],b[0])>=3)

    def test_rotated_trapezoid_export_uv_and_outline_are_from_actual_target(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);texture=root/'texture.png'
            Image.new('RGBA',(16,16),(230,100,50,255)).save(texture)
            u=np.array([1.,2.,0.]);u/=np.linalg.norm(u)
            v=np.array([0.,0.,1.]);anchor=np.array([4.,-2.,8.])
            local=np.array([[-2.9,0],[-2.071,2],[2.071,2],[2.9,0]])
            vertices=[(anchor+u*x+v*y).tolist() for x,y in local]
            source={'faces':[{'vertices':vertices,'uv':[[0,0],[0,16],[16,16],[16,0]],'texture':'t'}],
                    'textures':{'t':str(texture)}}
            before=copy.deepcopy(source)
            result=convert_mesh_surface(source,root/'converted')
            target=decode_bedrock(result['geometry'],result['atlas_path'])
            self.assertEqual(source,before)
            self.assertFalse(compare_geometry(source,target)['surface_geometry_equal'])
            self.assertEqual(result['report']['status'],'review')
            self.assertEqual(len(target['faces']),len(result['wire_edges']))
            for f,edges in zip(target['faces'],result['wire_edges']):
                points=np.array(f['vertices'])
                normal=np.array(f['normal'])
                for edge in edges:
                    for point in edge:
                        # Each shown segment lies on the emitted rectangle's
                        # perimeter, including partial exposed shared edges.
                        distances=[]
                        for a,b in zip(points,np.roll(points,-1,axis=0)):
                            t=np.clip(np.dot(np.array(point)-a,b-a)/np.dot(b-a,b-a),0,1)
                            distances.append(np.linalg.norm(np.array(point)-(a+t*(b-a))))
                        self.assertLess(min(distances),1e-7)

    def test_preview_keeps_contour_edges_and_refreshes_old_cache(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            face={'vertices':[[0,0,0],[2,0,0],[2,1,0],[0,1,0]],
                  'wire_edges':[[[0,0,0],[2,0,0]]],'texture':'t'}
            for name in ('ir_original.json','ir_bedrock.json'):
                (root/name).write_text(json.dumps({'faces':[face],'textures':{}}))
            (root/'preview.json').write_text(json.dumps({'preview_version':2,'stale':True}))
            preview=read_preview(root)
            self.assertEqual(preview['preview_version'],PREVIEW_VERSION)
            self.assertNotIn('stale',preview)
            self.assertEqual(preview['bedrock_ir']['faces'][0]['wire_edges'],face['wire_edges'])


if __name__=='__main__':unittest.main()
