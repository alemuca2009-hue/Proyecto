"""Both application entry points use the restored, separately testable engine."""
import hashlib
import io
import json
from pathlib import Path
import tempfile
import time
import unittest
import zipfile

from PIL import Image
from app import Studio
from bridge.pipeline import run_conversion
from conversion_engine import convert_file
from bridge.rendering import render_view
from compare_engine_v244 import snapshot


def fan_jar(path):
    pixels=Image.new('RGBA',(8,8))
    pixels.putdata([(x*30,y*30,(x+y)*15,255) for y in range(8) for x in range(8)])
    data=io.BytesIO();pixels.save(data,format='PNG')
    obj='''mtllib fan.mtl
v 0 0 0.5
v 1 0 0.5
v 1 1 0.5
v 0 1 0.5
v 0.5 0.5 0.5
vt 0 0
vt 1 0
vt 1 1
vt 0 1
vt 0.5 0.5
usemtl surface
f 1/1 2/2 5/5
f 2/2 3/3 5/5
f 3/3 4/4 5/5
f 4/4 1/1 5/5
'''
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('assets/test/models/block/fan.json',json.dumps({
            'loader':'neoforge:obj','model':'test:models/block/fan.obj',
            'textures':{'skin':'test:block/pattern'},'flip_v':False}))
        archive.writestr('assets/test/models/block/fan.obj',obj)
        archive.writestr('assets/test/models/block/fan.mtl','newmtl surface\nmap_Kd #skin\n')
        archive.writestr('assets/test/textures/block/pattern.png',data.getvalue())


class ModularPipelineTests(unittest.TestCase):
    def test_real_obj_pipeline_matches_refined_engine_and_keeps_review(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);jar=root/'source.jar';fan_jar(jar)
            before=hashlib.sha256(jar.read_bytes()).hexdigest()
            result=run_conversion(jar,root/'conversion',models=['test:block/fan'],size=64)
            report=result['reports'][0]
            self.assertEqual(report['status'],'review')
            self.assertEqual(report['target_kind'],'surface_approximation')
            self.assertEqual(report['conversion_engine']['algorithm_version'],'2.5.0')
            proof=report['metrics']['geometry_independent']
            self.assertTrue(proof['surface_geometry_equal'])
            self.assertTrue(report['metrics']['six_views']['all_views_pixel_identical'])
            model=root/'conversion/models'/report['slug']
            original=json.loads((model/'ir_original.json').read_text())
            target=json.loads((model/'ir_bedrock.json').read_text())
            self.assertEqual(len(original['faces']),4)
            # An independently proven rectangle replaces 508 legacy strips.
            self.assertEqual(len(target['faces']),1)
            expected=convert_file(jar,'test:block/fan',root/'standalone')
            self.assertEqual(snapshot(model),snapshot(expected.directory))
            with zipfile.ZipFile(result['archive']) as archive:
                self.assertIsNone(archive.testzip())
                self.assertTrue(any(name.endswith('model.geo.json') for name in archive.namelist()))
            self.assertEqual(hashlib.sha256(jar.read_bytes()).hexdigest(),before)

    def test_lazy_render_worker_matches_standalone_engine_without_main_conversion(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);jar=root/'source.jar';fan_jar(jar)
            studio=Studio(root/'workspace',java=jar)
            expected=convert_file(jar,'test:block/fan',root/'standalone')
            settings={'views':['frontal'],'modes':['texture'],'size':64}
            config={'profiles':[dict(settings,id='java',name='Original',representation='original'),
                                dict(settings,id='bedrock',name='Traducido',representation='translated')],
                    'models':[{'id':'test:block/fan','profile_ids':['java','bedrock']}]}
            try:
                studio.render_jobs.start(config)
                until=time.monotonic()+20
                while studio.render_jobs.active and time.monotonic()<until:time.sleep(.02)
                self.assertFalse(studio.render_jobs.active)
                status=studio.render_jobs.status()
                self.assertEqual(status['state'],'done',status)
                self.assertEqual(status['result']['generated'],2)
                self.assertEqual(status['result']['failed'],0)
                with zipfile.ZipFile(studio.render_jobs.download()) as archive:
                    pngs=[name for name in archive.namelist() if name.endswith('.png')]
                    images={}
                    for name in pngs:
                        with Image.open(io.BytesIO(archive.read(name))) as image:images[name]=image.tobytes()
                    manifest=json.loads(archive.read('RENDERS_EXPORTADOS/manifiesto.json'))
                    self.assertEqual(manifest['application_version'],'2.5.1')
                    model=manifest['models'][0]
                    self.assertEqual(model['target_kind'],'surface_approximation')
                    self.assertEqual(model['conversion_engine'],expected.report['conversion_engine'])
                    bounds=model['render_bounds']
                    from bridge.render_annotations import annotate_vertex_count, count_vertices
                    original=render_view(expected.original_ir,'frontal',64,bounds=bounds)
                    target=render_view(expected.target_ir,'frontal',64,bounds=bounds)
                    annotate_vertex_count(original,count_vertices(expected.original_ir))
                    annotate_vertex_count(target,count_vertices(expected.target_ir))
                    original,target=original.tobytes(),target.tobytes()
                    self.assertCountEqual(list(images.values()),[original,target])
                self.assertEqual(studio.ready,{})
                self.assertIsNone(studio.result)
            finally:studio.render_jobs.cancel()


if __name__=='__main__':unittest.main()
