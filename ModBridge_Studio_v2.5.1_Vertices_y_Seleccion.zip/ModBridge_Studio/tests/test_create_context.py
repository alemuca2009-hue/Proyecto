import json,struct,tempfile,unittest,zipfile
from pathlib import Path
from bridge.create_context import class_utf8_constants,create_model_context
from bridge.resources import ResourcePack

def class_bytes(strings):
    pool=[]
    for s in strings:
        raw=s.encode();pool.append(b'\x01'+struct.pack('>H',len(raw))+raw)
    return b'\xca\xfe\xba\xbe\x00\x00\x00\x41'+struct.pack('>H',len(pool)+1)+b''.join(pool)

class CreateContextTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'test.jar'
    def tearDown(self):self.tmp.cleanup()
    def pack(self,include_registry=True,include_old_texture=False):
        with zipfile.ZipFile(self.path,'w') as z:
            z.writestr('assets/create/models/block/track/station_overlay.json',json.dumps({'textures':{'0':'create:block/track'},'elements':[{},{}]}))
            z.writestr('assets/create/models/block/track_overlay/station.json',json.dumps({'textures':{'1':'create:block/track_station_indicator'},'elements':[{}]}))
            if include_registry:z.writestr('com/simibubi/create/AllPartialModels.class',class_bytes(['track_overlay/station','TRACK_STATION_OVERLAY']))
            if include_old_texture:z.writestr('assets/create/textures/block/track.png',b'original')
        p=ResourcePack(self.path);self.addCleanup(p.close);return p
    def test_class_constants_valid_and_truncated(self):
        self.assertEqual(class_utf8_constants(class_bytes(['a','track_overlay/station'])),['a','track_overlay/station'])
        with self.assertRaises(ValueError):class_utf8_constants(class_bytes(['x'])[:-1])
    def test_context_requires_source_registry_and_never_replaces(self):
        p=self.pack();before=p.read_bytes('assets/create/models/block/track/station_overlay.json')
        r=create_model_context(p,'create:block/track/station_overlay')
        self.assertFalse(r['conversion_success']);self.assertFalse(r['equivalent_replacement']);self.assertTrue(r['coverage_eligible'])
        self.assertEqual(r['related_models'][0]['id'],'create:block/track_overlay/station')
        self.assertEqual(r['related_models'][0]['source_element_count'],2)
        self.assertEqual(p.read_bytes('assets/create/models/block/track/station_overlay.json'),before)
    def test_no_registry_means_no_inferred_adapter(self):
        self.assertIsNone(create_model_context(self.pack(False),'create:block/track/station_overlay'))
    def test_user_supplied_original_texture_prevents_legacy_diagnosis(self):
        self.assertIsNone(create_model_context(self.pack(include_old_texture=True),'create:block/track/station_overlay'))
    def test_unrelated_models_are_not_remapped(self):
        self.assertIsNone(create_model_context(self.pack(),'create:block/shaft'))

if __name__=='__main__':unittest.main()
