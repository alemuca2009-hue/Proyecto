"""Compare a completed regression run with supplied Java/Bedrock PNG pairs.

Requires Shapely for independent containment checks (development only).
Uses decoded .geo.json, the real atlas and the manifest's camera bounds.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
from PIL import Image, ImageDraw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--before', type=Path, required=True)
    parser.add_argument('--renders', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from bridge import __version__
    from bridge.geometry import decode_bedrock
    from bridge.render_modes import ProfileRenderer
    from run_geometry_v247 import precise_plane, positive_surfaces, geometry_key
    import audit_containment_v245
    audit_containment_v245.plane = precise_plane
    load = lambda path: json.loads(path.read_text(encoding='utf-8'))
    manifest = load(args.renders/'RENDERS_EXPORTADOS/manifiesto.json')
    old = {row['id']: row for row in load(args.before)['rows']}
    run = load(args.run)
    output = args.output; output.mkdir(parents=True, exist_ok=True)
    rows, sheets = [], []
    for r in run['rows']:
        mid = r['id']; directory = Path(r['directory'])
        original = load(directory/'ir_original.json')
        target = decode_bedrock(load(directory/'model.geo.json'), directory/'atlas.png')
        serialized = load(directory/'ir_bedrock.json')
        assert geometry_key(target) == geometry_key(serialized), mid
        bounds = next(m['render_bounds'] for m in manifest['models'] if m['id'] == mid)
        source_renderer = ProfileRenderer(original, bounds)
        target_renderer = ProfileRenderer(target, bounds)
        row = {'id': mid, 'source_unchanged': r['geometry_sha256']['source'] == old[mid]['geometry_sha256']['source'],
               'original_files_unchanged': r['original_files_sha256'] == old[mid]['original_files_sha256'],
               'decoded_matches_exported_ir': True,
               'before_area_coverage': old[mid]['area_coverage_ratio'],
               'after_area_coverage': r['area_coverage_ratio'],
               'before_faces': old[mid]['target']['face_count'],
               'after_faces': r['target']['face_count'], 'views': {}}
        best = None
        pairs = [p for p in manifest['comparison_pairs'] if p['model_id'] == mid and p['mode'] == 'solid']
        for pair in pairs:
            view = pair['view']
            before = Image.open(args.renders/pair['bedrock_path']).convert('RGBA')
            supplied_java = Image.open(args.renders/pair['java_path']).convert('RGBA')
            source = source_renderer.render(view, 192, 'solid')
            after = target_renderer.render(view, 192, 'solid')
            a, b, c = [np.asarray(im) for im in (source, before, after)]
            masks = [im[:, :, 3] > 0 for im in (a, b, c)]
            row['views'][view] = {
                'source_matches_supplied_java': bool(np.array_equal(a, np.asarray(supplied_java))),
                'before_missing': int((masks[0] & ~masks[1]).sum()),
                'before_extra': int((~masks[0] & masks[1]).sum()),
                'after_missing': int((masks[0] & ~masks[2]).sum()),
                'after_extra': int((~masks[0] & masks[2]).sum())}
            importance = row['views'][view]['before_missing'] * 100000 + int(masks[0].sum())
            if best is None or importance > best[0]:
                best = (importance, view, [im.copy() for im in (source, before, after)])
            for im in (source, before, supplied_java, after): im.close()
        row['before_missing'] = sum(v['before_missing'] for v in row['views'].values())
        row['after_missing'] = sum(v['after_missing'] for v in row['views'].values())
        row['after_extra'] = sum(v['after_extra'] for v in row['views'].values())
        # Compare the texture rendering as well, without treating one view's
        # pixel equality as proof of the whole continuous UV mapping.
        previous = load(Path(old[mid]['directory'])/'ir_bedrock.json')
        previous_renderer = ProfileRenderer(previous, bounds)
        tex = [np.asarray(renderer.render(best[1], 192, 'texture')).astype(float)
               for renderer in (source_renderer, previous_renderer, target_renderer)]
        row['texture_view'] = {'view': best[1],
            'before_rgba_mae': float(np.abs(tex[0]-tex[1]).mean()),
            'after_rgba_mae': float(np.abs(tex[0]-tex[2]).mean())}
        src, zero_source = positive_surfaces(original)
        dst, zero_target = positive_surfaces(target)
        measured = audit_containment_v245.audit(src, dst)
        row['containment'] = {k: v for k, v in measured.items() if not isinstance(v, list)}
        row['containment'].update(outside_face_count=len(measured['outside_faces']),
            missing_plane_count=len(measured['target_faces_without_source_plane']),
            invalid_face_count=len(measured['invalid_faces']),
            excluded_zero_area_source=len(zero_source), excluded_zero_area_target=len(zero_target))
        surface = load(directory/'surface_report.json') if (directory/'surface_report.json').exists() else {}
        row['surface'] = {k: v for k, v in surface.items()
                          if k in ('exact_geometry', 'rgba_texels_preserved', 'surface_rectangles')}
        tile = Image.new('RGB', (600, 244), (24, 30, 40)); draw = ImageDraw.Draw(tile)
        draw.text((8, 4), mid, fill='white')
        draw.text((8, 18), best[1] + ' | pixeles ausentes (6 vistas): '
                  + str(row['before_missing']) + ' -> ' + str(row['after_missing']), fill='#bfccd7')
        for i, (label, im) in enumerate(zip(('Java original', 'Bedrock 2.4.7', 'Bedrock 2.4.8'), best[2])):
            draw.text((8+i*200, 36), label, fill='white'); tile.paste(im, (4+i*200, 50), im); im.close()
        sheets.append((row['before_missing'], tile)); rows.append(row)
        (output/'VALIDACION_V248_PARCIAL.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
        print(mid, row['before_missing'], '->', row['after_missing'],
              'contained', measured['passed_no_overhang'], flush=True)
    sheets.sort(key=lambda item: -item[0])
    selected = sheets[:12]
    sheet = Image.new('RGB', (1200, 244*((len(selected)+1)//2)), (24, 30, 40))
    for i, (_, tile) in enumerate(selected): sheet.paste(tile, (i % 2*600, i//2*244))
    sheet.save(output/'COMPARACION_V248.png')
    result = {'version': __version__, 'source': run['source'], 'runtime_tested': False,
        'model_count': len(rows), 'all_source_renders_match': all(
            v['source_matches_supplied_java'] for r in rows for v in r['views'].values()),
        'all_sources_unchanged': all(r['source_unchanged'] and r['original_files_unchanged'] for r in rows),
        'all_contained': all(r['containment']['passed_no_overhang'] for r in rows),
        'area_regressions': [r['id'] for r in rows if r['after_area_coverage']+1e-9 < r['before_area_coverage']],
        'silhouette_regressions': [r['id'] for r in rows if r['after_missing']+r['after_extra'] > r['before_missing']],
        'source_render_zip_png_count': len(manifest['images']),
        'source_render_zip_model_count': len(manifest['models']),
        'source_render_hash_errors': sum(hashlib.sha256((args.renders/i['path']).read_bytes()).hexdigest() != i['sha256']
                                        for i in manifest['images']),
        'scope': 'Six 192px orthographic solid views; one texture view per model; decoded planar containment at 1e-5 model units. No in-game test.',
        'rows': rows}
    (output/'VALIDACION_V248.json').write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    (output/'VALIDACION_V248_PARCIAL.json').unlink()


if __name__ == '__main__': main()
