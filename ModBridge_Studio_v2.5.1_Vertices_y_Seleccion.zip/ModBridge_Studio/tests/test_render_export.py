"""End-to-end checks for planned, real profile renders and atomic ZIP exports."""
import copy
import hashlib
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from PIL import Image

from bridge.control import ConversionCancelled
from bridge.render_export import (MODES, ROOT_DIRECTORY, VIEWS, export_renders,
                                  load_render_ir, plan_render_export)


def profile(pid='p', **changes):
    result = {'id': pid, 'name': 'Perfil ' + pid, 'views': ['frontal'],
              'modes': ['solid'], 'size': 64}
    result.update(changes)
    return result


def config(profiles=None, models=None):
    return {'profiles': profiles or [profile()],
            'models': models or [{'id': 'm', 'profile_ids': ['p']}]}


def cube():
    points = [
        [[-1,-1,-1],[-1,1,-1],[1,1,-1],[1,-1,-1]],
        [[1,-1,1],[1,1,1],[-1,1,1],[-1,-1,1]],
        [[-1,-1,1],[-1,1,1],[-1,1,-1],[-1,-1,-1]],
        [[1,-1,-1],[1,1,-1],[1,1,1],[1,-1,1]],
        [[-1,1,-1],[-1,1,1],[1,1,1],[1,1,-1]],
        [[-1,-1,1],[-1,-1,-1],[1,-1,-1],[1,-1,1]],
    ]
    return {'faces': [{'vertices': face, 'uv': [[0,0],[0,1],[1,1],[1,0]],
                       'texture': 'skin'} for face in points],
            'textures': {'skin': 'originals/skin.png'}}


def write_model(root, texture=True):
    root.mkdir(parents=True)
    (root / 'originals').mkdir()
    if texture:
        Image.new('RGBA', (3, 5), (31, 140, 220, 255)).save(root / 'originals' / 'skin.png')
    ir = cube()
    for filename in ('ir_original.json', 'ir_bedrock.json'):
        (root / filename).write_text(json.dumps(ir), encoding='utf-8')
    return {'name': 'Cóg wheel', 'master': 'Maestra uno', 'modeldir': str(root)}


def hashes(root):
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}


class RenderPlanTests(unittest.TestCase):
    def test_planning_is_pure_and_counts_independent_mode_images(self):
        profiles = [profile('a', views=['superior', 'frontal'], modes=['wireframe', 'solid'],
                            three_combinations=True),
                    profile('b', modes=['texture']),
                    profile('duplicate', views=['superior', 'frontal'], modes=['wireframe', 'solid'],
                            three_combinations=True), {'id': 'unused'}]
        models = [{'id': mid, 'profile_ids': ['a', 'b', 'duplicate']} for mid in ['m', 'n']]
        original = config(profiles, models)
        snapshot = copy.deepcopy(original)
        with patch('bridge.render_export.load_render_ir', side_effect=AssertionError('must not load')):
            plan = plan_render_export(original, {'m': {}, 'n': {}})
        self.assertEqual(original, snapshot)
        self.assertEqual(plan['summary'], {
            'model_count': 2, 'profile_count': 3, 'view_count': 2, 'mode_count': 3,
            'combination_count': 4, 'image_count': 26, 'duplicate_count': 24,
            'requested_image_count': 50, 'comparison_pair_count': 0,
            'assignments': plan['summary']['assignments']})
        self.assertEqual([row['image_count'] for row in plan['summary']['assignments']], [12,1,0,12,1,0])
        self.assertEqual(plan['total_images'], 26)
        self.assertNotIn('unused', [p['id'] for p in plan['profiles']])

    def test_parameter_flags_generate_exact_requested_combinations(self):
        for options, expected in [({}, {(False, False)}), ({'xray': True}, {(True, False)}),
                                  ({'normals': True}, {(False, True)}),
                                  ({'xray': True, 'normals': True}, {(True, True)}),
                                  ({'three_combinations': True}, {(True, False), (False, True), (True, True)})]:
            plan = plan_render_export(config([profile(**options)]), {'m': {}})
            self.assertEqual({(j['xray'],j['normals']) for j in plan['jobs']}, expected)
            self.assertEqual(plan['total_images'], len(expected))

    def test_dedup_ignores_inactive_opacity_and_keeps_effective_settings(self):
        profiles = [profile('a', opacity=.2), profile('b', opacity=.7),
                    profile('c', xray=True, opacity=.2), profile('d', xray=True, opacity=.7),
                    profile('e', representation='original'), profile('f', size=128),
                    profile('g', modes=['texture'])]
        plan = plan_render_export(config(profiles, [{'id': 'm', 'profile_ids': list('abcdefg')}]), {'m': {}})
        self.assertEqual(plan['total_images'], 6)
        self.assertEqual(len(plan['duplicates']), 1)
        self.assertEqual(plan['duplicates'][0]['profile_id'], 'b')
        self.assertEqual(plan['duplicates'][0]['same_as'], plan['jobs'][0]['path'])

    def test_repeated_selections_are_ordered_unique(self):
        p = profile(views=['frontal','superior','frontal'], modes=['texture','solid','texture'])
        plan = plan_render_export(config([p], [{'id':'m','profile_ids':['p','p']}]), {'m':{}})
        self.assertEqual(plan['total_images'],4)
        self.assertEqual([j['view'] for j in plan['jobs']],['frontal','frontal','superior','superior'])
        self.assertEqual([j['mode'] for j in plan['jobs']],['texture','solid','texture','solid'])

    def test_paths_are_ascii_short_and_collision_safe_on_windows(self):
        profiles = [profile('x', name='CON'), profile('y', name='con', normals=True)]
        models = [{'id':str(i), 'master':'../MAE:STRA', 'profile_ids':['x','y']} for i in range(4)]
        catalog = {str(i): {'name': name} for i, name in enumerate(['NUL', 'nul', '../\u00e1:*?"<>|\\', '\U0001f436'*60])}
        plan = plan_render_export(config(profiles, models), catalog)
        paths = [j['path'] for j in plan['jobs']]
        self.assertEqual(len(paths), len({p.casefold() for p in paths}))
        for path in paths:
            self.assertTrue(path.isascii())
            self.assertLess(len(path), 225)
            self.assertEqual(len(path.split('/')), 5)
            self.assertNotIn('..', path)
            self.assertRegex(path, r'^[A-Za-z0-9_/]+\.png$')
            self.assertTrue(path.endswith('_sin_rayosx_normales.png') or path.endswith('_sin_rayosx_sin_normales.png'))

    def test_invalid_selections_are_rejected_without_side_effects(self):
        invalid = [
            {'models': [], 'profiles': [profile()]},
            {'models': [{'id':'m','profile_ids':[]}], 'profiles':[profile()]},
            config([profile(views=[])]), config([profile(modes=[])]),
            config([profile(views=['north'])]), config([profile(modes=['combined'])]),
            config([profile(xray='yes')]), config([profile(normals=1)]),
            config([profile(three_combinations=None)]), config([profile(size=True)]),
            config([profile(size=63)]), config([profile(size=513)]),
            config([profile(size=64.5)]), config([profile(opacity=float('nan'))]),
            config([profile(opacity=float('inf'))]), config([profile(opacity=0)]),
            config([profile(representation='preview')]), {**config(), 'mesh_mode': 'fake'},
            config([profile(), profile()]),
            config(models=[{'id':'m','profile_ids':['missing']}]),
            config(models=[{'id':'missing','profile_ids':['p']}]),
            config(models=[{'id':'m','profile_ids':['p']},{'id':'m','profile_ids':['p']}]),
        ]
        for candidate in invalid:
            with self.subTest(candidate=candidate), self.assertRaises(ValueError):
                plan_render_export(candidate, {'m':{}})

    def test_image_limit_and_profile_limit_are_explicit_errors(self):
        with patch('bridge.render_export.MAX_REQUESTED_IMAGES', 2), self.assertRaisesRegex(ValueError, 'divide'):
            plan_render_export(config([profile(three_combinations=True)]), {'m':{}})
        with self.assertRaisesRegex(ValueError, '32'):
            plan_render_export(config([profile(str(i)) for i in range(33)]), {'m':{}})

    def test_comparison_expands_each_view_mode_parameter_to_both_sources(self):
        selection = config([profile(representation='comparison', views=['frontal','superior'],
                                    modes=['solid','texture'], three_combinations=True)],
                           [{'id': mid, 'profile_ids': ['p']} for mid in ('m','n')])
        before = copy.deepcopy(selection)
        plan = plan_render_export(selection, {'m': {}, 'n': {}})
        self.assertEqual(selection, before)
        self.assertEqual(plan['summary']['comparison_pair_count'], 24)
        self.assertEqual(plan['total_images'], 48)
        self.assertEqual(plan['summary']['requested_image_count'], 48)
        self.assertEqual(plan['summary']['duplicate_count'], 0)
        self.assertEqual(plan['profiles'][0]['representation'], 'comparison')
        jobs = {job['path']: job for job in plan['jobs']}
        for pair in plan['comparison_pairs']:
            self.assertTrue(pair['java_path'].endswith('_java.png'))
            self.assertTrue(pair['bedrock_path'].endswith('_bedrock.png'))
            java, bedrock = jobs[pair['java_path']], jobs[pair['bedrock_path']]
            self.assertEqual((java['representation'], bedrock['representation']), ('original','translated'))
            for key in ('model_id','profile_id','view','mode','xray','normals','opacity','size'):
                self.assertEqual(java[key], bedrock[key])
        with patch('bridge.render_export.MAX_REQUESTED_IMAGES', 47), self.assertRaisesRegex(ValueError, 'divide'):
            plan_render_export(selection, {'m': {}, 'n': {}})

    def test_comparison_deduplicates_against_individual_and_comparison_profiles(self):
        profiles = [profile('java', representation='original'), profile('bedrock'),
                    profile('compare', representation='comparison'),
                    profile('again', representation='comparison')]
        for order in (['java','bedrock','compare','again'], ['compare','java','again','bedrock']):
            with self.subTest(order=order):
                plan = plan_render_export(config(profiles, [{'id':'m','profile_ids':order}]), {'m':{}})
                self.assertEqual(plan['total_images'], 2)
                self.assertEqual(plan['summary']['requested_image_count'], 6)
                self.assertEqual(plan['summary']['duplicate_count'], 4)
                self.assertEqual(plan['summary']['comparison_pair_count'], 2)
                self.assertEqual(len({j['path'].casefold() for j in plan['jobs']}), 2)
                for pair in plan['comparison_pairs']:
                    for side, representation in [('java','original'), ('bedrock','translated')]:
                        owner = next(j for j in plan['jobs'] if j['representation']==representation)
                        self.assertEqual(pair[side+'_path'], owner['path'])
                        self.assertEqual(pair[side+'_owner_profile_id'], owner['profile_id'])


class RenderExportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root/'source'
        self.source.mkdir()
        self.destination = self.root/'output'
        self.catalog = {'m':write_model(self.source/'m'), 'n':write_model(self.source/'n')}

    def tearDown(self):
        self.temp.cleanup()

    def read_zip(self, result):
        with zipfile.ZipFile(result['archive']) as z:
            self.assertIsNone(z.testzip())
            names = z.namelist()
            manifest = json.loads(z.read(ROOT_DIRECTORY+'/manifiesto.json'))
            pngs = {name:z.read(name) for name in names if name.endswith('.png')}
        return names, manifest, pngs

    def test_real_multiple_models_profiles_views_modes_and_flags_export(self):
        profiles = [profile('main', views=list(VIEWS), modes=list(MODES), three_combinations=True),
                    profile('baseline', modes=['texture'], representation='original'),
                    profile('duplicate', modes=['texture'], representation='original'),
                    {'id':'unused'}]
        models = [{'id':'m', 'profile_ids':['main','baseline','duplicate']},
                  {'id':'n', 'master':'Otra maestra', 'profile_ids':['baseline']}]
        before = hashes(self.source)
        events = []
        result = export_renders(config(profiles, models), self.catalog, self.destination, progress=events.append)
        names, manifest, pngs = self.read_zip(result)
        self.assertEqual(result['generated'], 56)
        self.assertEqual(result['failed'], 0)
        self.assertEqual(result['duplicates_skipped'], 1)
        self.assertEqual(result['summary']['image_count'], 56)
        self.assertEqual(hashes(self.source), before)
        self.assertEqual(len(pngs), 56)
        self.assertEqual(len({name.split('/')[1] for name in pngs}), 2)
        self.assertEqual(len({name.split('/')[3] for name in pngs}), 2)
        self.assertTrue(all(not name.endswith('/') for name in names))
        self.assertEqual(len(manifest['images']),56)
        self.assertEqual(manifest['application_version'],'2.5.1')
        self.assertNotIn(str(self.source),json.dumps(manifest))
        for name,payload in pngs.items():
            self.assertEqual(len(name.split('/')),5)
            with Image.open(io.BytesIO(payload)) as image:
                self.assertEqual(image.size,(64,64))
                self.assertEqual(image.mode,'RGBA')
                self.assertIsNotNone(image.getbbox(),name)
            self.assertEqual(hashlib.sha256(payload).hexdigest(),next(i['sha256'] for i in manifest['images'] if i['path']==name))
        self.assertEqual(events[-1]['progress'],56)
        self.assertEqual(events[-1]['total'],56)
        self.assertTrue(any(e['current_model'] and e['current_profile'] for e in events))

    def test_model_prepare_failure_and_missing_texture_do_not_stop_other_models(self):
        (self.source/'m'/'originals'/'skin.png').unlink()
        profiles = [profile('solid'), profile('texture', modes=['texture'])]
        models = [{'id':mid,'profile_ids':['solid','texture']} for mid in ('broken','m','n')]
        catalog = {**self.catalog, 'broken':{'name':'Broken'}}
        calls=[]
        def prepare(mid,descriptor):
            calls.append(mid)
            if mid=='broken':
                raise ValueError('No se pudo convertir')
            return descriptor
        result=export_renders(config(profiles,models),catalog,self.destination,prepare_model=prepare)
        names,manifest,pngs=self.read_zip(result)
        self.assertEqual(calls,['broken','m','n'])
        self.assertEqual((result['generated'],result['failed']),(3,3))
        self.assertEqual(len(pngs),3)
        self.assertEqual([e['affected_images'] for e in result['errors']],[2,1])
        self.assertTrue(result['summary']['has_errors'])
        self.assertFalse(result['summary']['all_failed'])
        self.assertEqual(manifest['summary']['failed'],3)

    def test_prepare_is_lazy_after_previous_model_render(self):
        events=[]
        def prepare(mid, descriptor):
            if mid=='n':
                self.assertTrue(any(e['model_id']=='m' and e['generated']==1 for e in events))
            return descriptor
        models=[{'id':mid,'profile_ids':['p']} for mid in ('m','n')]
        result=export_renders(config(models=models), self.catalog, self.destination, progress=events.append, prepare_model=prepare)
        self.assertEqual(result['generated'],2)

    def test_cancelled_export_has_no_archive_or_temporary_zip(self):
        stopped=False
        def progress(event):
            nonlocal stopped
            stopped=event['generated']>=1
        p=profile(views=list(VIEWS),modes=list(MODES),three_combinations=True)
        before=hashes(self.source)
        with self.assertRaises(ConversionCancelled):
            export_renders(config([p]),self.catalog,self.destination,progress=progress,cancel=lambda:stopped)
        self.assertFalse((self.destination/'renders.zip').exists())
        self.assertFalse(list(self.destination.glob('*.tmp.zip')))
        self.assertEqual(hashes(self.source),before)

    def test_zip_write_failure_is_fatal_and_does_not_publish_partial_archive(self):
        with patch('bridge.render_export.zipfile.ZipFile.writestr',side_effect=OSError('disk full')):
            with self.assertRaisesRegex(OSError,'disk full'):
                export_renders(config(),self.catalog,self.destination)
        self.assertFalse((self.destination/'renders.zip').exists())
        self.assertFalse(list(self.destination.glob('*.tmp.zip')))

    def test_per_image_failure_continues_and_manifest_records_affected_profile(self):
        from bridge.render_modes import ProfileRenderer
        original=ProfileRenderer.render
        def intermittent(renderer,view,**options):
            if view=='superior':raise ValueError('simulated invalid projection')
            return original(renderer,view,**options)
        with patch.object(ProfileRenderer,'render',intermittent):
            result=export_renders(config([profile(views=['superior','frontal'])]),self.catalog,self.destination)
        names,manifest,pngs=self.read_zip(result)
        self.assertEqual((result['generated'],result['failed']),(1,1))
        self.assertEqual(manifest['errors'][0]['profile_id'],'p')
        self.assertEqual(len(pngs),1)

    def test_all_failed_produces_clear_error_manifest_without_empty_profile_folders(self):
        result=export_renders(config(),{'m':{'modeldir':str(self.source/'absent')}},self.destination)
        names,manifest,pngs=self.read_zip(result)
        self.assertEqual(names,[ROOT_DIRECTORY+'/manifiesto.json'])
        self.assertTrue(result['summary']['all_failed'])
        self.assertEqual(result['failed'],1)
        self.assertEqual(pngs,{})

    def test_relocates_windows_texture_paths_and_rejects_external_file(self):
        modeldir=self.source/'m'
        path=modeldir/'ir_bedrock.json'
        ir=cube()
        ir['textures']['skin']=r'C:\Old\Output\models\m\originals\skin.png'
        path.write_text(json.dumps(ir),encoding='utf-8')
        loaded=load_render_ir(modeldir,'translated')
        self.assertEqual(loaded['textures']['skin'],str(modeldir/'originals'/'skin.png'))
        outside=self.root/'outside.png'
        Image.new('RGBA',(1,1),(255,0,0,255)).save(outside)
        ir['textures']['skin']=str(outside)
        path.write_text(json.dumps(ir),encoding='utf-8')
        self.assertIsNone(load_render_ir(modeldir,'translated')['textures']['skin'])
        alias=modeldir/'outside.png'
        alias.symlink_to(outside)
        ir['textures']['skin']='outside.png'
        path.write_text(json.dumps(ir),encoding='utf-8')
        self.assertIsNone(load_render_ir(modeldir,'translated')['textures']['skin'])

    def test_export_destination_cannot_modify_original_model_directory(self):
        before=hashes(self.source)
        destination=self.source/'m'/'accidental_export'
        with self.assertRaisesRegex(ValueError,'fuera de los recursos'):
            export_renders(config(),self.catalog,destination)
        self.assertFalse(destination.exists())
        self.assertEqual(hashes(self.source),before)

    def test_manifest_labels_diagnostic_target_separately_from_original(self):
        modeldir=self.source/'m'
        (modeldir/'report.json').write_text(json.dumps({'target_kind':'experimental_poly_mesh','status':'unsupported'}))
        profiles=[profile('target'),profile('original',representation='original')]
        selection=config(profiles,[{'id':'m','profile_ids':['target','original']}])
        selection['mesh_mode']='exact'
        result=export_renders(selection,self.catalog,self.destination)
        _,manifest,_=self.read_zip(result)
        self.assertEqual(manifest['mesh_mode'],'exact')
        self.assertEqual(manifest['models'][0]['target_kind'],'experimental_poly_mesh')
        self.assertTrue(manifest['models'][0]['translated_diagnostic_only'])
        self.assertEqual([i['diagnostic_only'] for i in manifest['images']],[True,False])

    def test_missing_unrequested_representation_does_not_block_valid_original(self):
        (self.source/'m'/'ir_bedrock.json').unlink()
        result=export_renders(config([profile(representation='original')]),self.catalog,self.destination)
        self.assertEqual(result['generated'],1)
        self.assertEqual(result['failed'],0)

    def test_real_comparison_has_distinct_images_with_one_shared_camera(self):
        translated = cube()
        for face in translated['faces']:
            face['vertices'] = [[coordinate * .5 for coordinate in vertex] for vertex in face['vertices']]
        (self.source/'m'/'ir_bedrock.json').write_text(json.dumps(translated))
        before = hashes(self.source)
        selection = config([profile(representation='comparison', modes=list(MODES))],
                           [{'id':mid, 'profile_ids':['p']} for mid in ('m','n')])
        result = export_renders(selection, self.catalog, self.destination)
        _, manifest, pngs = self.read_zip(result)
        self.assertEqual((result['generated'],result['failed']), (12,0))
        self.assertEqual(manifest['summary']['comparison_complete_pairs'], 6)
        self.assertEqual(manifest['summary']['comparison_partial_pairs'], 0)
        self.assertEqual(hashes(self.source), before)
        self.assertEqual(manifest['models'][0]['render_bounds'], [[-1,-1,-1],[1,1,1]])
        for pair in manifest['comparison_pairs']:
            self.assertEqual(pair['status'], 'complete')
            self.assertTrue(pair['java_available'] and pair['bedrock_available'])
            self.assertIn(pair['java_path'], pngs)
            self.assertIn(pair['bedrock_path'], pngs)
            if pair['model_id']=='m':
                self.assertNotEqual(pngs[pair['java_path']], pngs[pair['bedrock_path']])
                if pair['mode']=='solid':
                    with Image.open(io.BytesIO(pngs[pair['java_path']])) as java, Image.open(io.BytesIO(pngs[pair['bedrock_path']])) as bedrock:
                        # The new top-right text is independent of the model.
                        # Compare the central geometry scanline below that badge.
                        middle = java.height//2
                        jbox, bbox = java.crop((0,middle,java.width,middle+1)).getbbox(), bedrock.crop((0,middle,bedrock.width,middle+1)).getbbox()
                        self.assertGreater(jbox[2]-jbox[0], 1.8*(bbox[2]-bbox[0]))

    def test_comparison_partial_pairs_keep_valid_side_and_continue_other_models(self):
        for missing, available in [('ir_bedrock.json','java'), ('ir_original.json','bedrock')]:
            with self.subTest(missing=missing):
                path = self.source/'m'/missing
                saved = path.read_bytes(); path.unlink()
                selection = config([profile(representation='comparison')],
                                   [{'id':mid,'profile_ids':['p']} for mid in ('m','n')])
                try:
                    result = export_renders(selection, self.catalog, self.destination)
                    _, manifest, pngs = self.read_zip(result)
                    self.assertEqual((result['generated'],result['failed']), (3,1))
                    partial, complete = manifest['comparison_pairs']
                    self.assertEqual(partial['status'], 'partial')
                    self.assertEqual(complete['status'], 'complete')
                    self.assertTrue(partial[available+'_available'])
                    self.assertIn(partial[available+'_path'], pngs)
                    self.assertEqual(manifest['summary']['comparison_partial_pairs'], 1)
                    self.assertEqual(manifest['summary']['comparison_complete_pairs'], 1)
                    self.assertEqual(manifest['summary']['comparison_failed_pairs'], 0)
                finally:
                    path.write_bytes(saved)

    def test_comparison_manifest_tracks_deduplicated_and_diagnostic_pairs(self):
        (self.source/'m'/'report.json').write_text(json.dumps({'target_kind':'experimental_poly_mesh'}))
        profiles = [profile('java',representation='original'), profile('cmp',representation='comparison'),
                    profile('copy',representation='comparison')]
        selection = config(profiles,[{'id':'m','profile_ids':['java','cmp','copy']}])
        result = export_renders(selection,self.catalog,self.destination)
        _, manifest, pngs = self.read_zip(result)
        self.assertEqual((result['generated'],result['duplicates_skipped']), (2,3))
        self.assertEqual(manifest['summary']['comparison_complete_pairs'], 2)
        for pair in manifest['comparison_pairs']:
            self.assertEqual(pair['java_owner_profile_id'],'java')
            self.assertEqual(pair['bedrock_owner_profile_id'],'cmp')
            self.assertIn(pair['java_path'],pngs)
            self.assertIn(pair['bedrock_path'],pngs)
            self.assertTrue(pair['bedrock_diagnostic_only'])

    def test_comparison_failure_has_no_fabricated_pair_images(self):
        selection = config([profile(representation='comparison')])
        result = export_renders(selection, {'m':{'modeldir':str(self.source/'absent')}}, self.destination)
        names, manifest, pngs = self.read_zip(result)
        self.assertEqual(names,[ROOT_DIRECTORY+'/manifiesto.json'])
        self.assertEqual((result['generated'],result['failed']), (0,2))
        self.assertEqual(manifest['summary']['comparison_failed_pairs'], 1)
        self.assertEqual(manifest['comparison_pairs'][0]['status'],'failed')
        self.assertFalse(manifest['comparison_pairs'][0]['java_available'])
        self.assertFalse(manifest['comparison_pairs'][0]['bedrock_available'])
        self.assertEqual(pngs,{})


if __name__=='__main__':
    unittest.main()
