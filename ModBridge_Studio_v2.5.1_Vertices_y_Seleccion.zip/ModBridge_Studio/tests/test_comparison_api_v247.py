"""Real HTTP/worker checks for paired Java/Bedrock exports."""
import hashlib
import json
import unittest

import test_render_api_v246 as support


class ComparisonHTTPTests(unittest.TestCase):
    setUp = support.RenderProfileHTTPTests.setUp
    tearDown = support.RenderProfileHTTPTests.tearDown
    request = support.RenderProfileHTTPTests.request
    json_request = support.RenderProfileHTTPTests.json_request
    wait_render = support.RenderProfileHTTPTests.wait_render
    run_export = support.RenderProfileHTTPTests.run_export
    assert_safe_archive = support.RenderProfileHTTPTests.assert_safe_archive

    def test_comparison_and_overlapping_java_profile_download_unique_pairs(self):
        settings = dict(views=['superior', 'frontal'], modes=['wireframe', 'solid'],
                        three_combinations=True)
        config = {'profiles': [
            support.profile('compare', representation='comparison', **settings),
            support.profile('java', representation='original', **settings),
        ], 'models': [
            {'id': 'qa:block/uno', 'profile_ids': ['compare', 'java'], 'master': 'Una maestra'},
            {'id': 'qa:block/dos', 'profile_ids': ['compare', 'java'], 'master': 'Otra maestra'},
        ]}
        plan, final, archive, _ = self.run_export(config)
        self.assertEqual(plan['image_count'], 48)
        self.assertEqual(plan['duplicate_count'], 24)
        self.assertEqual(plan['comparison_pair_count'], 24)
        self.assertEqual(final['result']['generated'], 48)
        with archive:
            self.assert_safe_archive(archive)
            manifest = json.loads(archive.read('RENDERS_EXPORTADOS/manifiesto.json'))
            self.assertEqual(len(manifest['comparison_pairs']), 24)
            self.assertEqual(len(manifest['images']), 48)
            for pair in manifest['comparison_pairs']:
                self.assertEqual(pair['status'], 'complete')
                self.assertTrue(pair['java_path'].endswith('_java.png'))
                self.assertTrue(pair['bedrock_path'].endswith('_bedrock.png'))
                self.assertIn(pair['java_path'], archive.namelist())
                self.assertIn(pair['bedrock_path'], archive.namelist())
            for image in manifest['images']:
                self.assertEqual(hashlib.sha256(archive.read(image['path'])).hexdigest(), image['sha256'])
        self.assertEqual(hashlib.sha256(self.jar.read_bytes()).hexdigest(), self.original_hash)
        self.assertEqual(self.studio.ready, {})

    def test_failed_model_does_not_discard_another_models_comparison(self):
        config = {'profiles': [support.profile('compare', modes=['solid'], representation='comparison')],
                  'models': [{'id': mid, 'profile_ids': ['compare']}
                             for mid in ('qa:block/uno', 'qa:block/no_soportado')]}
        plan, final, archive, _ = self.run_export(config)
        self.assertEqual(plan['image_count'], 4)
        self.assertEqual(final['result']['generated'], 2)
        self.assertEqual(final['result']['failed'], 2)
        with archive:
            self.assert_safe_archive(archive)
            manifest = json.loads(archive.read('RENDERS_EXPORTADOS/manifiesto.json'))
            pairs = {pair['model_id']: pair for pair in manifest['comparison_pairs']}
            self.assertEqual(pairs['qa:block/uno']['status'], 'complete')
            self.assertEqual(pairs['qa:block/no_soportado']['status'], 'failed')
            self.assertEqual(sum(name.endswith('.png') for name in archive.namelist()), 2)
        self.assertEqual(hashlib.sha256(self.jar.read_bytes()).hexdigest(), self.original_hash)


if __name__ == '__main__':
    unittest.main()
