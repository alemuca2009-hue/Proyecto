import math,tempfile,unittest
from pathlib import Path
import numpy as np
from PIL import Image
from bridge.geometry import decode_bedrock
from bridge.mesh_surface import convert_mesh_surface
from bridge.rendering import render_view

class MeshSurfaceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.texture=self.root/'texture.png'
        a=np.zeros((16,32,4),dtype=np.uint8);a[:,:16]=[255,0,0,255];a[:,16:]=[0,200,255,128]
        Image.fromarray(a).save(self.texture)
    def tearDown(self):self.temp.cleanup()
    def ir(self,vertices,uv=None):
        return {'id':'test:mesh','faces':[{'vertices':vertices,'uv':uv or [[0,0],[0,16],[32,16],[32,0]],'texture':'t'}],'textures':{'t':str(self.texture)}}
    def test_rotated_asymmetric_plane_preserves_corners_and_normal(self):
        theta=math.radians(37);phi=math.radians(29)
        u=np.array([math.cos(theta),math.sin(theta),0.])
        v=np.array([-math.sin(theta)*math.cos(phi),math.cos(theta)*math.cos(phi),math.sin(phi)])
        c=np.array([3.,-2.,7.]);verts=[c+v*4,c,c+u*9,c+u*9+v*4]
        source=self.ir([p.tolist() for p in verts]);r=convert_mesh_surface(source,self.root)
        target=decode_bedrock(r['geometry'],r['atlas_path']);points=np.asarray(target['faces'][0]['vertices'])
        for expected in verts:self.assertLess(np.min(np.linalg.norm(points-expected,axis=1)),1e-8)
        np.testing.assert_allclose(target['faces'][0]['normal'],np.cross(u,v),atol=1e-8)
        self.assertEqual(r['report']['status'],'review');self.assertFalse(r['report']['static_equivalence_passed'])
        self.assertNotIn('poly_mesh',r['geometry']['minecraft:geometry'][0]['bones'][0])
    def test_triangle_has_transparent_mask_and_no_polymesh(self):
        source=self.ir([[0,0,0],[8,0,0],[0,8,0]],[[0,0],[32,0],[0,16]])
        r=convert_mesh_surface(source,self.root,pixels_per_unit=8)
        with Image.open(r['atlas_path']) as image:
            alpha=np.asarray(image)[:,:,3]
            self.assertGreater(np.count_nonzero(alpha),0)
            self.assertGreater(np.count_nonzero(alpha==0),0)
        target=decode_bedrock(r['geometry'],r['atlas_path'])
        self.assertEqual(len(target['faces'][0]['vertices']),4)
        self.assertFalse(r['report']['exact_geometry'])
        self.assertEqual(r['report']['source_face_count'],1)
        self.assertGreater(r['report']['surface_rectangles'],1)
        # Native target vertices must lie inside x+y<=8, not in an enclosing
        # masked rectangle as in 2.4.3. Check the serialized/decoded geometry.
        for face in target['faces']:
            for x,y,z in face['vertices']:
                self.assertGreaterEqual(x,-1e-8);self.assertGreaterEqual(y,-1e-8)
                self.assertLessEqual(x+y,8+1e-8)
        self.assertGreater(r['report']['contour_refinement']['area_coverage_ratio'],.98)
    def test_triangle_silhouette_small_sampling_error(self):
        tex=self.root/'solid.png';Image.new('RGBA',(16,16),'white').save(tex)
        source=self.ir([[0,0,0],[8,0,0],[0,8,0]],[[0,0],[16,0],[0,16]])
        source['textures']['t']=str(tex)
        r=convert_mesh_surface(source,self.root,pixels_per_unit=16)
        target=decode_bedrock(r['geometry'],r['atlas_path'])
        bounds=[[0,0,-.001],[8,8,.001]]
        a=np.asarray(render_view(source,'frontal',128,bounds))[:,:,3]>0
        b=np.asarray(render_view(target,'frontal',128,bounds))[:,:,3]>0
        self.assertGreater(np.count_nonzero(a&b)/np.count_nonzero(a|b),.96)
    def test_rectangle_uv_colors_not_mirrored(self):
        source=self.ir([[0,4,0],[0,0,0],[8,0,0],[8,4,0]])
        r=convert_mesh_surface(source,self.root,pixels_per_unit=4)
        target=decode_bedrock(r['geometry'],r['atlas_path'])
        a=np.asarray(render_view(source,'frontal',128,[[0,0,0],[8,4,0]]))
        b=np.asarray(render_view(target,'frontal',128,[[0,0,0],[8,4,0]]))
        np.testing.assert_array_equal(a,b)
    def test_gimbal_oriented_vertical_faces(self):
        for index,vertices in enumerate([
            [[0,4,0],[0,0,0],[0,0,8],[0,4,8]],
            [[4,0,0],[0,0,0],[0,0,8],[4,0,8]],
            [[0,0,4],[0,0,0],[0,8,0],[0,8,4]]]):
            r=convert_mesh_surface(self.ir(vertices),self.root/str(index))
            target=decode_bedrock(r['geometry'],r['atlas_path'])
            points=np.asarray(target['faces'][0]['vertices'])
            for v in vertices:self.assertLess(np.min(np.linalg.norm(points-v,axis=1)),1e-8)
    def test_budget_adjusts_sampling_without_dropping_faces(self):
        source=self.ir([[0,4,0],[0,0,0],[8,0,0],[8,4,0]])
        source['faces']*=20
        r=convert_mesh_surface(source,self.root,pixels_per_unit=32,max_atlas=64)
        self.assertEqual(r['report']['surface_rectangles'],20)
        self.assertLess(r['report']['effective_pixels_per_model_unit'],32)
        self.assertLessEqual(max(r['report']['atlas_size']),64)
    def test_nonplanar_quad_split_original_untouched(self):
        source=self.ir([[0,4,0],[0,0,0],[8,0,1],[8,4,0]])
        original=[v[:] for v in source['faces'][0]['vertices']]
        r=convert_mesh_surface(source,self.root)
        self.assertEqual(r['report']['contour_refinement']['input_planar_patches'],2)
        self.assertGreater(r['report']['surface_rectangles'],2)
        self.assertEqual(source['faces'][0]['vertices'],original)
    def test_empty_rejected(self):
        with self.assertRaises(ValueError):convert_mesh_surface({'faces':[]},self.root)

if __name__=='__main__':unittest.main()
