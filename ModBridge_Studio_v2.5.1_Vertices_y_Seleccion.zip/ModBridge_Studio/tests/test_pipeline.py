"""End-to-end contracts: original bytes, six views, safe ZIPs and honest statuses.

The fixtures are generated locally and contain no Minecraft proprietary assets.
Run: python -m unittest discover -s tests -v
"""
from __future__ import annotations
import io
import http.client
import threading
import time
from http.server import ThreadingHTTPServer
import json
import tempfile
import unittest
import zipfile
from pathlib import Path, PurePosixPath
from unittest.mock import patch

from PIL import Image

from bridge.pipeline import VIEWS, model_slug, run_conversion
from bridge.resources import ResourcePack, asset_path, normalize_id
from bridge.reference import ReferenceAddon, archive_entries


def make_fixture(path: Path):
    image = Image.new('RGBA', (16, 16))
    image.putdata([(x * 13, y * 11, (x * 7 + y * 5) % 256,
                    0 if (x, y) == (0, 0) else 255)
                   for y in range(16) for x in range(16)])
    buf = io.BytesIO(); image.save(buf, format='PNG')
    texture_bytes = buf.getvalue()
    parent = {
        'textures': {'surface': 'fixture:block/asymmetric'},
        'elements': [{'from': [1, 2, 3], 'to': [15, 14, 13],
                      'faces': {face: {'texture': '#surface', 'uv': [0, 0, 16, 16]}
                                for face in ('north', 'south', 'east', 'west', 'up', 'down')}}],
    }
    originals = {
        'assets/fixture/models/block/base.json': json.dumps(parent, indent=3).encode(),
        'assets/fixture/models/block/sample.json': b'{"parent":"fixture:block/base"}\n',
        'assets/fixture/models/block/custom.json': b'{"loader":"fixture:runtime_geometry"}',
        'assets/fixture/models/block/missing.json': json.dumps({
            'parent': 'fixture:block/base',
            'textures': {'surface': 'fixture:block/not_in_archive'},
        }).encode(),
        'assets/fixture/textures/block/asymmetric.png': texture_bytes,
    }
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, data in originals.items(): z.writestr(name, data)
    return originals


class PipelineIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name)
        cls.jar = cls.root / 'fixture.jar'
        cls.originals = make_fixture(cls.jar)
        cls.result = run_conversion(
            cls.jar, cls.root / 'run',
            models=['fixture:block/sample', 'fixture:block/custom', 'fixture:block/missing'],
            size=64,
        )
        cls.export = Path(cls.result['export_dir'])
        cls.reports = {r['id']: r for r in cls.result['reports']}

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def test_original_bytes_and_inheritance_dependencies_are_preserved(self):
        for name in (
            'assets/fixture/models/block/sample.json',
            'assets/fixture/models/block/base.json',
            'assets/fixture/textures/block/asymmetric.png',
        ):
            with self.subTest(name=name):
                self.assertEqual((self.export / 'modelos_originales' / name).read_bytes(),
                                 self.originals[name])
        report = self.reports['fixture:block/sample']
        self.assertIn('assets/fixture/models/block/base.json', report['source_dependencies'])
        self.assertTrue(report['metrics']['rgba_texels_preserved'])

    def test_output_contract_has_six_pairs_per_model(self):
        self.assertEqual(set(VIEWS), {'superior', 'frontal', 'inferior', 'trasera', 'izquierda', 'derecha'})
        for dirname in ('modelos_originales', 'modelos_traducidos', 'comparaciones', 'intermedio', 'reportes'):
            self.assertTrue((self.export / dirname).is_dir(), dirname)
        for report in self.reports.values():
            for side in VIEWS:
                for representation in ('original', 'traducido', 'diferencia'):
                    with self.subTest(model=report['id'], side=side, image=representation):
                        file = self.export / 'comparaciones' / report['slug'] / side / (representation + '.png')
                        with Image.open(file) as image:
                            self.assertEqual(image.size, (64, 64))
        good = self.reports['fixture:block/sample']
        self.assertTrue((self.export / 'modelos_traducidos' / good['slug'] / 'model.geo.json').is_file())
        self.assertTrue((self.export / 'ABRIR_COMPARACION.html').is_file())

    def test_unsupported_or_missing_assets_never_receive_verified_label(self):
        unsupported = self.reports['fixture:block/custom']
        missing = self.reports['fixture:block/missing']
        self.assertEqual(unsupported['status'], 'unsupported')
        self.assertNotEqual(missing['status'], 'verified_static')
        self.assertTrue(unsupported['warnings'])
        self.assertTrue(missing['warnings'])
        for report in self.reports.values():
            self.assertIs(report['runtime_tested'], False)
        self.assertIs(self.result['summary']['runtime_tested'], False)

    def test_static_geometry_checks_and_views_agree_on_supported_fixture(self):
        report = self.reports['fixture:block/sample']
        self.assertTrue(report['metrics']['static_equivalence_passed'])
        self.assertTrue(report['metrics']['geometry_independent']['surface_geometry_equal'])
        self.assertTrue(report['metrics']['geometry_independent']['texture_sample_check_passed'])
        self.assertTrue(report['metrics']['six_views']['all_views_pixel_identical'])
        self.assertEqual(report['status'], 'verified_static')

    def test_export_contains_model_assets_and_no_gameplay_pack(self):
        self.assertEqual(self.result['summary']['export_scope'], 'models_only')
        self.assertFalse(self.result['summary']['creates_game_content'])
        self.assertFalse((self.export/'paquete_bedrock').exists())
        self.assertEqual(list(self.export.rglob('*.mcaddon')), [])
        all_geometry_ids = set()
        for file in (self.export/'modelos_traducidos').glob('*/model.geo.json'):
            geo = json.loads(file.read_text())
            for definition in geo['minecraft:geometry']:
                identifier = definition['description']['identifier']
                self.assertNotIn(identifier, all_geometry_ids)
                all_geometry_ids.add(identifier)
            self.assertTrue((file.parent/'atlas.png').is_file())
        self.assertGreater(len(all_geometry_ids), 0)
        self.assertNotIn('preview_addon', self.result['summary'])
        self.assertNotIn('anchor_addon', self.result['summary'])

    def test_final_zip_is_portable_and_does_not_expose_workspace_paths(self):
        with zipfile.ZipFile(self.result['archive']) as z:
            self.assertIsNone(z.testzip())
            for name in z.namelist():
                path = PurePosixPath(name)
                self.assertFalse(path.is_absolute(), name)
                self.assertNotIn('..', path.parts, name)
                self.assertNotIn('\\', name)
                if name.endswith(('.json', '.txt', '.html', '.csv')):
                    text = z.read(name).decode('utf-8-sig')
                    self.assertNotIn(str(self.root), text, name)
                    self.assertNotIn('/workspace/scratch/', text, name)
            for report in self.reports.values():
                exported = json.loads(z.read('reportes/modelos/' + report['slug'] + '.json'))
                for key, value in exported['paths'].items():
                    self.assertFalse(PurePosixPath(value).is_absolute(), (key, value))
        for ir_file in (self.export / 'intermedio').rglob('ir_*.json'):
            ir = json.loads(ir_file.read_text())
            for texture in ir.get('textures', {}).values():
                self.assertFalse(Path(texture).is_absolute())
                target = (ir_file.parent / texture).resolve()
                self.assertTrue(target.is_relative_to(self.export.resolve()))
                self.assertTrue(target.is_file(), texture)

    def test_visual_differences_do_not_block_matching_geometry_and_preserved_pixels(self):
        # Exercise the real converter; only inject the separate renderer outcome.
        with patch('bridge.pipeline.compare_views', return_value={
            'all_views_pixel_identical': False, 'views': {},
            'geometry': {'surface_geometry_equal': True, 'texture_sample_check_passed': True},
        }):
            result = run_conversion(self.jar, self.root / 'visual_gate', models=['fixture:block/sample'], size=64)
        self.assertEqual(result['reports'][0]['status'], 'verified_static')
        self.assertFalse(result['reports'][0]['metrics']['six_views']['all_views_pixel_identical'])
        self.assertTrue(result['reports'][0]['warnings'])

    def test_independent_geometry_failure_downgrades_conversion(self):
        with patch('bridge.pipeline.compare_views', return_value={
            'all_views_pixel_identical': True, 'views': {},
            'geometry': {'surface_geometry_equal': False, 'texture_sample_check_passed': True,
                         'bounds_max_absolute_error': 1.0},
        }):
            result = run_conversion(self.jar, self.root / 'geometry_gate', models=['fixture:block/sample'], size=64)
        self.assertNotEqual(result['reports'][0]['status'], 'verified_static')


    def test_independent_uv_failure_downgrades_despite_copied_texels(self):
        with patch('bridge.pipeline.compare_views', return_value={
            'all_views_pixel_identical': True, 'views': {},
            'geometry': {'surface_geometry_equal': True, 'uv_mapping_check_passed': False},
        }):
            result = run_conversion(self.jar, self.root / 'uv_gate', models=['fixture:block/sample'], size=64)
        self.assertEqual(result['reports'][0]['status'], 'review')



class ArchiveInputTests(unittest.TestCase):
    def test_unsafe_jar_members_are_neither_discovered_nor_extracted(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); jar = root / 'unsafe.jar'
            with zipfile.ZipFile(jar, 'w') as z:
                z.writestr('assets/fixture/models/block/safe.json', '{}')
                z.writestr('../escape.txt', 'not executable')
                z.writestr('/absolute.txt', 'not executable')
                z.writestr('assets/fixture/models/../../escape.json', '{}')
                z.writestr('assets\\fixture\\models\\evil.json', '{}')
            with ResourcePack(jar) as pack:
                self.assertEqual(pack.models(), ['fixture:block/safe'])
                for name in ('../escape.txt', '/absolute.txt', 'assets/fixture/models/../../escape.json'):
                    self.assertFalse(pack.exists(name))
                    with self.assertRaises(FileNotFoundError): pack.read_bytes(name)
                self.assertTrue(pack.warnings)
            self.assertEqual(sorted(p.name for p in root.iterdir()), ['unsafe.jar'])

    def test_reference_archive_rejects_traversal_even_when_nested(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); child = io.BytesIO()
            with zipfile.ZipFile(child, 'w') as z:
                z.writestr('../outside.png', 'data')
            addon = root / 'unsafe.mcaddon'
            with zipfile.ZipFile(addon, 'w') as z: z.writestr('inner.mcpack', child.getvalue())
            with self.assertRaises(ValueError): list(archive_entries(addon))
            self.assertFalse((root.parent / 'outside.png').exists())

    def test_identifiers_cannot_escape_resource_namespace(self):
        for identifier in ('../outside:block/model', 'a/b:block/model',
                           'fixture:../../outside', 'fixture:/absolute', 'fixture:block\\model'):
            with self.subTest(identifier=identifier):
                with self.assertRaises(ValueError): asset_path(identifier)

    def test_reference_jsonc_preserves_strings_and_exact_rgba_matching(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); jar = root / 'fixture.jar'; originals = make_fixture(jar)
            addon = root / 'reference.mcaddon'
            geometry = b'''\xef\xbb\xbf{ // comment
              "format_version": "1.12.0",
              "url": "https://example.invalid/a,}",
              "minecraft:geometry": [{
                "description": {"identifier":"geometry.fixture.sample", "texture_width":16, "texture_height":16,},
                "bones": [{"name":"root", "cubes":[],}],
              }],
            }'''
            png = originals['assets/fixture/textures/block/asymmetric.png']
            with zipfile.ZipFile(addon, 'w') as z:
                z.writestr('RP/models/entity/sample.geo.json', geometry)
                z.writestr('RP/textures/entity/sample.png', png)
            reference = ReferenceAddon(addon)
            self.assertEqual(reference.summary['parse_errors'], 0)
            self.assertEqual(reference.summary['geometry_definitions'], 1)
            self.assertEqual(len(reference.compare_texture(png)), 1)
            candidates = reference.candidates('fixture:block/sample')
            self.assertEqual(candidates[0]['match'], 'name_candidate')
            self.assertIn('no demuestra equivalencia', candidates[0]['note'])


class LocalServerTests(unittest.TestCase):
    def setUp(self):
        from app import Studio, make_handler
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.jar = self.root / 'fixture.jar'; make_fixture(self.jar)
        self.studio = Studio(self.root / 'workspace', java=self.jar)
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(self.studio))
        self.thread = threading.Thread(target=lambda: self.server.serve_forever(poll_interval=0.01), daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(timeout=2)
        self.temp.cleanup()

    def request(self, method, path, body=None, headers=None, authorized=False):
        hs = dict(headers or {})
        if authorized: hs['X-Bridge-Token'] = self.studio.token
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        try:
            connection.request(method, path, body=body, headers=hs)
            response = connection.getresponse()
            return response.status, dict(response.getheaders()), response.read()
        finally: connection.close()

    def test_wrong_host_or_token_or_cross_origin_cannot_mutate(self):
        for headers in ({}, {'X-Bridge-Token': 'invalid'},
                        {'X-Bridge-Token': self.studio.token, 'Host': 'evil.example'},
                        {'X-Bridge-Token': self.studio.token, 'Origin': 'https://evil.example'}):
            with self.subTest(headers=list(headers)):
                status, _, _ = self.request('POST', '/api/cancel', headers=headers)
                self.assertEqual(status, 403)
                self.assertFalse(self.studio.cancelled)
        self.assertEqual(self.request('GET', '/api/status', headers={'Host': 'evil.example'})[0], 403)

    def test_allowed_local_origin_and_token_can_mutate(self):
        origin = 'http://127.0.0.1:' + str(self.server.server_port)
        self.assertEqual(self.request('POST', '/api/cancel', headers={'Origin': origin}, authorized=True)[0], 200)
        self.assertTrue(self.studio.cancelled)

    def test_path_traversal_cannot_read_workspace_or_program_files(self):
        secret = self.studio.workspace / 'private.txt'; secret.write_text('local-private-fixture')
        self.studio.run = self.studio.workspace / 'run'
        (self.studio.run / 'models').mkdir(parents=True)
        for path in ('/output/../../private.txt', '/output/%2e%2e/%2e%2e/private.txt', '/../app.py'):
            with self.subTest(path=path):
                status, _, data = self.request('GET', path)
                self.assertEqual(status, 404)
                self.assertNotIn(b'local-private-fixture', data)

    def test_dependency_upload_preserves_primary_and_sanitizes_filename(self):
        primary = self.studio.java
        status, _, data = self.request('POST', '/api/upload?kind=dependency', body=self.jar.read_bytes(),
                                      headers={'X-Filename': '../../outside.jar'}, authorized=True)
        self.assertEqual(status, 200, data)
        self.assertEqual(self.studio.java, primary)
        self.assertEqual(len(self.studio.dependencies), 1)
        saved = Path(self.studio.dependencies[0])
        self.assertEqual(saved.parent, self.studio.workspace / 'uploads')
        self.assertTrue(saved.name.endswith('_outside.jar'))
        self.assertEqual(saved.read_bytes(), self.jar.read_bytes())
        self.assertEqual(len(self.studio.project['dependencies']), 1)
        self.assertFalse((self.root.parent / 'outside.jar').exists())

    def test_invalid_upload_does_not_replace_active_mod(self):
        primary = self.studio.java
        status, _, _ = self.request('POST', '/api/upload?kind=java', body=b'not a zip', authorized=True)
        self.assertEqual(status, 400)
        self.assertEqual(self.studio.java, primary)
        self.assertGreater(len(self.studio.project['models']), 0)

    def test_oversized_upload_is_rejected_before_body_is_read(self):
        status, _, _ = self.request('POST', '/api/upload?kind=java', body=b'',
                                    headers={'Content-Length': str(512 * 1024 * 1024 + 1)}, authorized=True)
        self.assertEqual(status, 400)

    def test_http_conversion_and_download_roundtrip(self):
        options = json.dumps({'models': ['fixture:block/sample'], 'render_size': 64}).encode()
        status, _, data = self.request('POST', '/api/convert', body=options, authorized=True)
        self.assertEqual(status, 202, data)
        deadline = time.monotonic() + 5
        while self.studio.job['state'] == 'running' and time.monotonic() < deadline:
            time.sleep(0.01)
        self.assertEqual(self.studio.job['state'], 'done', self.studio.job)
        status, headers, data = self.request('GET', '/download/result.zip')
        self.assertEqual(status, 200)
        self.assertIn('attachment;', headers['Content-Disposition'])
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            self.assertIn('ABRIR_COMPARACION.html', z.namelist())
            self.assertFalse(any(n.startswith('paquete_bedrock/') or n.endswith(('.mcaddon','.mcpack','.js')) for n in z.namelist()))
            self.assertIsNone(z.testzip())
        status, _, data = self.request('GET', '/api/model?id=fixture%3Ablock%2Fsample&geometry=1')
        self.assertEqual(status, 200)
        model = json.loads(data)
        self.assertEqual(model['report']['id'], 'fixture:block/sample')
        self.assertGreater(len(model['original_ir']['faces']), 0)
        status, _, image = self.request('GET', model['views_base'] + '/frontal/original.png')
        self.assertEqual(status, 200)
        with Image.open(io.BytesIO(image)) as opened: self.assertEqual(opened.size, (64, 64))


if __name__ == '__main__':
    unittest.main()
