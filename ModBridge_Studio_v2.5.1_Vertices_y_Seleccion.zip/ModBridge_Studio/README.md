# ModBridge Studio 2.5.1 · Vértices en renders y conversión seleccionada

Programa local en español para convertir modelos 3D estáticos de Java a geometría Bedrock. El motor permanece separado en `conversion_engine/`: conserva la base 2.4.4 y añade repasos automáticos acotados para mejorar los casos difíciles.

## Qué cambia en 2.5.1

- Cada PNG de la exportación por perfiles muestra **VÉRTICES: N** en la esquina superior derecha, con letras de estilo píxel, blancas y sobre un fondo oscuro. En resoluciones pequeñas se divide en dos líneas para que quepa el número completo.
- El conteo corresponde a la geometría completa de cada representación: Java y Bedrock tienen su propio valor. Cuenta posiciones XYZ distintas sin redondearlas, unificando esquinas compartidas por varias caras; no cuenta solo los vértices visibles ni duplica una posición por sus materiales o UV. El PNG y el manifiesto incluyen también ese dato.
- **Convertir seleccionados** aparece junto al botón existente. Procesa únicamente los modelos marcados, incluso si están ocultos por un filtro, y se deshabilita cuando no hay selección o hay una tarea activa. Una selección vacía también se rechaza en el servidor.
- La conversión seleccionada crea un lote nuevo con esos modelos. **Reiniciar seleccionados** conserva su función de volver a procesar los marcados y reunirlos con los demás resultados terminados.

Consulta [los cambios y pruebas de 2.5.1](docs/CAMBIOS_Y_VALIDACION_V251.md). El motor de conversión mantiene el algoritmo **2.5.0** y su API **1.1.0**; esta actualización cambia la interfaz y la presentación de los renders.

## Qué cambia en 2.5.0

- **Pausar**, gris, se transforma en **Continuar**, verde. Conserva el avance y retoma el mismo proceso. El estado **Pausando…** indica que todavía está alcanzando un punto seguro.
- **Reiniciar seleccionados** vuelve a convertir únicamente los modelos marcados y conserva los resultados completos de los demás. Sin selección, el aviso al pasar el cursor dice **Ocupas seleccionar modelos**. Para reiniciar, primero termina o detén la tarea activa.
- Hasta **dos repasos automáticos** por defecto: solo se aceptan mejoras que no aumenten las áreas omitidas o salientes ni reduzcan la densidad nominal del atlas. Se detienen al comprobar coincidencia o alcanzar el límite.
- De los 65 casos de superficies de los archivos aportados, los 65 mejoraron según esas medidas; uno alcanzó coincidencia geométrica. Los otros 64 siguen identificados como aproximados. El caso nativo `goggles` conserva sus caras degeneradas y su estado de revisión.
- Los parámetros y el algoritmo siguen siendo editables sin modificar la interfaz. `refinement_passes: 0` permite volver al comportamiento base para comparar.

La pausa principal controla la conversión, sus comparaciones y empaquetado. La exportación independiente de renders por perfiles conserva su cancelación propia. Durante un reinicio, un ZIP previo pendiente de sustituir se identifica como **Descargar ZIP anterior**.

**Para editar el algoritmo:** empieza por [conversion_engine/README.md](conversion_engine/README.md). Consulta [los cambios](docs/CAMBIOS_V250.md), [el análisis de tus modelos](docs/ANALISIS_RESULTADOS_V250.md) y [la validación](docs/VALIDACION_V250.md).

**Actualización:** extrae en una carpeta nueva y vuelve a convertir desde el JAR. Los ZIP de resultados anteriores conservan su contenido histórico.

## Instalar y abrir

1. Cierra la versión anterior. Extrae el ZIP completo en una carpeta nueva y corta, por ejemplo `C:\ModBridge251`.
2. Instala Python 3.10 o posterior. En Windows abre `INICIAR_WINDOWS.bat`; en macOS/Linux ejecuta `sh iniciar_mac_linux.sh`.
3. El lanzador crea `.venv` e instala NumPy y Pillow la primera vez; esa instalación necesita internet. Las conversiones se procesan localmente.
4. Se abre `http://127.0.0.1:8765` o un puerto libre. Mantén abierta la consola.
5. Carga el JAR original y, si hace falta, sus dependencias. Se incluye respaldo de recursos vanilla 1.21.1; las dependencias aportadas tienen prioridad. El `.mcaddon` de referencia sirve para comparar recursos.
6. Para convertir geometría, selecciona **Superficies** y procesa los modelos. Los ZIP ya descargados conservan su contenido histórico; las superficies reconstruidas se clasifican como **Revisar** al consultar o procesar sus reportes en esta versión.
7. Revisa **Seis vistas**, **Geometría 3D** y el reporte antes de descargar el ZIP.

Se entrega código Python con lanzadores, **no un `.exe` autónomo**. No requiere Java ni Minecraft para leer los recursos. El visor necesita WebGL. Node solo se usa en algunas pruebas de desarrollo.

## Funciones conservadas de 2.4.7

- **Comparación Java / Bedrock:** selecciona **Comparación (Java + Bedrock)** en la representación de un perfil para exportar ambos lados con idénticos ajustes y encuadre. Cada imagen se identifica con `_java` o `_bedrock`.
- **Control maestro:** aplica perfiles, una maestra común y ajustes de render a todos los modelos del configurador o solo a los marcados. Incluye resumen previo, Aplicar y Deshacer; se conservan los controles individuales.
- **Recuperación de rectángulos en 2.5.0:** agrupa únicamente caras cuya unión rectangular, orientación, multiplicidad y continuidad UV puedan comprobarse. No se reactiva la reconstrucción general de regiones de 2.4.7.
- **Validación histórica de 2.4.7:** `docs/VALIDACION_V247.md` conserva la revisión de 1.566 renders de 87 modelos de una entrega anterior. Los resultados de los archivos actuales están en `docs/ANALISIS_RESULTADOS_V250.md`.

La corrección no convierte cualquier polígono arbitrario en un rectángulo exacto. Las aproximaciones siguen indicadas como tales; una coincidencia de imagen no sustituye la comprobación de superficie y UV. No se garantiza traducción 1:1 universal ni validación dentro del juego.

## Control maestro de exportación

1. Marca los modelos en la biblioteca y abre **Avanzados → Generar y descargar renders (.ZIP)**.
2. En la sección **Control maestro**, elige **Todos los modelos del configurador** o **Solo los modelos marcados**. El alcance se aplica a los modelos presentes en ese recuadro; no cambia por sí solo cuáles se exportarán.
3. Marca los perfiles que quieres aplicar y elige **Reemplazar**, **Añadir** o **Quitar** asignaciones. Puedes usar Todos/Ninguno para esa lista de perfiles.
4. Para agruparlos en la misma carpeta maestra, activa **Usar una maestra común** y escribe su nombre.
5. Para unificar vistas, modos, Rayos X, Normales, resolución y representación, usa **Editar ajustes del perfil activo**, configura ese perfil y vuelve al control maestro. Activa **Copiar los ajustes del perfil activo a los perfiles elegidos**. Los nombres individuales de perfiles y modelos se conservan.
6. Comprueba el resumen de alcance y pulsa **Aplicar control maestro**. Si un perfil se comparte con modelos fuera del alcance, se crea una copia para que esos modelos conserven su configuración. La operación se rechaza completa si excedería el límite de 32 perfiles.
7. Puedes **Deshacer aplicación** antes de otro cambio de configuración. Después revisa el resumen de imágenes y genera el ZIP como antes.

## Funciones conservadas de 2.4.6

- **Revisar:** todo resultado con el aviso «SUPERFICIES RECONSTRUIDAS» queda en revisión aunque sus comprobaciones coincidan. La reclasificación no modifica los originales ni las métricas.
- **Avanzados:** sección contraída al iniciar; filtros de Geometría y Texturas basados en las conclusiones reales de las tarjetas y los tipos de destino existentes. Varias casillas dentro de una categoría se combinan con «o»; ambas categorías se combinan con «y», junto con búsqueda y filtros actuales.
- **Generar y descargar renders (.ZIP):** configurador de siete secciones con selección por modelo, múltiples perfiles independientes, seis perspectivas, Alambre/Sólido/Texturas, Rayos X y Normales. Cada modo produce su propio PNG.
- Resumen exacto antes de iniciar, progreso por modelo/perfil, cancelación y detalle de incidencias. El ZIP de renders se genera en un proceso separado del resultado de conversión.

## Generar renders por perfiles

1. Carga el JAR y marca los modelos en la biblioteca. Abre **Avanzados → Generar y descargar renders (.ZIP)**.
2. En **Modelos**, confirma cuáles participarán. «Todos» y «Ninguno» afectan solo a la selección del configurador. Cada modelo muestra sus perfiles asignados y la **Maestra** que agrupa su carpeta; por defecto usa el nombre del JAR. Puedes modificar esta agrupación sin cambiar el modelo fuente.
3. En **Perfiles**, añade o duplica perfiles, ponles un nombre y elige cuál editar. Las casillas de cada modelo determinan qué perfiles usará. Puedes exportar el original Java, la geometría traducida o elegir **Comparación (Java + Bedrock)**; esta última genera ambos lados automáticamente y queda registrada.
4. Elige perspectivas y modos para cada perfil. **Arriba, Abajo, Izquierda, Derecha, Enfrente y Atrás** son cámaras ortográficas sobre la geometría completa. La resolución inicial hereda el ajuste principal (128/192/256 px); el configurador permite 64–512 px, el rango admitido por el motor existente.
5. Marca Rayos X y/o Normales. Sin casillas hay una variante normal; con una hay una variante con ese parámetro; con ambas hay una variante conjunta. **Generar las 3 combinaciones** produce exactamente: solo Rayos X, solo Normales y ambos. No añade una cuarta imagen sin parámetros. Normales utiliza la convención del visor: azul exterior y rojo interior. Rayos X permite ajustar la opacidad.
6. Revisa el **Resumen**: cantidades, pares Java/Bedrock solicitados, asignaciones por modelo/perfil e imágenes repetidas omitidas. El servidor valida el cálculo antes de habilitar **Generar ZIP**.
7. Pulsa **Generar ZIP**. Se carga un modelo a la vez. Los modelos sin conversión se preparan en una carpeta independiente con el modo Superficies/Solo exactos elegido en la interfaz principal. Se muestran el modelo y perfil actuales; cerrar y reabrir el recuadro conserva el seguimiento.
8. Al terminar, pulsa **Descargar ZIP de renders**. Si un modelo o una imagen falla, se informa la incidencia y se continúa con los demás. Si se cancela, no se ofrece un archivo parcial como completo.

El ZIP contiene `RENDERS_EXPORTADOS/MAESTRA_…/MODELO_…/PERFIL_…/nombre_arriba_alambre_sin_rayosx_sin_normales.png` y `RENDERS_EXPORTADOS/manifiesto.json`. Los nombres se normalizan sin espacios ni caracteres incompatibles; las carpetas llevan identificadores cortos para evitar colisiones. Solo se crean carpetas que contienen imágenes.

En **Comparación**, cada perspectiva, modo y combinación produce dos PNG separados: `nombre_arriba_solido_sin_rayosx_sin_normales_java.png` y `nombre_arriba_solido_sin_rayosx_sin_normales_bedrock.png`. Ambos utilizan la misma cámara, escala, resolución y parámetros. El Control maestro permite aplicar esta representación a todos los modelos. El total de imágenes cuenta ambos lados. Si falta uno, se conserva el render válido y se informa la incidencia; el archivo de descripción del ZIP registra si cada pareja está completa, parcial o fallida. Son renders de la geometría del programa, no capturas dentro del juego.

Las configuraciones idénticas de un modelo se guardan una sola vez en el primer perfil asignado. El resumen y el manifiesto indican las referencias omitidas. La deduplicación considera perspectiva, modo, parámetros, resolución, representación y opacidad efectiva; no elimina perspectivas distintas de un modelo simétrico solo porque se parezcan.

Los renders utilizan el motor real de geometría y texturas, sin capturar la interfaz. El modo Texturas informa los recursos faltantes en vez de presentar un sustituto como textura válida. Durante la generación se bloquean cambios de recursos y otra conversión simultánea; el ZIP de conversión anterior sigue disponible. Los perfiles se conservan al cerrar y reabrir el recuadro dentro de la misma sesión y proyecto.

Consulta `docs/CAMBIOS_V246.md` y `docs/VALIDACION_V246.md` para el alcance y los resultados de pruebas.

## Motor base y repaso automático

La primera conversión mantiene las franjas por polígono y las máscaras de la 2.4.4. El motor general de regiones de 2.4.5–2.4.8 queda como histórico en `docs/HISTORICO/MOTOR_245_248_RETIRADO.zip`. La 2.5.0 incorpora una recuperación limitada a rectángulos demostrados, más dos intentos predeterminados de refinamiento de contornos.

`conversion_engine/settings.json` permite ajustar los límites. `adaptive.py` decide qué intento conservar; `rectangle_recovery.py` comprueba qué caras se pueden unir; `surface_proof.py` verifica la geometría Bedrock decodificada. Cada reporte registra intentos, errores de cobertura y el resultado elegido.

Los originales, vértices y UV se conservan como fuente e IR de auditoría. El atlas se remuestrea y algunos polígonos conservan planos envolventes con transparencia. Una aproximación que mejora no necesariamente alcanza coincidencia; los repasos pueden aumentar el tiempo y el número de caras.

## Biblioteca y revisión

La búsqueda, la ordenación A-Z, los filtros por resultado y **Modelo 3D extendido** se conservan. La selección explícita prevalece sobre los filtros; sin selección, **Convertir modelos** procesa todos los resultados filtrados, incluidas las páginas no visibles. **Reiniciar seleccionados** siempre exige una selección explícita. **Ver este modelo** prepara una inspección individual. **Detener** conserva los modelos terminados y **Exportar terminados** permite un resultado parcial.

| Resultado | Significado |
|---|---|
| Verde · Verificados | Superó las comprobaciones estáticas implementadas de geometría y píxeles; no certifica ejecución en Minecraft. |
| Ámbar · Revisar | Hay diferencias, aproximaciones, recursos faltantes o evidencia insuficiente. |
| Rojo · No convertidos | Recurso no soportado o error; el reporte conserva la causa. |
| Turquesa · Plantillas | Definición abstracta que requiere una instancia concreta. |

Alambre, Sólido, Texturas, Rayos X y Normales siguen disponibles con cámaras sincronizadas. El alambre puede omitir divisiones internas coplanares; las caras exportadas y la auditoría conservan la geometría completa. El límite de previsualización no reduce la geometría exportada.

## Escala y ruedas de agua

**16 unidades = 1 bloque.** No se reducen los modelos grandes a un bloque. `extended3d` informa que la geometría excede el perfil convencional; no indica éxito de conversión. `visible_bounds_*` modifica la visibilidad, no el tamaño de los cubos.

| Recurso | Función |
|---|---|
| `create:block/water_wheel/block` | Base de la rueda pequeña. |
| `create:block/water_wheel/wheel` | Rotor pequeño. |
| `modbridge:block/water_wheel/assembled` | Receta explícita de base + rotor en una pose estática. |
| `create:block/large_water_wheel/block` | Rueda grande. |
| `create:block/large_water_wheel/block_extension` | Variante grande extendida. |

Una geometría que requiere integración como entidad sigue siendo un modelo 3D: este programa no crea ni controla entidades. Las recetas explícitas no reconstruyen automáticamente cualquier máquina a partir de su renderer Java.

## Exportaciones

| Carpeta | Contenido |
|---|---|
| `modelos_originales/` | JSON, padres, PNG, OBJ y demás recursos utilizados. |
| `modelos_traducidos/<modelo>/` | Geometría, atlas y reportes. Las mallas de diagnóstico se identifican como no compatibles. |
| `comparaciones/<modelo>/` | Original, destino y diferencia desde seis lados, lámina y métricas. |
| `intermedio/<modelo>/` | Vértices, caras, normales y UV para auditoría. |
| `reportes/` | Resumen CSV/JSON, estados, perfiles y advertencias. |
| `ABRIR_COMPARACION.html` | Comparación de imágenes que puede abrirse sin servidor. |

Los recursos originales permanecen intactos. Las exportaciones completas y parciales se reconstruyen desde una carpeta limpia. No se generan `.mcaddon`, `.mcpack`, manifiestos, definiciones de entidad/bloque ni scripts de juego.

`examples/Demostracion_ModBridge.jar` permite probar modelos sintéticos. `examples/Pasador_v245/` conserva un ejemplo histórico de la 2.4.5; no representa la salida del motor restaurado. Los ejemplos de `examples/WaterWheel_242_Historico.zip` proceden de **2.4.2** y se conservan como evidencia histórica; no representan resultados de esta versión. Vuelve a convertir el JAR fuente para obtener resultados nuevos. El JAR de Create utilizado en la validación no se redistribuye.

## Límites

Solo se convierten recursos estáticos. No se traduce código Java, animaciones del renderer, cinética, RPM, física, lógica del agua, interacción, colocación o colisiones. Se preservan los `.mcmeta` como fuente, pero no se genera una animación Bedrock.

Las seis vistas son renders ortográficos propios, con cámara y escala comunes; no son capturas de Java o Bedrock. La aceptación y apariencia final requieren vincular geometría y textura en el proyecto Bedrock y probarlas dentro del juego. No se certifica esa ejecución ni el arranque nativo de Windows desde este entorno.

## Terminal y pruebas

```bash
python app.py serve
python app.py convert --input create.jar --output resultado --filter water_wheel --size 128
python app.py convert --input create.jar --output resultado --model create:block/track/bogey/bogey_drive_wheel_pin
python -m unittest discover -s tests -v
node --test tests/test_library.cjs tests/test_verification_cards.cjs tests/test_viewer_contours.cjs tests/test_render_config.cjs tests/test_analysis_filters.cjs tests/test_job_controls.cjs
```

Opciones conservadas: `--mesh-mode`, `--model`, `--filter`, `--size`, `--input`, `--reference`, `--dependency`, `--output` y las del servidor. `--mesh-mode exact` mantiene las mallas OBJ no representables como diagnóstico editable, sin adaptar su superficie. No existe `--anchor-mode`.

La regresión de los 87 modelos sobre el JAR real se puede repetir con `tests/run_geometry_v247.py`; consulta su ayuda y aporta el manifiesto del ZIP de renders y el JAR fuente. `tests/render_regression_v247.py` compara los renders de dos ejecuciones. Se conservan los scripts históricos. Las pruebas opcionales de navegador usan Playwright/Chromium; la auditoría geométrica adicional usa Shapely. Ninguna es dependencia de uso del programa.

La aplicación es **2.5.1**, el algoritmo se mantiene en **2.5.0**, la base es **2.4.4** y la API del motor es **1.1.0**. El formato de geometría sigue en **1.21.0** y la previsualización pasa a **4** para renovar cachés. Los documentos `V250`, `V249`, `V248`, `V247`, `V246`, `V245`, `V244`, `V243`, `V242` e `HISTORICO` conservan resultados de sus respectivas versiones.
