#!/usr/bin/env python3
"""Local-only ModBridge Studio web app and CLI. No external service required."""
from __future__ import annotations
import argparse, json, mimetypes, secrets, sys, threading, time, traceback, webbrowser, os, subprocess
from bridge.pack import write_json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse, urlencode
from bridge.resources import ResourcePack
from bridge.reference import ReferenceAddon
from bridge.pipeline import run_conversion, model_slug, read_json
from bridge.preview import read_preview, texture_path
from bridge import __version__
from bridge.catalog import compact_report
from bridge.verification import final_status
from bridge.analysis_states import ANALYSIS_FILTERS
from bridge.render_jobs import RenderJobs

BASE=Path(__file__).resolve().parent
MAX_UPLOAD=512*1024*1024

class Studio:
    def __init__(self, workspace, java=None, reference=None, dependencies=None):
        self.workspace=Path(workspace).resolve();self.workspace.mkdir(parents=True,exist_ok=True)
        self.java=str(Path(java).resolve()) if java else None
        self.reference=str(Path(reference).resolve()) if reference else None
        self.dependencies=list(dependencies or []);self.project=None;self.result=None;self.run=None;self.revision=0
        self.job={'state':'idle','progress':0,'total':0,'current':'','message':'Listo para importar'}
        self.lock=threading.RLock();self.token=secrets.token_urlsafe(32);self.cancelled=False
        self.pause_requested=False
        self.worker=None;self.workrun=None;self.operation=None;self.batch_total=0;self.batch_completed=0;self.ready={};self.ready_offset=0
        self.render_jobs=RenderJobs(self, BASE)
        self._catalog_cache={}
        if self.java:self.index()

    def build_project(self, java, reference, dependencies, revision):
        if not java:return None
        with ResourcePack(java,extra_paths=dependencies) as pack:
            project={'name':Path(java).name,'inventory':pack.inventory(),
                'models':[{'id':m} for m in pack.models()],
                'dependencies':[Path(p).name for p in dependencies], 'revision':revision}
        if reference:project['reference']=ReferenceAddon(reference).summary
        return project

    def index(self):
        self.project=self.build_project(self.java,self.reference,self.dependencies,self.revision)

    def replace_input(self, kind, path):
        """Validate and index a prospective project before committing any state."""
        with self.lock:
            if self.job['state'] in {'running','pausing','paused','stopping'} or self.render_jobs.active:raise ValueError('Esperar a que termine la tarea antes de cambiar los archivos.')
            java,reference,dependencies=self.java,self.reference,list(self.dependencies)
            if kind=='reference':ReferenceAddon(path);reference=str(path)
            else:
                with ResourcePack(path) as pack:
                    pack.inventory()
                    if kind=='java' and not pack.models():raise ValueError('El archivo no contiene modelos Java JSON.')
                if kind=='java':java=str(path);dependencies=[]
                elif kind=='dependency':dependencies.append(str(path))
                else:raise ValueError('Tipo de archivo inválido.')
            revision=self.revision+1
            project=self.build_project(java,reference,dependencies,revision)
            self.java,self.reference,self.dependencies=java,reference,dependencies
            self.revision=revision;self.project=project
            self.result=None;self.run=None;self.cancelled=False;self.ready={};self.batch_total=0;self.batch_completed=0
            self.render_jobs.reset();self._catalog_cache.clear()
            self.job={'state':'idle','progress':0,'total':0,'current':'',
                'message':'Recursos actualizados. Convertir para generar resultados nuevos.'}

    def catalogue_entry(self, entry):
        """Hydrate legacy compact results once, without rewriting original files."""
        if isinstance(entry.get('analysis'),dict) or 'metrics' in entry or 'target_kind' in entry:
            return compact_report(entry)
        current=self.ready.get(entry.get('id'),{})
        run=entry.get('run') or current.get('run') or self.run
        slug=entry.get('slug') or current.get('slug')
        if run and slug:
            path=(Path(run)/'models'/slug/'report.json').resolve()
            if path.is_relative_to(self.workspace) and path.is_file():
                stat=path.stat();key=(str(path),stat.st_mtime_ns,stat.st_size)
                cached=self._catalog_cache.get(key)
                if cached is None:
                    detailed=read_json(path)
                    if detailed:
                        cached=compact_report(detailed)
                        # A bounded cache contains only compact facets, no meshes.
                        if len(self._catalog_cache)>=10000:self._catalog_cache.clear()
                        self._catalog_cache[key]=cached
                if cached is not None:return dict(cached)
        return compact_report(entry)

    def status(self, compact=False):
        with self.lock:
            result=None
            if self.result:
                result={k:v for k,v in self.result.items() if k not in {'archive','export_dir','reports'}}
                result['reports']=[self.catalogue_entry(r) for r in self.result['reports']]
            project=self.project
            if compact and project:project={k:v for k,v in project.items() if k!='models'}
            return {'project':project,'job':dict(self.job),'result':result,
                'result_is_previous':bool(self.result and self.run and self.result.get('archive')
                    and Path(self.result['archive']).parent != self.run),
                'ready_models':[self.catalogue_entry(r) for r in self.ready.values()],
                'render_job':self.render_jobs.status(),
                'can_export_partial':bool(self.run and self.batch_completed)}

    def update(self,value):
        with self.lock:self.job.update(value)

    def _refresh(self, run):
        # A killed process may leave the last JSONL line incomplete: publish only full lines.
        path=run/'ready.ndjson'
        if path.exists():
            with path.open('rb') as stream:
                stream.seek(self.ready_offset)
                while True:
                    line=stream.readline()
                    if not line.endswith(b'\n'):break
                    self.ready_offset=stream.tell()
                    try:entry=json.loads(line)
                    except ValueError:continue
                    self.ready[entry['id']]={**entry,'run':str(run)}
                    if run==self.run:self.batch_completed+=1
        if not self.cancelled:
            value=read_json(run/'progress.json')
            if value:self.job.update(value)
            if self.pause_requested:
                acknowledged=read_json(run/'control_status.json',{}).get('state')=='paused'
                self.job.update(state='paused' if acknowledged else 'pausing',
                    message='En pausa. Los modelos y el avance se conservan.' if acknowledged else 'Pausando en el siguiente punto seguro…')

    def start(self,options,operation='convert'):
        with self.lock:
            if self.worker is not None or self.render_jobs.active or self.job['state'] in {'running','pausing','paused','stopping'}:raise ValueError('Ya hay una tarea en curso.')
            if not self.java:raise ValueError('Primero se debe cargar el mod Java.')
            mesh_mode=options.get('mesh_mode','surface')
            if mesh_mode not in {'surface','exact'}:raise ValueError('Modo de malla inválido: usar surface o exact.')
            size=max(64,min(512,int(options.get('render_size',192))))
            models=options.get('models')
            if (operation=='restart' or options.get('selection_only') is True) and (not isinstance(models,list) or not models):
                raise ValueError('Ocupas seleccionar modelos')
            available={m['id'] for m in self.project['models']}
            if models and (not isinstance(models,list) or any(not isinstance(m,str) or m not in available for m in models)):
                raise ValueError('La selección contiene modelos inexistentes.')
            if models and len(models)!=len(set(models)):
                raise ValueError('La selección contiene modelos repetidos.')
            if operation=='preview' and (not models or len(models)!=1):raise ValueError('Elegir un modelo para previsualizar.')
            if operation=='export' and not self.run:raise ValueError('No hay un lote para exportar.')
            workrun=self.workspace/'runs'/('job_'+time.strftime('%Y%m%d_%H%M%S')+'_'+secrets.token_hex(4))
            workrun.mkdir(parents=True)
            config={'run':str(workrun),'operation':operation,'java':self.java,'dependencies':list(self.dependencies),
                'reference':self.reference if options.get('include_reference',True) else None,
                'models':models,'filter':options.get('filter',''),'render_size':size,'mesh_mode':mesh_mode}
            if operation=='restart':
                config['filter']=''
                config['retained_models']={mid:str(Path(entry['run'])/'models'/entry['slug'])
                    for mid,entry in self.ready.items() if mid not in set(models)}
            if operation=='export':config.update(source_run=str(self.run),planned_total=self.batch_total)
            write_json(workrun/'config.json',config)
            env=os.environ.copy()
            for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):env[name]='1'
            with (workrun/'worker.log').open('wb') as log:
                process=subprocess.Popen([sys.executable,'-u',str(BASE/'worker.py'),str(workrun/'config.json')],
                    cwd=str(BASE),env=env,stdout=log,stderr=subprocess.STDOUT,
                    creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            if operation in {'convert','restart'}:
                if operation=='convert':self.result=None;self.ready={}
                self.run=workrun;self.batch_completed=0
                self.batch_total=len(models) if models else sum(config['filter'].lower() in mid.lower() for mid in available)
            if operation=='restart':self.batch_total+=len(config['retained_models'])
            self.pause_requested=False
            self.cancelled=False;self.workrun=workrun;self.operation=operation;self.ready_offset=0;self.worker=process
            self.job={'state':'running','progress':0,'total':len(models) if models else 0,'current':'','operation':operation,
                'message':'Generando vistas del modelo' if operation=='preview' else 'Preparando recursos'}
        def watch():
            while process.poll() is None:
                with self.lock:
                    if self.worker is process:self._refresh(workrun)
                try:process.wait(timeout=.10)
                except subprocess.TimeoutExpired:pass
            with self.lock:
                if self.worker is not process:return
                self._refresh(workrun)
                if self.cancelled:
                    self.job.update(state='cancelled',message='Detenido. Puedes revisar los modelos terminados y exportarlos por separado.')
                else:
                    completion=read_json(workrun/'completion.json',{})
                    if completion.get('ok'):
                        if operation!='preview':self.result=completion['result']
                        self.job.update(state='done',message='Vistas listas para inspeccionar' if operation=='preview' else 'Exportación lista')
                    else:self.job.update(state='error',message=completion.get('error','El proceso terminó antes de completar la tarea. Consulta worker.log.'))
                self.worker=None;self.pause_requested=False
        threading.Thread(target=watch,daemon=True).start()

    def pause(self, paused=True):
        if not isinstance(paused,bool):raise ValueError('paused debe ser booleano.')
        with self.lock:
            if self.worker is None or self.worker.poll() is not None or self.cancelled:
                raise ValueError('No hay una conversión activa para pausar o continuar.')
            self.pause_requested=paused
            write_json(self.workrun/'control.json',{'paused':paused})
            self.job.update(state='pausing' if paused else 'running',
                message='Pausando en el siguiente punto seguro…' if paused else 'Continuando desde el avance conservado…')

    def cancel(self):
        with self.lock:
            self.cancelled=True;process=self.worker
            if process is None:return
            self.job.update(state='stopping',message='Deteniendo el proceso y liberando su memoria…')
        # Never wait for a model, rasterization, or ZIP operation to finish.
        try:
            process.terminate()
            try:process.wait(timeout=.5)
            except subprocess.TimeoutExpired:
                process.kill()
                try:process.wait(timeout=.5)
                except subprocess.TimeoutExpired:pass
        except ProcessLookupError:pass

    def model(self,mid,geometry=False):
        with self.lock:entry=self.ready.get(mid)
        if not entry:raise ValueError('Las vistas de este modelo aún no están listas.')
        run=Path(entry['run']);md=run/'models'/entry['slug']
        result={'report':read_json(md/'report.json'),'views_base':'/runs/'+run.name+'/models/'+entry['slug']+'/vistas'}
        if result['report']:
            result['report']['status']=final_status(result['report'])
        if geometry:
            preview=read_preview(md)
            for side in ('original_ir','bedrock_ir'):
                ir=preview.get(side,{})
                ir['textures']={key:'/api/texture?'+urlencode({'id':mid,'side':side,'name':key,'run':run.name})
                                for key in ir.get('textures',{})}
            result.update(preview)
        return result

    def preview_texture(self, mid, side, name, run=None):
        if side not in {'original_ir','bedrock_ir'}:
            raise ValueError('Representación no válida.')
        with self.lock:entry=self.ready.get(mid)
        if not entry:raise ValueError('Las vistas de este modelo aún no están listas.')
        if run is not None and run!=Path(entry['run']).name:
            raise ValueError('El modelo se actualizó. Abre de nuevo su vista.')
        md=Path(entry['run'])/'models'/entry['slug']
        value=read_preview(md).get(side,{}).get('textures',{}).get(name)
        path=texture_path(md,value)
        if path is None:raise ValueError('Textura no disponible en este modelo.')
        return path,md


def make_handler(studio):
    class Handler(BaseHTTPRequestHandler):
        server_version='ModBridge/'+__version__
        def log_message(self,fmt,*args):
            if args and 'api/status' in str(args[0]):return
            print(fmt%args)
        def allowed(self):
            host=self.headers.get('Host','').split(':')[0]
            return host in {'127.0.0.1','localhost','[::1]'}
        def respond(self,code,data,typ='application/json; charset=utf-8'):
            if isinstance(data,(dict,list)):data=json.dumps(data,ensure_ascii=False,allow_nan=False).encode('utf-8')
            if isinstance(data,str):data=data.encode('utf-8')
            self.send_response(code);self.send_header('Content-Type',typ);self.send_header('Content-Length',str(len(data)))
            self.send_header('X-Content-Type-Options','nosniff');self.send_header('Cache-Control','no-store')
            self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'")
            self.end_headers();self.wfile.write(data)
        def json_error(self,e,code=400):self.respond(code,{'error':str(e)})
        def file(self,path,root,download=False):
            p=Path(path).resolve();root=Path(root).resolve()
            if not p.is_relative_to(root) or not p.is_file():self.json_error('Archivo no encontrado',404);return
            self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(p.name)[0] or 'application/octet-stream')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Length',str(p.stat().st_size))
            if download:self.send_header('Content-Disposition','attachment; filename="'+('ModBridge_renders.zip' if download=='renders' else 'ModBridge_resultado.zip')+'"')
            self.end_headers()
            with p.open('rb') as f:
                while chunk:=f.read(1024*1024):self.wfile.write(chunk)
        def do_GET(self):
            if not self.allowed():self.json_error('Host no permitido',403);return
            u=urlparse(self.path);q=parse_qs(u.query)
            try:
                if u.path=='/api/status':self.respond(200,studio.status(compact=q.get('compact')==['1']))
                elif u.path=='/api/inventory':self.respond(200,studio.project or {})
                elif u.path=='/api/analysis-filters':self.respond(200,ANALYSIS_FILTERS)
                elif u.path=='/api/renders/status':self.respond(200,studio.render_jobs.status())
                elif u.path=='/download/renders.zip':self.file(studio.render_jobs.download(),studio.workspace,'renders')
                elif u.path=='/api/model':
                    self.respond(200,studio.model(q.get('id',[''])[0],geometry=q.get('geometry')==['1']))
                elif u.path=='/api/texture':
                    path,root=studio.preview_texture(q.get('id',[''])[0],q.get('side',[''])[0],q.get('name',[''])[0],q.get('run',[None])[0])
                    self.file(path,root)
                elif u.path=='/download/result.zip':
                    if not studio.result:raise ValueError('No hay ZIP listo.')
                    self.file(studio.result['archive'],studio.workspace,True)
                elif u.path.startswith('/runs/'):
                    # Only completed model output is exposed, never worker configuration or uploads.
                    parts=Path(u.path[len('/runs/'):]).parts
                    if len(parts)<4 or parts[1]!='models' or parts[-1] not in {'original.png','traducido.png','diferencia.png'}:
                        self.json_error('Archivo no encontrado',404);return
                    self.file(studio.workspace/'runs'/u.path[len('/runs/'):],studio.workspace/'runs')
                elif u.path.startswith('/output/'):
                    if not studio.run:raise ValueError('No hay resultados.')
                    self.file(studio.run/'models'/u.path[len('/output/'):],studio.run/'models')
                elif u.path=='/' or u.path=='/index.html':
                    page=(BASE/'web'/'index.html').read_text(encoding='utf-8')
                    script='<script>window.bridgeToken='+json.dumps(studio.token)+';</script>'
                    page=page.replace('</head>',script+'</head>');self.respond(200,page,'text/html; charset=utf-8')
                else:self.file(BASE/'web'/u.path.lstrip('/'),BASE/'web')
            except (BrokenPipeError,ConnectionResetError):pass
            except Exception as e:self.json_error(e)
        def do_POST(self):
            if not self.allowed() or self.headers.get('X-Bridge-Token')!=studio.token:
                self.json_error('Solicitud no autorizada. Recargar la aplicación local.',403);return
            origin=self.headers.get('Origin')
            if origin and origin not in {'http://127.0.0.1:'+str(self.server.server_port),'http://localhost:'+str(self.server.server_port)}:
                self.json_error('Origen no permitido',403);return
            u=urlparse(self.path);q=parse_qs(u.query)
            try:
                length=int(self.headers.get('Content-Length','0'))
                if length<0 or length>MAX_UPLOAD:raise ValueError('Máximo 512 MB por archivo.')
                if u.path=='/api/upload':
                    if studio.job['state'] in {'running','pausing','paused','stopping'} or studio.render_jobs.active:raise ValueError('Esperar a que termine la tarea antes de cambiar los archivos.')
                    kind=q.get('kind',['java'])[0]
                    if kind not in {'java','reference','dependency'}:raise ValueError('Tipo de archivo inválido.')
                    name=self.headers.get('X-Filename',kind+'.zip')
                    # Never trust the browser-provided filename as a filesystem path.
                    name=Path(name.replace('\\','/')).name
                    name=''.join(c for c in name if c.isalnum() or c in '._-')[:120] or kind+'.zip'
                    path=studio.workspace/'uploads'/(secrets.token_hex(5)+'_'+name);path.parent.mkdir(exist_ok=True)
                    with path.open('wb') as f:
                        remaining=length
                        while remaining:
                            chunk=self.rfile.read(min(1024*1024,remaining))
                            if not chunk:raise ValueError('Carga incompleta.')
                            f.write(chunk);remaining-=len(chunk)
                    try:studio.replace_input(kind,path)
                    except Exception:
                        path.unlink(missing_ok=True)
                        raise
                    self.respond(200,{'ok':True,'project':studio.project,'kind':kind})
                elif u.path in {'/api/convert','/api/convert-selected','/api/preview','/api/export-completed','/api/restart'}:
                    if length>2000000:raise ValueError('Selección demasiado grande.')
                    options=json.loads(self.rfile.read(length) or '{}')
                    if u.path=='/api/convert-selected':
                        if not isinstance(options,dict):raise ValueError('La selección debe ser un objeto.')
                        options['selection_only']=True
                    operation={'/api/convert':'convert','/api/convert-selected':'convert','/api/preview':'preview','/api/export-completed':'export','/api/restart':'restart'}[u.path]
                    studio.start(options,operation);self.respond(202,{'ok':True})
                elif u.path in {'/api/renders/plan','/api/renders/start'}:
                    if length>2000000:raise ValueError('Configuración de renders demasiado grande.')
                    config=json.loads(self.rfile.read(length) or '{}')
                    if not isinstance(config,dict):raise ValueError('La configuración debe ser un objeto.')
                    if u.path=='/api/renders/plan':self.respond(200,{'plan':studio.render_jobs.plan(config)})
                    else:studio.render_jobs.start(config);self.respond(202,{'ok':True})
                elif u.path=='/api/renders/cancel':studio.render_jobs.cancel();self.respond(200,{'ok':True})
                elif u.path in {'/api/pause','/api/resume'}:
                    studio.pause(u.path=='/api/pause');self.respond(200,{'ok':True})
                elif u.path=='/api/cancel':studio.cancel();self.respond(200,{'ok':True})
                else:self.json_error('Ruta no encontrada',404)
            except (BrokenPipeError,ConnectionResetError):pass
            except Exception as e:self.json_error(e)
    return Handler


def main():
    parser=argparse.ArgumentParser(description='ModBridge Studio · Java → Bedrock')
    sub=parser.add_subparsers(dest='command')
    ui=sub.add_parser('serve',help='Abrir interfaz local');ui.add_argument('--port',type=int,default=8765)
    ui.add_argument('--no-browser',action='store_true');ui.add_argument('--workspace',default=str(BASE/'workspace'))
    for p in [ui,sub.add_parser('convert',help='Convertir y exportar desde terminal')]:
        p.add_argument('--input');p.add_argument('--reference');p.add_argument('--dependency',action='append',default=[])
        if p.prog.endswith('convert'):
            p.add_argument('--mesh-mode',choices=['surface','exact'],default='surface',help='surface: planos texturados aproximados para OBJ; exact: conservar malla incompatible como diagnóstico')
            p.add_argument('--output',required=True);p.add_argument('--model',action='append');p.add_argument('--filter',default='');p.add_argument('--size',type=int,default=192)
    args=parser.parse_args()
    if args.command=='convert':
        if not args.input:parser.error('--input es obligatorio para convert')
        result=run_conversion(args.input,args.output,models=args.model,pattern=args.filter,dependencies=args.dependency,
            reference_path=args.reference,size=args.size,mesh_mode=args.mesh_mode,progress=lambda p:print(json.dumps(p,ensure_ascii=False),flush=True))
        print(json.dumps({'archive':result['archive'],'summary':result['summary']},ensure_ascii=False,indent=2));return
    if args.command is None:args=parser.parse_args(['serve'])
    studio=Studio(args.workspace,args.input,args.reference,args.dependency)
    try:server=ThreadingHTTPServer(('127.0.0.1',args.port),make_handler(studio))
    except OSError:
        server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(studio))
    url='http://127.0.0.1:'+str(server.server_port)
    print('\nModBridge Studio: '+url+'\nMantener esta ventana abierta. Ctrl+C para cerrar.\n',flush=True)
    if not args.no_browser:threading.Timer(0.6,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:print('\nCerrando ModBridge.')
    finally:studio.cancel();studio.render_jobs.cancel();server.server_close()

if __name__=='__main__':main()
