# ModBridge Studio 2.5.1

## Conteo de vértices en los renders por perfiles

Cada PNG exportado por perfiles incluye **VÉRTICES: N** en la esquina superior derecha. La tipografía es una fuente bitmap incluida en el código, con píxeles enteros, letras blancas y fondo oscuro. No necesita fuentes instaladas ni conexión a internet. En 64 px se divide en dos líneas cuando no cabe en una.

El número corresponde al IR completo de la representación renderizada. En una comparación, Java utiliza sus vértices y Bedrock los de su propia geometría. Cuenta **posiciones XYZ distintas, sin redondeo**: un cubo con seis caras comparte ocho posiciones, no se cuenta como 24. Una posición coincidente se cuenta una vez aunque cambien UV, normal o material; dos puntos cercanos con coordenadas distintas se conservan como dos. Incluye posiciones ocultas por otras caras o por la cámara. No es un conteo de píxeles de imagen ni de vértices enviados a la GPU después de triangular.

Se aplica a todas las perspectivas y a Alambre, Sólido y Texturas, incluidas sus variantes de Rayos X y Normales. Mantiene la resolución, la cámara común y la geometría. El texto se superpone dentro del PNG; fuera del recuadro los píxeles del render permanecen iguales. Las seis vistas de auditoría del resultado de conversión conservan su contenido original sin esta anotación.

El PNG incluye metadatos `VertexCount`, `VertexCountMethod` y `Representation`. El manifiesto añade `vertex_counts` por modelo y `vertex_count` / `vertex_annotation` por imagen. El método se identifica como `unique_xyz_exact_full_ir`. Las parejas y la eliminación de imágenes repetidas mantienen su funcionamiento.

Para modificar la fuente, el recuadro o la definición de conteo, edita `bridge/render_annotations.py`. La integración está en `bridge/render_export.py`. Es presentación de exportación y permanece fuera del algoritmo de conversión.

## Convertir seleccionados

El nuevo botón está inmediatamente después del botón actual de convertir. Usa solo los identificadores válidos marcados en la biblioteca, incluidos los ocultos por filtros o paginación. Sin una selección válida está deshabilitado. Durante una conversión, una pausa o una exportación de renders también está deshabilitado.

Este botón crea un lote de conversión con la selección explícita. No tiene la alternativa de convertir todos los filtrados cuando la selección queda vacía. La ruta `/api/convert-selected` valida esa restricción en el servidor y mantiene la protección por token; enviar `selection_only: false` no la desactiva. Los dos botones de convertir se bloquean mientras se envía la petición para evitar duplicarla.

El botón existente conserva su comportamiento. **Reiniciar seleccionados** sigue reconstruyendo los modelos marcados y conservando los resultados terminados de los demás. Pausa, continuación y repasos automáticos siguen disponibles.

## Validación

- Suite Python: **258 pruebas aprobadas**. Incluye exportación real de 36 PNG con distintas representaciones, vistas y modos; un cubo fuente de ocho posiciones y un destino de cuatro obtienen sus conteos respectivos.
- Suite JavaScript sin navegador: **61 pruebas aprobadas**. Ejecuta los manejadores reales para comprobar selección vacía, filtros, identificadores obsoletos, bloqueo durante una tarea, errores de red y conservación del comportamiento del botón anterior.
- Se comprueba que el recuadro cabe en 64, 128, 192, 256 y 512 px y que no modifica píxeles fuera de su área. Se inspeccionaron visualmente PNG exportados a 64, 192 y 512 px.
- El servidor rechaza selecciones vacías o inválidas antes de crear un lote. Una conversión real con un único identificador produce un lote de un modelo.
- Se comparó el contenido de `conversion_engine/` con 2.5.0: no hay cambios en sus archivos. La aplicación pasa a **2.5.1**; el algoritmo continúa en **2.5.0** y la API en **1.1.0**.

Los registros completos están en `VALIDACION_V251_PYTHON.txt` y `VALIDACION_V251_JAVASCRIPT.txt`. No se realizó una nueva comprobación de interfaz en navegador real ni de integración dentro de Minecraft. Los límites de conversión y resultados de la auditoría 2.5.0 continúan documentados en sus archivos históricos.

## Instalar

Cierra la versión anterior, extrae este ZIP en una carpeta nueva y abre el lanzador de tu sistema. Vuelve a generar los renders por perfiles para que los PNG incluyan el contador; los ZIP descargados anteriormente conservan sus imágenes.
