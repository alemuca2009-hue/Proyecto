# Pruebas de integración de renders 2.4.6

Verificación ejecutada el 8 de noviembre de 2026, con Python 3.12 y Chrome Headless Shell 151.0.7922.34 mediante Playwright.

## HTTP, procesos y archivos

`tests/test_render_api_v246.py`: ocho pruebas aprobadas con un servidor HTTP local, procesos de renderizado reales y recursos Java de prueba. Comprueban:

- Exportación de dos modelos sin conversión previa, dos maestras y dos perfiles: 26 PNG reales a 64 × 64, con geometría, modos y parámetros que producen píxeles distintos.
- Exportación de modelos previamente convertidos, con las seis perspectivas, tres modos y ambos parámetros: 36 PNG; hashes de todos sus archivos de modelo, reportes y ZIP de conversión intactos.
- Configuraciones equivalentes deduplicadas, sin carpetas vacías ni perfiles sin asignar.
- Un modelo no compatible no impide generar el siguiente modelo.
- Selecciones inválidas, identificadores ajenos al catálogo y solicitudes sin autorización rechazados.
- Una selección inválida conserva el último ZIP completo.
- Cancelación y bloqueo de tareas de conversión mientras se generan renders.
- Conversión y exportación de modelos originales disponibles después de generar renders.

Los ZIP se abren, se comprueba su CRC, se decodifican sus PNG y se verifican las rutas jerárquicas, la ausencia de nombres duplicados y la conservación del archivo fuente mediante SHA-256.

```sh
python -m unittest discover -s tests -p test_render_api_v246.py -v
```

## Interfaz y descarga real

`tests/test_render_config_browser.cjs` abre el programa y utiliza sus controles sin sustituir las rutas de renderizado. La exportación verificada contiene **109 PNG y 43 búferes de píxeles distintos**, en dos maestras y dos modelos con asignaciones distintas de perfiles.

Incluye desplegar/contraer Avanzados, selección de modelos, todos/ninguno, añadir/duplicar/eliminar perfiles, editar maestras, seis perspectivas, tres modos, tres combinaciones, conteos dinámicos, deduplicación, indicador de progreso, cerrar/reabrir el modal, descarga del ZIP, cancelación y conversión posterior. También comprueba que los filtros coincidan con el catálogo del servidor y que la combinación de Geometría y Texturas actualice la lista correctamente.

El modal se comprueba a 1440, 768 y 390 píxeles de ancho, sin desbordamiento horizontal. La biblioteca y el visor anteriores se probaron además con `test_library_browser.cjs` y `test_viewer_browser.cjs`, incluyendo texturas, orientación UV, transparencias, Rayos X, normales, alambre y ocho anchos de ventana. El visor terminó sin errores de WebGL.

Las dependencias de navegador son exclusivamente de desarrollo; no se requieren para ejecutar ModBridge. Con Node, Playwright y Chromium instalados:

```sh
node tests/test_render_config_browser.cjs
node tests/test_library_browser.cjs
node tests/test_viewer_browser.cjs
```

Se puede indicar un ejecutable existente mediante `CHROMIUM_EXECUTABLE`. Las capturas opcionales se guardan solo si se establece `QA_SCREENSHOTS`; son evidencia visual de la interfaz y no participan en la generación de los renders exportados.
