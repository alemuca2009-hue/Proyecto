# Validación de ModBridge Studio 2.4.4

| Prueba | Resultado |
|---|---|
| Suite Python completa | 151 correctas, 0 fallos. |
| Suite JavaScript | 16 correctas, 0 fallos. |
| Sintaxis de app.js, library.js y viewer.js | Correcta. |
| Modelos reales de Create 1.21.1–6.0.10 | 8 conversiones completas, sin errores de adaptación. |
| Caso reproducido de la captura | 16 caras salientes en 2.4.3; 0 en 2.4.4. |
| Geometría, UV y normales del IR fuente de la manivela | Sin cambios. |
| Recursos fuente usados por la manivela | Todos idénticos byte por byte. |

## Comprobación del caso reproducido

Se compararon los vértices del destino serializado y decodificado con los
planos y semiespacios convexos de las caras originales, con tolerancia de
1e-6 unidades de modelo. La prueba de contención es independiente del
algoritmo que construye las franjas. La manivela pasa de 60 a 1082 caras de
destino; las 1082 quedan dentro de alguna cara original. Su cobertura planar
es 99,8651 % y no utiliza caras de respaldo.

La imagen `COMPARACION_CONTORNOS_V244.png` es una proyección calculada de los
IR originales y exportados, no una captura de Minecraft. El modo Alambre de
2.4.4 muestra los contornos de unión derivados de esos mismos rectángulos.

## Otros modelos comprobados

La cobertura se mide por área de cara. Las caras de respaldo conservan la
máscara anterior y se contabilizan como cubiertas; **no significa que su
geometría se haya corregido**. Los contornos pendientes están declarados.

| Modelo | Cobertura de área | Rectángulos | Caras con máscara anterior | Estado |
|---|---:|---:|---:|---|
| `create:block/copper_valve_handle` | 99.8651 % | 1082 | 0 | review |
| `create:block/large_water_wheel/block` | 99.9737 % | 3497 | 2125 | review |
| `create:block/large_water_wheel/block_extension` | 99.9414 % | 3482 | 1323 | review |
| `create:block/mechanical_roller/wheel` | 99.6612 % | 2876 | 0 | review |
| `create:block/shaft` | Exacto | — | 0 | verified_static |
| `create:block/water_wheel/wheel` | 99.9266 % | 3418 | 1259 | review |
| `create:block/white_valve_handle` | 99.8651 % | 1082 | 0 | review |
| `modbridge:block/water_wheel/assembled` | 99.9472 % | 3444 | 1259 | review |

## Regresiones

Se comprueban trapezoides, triángulos, polígonos cóncavos, orientación en 3D,
UV, contención de vértices, presupuestos de subdivisión, conservación de
caras grandes, contornos que corresponden al destino real, renovación de
cachés y preservación de triángulos al retirar divisiones interiores del
alambre. La regla de verificación de 2.4.3 sigue cubierta por sus pruebas.

Dos pruebas anteriores que exigían un rectángulo por triángulo o dos por
cuadrilátero no plano se actualizaron al nuevo contrato: subdivisiones
interiores, sin salientes y con origen intacto.

## Límites y reproducción

No se ejecutaron Windows ni Minecraft. Chromium no está instalado; las
pruebas de visor ejecutan el código real con buffers WebGL simulados y las
comparaciones gráficas se calculan desde la geometría exportada.

El entorno usa Python 3.12.14, NumPy 2.3.5 y Pillow 13.0.0. Los
requisitos del lanzador no se modificaron y mantienen Pillow <13.

- `pruebas_python_v244.txt`: resultado completo de Python.
- `pruebas_node_v244.txt`: resultado completo de JavaScript.
- `COMPARACION_CREATE_V244.json`: datos de las ocho conversiones, hashes y
  comprobación independiente de contención.
- `CAMBIOS_CODIGO_V243_V244.patch`: cambios frente al ZIP 2.4.3.

Las pruebas de versiones anteriores y los ejemplos Water Wheel incluidos
se conservan como históricos; no sustituyen esta validación.
