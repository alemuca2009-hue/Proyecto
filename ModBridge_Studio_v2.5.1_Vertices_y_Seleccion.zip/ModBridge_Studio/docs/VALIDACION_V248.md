# Validación de ModBridge Studio 2.4.8

Se analizaron **2.304 PNG de 64 modelos**, con 1.152 pares Java/Bedrock en seis
vistas y tres perfiles. Los hashes de todas las imágenes coinciden con su
manifiesto. El ZIP contiene renders, no modelos fuente.

Se utilizó Create 6.0.10 para Minecraft 1.21.1, descargado de su publicación en
Modrinth. Su SHA-256 coincide con el registrado en la documentación 2.4.7:
`ef87fe5709f1ba1f5b8bb20a2925b5afb4669e178fd6d8bf10c167759eefe37a`.
Las 64 conversiones de referencia 2.4.7 terminaron sin errores.

Los 64 modelos forman **21 familias** con iguales vértices, UV, atributos y
dimensiones de textura. Se reconvirtieron los 21 representantes con la 2.4.8:
**21 terminados, 0 errores**. Las variantes de color comparten familia; no se
afirma haber revisado visualmente cada textura de cada variante.

## Resultado comprobado

- **268 pruebas Python, 51 pruebas Node y 5 pruebas sobre una extracción limpia: aprobadas.**
- La geometría .geo.json se decodificó de nuevo y coincide con el IR exportado.
- Los 126 renders Java originales de los representantes coinciden píxel a píxel
  con los enviados por el usuario.
- Los 21 casos conservan la geometría y los archivos fuente originales.
- La auditoría independiente de contención con Shapely pasa en los 21 casos:
  ningún rectángulo sobresale del área fuente por encima de la tolerancia
  declarada de 0,00001 unidades de modelo. Se excluyen y registran caras de área cero.
- No hubo regresiones de cobertura de área ni de silueta en las vistas probadas.
- **12 representantes reducen sus píxeles de superficie faltantes.**
- Se mantiene el máximo de 12.000 rectángulos por modelo.

## Comparación de superficie

Los píxeles son la suma de las seis vistas sólidas a 192 × 192, con la cámara
del manifiesto original. Cero píxeles faltantes no demuestra equivalencia 3D,
texturas perfectas ni funcionamiento dentro del juego. La cobertura de área
incluye la multiplicidad de superficies y no representa volumen.

| Modelo | Píxeles faltantes 2.4.7 → 2.4.8 | Cobertura de área 2.4.7 → 2.4.8 | Caras 2.4.7 → 2.4.8 |
|---|---:|---:|---:|
| `create:block/black_valve_handle` | 0 → 0 | 99.986093% → 99.986093% | 11080 → 11080 |
| `create:block/blaze_burner/block_with_fire` | 0 → 0 | 99.864034% → 99.966009% | 548 → 2084 |
| `create:block/blaze_burner/flame` | 416 → 416 | 99.896568% → 99.987071% | 776 → 6152 |
| `create:block/chain_conveyor/guard` | 0 → 0 | 99.979078% → 99.996663% | 526 → 2106 |
| `create:block/chain_conveyor/item` | 26 → 0 | 99.791643% → 99.919282% | 8711 → 5954 |
| `create:block/chain_conveyor/wheel` | 198 → 0 | 99.629239% → 99.855384% | 7652 → 5395 |
| `create:block/crushing_wheel/block` | 216 → 0 | 99.502183% → 99.960847% | 12000 → 11999 |
| `create:block/flywheel/block` | 8 → 0 | 99.787289% → 99.843836% | 11550 → 11034 |
| `create:block/flywheel/item` | 8 → 0 | 99.834910% → 99.892334% | 11030 → 10584 |
| `create:block/goggles` | 0 → 0 | 100.000000% → 100.000000% | 51 → 51 |
| `create:block/large_water_wheel/block` | 96 → 12 | 98.997314% → 99.549144% | 11999 → 12000 |
| `create:block/large_water_wheel/block_extension` | 56 → 14 | 99.545520% → 99.750978% | 12000 → 12000 |
| `create:block/mechanical_roller/item` | 0 → 0 | 99.997946% → 99.997946% | 7492 → 8260 |
| `create:block/mechanical_roller/wheel` | 0 → 0 | 99.994247% → 99.994247% | 7210 → 7210 |
| `create:block/track/bogey/bogey_drive` | 0 → 0 | 99.994047% → 99.995178% | 7339 → 10449 |
| `create:block/track/bogey/bogey_drive_wheel` | 150 → 0 | 98.582439% → 99.944567% | 11999 → 11805 |
| `create:block/track/bogey/bogey_frame` | 0 → 0 | 99.999993% → 99.999994% | 637 → 2173 |
| `create:block/track/bogey/bogey_wheel` | 66 → 0 | 99.625456% → 99.940091% | 10586 → 11986 |
| `create:block/water_wheel/item` | 90 → 40 | 99.453663% → 99.614017% | 12000 → 9271 |
| `create:block/water_wheel/wheel` | 128 → 64 | 99.269114% → 99.482907% | 11999 → 9240 |
| `modbridge:block/water_wheel/assembled` | 90 → 40 | 99.473603% → 99.626840% | 11999 → 9231 |

## Casos pendientes y texturas

La llama conserva sus grietas en estas vistas sólidas: la pérdida de área es
menor, pero la unión de rectángulos interiores no reproduce exactamente sus
aristas oblicuas. También quedan diferencias en las ruedas de agua. El motor
las declara como aproximaciones y mantiene los originales y el diagnóstico.

Modelos con píxeles faltantes restantes:

- `create:block/blaze_burner/flame`: 416 píxeles faltantes; 0 añadidos.
- `create:block/large_water_wheel/block`: 12 píxeles faltantes; 0 añadidos.
- `create:block/large_water_wheel/block_extension`: 14 píxeles faltantes; 0 añadidos.
- `create:block/water_wheel/item`: 40 píxeles faltantes; 0 añadidos.
- `create:block/water_wheel/wheel`: 64 píxeles faltantes; 0 añadidos.
- `modbridge:block/water_wheel/assembled`: 40 píxeles faltantes; 0 añadidos.

Se comparó además una vista con texturas por representante. El error RGBA medio
está registrado en el JSON; **1 casos aumentan ese error** en la vista
medida. Uniones con UV discontinuas pueden cambiar la fase de muestreo; no se
certifican como transferencia nativa. Los resultados se conservan visibles:

| Modelo | Error RGBA medio anterior | Error RGBA medio nuevo |
|---|---:|---:|
| `create:block/blaze_burner/block_with_fire` | 0.322910 | 0.325419 |

El error se mide sobre canales de 0 a 255; no es una métrica perceptual ni una
prueba completa de UV. Se preserva la transferencia nativa en los modelos que
ya eran completamente nativos. La interfaz sigue clasificando las superficies
como Revisar.

## Entorno y alcance

Pruebas ejecutadas en Linux con Python, NumPy y Pillow. Shapely se utilizó solo
para la auditoría independiente y no se agregó a las dependencias del programa.
No se ejecutó Windows ni Minecraft Bedrock en esta sesión. No se validó lógica
de mods, animaciones, entidades jugables ni integración completa de un addon.

La corrección puede aumentar el tiempo de conversión al comparar varios planes.
No se aumentó el límite de rectángulos. Las conversiones anteriores se mantienen
intactas: para obtener estos resultados hay que reconvertir el JAR con 2.4.8.

## Evidencia incluida

- `VALIDACION_V248.json`: métricas, selección de planes, entorno y hashes.
- `COMPARACION_V248.png`: comparaciones reales Java / 2.4.7 / 2.4.8.
- `FAMILIAS_MODELOS_V248.json`: correspondencia entre los 64 modelos y los 21 casos.
- `pruebas_python_v248.txt`, `pruebas_node_v248.txt`, `pruebas_extraido_v248.txt`.
- `CAMBIOS_CODIGO_V247_V248.patch` y nuevas pruebas de regresión.
