# Validación de ModBridge Studio 2.4.6

Validación realizada sobre el proyecto completo basado en el ZIP entregado de 2.4.5. Se incluyeron pruebas de código, HTTP, procesos reales de conversión/renderizado, descarga ZIP y navegador. Los registros detallados acompañan este documento.

## Resultados

| Comprobación | Resultado |
|---|---|
| Suite Python completa | 236 pruebas aprobadas; 0 fallos, 40,138 s |
| Suite JavaScript | 40 pruebas aprobadas; 0 fallos |
| Biblioteca en navegador real | Conversión, cuatro grupos, filtros, selección, paginación de 245 modelos y ocho anchuras aprobados |
| Visor WebGL en navegador real | 20 comprobaciones aprobadas; texturas/UV, profundidad, transparencia, Rayos X, Normales, cámaras; error WebGL = 0 |
| Configurador en navegador real | Selección, perfiles, seis vistas, modos, tres combinaciones, resumen, deduplicación, progreso, cancelación y descarga aprobados |
| ZIP descargado desde el configurador | 109 PNG, 2 modelos, 2 maestras, perfiles asignados por modelo; 43 buffers de píxeles distintos; CRC y rutas válidos |
| Exportación de un modelo real de Create | 108 PNG: original/traducido × 6 vistas × 3 modos × 3 combinaciones; 0 fallos y CRC válido |
| Muestras de tres modelos reales | 36 PNG sobre pasador, volante y rueda grande; hasta 12.000 caras traducidas |
| Diseño del configurador | Revisado visualmente y sin desbordamiento horizontal a 1440, 768 y 390 px |

El entorno fue Linux con Python, NumPy y Pillow; versiones exactas en `VALIDACION_V246.json`. Las pruebas visuales utilizaron Chrome Headless Shell 151.0.7922.34. Las capturas internas de revisión no forman parte del paquete.

## Evidencia funcional

- **Revisar:** se comprueban las dos condiciones que activan el aviso de superficies reconstruidas, incluso en reportes compactos antiguos. No se modifican bytes, fechas, geometría ni métricas de las fuentes. La caché evita volver a leer el mismo reporte.
- **Filtros:** las etiquetas del servidor se contrastan con las tarjetas reales. Se prueba «o» dentro de Geometría y la intersección con Texturas después de una conversión real.
- **Modelos y perfiles:** se prueban todos/ninguno, selección individual, añadir/duplicar/eliminar perfiles y asignaciones diferentes por modelo. Abrir el configurador no genera imágenes automáticamente.
- **Combinaciones:** Rayos X y Normales juntos producen una sola variante. El botón de tres combinaciones produce exactamente tres por vista y modo. Las configuraciones idénticas se contabilizan una vez y no crean carpetas vacías.
- **Imágenes:** PNG reales con tamaño correcto, vistas y parámetros aplicados; Texturas sin parámetros conserva los píxeles del renderizador anterior. Se cargan todos los polígonos del IR, no la muestra limitada del visor.
- **Conservación:** se comparan hashes del JAR, modelos preparados, reportes y ZIP de conversión antes/después de exportar renders. La preparación de modelos pendientes no modifica la lista de resultados de la conversión principal.
- **Errores:** un modelo no compatible no interrumpe el siguiente; la textura ausente falla en su modo sin sustituirla por un recurso inventado. Se verifican cancelación, permisos HTTP, configuraciones inválidas y errores de escritura ZIP.
- **Rutas:** nombres ASCII, sin espacios ni componentes de recorrido, unicidad sin distinguir mayúsculas y jerarquía de cinco componentes para cada PNG. El manifiesto registra SHA256 y referencias de duplicados.
- **Regresión:** siguen operativas la conversión general, la previsualización, la exportación parcial de modelos terminados, el ZIP tradicional y la inspección 3D.

## Repetir las pruebas

Desde `ModBridge_Studio`, con NumPy y Pillow instalados:

```bash
python -m unittest discover -s tests -v
node --test tests/test_library.cjs tests/test_verification_cards.cjs tests/test_viewer_contours.cjs tests/test_render_config.cjs tests/test_analysis_filters.cjs
```

Con Playwright y Chromium instalados como herramientas de desarrollo:

```bash
node tests/test_library_browser.cjs
node tests/test_viewer_browser.cjs
node tests/test_render_config_browser.cjs
```

Los recorridos de navegador abren su propio servidor y espacio temporal. Admiten `CHROMIUM_EXECUTABLE` y `PYTHON` para indicar ejecutables. Las herramientas de pruebas de navegador no son dependencias de uso del programa.

## Límites de la comprobación

No se ejecutó Windows nativo ni Minecraft Bedrock en este entorno. Los lanzadores y dependencias de uso se conservan. La calidad geométrica sigue dependiendo de los recursos fuente y de las limitaciones ya documentadas en 2.4.5; reclasificar una superficie como Revisar no modifica su geometría.

Los perfiles se conservan mientras se trabaja en la misma sesión y proyecto. El programa no incorpora una biblioteca persistente de perfiles entre reinicios. Los renders son ortográficos sobre recursos estáticos, no una simulación de lógica, animación o materiales especiales del juego.
