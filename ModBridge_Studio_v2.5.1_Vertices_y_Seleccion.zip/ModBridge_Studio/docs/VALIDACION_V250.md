# Validación de ModBridge Studio 2.5.0

## Entorno y alcance

Validación local con Python 3.12.14, NumPy 2.3.5, Pillow 12 y Node 24.22.1. Pillow 12 está dentro del rango declarado por el proyecto. Las dependencias de uso siguen siendo NumPy y Pillow; Node y Playwright solo se utilizan en desarrollo.

## Pruebas automatizadas

- **253 pruebas Python:** motor independiente, referencia original 2.4.4 con los repasos desactivados, adaptación superficial, recuperación de rectángulos, continuidad UV, huecos, capas repetidas, triangulación, atlas, API, exportación, biblioteca, perfiles, verificación y controles del trabajador.
- **57 pruebas JavaScript sin navegador:** filtros, tarjetas de verificación, contornos del visor, perfiles, control maestro y ejecución de los manejadores reales de pausa, continuación y reinicio con adaptadores de DOM y red.
- **66 modelos reales auditados:** los 65 casos de superficies se reconvirtieron desde el IR y las texturas fuente; el caso nativo se separó para diagnóstico. Cero errores de ejecución, 65 mejoras aceptadas y una nueva coincidencia geométrica confirmada por el comparador independiente. Véase `ANALISIS_RESULTADOS_V250.md` y `AUDITORIA_MODELOS_V250.json`.

Los registros de las suites se incluyen en `VALIDACION_V250_PYTHON.txt` y `VALIDACION_V250_JAVASCRIPT.txt`.

## Comportamientos comprobados

- Pausar un proceso real congela el progreso en un punto seguro; continuar retoma el mismo trabajador y termina un ZIP íntegro.
- Cancelar durante la pausa libera el trabajador y permite iniciar otro lote.
- El reinicio recompone únicamente la selección explícita. Los modelos no seleccionados conservan los bytes de geometría y atlas, y el JAR fuente no cambia.
- La selección vacía, inexistente o duplicada se rechaza antes de crear un lote. Los nuevos endpoints conservan la protección por token.
- Un ZIP previo se distingue del resultado del lote actual, incluso después de una inspección individual o un intento de exportación parcial. Su presencia no oculta el botón para exportar los modelos terminados del nuevo lote.
- Los repasos respetan huecos, capas duplicadas y discontinuidades UV. Un fallo de un intento conserva la salida anterior; la cancelación se propaga.
- Un rectángulo sintético triangulado en abanico pasa de 508 franjas base a un rectángulo coincidente. Los casos oblicuos que no son exactos siguen indicados como aproximados.
- La referencia externa original 2.4.4 conserva sus hashes de geometría, IR, UV, atlas y originales al usar `refinement_passes=0`.

## Comprobaciones no completadas

La ejecución de navegador real no pudo iniciarse en este entorno: el navegador descargado de Playwright no está disponible y el Chromium del sistema rechaza la creación del socket de su proceso. Los cinco scripts históricos de navegador tampoco arrancan por esa dependencia ausente. No se presentan como pruebas aprobadas ni se afirma una revisión visual de la interfaz o de su disposición móvil.

Los controles se verificaron mediante los manejadores JavaScript reales y pruebas de servidor y procesos. El script opcional `tests/browser_job_controls_v250.py` queda incluido para ejecutarlo en un entorno con Playwright y Chromium funcionales.

No se ha probado el arranque nativo en Windows ni la integración dentro de Minecraft. La coincidencia geométrica es una comprobación estática y no certifica el comportamiento en el juego. Los 64 casos de superficie que todavía difieren y las caras degeneradas de `goggles` siguen declarados como tales.

## Repetir las suites

Desde `ModBridge_Studio/`:

```bash
python -m unittest discover -s tests -v
node --test tests/test_library.cjs tests/test_verification_cards.cjs tests/test_viewer_contours.cjs tests/test_render_config.cjs tests/test_analysis_filters.cjs tests/test_job_controls.cjs
```

La auditoría de archivos reales se repite con `tests/audit_v250_results.py`, aportando los ZIP originales. Esos archivos de entrada no se redistribuyen dentro del programa.
