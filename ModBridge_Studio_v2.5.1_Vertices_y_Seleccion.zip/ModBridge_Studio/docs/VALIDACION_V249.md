# Validación de ModBridge Studio 2.4.9

## Objetivo

Recuperar el comportamiento geométrico de 2.4.4 y separar su motor, conservando las funciones actuales de la aplicación. Esta validación comprueba equivalencia con esa versión; no declara reparadas sus pérdidas de superficie.

## Evidencia y alcance

| Comprobación | Resultado |
|---|---|
| Suite del programa 2.4.4 original, sin cambios | 151 pruebas correctas. |
| Suite completa de la aplicación modular | 239 pruebas correctas. |
| Lógica JavaScript de biblioteca, filtros, visor, perfiles y control maestro | 51 pruebas correctas. |
| Comparación con el motor original sobre Create | 21 modelos × 2 modos = 42 conversiones equivalentes. |
| Archivos comparados entre ambos motores | 684 comprobaciones de archivos. |
| Fixture sintética de cuatro triángulos | Salida superficial y diagnóstico iguales a la referencia independiente 2.4.4. |
| Uso sin aplicación | Copia aislada de `conversion_engine/`; importar, listar y convertir desde terminal funciona. |
| Configuración editable | Cambios reales del presupuesto alcanzan la API y la terminal; errores de configuración no se ignoran. |
| Reutilización de renders | Se invalida si falta la firma o cambia la configuración/modo; se reutiliza si coincide. |
| Conservación del JAR | SHA-256 idéntico antes y después. |

Se compararon geometría Bedrock, datos intermedios de origen/destino, vértices, UV, bordes, atlas, mapa del atlas, reporte superficial, respaldos y recursos fuente. Las rutas absolutas de las carpetas de salida y el formato/orden de claves JSON se normalizan. Los PNG y archivos originales se comparan byte a byte. No se redondean coordenadas ni UV.

La finalización de `visible_bounds_*`, que 2.4.4 realizaba en su pipeline, también se ejecuta en la referencia y ahora pertenece al módulo independiente. Las seis vistas y otras métricas de la aplicación no forman parte de la equivalencia de archivos del motor: permanecen como comprobaciones posteriores.

La fixture sintética conserva cuatro caras fuente y produce 508 franjas con el motor superficial 2.4.4; en modo `exact` conserva cuatro caras de diagnóstico. Este caso detecta si se reintroduce accidentalmente la unión de caras de versiones posteriores.

## Recursos usados

- Programa de referencia: ZIP 2.4.4 proporcionado, SHA-256 `384bb0293193025f58d7ed86fd8e75be25f1e0add89647b241633ed576c87836`.
- JAR real: `create-1.21.1-6.0.10.jar`, SHA-256 `ef87fe5709f1ba1f5b8bb20a2925b5afb4669e178fd6d8bf10c167759eefe37a`.
- Selección: 21 modelos representativos de las 21 familias identificadas en los 64 modelos del conjunto de renders previo. No se presenta como conversión de todo el JAR ni como prueba de los 64 individualmente.
- `MODELOS_PARIDAD_V249.json` contiene los identificadores. El JAR de Create no se redistribuye.

## Modelos comparados en modo Superficies

| Modelo | Caras fuente | Planos destino 2.4.4 / módulo |
|---|---:|---:|
| `create:block/black_valve_handle` | 60 | 1082 / 1082 |
| `create:block/blaze_burner/block_with_fire` | 42 | 548 / 548 |
| `create:block/blaze_burner/flame` | 24 | 776 / 776 |
| `create:block/chain_conveyor/guard` | 16 | 526 / 526 |
| `create:block/chain_conveyor/item` | 141 | 3495 / 3495 |
| `create:block/chain_conveyor/wheel` | 84 | 3497 / 3497 |
| `create:block/crushing_wheel/block` | 268 | 3465 / 3465 |
| `create:block/flywheel/block` | 164 | 3453 / 3453 |
| `create:block/flywheel/item` | 186 | 3474 / 3474 |
| `create:block/goggles` | 51 | 51 / 51 |
| `create:block/large_water_wheel/block` | 2136 | 3497 / 3497 |
| `create:block/large_water_wheel/block_extension` | 1340 | 3482 / 3482 |
| `create:block/mechanical_roller/item` | 68 | 3158 / 3158 |
| `create:block/mechanical_roller/wheel` | 40 | 2876 / 2876 |
| `create:block/track/bogey/bogey_drive` | 181 | 805 / 805 |
| `create:block/track/bogey/bogey_drive_wheel` | 352 | 3482 / 3482 |
| `create:block/track/bogey/bogey_frame` | 258 | 3408 / 3408 |
| `create:block/track/bogey/bogey_wheel` | 276 | 3426 / 3426 |
| `create:block/water_wheel/item` | 1308 | 3450 / 3450 |
| `create:block/water_wheel/wheel` | 1276 | 3418 / 3418 |
| `modbridge:block/water_wheel/assembled` | 1302 | 3444 / 3444 |

El modo `exact` también coincide para los mismos 21 modelos. Los conteos son una referencia de teselación, no una puntuación de calidad ni una afirmación de que el modelo quedó corregido.

## Cómo repetir

Desde la carpeta `ModBridge_Studio`, con las dependencias instaladas:

```bash
python -m unittest discover -s tests -v
node --test tests/test_library.cjs tests/test_verification_cards.cjs tests/test_viewer_contours.cjs tests/test_render_config.cjs tests/test_analysis_filters.cjs
python tests/compare_engine_v244.py --legacy-root ../original244/ModBridge_Studio --input create-1.21.1-6.0.10.jar --manifest docs/MODELOS_PARIDAD_V249.json --output ../comparacion_nueva
```

La última orden necesita una extracción sin modificar del ZIP 2.4.4 y el JAR fuente. Ejecuta cada versión en procesos distintos y termina con error si encuentra diferencias. La salida debe ser una carpeta nueva.

`PARIDAD_MOTOR_244_V249.json` incluye huellas por archivo y modelo. `pruebas_python_v249.txt`, `pruebas_node_v249.txt` y `pruebas_base_244_v249.txt` conservan los registros. `EXTRACCION_MOTOR_244.patch` muestra los pequeños cambios necesarios para parámetros e integración; `INTEGRACION_MOTOR_V249.patch` muestra las llamadas desde la aplicación.

## Entorno y límites de la validación

Python 3.12.14, NumPy 2.3.5, Pillow 12.0.0 y Node 24.22.1, en Linux. Las pruebas iniciales también pasaron con Pillow 13.0.0; la comprobación final usa Pillow 12.0.0, dentro de los requisitos distribuidos.

La comparación de archivos demuestra equivalencia en los casos revisados, no en todos los modelos posibles. Los defectos de 2.4.4 siguen presentes por decisión de alcance. No se probó dentro de Minecraft ni se certifica el arranque nativo en Windows desde este entorno. Las pruebas JavaScript verifican la lógica de la interfaz; no se presentan como una nueva campaña de navegador.
