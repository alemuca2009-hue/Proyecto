# Validación de ModBridge Studio 2.4.7

## Material analizado

Base completa: `ModBridge_Studio_v2.4.6_Perfiles_de_Render.zip`. Se conservan sus 183 archivos, incluidos ejemplos, recursos y documentación histórica; los cambios de código están en `CAMBIOS_CODIGO_V246_V247.patch`.

El adjunto `ModBridge_renders.zip` contiene 1.566 PNG de 87 modelos, a 192 × 192 píxeles. Se verificaron CRC, hashes y dimensiones. Los ocho casos visuales de diagnóstico se reprodujeron píxel a píxel con la versión anterior antes de compararlos con los originales. El JAR de referencia es `create-1.21.1-6.0.10.jar`, SHA-256 `ef87fe5709f1ba1f5b8bb20a2925b5afb4669e178fd6d8bf10c167759eefe37a`. No se redistribuye ese JAR.

## Geometría de los 87 modelos

| Comprobación | 2.4.6 | 2.4.7 |
|---|---:|---:|
| Modelos procesados sin error | 87 | 87 |
| Coincidencia independiente de superficie | 22 | 23 |
| Coincidencia independiente de UV/material | 9 | 10 |
| Caras de destino, suma de los 87 modelos | 249.060 | 634.750 |

- 50 modelos mejoran la cobertura de superficie; ninguno la empeora.
- Ninguna comprobación de geometría o UV aprobada antes pasa a fallar.
- Los 87 resultados permanecen en Revisar. Hay 64 aproximaciones de superficie, 22 reconstrucciones y una geometría nativa; el tipo de destino y la comprobación independiente son conceptos distintos.
- Los archivos originales y los vértices del IR fuente son idénticos antes y después.
- La auditoría independiente de contención no encuentra superficies fuera del original en ninguno de los 87 modelos, con tolerancia espacial de `1e-5` unidades. Esta comprobación no sustituye la verificación orientada de superficie ni certifica ejecución en Bedrock.
- `create:block/track/bogey/bogey_drive_piston` pasa por primera vez las comprobaciones completas de superficie y UV.

El conteo de área suma las caras con su multiplicidad; no es volumen ni un porcentaje de fidelidad visual. Las cuatro caras de área cero del modelo `goggles` se conservan y se excluyen únicamente del oráculo de área positiva. La comprobación independiente de equivalencia sigue siendo conservadora. Para rectángulos extremadamente finos se calcula la normal en coordenadas locales, evitando falsos inválidos por cancelación numérica sin relajar la tolerancia espacial.

La tabla por modelo está en `COMPARACION_GEOMETRIA_V247.json`.

## Comparación visual real

Se renderizaron ocho modelos representativos en las seis direcciones, usando el IR original y los destinos decodificados de ambas versiones, con encuadre común. Son 144 PNG sólidos y 24 PNG de Texturas: 168 imágenes reales del motor del programa, sin capturas de interfaz.

| Modelo | Píxeles de superficie omitidos, suma de seis vistas, antes → después |
|---|---:|
| Válvula negra | 124 → 0 |
| Rueda de transportador de cadenas | 198 → 198 |
| Rueda trituradora | 216 → 216 |
| Volante | 68 → 8 |
| Rueda de agua grande | 96 → 96 |
| Rueda motriz del bogey | 150 → 150 |
| Rueda de agua pequeña | 128 → 128 |
| Rodillo mecánico | 358 → 0 |

Las 48 comparaciones sólidas no empeoran la cobertura. Las cifras dependen de la vista y de la resolución de 192 px: cero píxeles perdidos no demuestra equivalencia de superficie 3D ni equivalencia UV. Se incluyen las láminas `COMPARACION_RENDERS_V247.png`, `COMPARACION_TEXTURAS_V247.png` y sus métricas en `COMPARACION_RENDERS_V247.json`.

El muestreo de las regiones unidas se revisó además sobre los píxeles cubiertos tanto por la versión anterior como por la nueva, para no ocultar deterioros locales mediante la mejora de cobertura. En el rodillo, sobre 21.553 píxeles comunes, el error RGBA medio baja de 0,8969 a 0,15937 y los píxeles diferentes de 1.148 a 248. La mejora no equivale a identidad de textura. En las ocho vistas de Texturas, el error sobre superficie común no aumenta; las métricas están en `COMPARACION_TEXTURAS_V247.json`. El refuerzo de muestreo solo afecta los atlas y UV de regiones derivadas. Después del ajuste se reconvirtieron los ocho casos y el pistón: vértices, fuentes y comprobaciones permanecen iguales al candidato auditado (`INVARIANTES_MUESTREO_V247.json`). Se regeneraron los 24 PNG de textura; los 144 sólidos se reutilizaron tras comprobar la identidad de vértices y normales.

## Casos que prueban la corrección

Un cuadrado dividido en cuatro triángulos alrededor de su centro pasaba a 252 rectángulos y perdía el 1,5625 % del área. Ahora produce una sola cara; coinciden superficie y UV. También pasa con rotación arbitraria. Las pruebas comprueban huecos, capas repetidas, orientación, discontinuidades UV y rechazo de exactitud falsa en trapecios.

El caso del cuadrado se prueba además a través del flujo completo: creación y carga de un JAR con OBJ y textura, conversión, ZIP de resultados y seis vistas. El trabajador de renders prepara un modelo aún no convertido y exporta original y destino como PNG idénticos, sin alterar el resultado principal. No se sustituye el motor por respuestas simuladas.

## Pruebas automáticas

- **263 pruebas de Python aprobadas**, sin errores ni casos omitidos, después del ajuste de muestreo y la incorporación de Comparación.
- **51 pruebas de Node aprobadas** para biblioteca, tarjetas, contornos, perfiles y filtros.
- Pruebas reales de navegador del control maestro, biblioteca y visor aprobadas.
- Dos pruebas adicionales de muestreo comprueban una textura no uniforme, la identidad de vértices al aumentar densidad y la prioridad de reducir el refuerzo antes de degradar las caras ordinarias cuando el atlas está lleno.

Desde una extracción limpia del ZIP se repitieron **12 pruebas de integración aprobadas**: servidor HTTP, trabajador real, descarga, contenido del ZIP, parejas Java/Bedrock y conversión completa del caso geométrico. El código del paquete final se contrasta con las huellas de ese ejemplar probado.

Los resultados legibles y JSON se incluyen en los archivos `pruebas_*_v247.*`.

## Control maestro y conservación de funciones

La prueba de navegador modifica todos los modelos, incluidos los desmarcados, sin cambiar su selección para exportar. Comprueba el alcance limitado a marcados, aislamiento de perfiles compartidos, Deshacer, edición individual posterior y diseño a 1440 y 390 px.

Desde ese control se descargó un ZIP real con 72 PNG, una carpeta maestra y rutas separadas por modelo y perfil. Se omitieron 72 configuraciones repetidas y se comprobaron nombres, manifiesto y contenido. Se conservan las tres combinaciones de parámetros y el cálculo previo de imágenes.

Las pruebas de biblioteca cubren filtros, búsqueda, selección, conversión real, paginación y ocho anchuras de interfaz. Las pruebas del visor incluyen modos, Rayos X, Normales, winding, profundidad, alfa, orientación UV, texturas NPOT y ausencia de errores WebGL.

## Comparación Java / Bedrock añadida

El nuevo adjunto mezcla 522 renders Java y 1.044 Bedrock; estos últimos coinciden byte a byte con el primer ZIP. Se reprodujeron exactamente 48 imágenes Java de ocho modelos para verificar su procedencia. El análisis está en `ANALISIS_JAVA_RECIBIDO_V247.md`. No contiene imágenes del modo Texturas.

La opción Comparación se probó desde el navegador mediante el control maestro y un trabajador real: 2 modelos × 2 perspectivas × 3 modos × 3 variantes de parámetros produjeron **72 PNG: 36 Java y 36 Bedrock**. Dos perfiles iguales solicitaron 72 pares lógicos; se guardaron 36 pares distintos y se omitieron 72 imágenes repetidas. Todas las referencias del manifiesto resuelven los archivos correctos. El JAR original permaneció idéntico. Se comprobó la interfaz a 1440 y 390 px.

Las pruebas del exportador comprueban además modelos de tamaños distintos con una misma cámara, deduplicación en ambos órdenes de selección, límite ampliado a los dos lados, pares parciales y fallos totales sin fabricar imágenes. Dos pruebas HTTP adicionales descargan las parejas desde el servidor y comprueban que un modelo fallido no interrumpe al siguiente. La regresión del Control maestro volvió a exportar correctamente sus 72 PNG anteriores.

## Coste y límites

El mayor detalle aumenta caras, atlas y tiempo de conversión. Continúa el límite de 12.000 rectángulos por modelo y se procesa un modelo a la vez durante la exportación. No se añadieron dependencias de uso: NumPy y Pillow. Shapely, Playwright y Node solo se utilizan para auditoría y pruebas opcionales.

En una medición aislada final, el rodillo de 7.210 caras produjo un atlas de 4096 × 2048, con un pico de memoria del proceso de aproximadamente 106,6 MiB y 3,77 s de adaptación. Es una medición de ese modelo y entorno, no una garantía de tiempo o memoria para todos los recursos.

La validación se ejecutó con Python 3.12 y Chrome Headless Shell 151 en Linux. Se comprobó el servidor, sus trabajadores y la descarga real. No se ejecutaron Windows ni Minecraft Bedrock nativos. Se entrega código Python con lanzadores, no un ejecutable autónomo.

Esta versión no garantiza traducción universal 1:1. Los contornos que siguen aproximados conservan sus métricas y advertencias. Microsoft documenta `poly_mesh` como obsoleto/restringido; no se usa como atajo para declarar compatibilidad universal. Referencias oficiales en `AUDITORIA_INDEPENDIENTE_V247.md`.
