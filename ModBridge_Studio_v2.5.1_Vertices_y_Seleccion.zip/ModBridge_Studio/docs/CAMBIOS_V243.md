# ModBridge Studio 2.4.3

Actualización sobre `ModBridge_Studio_v2.4.2_Biblioteca_Modelos3D.zip`.

## Comportamiento solicitado

Todo modelo en **Revisar** pasa automáticamente a **Verificados** si sus
tarjetas muestran simultáneamente:

- **Geometría: Coincidente**.
- **Texturas: Píxeles conservados**.

La regla también se aplica a **Modelo 3D extendido**, sin restricciones por
tamaño, tipo de geometría, advertencias o diferencias rasterizadas. Se
conservan las métricas y advertencias originales. No se afirma que las seis
vistas sean idénticas ni que el recurso se haya probado dentro del juego.

## Alcance de la actualización

- `bridge/verification.py`: regla común con los mismos campos, orden de
  precedencia y booleanos estrictos que las tarjetas de `web/app.js`.
- `bridge/pipeline.py`: estado definitivo antes de guardar el reporte y
  publicar el modelo; reclasificación al reexportar reportes anteriores.
  El resumen JSON cuenta los estados efectivamente exportados.
- `bridge/catalog.py`: el catálogo compacto conserva el estado definitivo,
  incluido el caso de reportes completos anteriores.
- `app.py`: el detalle de un reporte anterior aplica la misma regla.
- `web/index.html`, versión y guías: identificación 2.4.3 y explicación del
  nuevo criterio de aceptación.
- Pruebas: modelos normales y extendidos, procesamiento individual y por
  lotes, CLI, worker, API, exportación completa y parcial, alias de métricas,
  evidencia incompleta, texturas ausentes y estados no elegibles.

Los modelos con diferencias, con métricas sin comprobar o con texturas
faltantes no se promueven. Los estados No convertido, Error y Plantilla no se
alteran. Las aproximaciones OBJ incluidas siguen en revisión porque no
conservan la geometría y los píxeles de manera exacta.

No se modifica el conversor geométrico, el atlas, las UV, la escala, los
formatos de geometría ni las dependencias. El indicador `extended3d` permanece
independiente del estado. Las muestras de Water Wheel y la documentación de
2.4.2 se conservan como resultados históricos identificados con esa versión.

## Uso

Cierra la versión anterior, extrae el ZIP completo en una carpeta nueva y
abre el lanzador habitual. Carga tu JAR y procesa los modelos. El estado se
asigna al finalizar cada modelo, sin aprobación manual. Para resultados de
una sesión anterior, vuelve a procesar el JAR; los ZIP ya descargados no se
modifican automáticamente.

Consulta `VALIDACION_V243.md` y `VALIDACION_V243.json` para los resultados de
las comprobaciones ejecutadas en esta entrega.
