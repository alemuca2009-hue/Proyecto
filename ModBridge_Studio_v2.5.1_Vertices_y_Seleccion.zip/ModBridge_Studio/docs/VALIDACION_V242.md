# Validación de ModBridge Studio 2.4.2

La base utilizada es **2.4.1**, corregida y autorizada por el usuario. Se analizó antes de modificar archivos y se ejecutaron sus 127 pruebas originales. La copia de referencia permanece intacta. Las nuevas comprobaciones se añaden a la suite existente; no se elimina ninguna prueba anterior.

## Resultados ejecutados

| Comprobación | Resultado |
|---|---|
| Suite Python original 2.4.1 | 127/127 correctas antes de implementar. |
| Suite Python 2.4.2 | 135/135 correctas; 8 regresiones nuevas. |
| Biblioteca: lógica JavaScript | 12/12 correctas, con el ejecutor nativo de Node. |
| Biblioteca en navegador | Correcta: controles, conversión real HTTP/worker, API compacta, selección, filtros, contador y paginación. |
| Visor en navegador | Correcto: los 20 grupos de comprobaciones existentes; cero errores WebGL. |
| Sintaxis | Los 6 archivos JS/CJS, los 40 archivos Python y el lanzador sh correctos. |
| Diseño adaptable | 8 anchuras, de 360 a 1440 px, sin solapamientos ni desbordamiento horizontal de los controles. |
| Create: conversión real | 6 recursos: 2 verificados estáticos, 4 en revisión, sin errores de conversión. |
| Conservación del resultado 3D | 18 archivos de geometría, atlas y mapas idénticos byte a byte a 2.4.1. |
| Copia extraída del ZIP | Todas las pruebas anteriores de código e interfaz correctas desde otra carpeta. |
| Demostración incluida | 6 recursos convertidos por CLI sin el JAR Create, el addon ni archivos de desarrollo. |
| Integridad del empaquetado | CRC y contenido extraído correctos; sin rutas inseguras, duplicados, cachés o entornos virtuales. |

Entorno: Linux, Python 3.12.14, NumPy 2.3.5, Pillow 13.0.0, Node v24.22.1 y Google Chrome for Testing 157.0.8103.38 en modo headless con SwiftShader. Node, Playwright y Chromium son herramientas de pruebas; no se han añadido dependencias de ejecución a la aplicación.

## Cobertura de las regresiones

`test_library_catalog.py` comprueba modelos normales, tamaños extendidos y origen desplazado; evita clasificar una cara plana como extendida solo por no tener volumen. Prueba el booleano y los cuatro campos exactos del catálogo compacto, ausencia de métricas pesadas, recuperación de informes antiguos sin modificar la entrada y prioridad de marcas explícitas.

Se sigue el indicador por informe completo, `ready.json`, `ready.ndjson`, finalización del worker, `result.json`, `Studio.status()` normal/compacto, consulta individual y exportación parcial. Se comprueban también la vista individual, reexportación de un informe anterior y los argumentos reales de la CLI, incluidos ambos valores de `--mesh-mode`.

`test_library.cjs` verifica las cuatro categorías excluyentes, resultados pendientes/desconocidos, intersecciones con búsqueda y tamaño, orden A-Z antes de convertir, desempates sin renombrar, conservación del catálogo original y un conjunto de 245 modelos. Comprueba selecciones ocultas, lista vacía, combinación de informes y cambios de metadatos aunque no cambie su cantidad.

`test_library_browser.cjs` ejecuta conversiones reales del JAR de demostración por la interfaz y el worker. Comprueba los filtros bloqueados antes de disponer de resultados, todos los colores, contador, casilla extendida, A-Z, cambios de recurso y la lista exacta de identificadores enviada a convertir. Los casos de 245 modelos utilizan respuestas deterministas de prueba para comprobar paginación y actualizaciones. Ambas partes se distinguen en el registro.

La suite original `test_viewer_browser.cjs` permanece sin cambios. Conserva las verificaciones de modos de sombreado, texturas, UV, alpha, profundidad, selección por teclado, cámaras sincronizadas, restablecimiento, persistencia, Rayos X, opacidad, Normales, caras invertidas y alambre sin diagonales internas. Se revisaron visualmente las capturas de biblioteca a 1440 y 390 px; esas capturas temporales no forman parte de la entrega.

## Conversiones reales de Create

Entrada: `create-1.21.1-6.0.10(1).jar`, referencia `create_addon(1).mcaddon`. Los hashes están en `VALIDACION_V242.json`. Se utilizaron superficies OBJ y vistas de 128 px. Duración observada del lote: 11.14 s.

| Modelo | Estado | extended3d |
|---|---|---|
| `modbridge:block/water_wheel/assembled` | `review` | `true` |
| `create:block/large_water_wheel/block` | `review` | `true` |
| `create:block/large_water_wheel/block_extension` | `review` | `true` |
| `create:block/water_wheel/block` | `verified_static` | `false` |
| `create:block/water_wheel/wheel` | `review` | `true` |
| `create:block/shaft` | `verified_static` | `false` |

La base pequeña conserva 16 × 16 × 16 unidades y el eje 4 × 16 × 4. El rotor pequeño mide 32 × 16 × 32 en la fuente; las ruedas grandes, aproximadamente 78 × 19 × 78 y 78 × 17,5 × 78. La escala global sigue siendo 1. Las medidas detalladas de fuente y destino se conservan en los reportes.

La conversión OBJ sigue siendo aproximada. Sus planos con máscara alpha pueden aumentar la envolvente geométrica del destino por sus márgenes transparentes; no se interpreta ese cambio como una nueva escala global ni como equivalencia exacta. `extended3d` es un indicador de tamaño/posición, independiente del estado de conversión. Las cuatro ruedas con OBJ conservan `review`.

Se compararon los cinco recursos Water Wheel incluidos en 2.4.1 y una conversión adicional de `shaft` ejecutada con esa misma base. Los archivos `model.geo.json`, `atlas.png` y `atlas_map.json` de cada recurso coinciden byte a byte: **18/18**. La evidencia y sus hashes están en `COMPARACION_GEOMETRIA_V242.json`. El ejemplo `examples/WaterWheel_Modelos3D` contiene la salida 2.4.2 con los seis recursos y sus originales necesarios.

## Extracción e independencia

Se creó un ZIP de verificación, se comprobó su CRC y se extrajo en una carpeta independiente. Cada archivo extraído se comparó con su entrada en el ZIP. Desde esa carpeta se ejecutaron las 135 pruebas Python, las 12 JavaScript, ambas suites de navegador, comprobaciones de sintaxis y una conversión CLI del JAR incluido. `PYTHONPATH` estuvo vacío y se comprobó que los módulos de la aplicación se importaran exclusivamente desde esa extracción.

Los registros incluidos proceden de esa ejecución. El conjunto exacto de código, recursos y pruebas está identificado por SHA-256 en `VALIDACION_V242.json`. Después de consolidar estos documentos se vuelve a generar y extraer el ZIP definitivo y se repite la misma batería antes de entregar. Las dependencias instaladas de Python y las herramientas opcionales del navegador no se empaquetan; no se requiere ningún archivo del árbol de desarrollo.

## Reproducir

Desde `ModBridge_Studio/`, con las dependencias de `requirements.txt` instaladas:

```sh
python -m unittest discover -s tests -v
node --test tests/test_library.cjs
node --check web/app.js
node --check web/library.js
node --check web/viewer.js
node --check tests/test_library.cjs
node --check tests/test_library_browser.cjs
node --check tests/test_viewer_browser.cjs
sh -n iniciar_mac_linux.sh
node tests/test_library_browser.cjs
node tests/test_viewer_browser.cjs
python app.py convert --input examples/Demostracion_ModBridge.jar --output prueba_demo --mesh-mode surface --size 128
```

Para las dos últimas suites de navegador se necesita Playwright y un Chromium instalado; `CHROMIUM_EXECUTABLE` permite indicar su ejecutable. Los lanzadores del programa solo instalan las dependencias Python.

Registros: `pruebas_python_v242.txt`, `pruebas_biblioteca_node_v242.txt`, `pruebas_biblioteca_navegador_v242.json`, `pruebas_visor_navegador_v242.json`. El registro estructurado de comprobaciones y archivos está en `VALIDACION_V242.json`. El inventario completo y el parche están en `COMPARACION_V241_V242.json` y `CAMBIOS_CODIGO_V241_V242.patch`.

## Compatibilidad y límites de lo comprobado

- Aplicación 2.4.2; geometría Bedrock 1.21.0 y previsualización interna 2 conservadas. La base 2.4.1 no contiene `port_map` ni `--port-mode`; no se crea un formato sustituto. Se conservan los argumentos reales, especialmente `--mesh-mode`.
- No se ejecutó Minecraft Bedrock ni Java. Las vistas son renders propios y `verified_static` no certifica comportamiento dentro del juego.
- El lanzador Windows se conserva byte a byte y no se ejecutó en Linux. El lanzador macOS/Linux conserva su contenido y supera la comprobación de sintaxis; no se probó el escritorio de macOS.
- La prueba real cubre los seis recursos enumerados; no equivale a convertir ni certificar todos los modelos de Create.
- La aplicación exporta solo modelos, texturas y auditoría. No añade mecánicas, bloques, entidades funcionales, scripts ni paquetes de juego instalables.
