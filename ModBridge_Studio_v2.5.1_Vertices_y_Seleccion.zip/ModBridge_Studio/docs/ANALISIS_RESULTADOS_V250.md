# Análisis de los archivos aportados para 2.5.0

## Material revisado

`ModBridge_resultado.zip` contiene resultados de la versión 2.4.9 para 2.685 modelos. `ModBridge_renders (4).zip` contiene 1.584 PNG y un manifiesto, correspondientes a 66 modelos. Para volver a convertir se utilizaron las caras, vértices, UV y texturas fuente del ZIP de resultados; las imágenes sirven como referencia visual, no como sustituto de los datos tridimensionales.

Los 66 modelos de los renders corresponden a 65 superficies aproximadas con diferencias y al modelo nativo `create:block/goggles`. La auditoría no equivale a reconvertir todos los 2.685 modelos del ZIP.

## Resultado de la auditoría

Se procesaron los 65 casos de superficies con la configuración predeterminada de 2.5.0. No hubo errores de ejecución. Los 65 aceptaron al menos un repaso que cumple la regla conservadora de mejora. La densidad nominal del atlas se mantuvo en 4 píxeles por unidad en todos ellos.

| Medida agregada en los 65 casos | Base 2.4.4 usada en 2.4.9 | Resultado 2.5.0 |
|---|---:|---:|
| Área omitida | 214,8891 | 103,5835 |
| Área fuera de la superficie fuente | 154.875,9110 | 98.201,2032 |
| Modelos con geometría coincidente | 0 | 1 |

Las áreas se suman por cara, en unidades de modelo al cuadrado, y la muestra contiene variantes de modelos. La reducción agregada es aproximadamente 51,8 % en omisiones y 36,6 % en superficie saliente. Son medidas de cobertura de la conversión, no una puntuación de apariencia ni de fidelidad de texturas.

| Modelo, con prefijo `create:block/` | Cambio observado |
|---|---|
| `track/bogey/bogey_drive_wheel_pin` | Área saliente de 160 a 0; omisión 0; de 20 a 10 rectángulos. La comparación independiente confirma coincidencia. |
| `black_valve_handle` | Omisión de 1,06552 a 0,27044; superficie saliente 0. De 1.082 a 4.186 rectángulos. Aún aproximado. |
| `large_water_wheel/block` | Superficie saliente de 32.535,27534 a 23.015,94212; omisión de 8,84732 a 8,78907. Aún aproximado. |
| `chain_conveyor/wheel` | Omisión de 10,28152 a 5,14990; superficie saliente de 35,30116 a 35,05033. Aún aproximado. |
| `track/bogey/bogey_frame` | Omisión de 16,8125 a aproximadamente 0,5; superficie saliente de 6.211,99929 a 0. Aún aproximado. |

**64 superficies siguen sin coincidencia completa.** El motor conserva esa conclusión. No se ha cambiado el umbral ni se ha hecho que las métricas declaren correctos resultados que todavía difieren. El detalle de los 66 modelos se incluye en `AUDITORIA_MODELOS_V250.json`.

## El caso goggles

`create:block/goggles` tiene 51 caras en fuente y destino. Coinciden los vértices, límites, normales y área total de 269,2, pero las caras 43, 45, 46 y 47 son degeneradas en ambos lados. El verificador no certifica superficies con esas caras inválidas. También existe una advertencia de UV fuera del sprite.

Este modelo usa conversión nativa, no el adaptador de superficies. No se le aplicaron repasos ni se eliminaron caras del original. Permanece en revisión; repetir el aproximador no corrige un defecto ya presente en la fuente.

## Repetir el análisis

Desde `ModBridge_Studio/`, con los dos archivos originales disponibles:

```bash
python tests/audit_v250_results.py --results ModBridge_resultado.zip --renders "ModBridge_renders (4).zip" --output auditoria_nueva
```

La auditoría guarda IR, geometría, atlas, reporte de superficie y comparación independiente por modelo. No produce las seis vistas ni un paquete de juego. Para el flujo habitual, carga el JAR original en la aplicación y vuelve a convertir.
