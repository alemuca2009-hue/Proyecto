# Auditoría independiente de geometría 2.4.7

Fecha de consulta: 9 de noviembre de 2026. Esta revisión no modifica los modelos fuente.

## Evidencia comprobada

El adjunto contiene 1.566 renders y un manifiesto: 87 modelos, tres perfiles, seis vistas, únicamente la representación traducida. Las imágenes permiten ver superficies y contornos de salida, pero por sí solas no prueban equivalencia con la geometría original. Se usó además el JAR de referencia Create 1.21.1–6.0.10 disponible de la validación anterior; el manifiesto adjunto identifica esa versión, aunque no incluye el hash completo del JAR del usuario.

La resolución de los 87 identificadores encuentra 38 referencias OBJ directas distintas. Sus caras tienen tres o cuatro vértices; el problema de triangulación en abanico para polígonos de más de cuatro vértices no explica estos casos. El censo se calculó durante esta auditoría.

### Pérdida geométrica corregible por teselación

Una superficie cuadrada 4 × 4 formada por cuatro triángulos que comparten el centro es exactamente representable por un solo rectángulo Bedrock. En 2.4.6 no se reconstruye: la función de unión acepta solo parejas de triángulos con una frontera de cuatro vértices no colineales. El ejemplo termina en 252 rectángulos, cobertura de 98,4375 % y comprobación independiente de superficie fallida. La pérdida de área se introduce artificialmente al aproximar cada triángulo por separado.

La unión coplanar de regiones compatibles antes de subdividir es una corrección objetiva. Debe respetar huecos, multiplicidad de capas, orientación y discontinuidades UV; una envolvente convexa general destruiría información.

### Límite real observado en las válvulas

`create:block/copper_valve_handle` contiene 60 caras cuadrangulares: 44 rectángulos exactos y 16 trapecios reales. Un ejemplo del contorno superior tiene vértices `[2.899504,8,-7]`, `[2.071072,8,-5]`, `[5,8,-2.071072]`, `[7,8,-2.899488]`. El coseno de ciertos ángulos adyacentes es aproximadamente 0,3826878, lejos del cero de un rectángulo. No es solo un problema de diagonales de triangulación.

Algunos mapas UV originales contienen perturbaciones de fracciones de texel que impiden describirlos mediante un único mapa afín exacto. Preservar los píxeles de un archivo de textura no demuestra que la asignación UV sea equivalente. Las mediciones se realizaron sobre los vértices y UV del OBJ original.

## Compatibilidad del formato: fuentes oficiales

Microsoft documenta que `poly_mesh` está obsoleto y que usarlo en contenido nuevo produce errores de contenido:

https://learn.microsoft.com/en-us/minecraft/creator/reference/content/visualreference/geometry.v1.12.0?view=minecraft-bedrock-stable

El validador oficial describe GEOFMT101 como error para `poly_mesh`, por tratarse de una característica restringida que puede no estar disponible en todas las plataformas:

https://learn.microsoft.com/en-us/minecraft/creator/reference/content/mctoolsvalreference/geofmt?view=minecraft-bedrock-stable

La especificación 1.21.0 permite UV por cara y rotación UV en incrementos de 90 grados. Omitir una cara evita que se dibuje; no existe un campo que convierta la cara rectangular de un cubo en un trapecio arbitrario:

https://learn.microsoft.com/en-us/minecraft/creator/reference/content/visualreference/geometry.v1.21.0?view=minecraft-bedrock-stable

Por ello no es válido declarar compatibilidad 1:1 universal exportando silenciosamente `poly_mesh`. Las máscaras transparentes pueden mejorar una silueta texturizada, pero no convierten su superficie rectangular en la geometría poligonal original: Alambre, Sólido, límites y normales seguirían describiendo otra forma.

## Pruebas independientes añadidas

`tests/test_geometry_audit_v247.py` comprueba seis casos mediante serialización real, decodificación y comparación independiente: cuadrado con cuatro triángulos, rotación arbitraria, marco con hueco, capas duplicadas, discontinuidad UV y rechazo de exactitud falsa en un trapecio. También verifica que las caras y texturas originales no se modifiquen. Cuatro casos exponen la regresión de 2.4.6. Tras integrar la unión coplanar de 2.4.7, las seis pruebas pasan (0,204 s): el cuadrado de cuatro triángulos y su variante rotada se exportan como un único rectángulo con superficie y UV/material coincidentes; el hueco y las capas duplicadas se conservan. El trapecio sigue declarado como aproximación, sin fingir exactitud.

## Criterio de aceptación

Una mejora puede recuperar equivalencia estática 1:1 en las regiones representables sin prometer equivalencia de todas las mallas ni ejecución dentro del juego. La comprobación debe utilizar el JSON Bedrock y atlas finales, conservar las diferencias restantes en Revisar y mantener las fuentes originales. Una coincidencia de renders desde seis direcciones es evidencia adicional, no sustituto de la comparación geométrica y UV.
