# ModBridge Studio 2.4.8 · Corrección de conversiones

Base: el ZIP 2.4.7 adjunto. Se mantienen los archivos históricos, ejemplos,
recursos vanilla, visor, biblioteca, control maestro y exportación por perfiles.

## Fallos corregidos

1. **Descartar una región útil por no alcanzar la precisión objetivo.** La 2.4.7
   podía deshacer una unión coplanar solo por agotar su presupuesto. La 2.4.8
   compara el área cubierta de las alternativas antes de elegir.
2. **Rechazar una región completa porque parte de sus UV era nativa.** En modelos
   que ya necesitan texturas remuestreadas, se permite una unión con UV mixtas
   cuando repara una aproximación geométrica. Se conservan los triángulos de
   interpolación originales. Los modelos completamente nativos no pierden esa
   propiedad, y no se remuestrean uniones formadas solo por rectángulos exactos.
3. **Una mejora local desaparecía por una decisión global.** El nuevo plan local
   compara cada región con su representación anterior, usando como máximo su
   mismo número de rectángulos y sin aumentar su distancia de borde muestreada.
   Si el plan local es mejor que las otras alternativas, se utiliza ese plan.
4. **Mayor precisión no siempre significa mejor reparto del presupuesto.** Se
   evalúan dos resoluciones para evitar que el detalle adicional de algunas
   caras deje menos presupuesto para superficies más importantes.

Se conserva la alternativa 2.4.7 cuando ninguna nueva mejora la cobertura total,
y sigue vigente el límite de 12.000 rectángulos por modelo. No se utilizan
máscaras salientes, rellenos de envolvente convexa ni cambios de escala.

## Texturas y estados

La unión de caras con UV discontinuas puede requerir textura derivada. Cada
rectángulo indica `original_tile` o `sampled` en `texture_transfer.per_face`.
`rgba_texels_preserved` y `uv_mapping_preserved` permanecen falsos cuando hay
muestreo. Una geometría plana exacta no implica texturas exactas.

La selección se registra en `coplanar_regions.plan_selection`: plan anterior,
alternativa global o alternativa local, cobertura, número de rectángulos y
métrica de borde. Las superficies siguen en Revisar. La cobertura es suma de
áreas planas, no porcentaje de exactitud del modelo, de volumen o de píxeles.
El criterio global protege el área total; no garantiza que cada cara individual
mejore. El plan local sí conserva el presupuesto y el borde muestreado de cada
región sustituida. Se publican además las comparaciones independientes.

## Validación y límites

Ver `VALIDACION_V248.md`, `VALIDACION_V248.json`, `COMPARACION_V248.png` y
`FAMILIAS_MODELOS_V248.json`. Se analizaron los 2.304 PNG de los 64 modelos
adjuntos. Los modelos se agruparon por vértices, UV, atributos y dimensiones de
textura; las diferencias de color no forman una nueva familia geométrica.
Se reconvirtieron 21 representantes. Esto no equivale a probar cada textura de
cada variante de color ni cada modelo posible de Create.

Las caras oblicuas siguen siendo aproximaciones cuando no pueden representarse
exactamente con caras rectangulares. La llama conserva grietas visibles pese a
una menor pérdida de área. Algunas ruedas todavía tienen diferencias de borde.
No se ha probado el programa en Windows ni los modelos dentro de Bedrock en
esta sesión. Se mantienen ambos lanzadores; las pruebas se ejecutaron en Linux.

## Reproducir las pruebas

```bash
python -m unittest discover -s tests
node --test tests/test_analysis_filters.cjs tests/test_library.cjs tests/test_render_config.cjs tests/test_verification_cards.cjs tests/test_viewer_contours.cjs
```

La auditoría real usa `tests/run_geometry_v247.py` (conserva su nombre histórico)
y `tests/audit_release_v248.py`. Necesita el JAR original, el ZIP de renders
extraído y Shapely como dependencia de desarrollo; Shapely no es dependencia
del programa. Los argumentos `--help` describen sus entradas.

## Referencias de formato y origen

- Create 6.0.10 para Minecraft 1.21.1: https://modrinth.com/mod/create/version/UjX6dr61
- Formato Bedrock 1.21.0: https://learn.microsoft.com/en-us/minecraft/creator/reference/content/visualreference/geometry.v1.21.0?view=minecraft-bedrock-stable

El JAR descargado para validar coincide por SHA-256 con el registrado en la
validación de la 2.4.7: `ef87fe5709f1ba1f5b8bb20a2925b5afb4669e178fd6d8bf10c167759eefe37a`.
No se incluye ese JAR adicional en la distribución.
