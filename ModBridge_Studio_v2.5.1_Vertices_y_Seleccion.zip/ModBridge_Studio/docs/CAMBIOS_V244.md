# ModBridge Studio 2.4.4 — contornos de malla

## Problema reproducido

La captura corresponde visualmente a la familia `valve_handle` de Create.
Se reprodujeron las puntas y líneas adicionales con
`create:block/copper_valve_handle` del JAR Create 1.21.1–6.0.10 aportado.
Sus caras superiores e inferiores son trapezoides. En 2.4.3, cada una se
exportaba como un rectángulo envolvente con transparencia. Alambre mostraba
también las partes de esos rectángulos que excedían la cara original.

## Corrección

El adaptador proyecta cada polígono sobre su propio plano. Divide el contorno
en bandas horizontales separadas por las alturas de sus vértices y subdivide
las bandas con bordes inclinados. Cada franja se obtiene de la intersección
de las secciones inferior y superior. Sus vértices quedan dentro del contorno;
las concavidades conservan intervalos separados.

El resultado se exporta como cubos planos Bedrock ordinarios. Se mantienen
la orientación y la escala. Las UV se muestrean desde el polígono original,
sin copiar la geometría fuente al reporte de destino ni falsificar las métricas.

Alambre utiliza los segmentos exteriores de la unión de los rectángulos
efectivamente exportados. Solo se suprimen las divisiones interiores
compartidas por franjas coplanares de una misma cara. El sólido, las texturas
y los análisis conservan todas las superficies del destino.

## Límites explícitos

Esto corrige los salientes, pero no convierte un trapezoide en un rectángulo
exacto. Los bordes inclinados conservan una aproximación interior. La
coincidencia geométrica estricta no se fuerza a verdadero. La regla de
verificación automática de 2.4.3 continúa funcionando sin cambios.

Cada cara refinada debe conservar al menos el 99 % de su área planar. El
objetivo de paso es 1/32 de unidad de modelo, con hasta 128 bandas por cara
y un presupuesto de 3500 rectángulos por modelo. No se elimina ninguna cara
para cumplir ese presupuesto: cuando la precisión no cabe, se mantiene la
representación anterior con máscara y se declara en el reporte. Si la malla
de entrada ya supera el presupuesto, se conserva sin añadir subdivisiones.

`metrics.surface.contour_refinement` informa cobertura, área omitida, áreas
salientes de las caras de respaldo, caras refinadas y caras pendientes.
Los valores de área se suman por cara; no representan el área de una unión
booleana del volumen completo ni una prueba dentro de Minecraft.

## Archivos

- `bridge/surface_contours.py`: bandas interiores, asignación del presupuesto
  por beneficio geométrico y contornos de unión de rectángulos.
- `bridge/mesh_surface.py`: integración en geometría, atlas y reporte.
- `bridge/surface_adapter.py`: conserva contornos en el IR de destino y
  explica las caras que continúan con máscara.
- `bridge/preview.py`: formato de vista previa 3 y renovación de cachés.
- `web/viewer.js`: bordes derivados del destino, conservando los triángulos.
- Versión, ayuda, guías y pruebas de regresión actualizadas.

La conversión de cuboides JSON, el modo «Solo exactos», los archivos fuente
y el criterio de aceptación de 2.4.3 se conservan. Los ejemplos Water Wheel
incluidos de 2.4.2 siguen identificados como históricos.

## Referencia del formato

La salida usa cubos planos. No se cambia a `poly_mesh` para aparentar una
conversión nativa: Microsoft documenta GEOFMT101 como error de malla restringida.
Referencia: https://learn.microsoft.com/en-us/minecraft/creator/reference/content/mctoolsvalreference/geofmt?view=minecraft-bedrock-stable

Los resultados reproducidos están en `VALIDACION_V244.md`,
`VALIDACION_V244.json` y `COMPARACION_CONTORNOS_V244.png`.
