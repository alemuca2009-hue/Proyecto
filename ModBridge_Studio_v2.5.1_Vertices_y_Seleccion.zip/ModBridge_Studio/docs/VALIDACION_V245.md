# Validación de ModBridge Studio 2.4.5

Fecha de documentación: 9 de noviembre de 2026.

La conversión final se comprobó con **41 recursos de nueve familias**, derivados de la revisión de las 65 capturas. Los 41 generaron geometría; ninguno terminó en error o no convertido. El caso de los pasadores cúbicos quedó verificado estáticamente. Los otros 40 conservan el estado **Revisar** porque todavía tienen aproximaciones geométricas, UV remuestreadas o ambas.

Una auditoría independiente de contención comprobó los **164.150 polígonos de destino decodificados**: no encontró superficie saliente fuera de la tolerancia declarada en ninguno de los 41 modelos. Ninguno recupera el antiguo rectángulo envolvente con máscara al agotarse el presupuesto. Esto no equivale a que todas las conversiones sean exactas.

## Material analizado

- `Geometrías(2).pdf`: revisión visual de sus 29 páginas, que contienen 65 capturas.
- `ModBridge_2.4.4_Revision_65_Capturas.pdf`: lectura y revisión visual de sus 10 páginas.
- Programa 2.4.4 adjunto: se extrajo una copia aislada para reproducir diez casos antes de aplicar los cambios.
- Create 1.21.1-6.0.10: JAR oficial cuyo SHA-256 coincide exactamente con el consignado en el diagnóstico recibido. No se redistribuye dentro de ModBridge.

Página de versión: https://modrinth.com/mod/create/version/UjX6dr61

Descarga oficial: https://cdn.modrinth.com/data/LNytGWDc/versions/UjX6dr61/create-1.21.1-6.0.10.jar

```text
ef87fe5709f1ba1f5b8bb20a2925b5afb4669e178fd6d8bf10c167759eefe37a
```

Los recortes del PDF omiten identificadores: 65 capturas no significan 65 modelos únicos. Los recursos ensayados son candidatos sustentados por su familia y por el JAR, sin atribuir un identificador inequívoco a cada imagen.

| Familia | Capturas del PDF | Recursos comprobados |
|---|---:|---:|
| valvulas | 35 | 18 |
| fuego | 3 | 3 |
| protecciones | 1 | 1 |
| transportador | 3 | 2 |
| trituradoras | 3 | 2 |
| volantes | 3 | 2 |
| ruedas agua | 8 | 5 |
| rodillos | 3 | 2 |
| bogeys | 6 | 6 |

## Antes y después

Las áreas son sumas de superficies planas en unidades de modelo². Los porcentajes no representan volumen ni un porcentaje de fidelidad visual. La comparación raster de esta tabla usa seis vistas de 64 × 64 píxeles.

| Recurso | Caras 2.4.4 | Caras 2.4.5 | Área fuente | Área 2.4.4 | Área 2.4.5 | Cobertura 2.4.5 |
|---|---:|---:|---:|---:|---:|---:|
| `track/bogey/bogey_drive_wheel_pin` | 20 | 10 | 160.000000 | 320.000000 | 160.000000 | 100.000000 % |
| `large_water_wheel/block` | 3497 | 12000 | 33666.276586 | 66192.704598 | 33328.709609 | 98.997314 % |
| `track/bogey/bogey_drive_wheel` | 3482 | 11999 | 2624.456741 | 4521.289840 | 2587.253455 | 98.582439 % |
| `chain_conveyor/item` | 3495 | 9215 | 6248.741354 | 6333.745575 | 6235.221655 | 99.783641 % |
| `crushing_wheel/block` | 3465 | 12000 | 3982.783854 | 4558.689998 | 3962.956862 | 99.502183 % |
| `flywheel/block` | 3453 | 5631 | 5335.321820 | 5475.081275 | 5321.794518 | 99.746458 % |
| `copper_valve_handle` | 1082 | 1082 | 789.644505 | 788.578989 | 788.578989 | 99.865064 % |
| `blaze_burner/block_with_fire` | 548 | 548 | 2941.920968 | 2937.920968 | 2937.920968 | 99.864034 % |
| `chain_conveyor/guard` | 526 | 526 | 888.731427 | 888.545489 | 888.545489 | 99.979078 % |
| `mechanical_roller/wheel` | 2876 | 2876 | 1908.695864 | 1902.229532 | 1902.229532 | 99.661217 % |

- **Pasadores cúbicos:** los 20 triángulos fuente pasan a diez rectángulos compatibles. Área 160 → 160, límites conservados, sin completar caras ausentes. La verificación independiente de superficies y UV es positiva; la teselación es distinta. Las seis vistas también coinciden a **256 × 256 píxeles**, comprobación adicional incluida en `examples/Pasador_v245/`.
- **Rueda grande:** se unen 949 pares de triángulos; 521 producen rectángulos exactos y 428 uniones convexas que todavía requieren aproximación. El área saliente de la versión anterior desaparece dentro de la tolerancia auditada. La cobertura de área es 98,997314 %, con hasta 12.000 rectángulos y estado Revisar.
- **Válvulas y rodillos:** sus contornos interiores siguen siendo aproximaciones. La válvula conserva 99,865064 % del área; no se presenta como una reconstrucción exacta ni como una eliminación total de subdivisiones.
- **Fuego:** 167 rectángulos reutilizan UV y texels originales; 381 todavía necesitan muestreo en cada modelo de fuego normal o azul. Sus quads fuente tienen pequeñas desviaciones de coplanaridad, que se respetan mediante triangulación.
- **Protección del transportador:** seis vistas idénticas a 64 píxeles siguen sin demostrar geometría exacta. Conserva una pequeña pérdida de área y queda en Revisar.

## Qué se verificó

1. Reconstrucción del JSON de destino para medir superficies, límites y normales. Se separa equivalencia de superficie de igualdad de teselación.
2. Comprobación independiente de UV/material cuando la representación permite una prueba completa. Copiar una imagen PNG por sí solo no basta para verificar su asignación a las caras.
3. Auditoría independiente con Shapely 2.2.0: diferencia entre cada polígono decodificado y las uniones de triángulos fuente coplanares. Tolerancia de plano y borde proyectado: 1e-5 unidades de modelo. La multiplicidad y orientación se comprueban por separado en el comparador del programa.
4. Área omitida, presupuesto, estado y distancia de borde muestreada por cara. Esta distancia es una medida por muestreo; no se etiqueta como cota certificada de Hausdorff.
5. Seis renders ortográficos por modelo. Son renders propios, no capturas dentro de Minecraft. El visor admite las 12.000 caras del presupuesto de conversión y no trunca estas muestras a 4.000.
6. **188 pruebas Python y 23 pruebas Node aprobadas**, más comprobaciones de sintaxis de los tres JavaScript principales. Los registros completos acompañan esta entrega. El informe de la interfaz resume las métricas y carga el JSON por cara bajo demanda, evitando crear un DOM enorme con los miles de rectángulos.

## Archivos de evidencia

- `VALIDACION_V245.json`: resultados compactos de los 41 modelos y los diez casos de referencia 2.4.4.
- `CONTENCION_GEOMETRIA_V245.json`: resultado independiente por modelo; 41/41 pasan y área exterior detectada igual a cero.
- `COMPARACION_GEOMETRIA_V245.png`: fuente, destino 2.4.4 y destino 2.4.5 con cámara y escala comunes. Muestra todas las aristas del JSON decodificado, incluidas las numerosas divisiones de las aproximaciones; no oculta esas divisiones usando el contorno de previsualización.
- `pruebas_python_v245.txt` y `pruebas_node_v245.txt`: resultados de las suites automatizadas.

## Reproducibilidad

Desde la carpeta del programa, aportando el JAR oficial por separado:

```bash
python tests/run_geometry_v245.py --input create-1.21.1-6.0.10.jar --output auditoria --size 64
python tests/audit_containment_v245.py --run auditoria --output contencion.json
```

El segundo script necesita Shapely como dependencia de desarrollo opcional. La aplicación y sus conversiones normales no dependen de Shapely.

Para reproducir la referencia anterior, el primer script admite `--program-root` apuntando al programa 2.4.4 y `--representatives`. `tests/render_geometry_v245.py` genera la lámina comparativa con `--before`, `--after` y `--output`.

## Límites de esta validación

No se ejecutó Minecraft Bedrock ni el lanzador en Windows nativo. No se ejecutaron las suites completas de navegador Playwright porque Chromium no estaba disponible y su instalación no se completó en este entorno. Sí se ejecutaron las pruebas Python del servidor HTTP y worker, además de las pruebas Node de lógica y presentación.

Las aproximaciones interiores pueden perder pequeñas áreas y aumentar la cantidad de rectángulos. Las caras UV no representables se remuestrean y se identifican explícitamente. Los 40 resultados en Revisar no se promocionan por una apariencia semejante ni por conservar los PNG fuente. Esta entrega corrige los salientes y mejora la reconstrucción y trazabilidad; no certifica equivalencia exacta universal ni funcionamiento dentro del juego.
