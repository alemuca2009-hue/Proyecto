# ModBridge Studio 2.4.5 - Geometría reconstruida

## Problema corregido

La versión 2.4.4 representaba triángulos aislados mediante rectángulos envolventes. La máscara alpha ocultaba parte de la textura, pero no eliminaba la geometría sobrante. Cuando el refinamiento no alcanzaba su umbral de cobertura o agotaba 3.500 rectángulos, volvía al mismo método. El JSON exportado tenía salientes reales: no era solamente un efecto del visor.

Se revisaron las 29 páginas de Geometrías(2).pdf y las 10 páginas de ModBridge_2.4.4_Revision_65_Capturas.pdf. Sus 65 capturas representan familias y variantes; no permiten identificar de forma inequívoca 65 recursos distintos porque los identificadores están recortados. La regresión usa los 41 candidatos descritos en la revisión y el mismo JAR fuente, verificado por SHA-256.

## Cambios del convertidor

1. **Reconstrucción antes de subdividir.** `surface_rectangles.py` une primero pares que forman rectángulos; después admite uniones convexas compatibles. No inventa tapas o caras ausentes. Conserva las coordenadas y UV de las esquinas, la orientación, los límites de material y la diagonal original de interpolación. Los pares rectangulares y los polígonos unidos se cuentan por separado.
2. **Sin respaldo saliente.** `surface_contours.py` reparte hasta 12.000 rectángulos interiores. Cada polígono recibe una representación antes de distribuir las subdivisiones adicionales según la reducción de error de área. Si ni la representación mínima cabe, se informa el fallo y se conserva la malla diagnóstica; no se descartan caras para aparentar éxito.
3. **Errores medidos.** Cada parche identifica su origen, estado, rectángulos, área omitida, cobertura y limitación por presupuesto. La distancia del borde se mide con 64 intervalos por arista y se declara como muestreo, no como distancia de Hausdorff exacta. Una aproximación interior puede perder área aunque ya no sobresalga.
4. **UV y texels.** `mesh_surface.py` copia cada textura RGBA una sola vez con borde protector y usa UV nativas, tamaños con signo y giros de 90 grados cuando la asignación es representable. Conserva también RGB oculto bajo alpha cero. En triángulos, prefiere una arista compatible con las UV cuando no aumenta la caja envolvente; no cambia por ello la orientación de los cuadriláteros. Las UV no afines, sesgadas o fuera de rango usan muestreo identificado por cara. Copiar una textura no demuestra por sí solo que su asignación sea correcta.
5. **Integridad al fallar.** El adaptador calcula y decodifica la propuesta antes de sustituir el atlas/JSON anteriores. Un fallo de adaptación conserva el par de diagnóstico original y su reporte.

## Verificación independiente

`rendering.py` vuelve a decodificar la geometría exportada. Informa por separado:

- `tessellation_equal`: coincidencia estricta de caras y vértices.
- `surface_geometry_equal`: coincidencia de superficie orientada, con huecos y multiplicidad; permite dos triángulos frente a un rectángulo.
- `uv_mapping_check_passed`: evidencia independiente de mapas UV afines y texturas RGBA completas copiadas al atlas. No confía en el reporte del convertidor.
- Comparación rasterizada desde seis lados, a resolución declarada.

La comprobación de superficie usa bordes coplanares orientados. Una diferencia de área ya demuestra desigualdad y permite omitir el cálculo detallado de bordes; en ese caso el reporte indica que no se realizó y deja sus mediciones en `null`. No se presenta un cero inventado como prueba.

Una comprobación UV explícitamente fallida impide promover o conservar el estado verificado, incluidas reexportaciones. Las aproximaciones no se reclasifican por tener imágenes similares a baja resolución.

## Interfaz y distribución

- Se distinguen reconstrucción de superficies y aproximación interior.
- El contador indica vistas **comparadas** y separa cuántas tienen píxeles idénticos.
- El reporte muestra superficie, teselación, UV/material, texels y errores de contorno.
- El visor admite las 12.000 caras del presupuesto de conversión sin omitir franjas. Los recursos que exceden su límite siguen identificados como vista aligerada; la exportación siempre utiliza todos los datos.
- Se renueva la caché de previsualización a formato 4. La geometría conserva formato 1.21.0.
- Los ejemplos antiguos de Water Wheel se conservan en un ZIP histórico para evitar rutas demasiado largas al extraer la distribución principal en Windows.

## Aplicar la corrección

Extraer la versión en una carpeta nueva, abrir el lanzador y cargar otra vez el JAR original. Elegir **Superficies** y convertir. Los ZIP y resultados generados por 2.4.4 no se modifican automáticamente.

## Límites y documentación de formato

La revisión cubre recursos estáticos y validaciones del programa. No acredita carga o apariencia en Minecraft Bedrock, animaciones del mod ni funcionamiento nativo en Windows. Los contornos oblicuos no representables con cubos planos mantienen aproximación documentada. Los `.mcmeta` fuente se preservan, pero el fuego no se convierte en una animación Bedrock.

Se contrastó la salida con la documentación oficial de geometría 1.21.0, que contempla UV por cara y giros de 0/90/180/270 grados:
https://learn.microsoft.com/en-us/minecraft/creator/reference/content/visualreference/geometry.v1.21.0?view=minecraft-bedrock-stable

Recurso fuente utilizado para repetir el diagnóstico:
https://modrinth.com/mod/create/version/UjX6dr61

El JAR de Create no se incluye en la entrega. Las pruebas y resultados medidos se documentan en `VALIDACION_V245.md` y `VALIDACION_V245.json`.
