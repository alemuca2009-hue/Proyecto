# Water Wheel: geometría grande y port de modelos 3D

## Qué hace el addon de referencia

El addon aportado separa el bloque y el modelo que dibuja la rueda. Sus entidades cliente referencian geometrías mayores que una celda; los bloques usan otras geometrías pequeñas. Para el conversor, la parte aplicable es **el formato del modelo, su tamaño, sus UV, sus texturas y su volumen de visibilidad**. El comportamiento que mantiene ese dibujo en el mundo queda fuera del port 3D.

Un `.geo.json` no crea una entidad: almacena geometrías identificadas por nombre. El uso depende de la definición que lo referencia. Por eso la carpeta `models/blocks/` del addon contiene geometrías que se dibujan como entidades. ModBridge exporta el modelo y documenta ese uso; no genera la definición de la entidad ni un bloque funcional.

## El límite no es estrictamente 1 × 1

La guía oficial de bloques personalizados permite una envolvente de hasta **30 × 30 × 30 unidades**, dentro de ±30 respecto del origen y con al menos una unidad por eje contenida en la celda base. Una celda equivale a 16 unidades. Por tanto, el tamaño permitido depende del uso del modelo. Las ruedas de 32 y 78 unidades no cumplen ese perfil convencional de bloque. [1]

`visible_bounds_width`, `visible_bounds_height` y `visible_bounds_offset` describen la caja de visibilidad; no son un factor de escala ni dimensiones de colisión. El esquema distingue esa descripción de los cubos, huesos y UV. [2]

## Medidas verificadas en el archivo aportado

Medidas X/Y/Z de la pose base, calculadas a partir de cubos, pivotes y rotaciones. No son colisiones ni el volumen recorrido durante una animación.

| Geometría del addon | Tamaño en unidades | Tamaño en bloques | Cubos |
|---|---:|---:|---:|
| `geometry.create.water_wheel_block` | 16 × 16 × 16 | 1 × 1 × 1 | 9 |
| `geometry.create.water_wheel_entity` | 32 × 32 × 16 | 2 × 2 × 1 | 201 |
| `geometry.create.water_wheel_item` | 29,76 × 29,76 × 14,88 | 1,86 × 1,86 × 0,93 | 210 |
| `geometry.create.large_water_wheel_block` | 18 × 18 × 16 | 1,125 × 1,125 × 1 | 58 |
| `geometry.create.large_water_wheel_entity` | 78,15632 × 78,15632 × 19 | 4,88477 × 4,88477 × 1,1875 | 442 |
| `geometry.create.large_water_wheel_item` | 27,35472 × 27,35472 × 6,65 | 1,70967 × 1,70967 × 0,415625 | 442 |

Las geometrías de inventario son versiones pequeñas independientes. No indican que la rueda del mundo haya sido reducida. La rueda grande aplica un material invisible al bloque y referencia la geometría grande desde la entidad cliente; la pequeña conserva una base visible separada.

### Archivos que prueban el vínculo geométrico

| Papel | Ruta dentro de `create_addon.mcaddon` |
|---|---|
| Geometrías pequeña: bloque, entidad e inventario | `Create(RE)/models/blocks/generators/water_wheel.geo.json` |
| Geometrías grande: bloque, entidad e inventario | `Create(RE)/models/blocks/generators/large_water_wheel.geo.json` |
| Referencias de geometría y texturas de la pequeña | `Create(RE)/entity/create/generators/water_wheel.rpe.json` |
| Referencias de geometría y texturas de la grande | `Create(RE)/entity/create/generators/large_water_wheel.rpe.json` |
| Orden de variantes de textura | `Create(RE)/render_controllers/create/water_wheel.rc.json` |
| Referencias geométricas del bloque pequeño | `Create (BE)/blocks/create/generators/water_wheel.b.json` |
| Referencias geométricas del bloque grande | `Create (BE)/blocks/create/generators/large_water_wheel.b.json` |

El programa lee esos vínculos para construir la auditoría de referencia. No copia sus comportamientos ni adopta automáticamente sus geometrías como reemplazo de la fuente Java. El registro reproducible con rutas, dimensiones y hashes de los archivos de entrada está en `REFERENCIA_WATER_WHEEL_MODELOS_3D.json`.

### Variantes de madera

| Índice | Textura | Pequeña | Grande |
|---:|---|---|---|
| 0 | Roble | Propia | Propia |
| 1 | Abeto | Propia | Propia |
| 2 | Abedul | Propia | Propia |
| 3 | Jungla | Propia | Propia |
| 4 | Acacia | Propia | Propia |
| 5 | Roble oscuro | Propia | Propia |
| 6 | Manglar | Propia | Reutiliza roble |
| 7 | Cerezo | Propia | Propia |
| 8 | Bambú | Propia | Propia |
| 9 | Carmesí | Propia | Propia |
| 10 | Distorsionado | Propia | Propia |
| 11 | Roble pálido | Propia | Propia |

Hay 12 entradas de textura para cada tamaño; la grande tiene 11 rutas distintas. Estas son variantes visuales que comparten geometría. Su cambio de textura no explica el tamaño y no exige reconstruir el modelo. La versión actual informa esas variantes de referencia; no genera estados de madera ni inventa texturas equivalentes de Java.

## Comparación con Create Java 1.21.1–6.0.10

En Java la base pequeña y el rotor son recursos diferentes. La receta adicional `modbridge:block/water_wheel/assembled` reúne ambos en sus coordenadas fuente como un modelo estático, con procedencia y hashes de los dos JSON. Los archivos originales permanecen intactos. Las variantes grandes `block` y `block_extension` se conservan separadas.

| Modelo Java | Tamaño fuente X/Y/Z | Envolvente exportada X/Y/Z | Estado |
|---|---:|---:|---|
| `water_wheel/block` | 16 × 16 × 16 | 16 × 16 × 16 | Verificado estático |
| `water_wheel/wheel` | 32 × 16 × 32 | ≈40,7231 × 17,8824 × 40,7231 | Revisión; OBJ aproximado |
| `modbridge:…/water_wheel/assembled` | 32 × 16 × 32 | ≈40,7231 × 17,8824 × 40,7231 | Revisión; OBJ aproximado |
| `large_water_wheel/block` | ≈78,000016 × 19 × 78,000016 | ≈93,000016 × 30,000018 × 93,000008 | Revisión; OBJ aproximado |
| `large_water_wheel/block_extension` | ≈78,000016 × 17,5 × 78,000016 | ≈93,000016 × 30,000018 × 93,000008 | Revisión; OBJ aproximado |

La diferencia entre ejes verticales de Java y del addon procede de sus poses base; no se añade un giro de colocación al modelo exportado. Tampoco se afirma equivalencia entre la rueda Java y la reconstrucción cuboide del addon, cuyas medidas difieren ligeramente.

**La escala global permanece en 1.0.** El aumento de envolvente de los OBJ viene de representarlos mediante rectángulos planos con márgenes alpha transparentes. La silueta se conserva de forma aproximada mediante esas máscaras, pero la topología y el muestreo de textura cambian. No es una conversión 1:1 de la malla. El informe muestra ambas envolventes, el error visual y el estado `review`.

A 128 px, la diferencia RGBA media fue 0 en la base; aproximadamente 1,092 en el rotor pequeño; 0,865 en el ensamblaje; 0,606 en la grande y 0,534 en la extensión, sobre canales de 0 a 255. Esta métrica incluye fondo y no demuestra por sí sola fidelidad geométrica. Las seis vistas y las diferencias completas están en el ejemplo incluido.

## Aplicación en ModBridge 2.4.1

- Se conserva la escala original y se informa el perfil de uso de cada geometría. No se recortan modelos a una celda.
- `model_profile` registra tamaños de fuente y destino, escala global, unidades por bloque y límites de visibilidad.
- La caja de visibilidad se calcula desde la geometría exportada, con margen de un bloque en ancho y alto totales y centro convertido al sistema de ejes Bedrock. Solo cambia la descripción del archivo: no altera cubos, pivotes, huesos ni UV. Cubre la pose estática, no futuras animaciones.
- El ensamblaje pequeño es una receta adicional identificada. Se mantienen disponibles base y rotor por separado.
- El panel de referencia muestra el uso geométrico real y las variantes de textura del addon.
- La salida contiene `.geo.json`, atlas PNG, originales, vistas y reportes. Se eliminaron el selector de bloques colocables, los paquetes de muestra, las definiciones de juego y los scripts de anclajes.
- La exportación completa y la parcial parten de una carpeta nueva para evitar incorporar packs antiguos al ZIP.

## Verificación y límites

Se aprobaron **127 pruebas automáticas** de geometría, UV, texturas, controles de proceso y API, incluidas pruebas específicas de escala grande, visibilidad, exclusión de archivos de juego y reexportación. La prueba con los cinco recursos reales terminó con una base `verified_static` y cuatro recursos `review`. Los ZIP de exportación pasan la comprobación CRC.

Se revisaron las láminas de seis vistas de la rueda grande y del ensamblaje pequeño. El visor conserva Alambre, Sólido, Texturas, Rayos X y Normales. Se comprobó la sintaxis de JavaScript; no se ejecutó el visor en un navegador real para esta revisión. No se probó en Windows ni dentro de Minecraft Bedrock. El registro preciso está en `VALIDACION_V241.json` y `pruebas_automatizadas_v241.txt`.

## Fuentes

Los datos de Water Wheel proceden de los dos archivos aportados por el usuario; sus hashes se incluyen en la auditoría JSON. Las reglas de formato se contrastaron con documentación primaria de Microsoft el 7 de noviembre de 2026:

1. [Advanced Block Visuals: Sizing and Culling](https://learn.microsoft.com/en-us/minecraft/creator/documents/customblockoversized?view=minecraft-bedrock-stable).
2. [Geometry 1.21.0: esquema del archivo](https://learn.microsoft.com/en-us/minecraft/creator/reference/content/schemasreference/schemas/minecraftschema_geometry_1.21.0?view=minecraft-bedrock-stable).


## Continuidad en 2.4.2

Esta investigación conserva los datos y resultados de la revisión 2.4.1. La versión 2.4.2 mantiene el mismo motor, escala y formato de geometría. Añade el indicador `extended3d` a los informes y al catálogo compacto y permite filtrar los modelos desde la biblioteca. La validación actual, incluidos un modelo normal de eje y las cinco piezas de rueda, se documenta en `VALIDACION_V242.md`. Los resultados históricos de 127 pruebas no sustituyen esa nueva ejecución.
