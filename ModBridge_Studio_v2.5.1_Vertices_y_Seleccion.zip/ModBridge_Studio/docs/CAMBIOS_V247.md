# ModBridge Studio 2.4.7 · Control maestro y regiones coplanares

Base: proyecto completo 2.4.6. Se conservan los recursos, lanzadores, historial, conversión, visor, filtros y exportador por perfiles. Las correcciones de geometría se obtienen al volver a convertir el JAR fuente; los resultados anteriores no se sobrescriben.

## Control maestro

La sección aparece al principio de **Exportación por perfiles**. Permite elegir el alcance «Todos los modelos del configurador» o «Solo los modelos marcados», aplicar una maestra común, reemplazar/añadir/quitar perfiles y copiar los ajustes del perfil activo a los perfiles elegidos.

Se copian perspectivas, modos, Rayos X, Normales, tres combinaciones, opacidad, resolución y representación. Los nombres de modelos y perfiles se conservan. El resumen anticipa cuántos modelos y perfiles cambiarán; las modificaciones se realizan al pulsar **Aplicar control maestro**. **Deshacer aplicación** restaura la configuración anterior mientras no se haya realizado otro cambio.

Si un perfil está compartido con modelos fuera del alcance, se crea una copia para aplicar los ajustes únicamente donde corresponde. La operación es atómica: si excede el límite existente de 32 perfiles, se rechaza sin aplicar cambios parciales. Se mantienen la selección de exportación y todos los controles individuales.

## Comparación en la exportación por perfiles

Se añade **Comparación (Java + Bedrock)** al selector de representación del perfil. Cada combinación se expande a dos trabajos reales con la misma cámara: original Java y destino Bedrock. El resumen calcula ambos PNG y el número de pares solicitados, también al aplicar ajustes con el Control maestro. Los modos individuales conservan su comportamiento.

Los archivos de comparación terminan en `_java.png` y `_bedrock.png` dentro de la carpeta del perfil. La deduplicación compara cada lado con todos los perfiles: si un render ya pertenece a otro perfil, no se duplica. El manifiesto `comparison_pairs` enlaza las dos rutas reales, sus perfiles propietarios y el resultado completo, parcial o fallido. Registra también si el destino solo es una malla diagnóstica. El límite existente de 100.000 imágenes considera ambos lados; no se oculta el coste de duplicar las representaciones.

Un lado inválido no impide exportar el otro ni los modelos siguientes. El motor conserva el encuadre común y solo retiene en memoria las representaciones del modelo actual. El ZIP conserva su formato y estructura anteriores, añadiendo los datos de comparación.

El nuevo adjunto `ModBridge_renders (2).zip` mezcla 522 imágenes Java con 1.044 Bedrock; estas últimas son idénticas a las del primer ZIP. Se reprodujeron exactamente 48 imágenes originales para contrastar su procedencia. Ver `ANALISIS_JAVA_RECIBIDO_V247.md`.

## Geometría corregida

La versión anterior unía parejas de triángulos y aproximaba el resto por separado. Un rectángulo formado por cuatro triángulos alrededor de un centro podía terminar con 252 rectángulos y perder el 1,5625 % del área. Ahora las regiones coplanares compatibles se reconstruyen antes de subdividir. Ese caso produce una sola cara y pasa las comprobaciones independientes de superficie y UV, también después de una rotación arbitraria.

La nueva unión cancela aristas compartidas de los polígonos originales. No usa una envolvente convexa. Conserva anillos interiores, huecos, orientación y multiplicidad de capas. Los triángulos de interpolación originales permanecen disponibles para el mapa UV; no se asigna un nuevo abanico sobre el contorno unido. Las caras con transferencia UV nativa no se convierten silenciosamente en mapas remuestreados para permitir una unión.

Las regiones unidas que siguen teniendo contornos oblicuos utilizan una precisión objetivo más fina, de 1/256 de unidad de modelo, y un cupo de subdivisiones proporcional a sus caras fuente. El límite total continúa siendo 12.000 rectángulos por modelo. La tolerancia real solicitada, el cupo y la condición de región unida quedan registrados por región. Estos parámetros son objetivos de aproximación, no una certificación de error máximo.

El plan conserva una referencia de la descomposición anterior. Las regiones aproximadas que no alcanzan su precisión por falta de presupuesto se revierten; si el nuevo plan pierde área o empeora la distancia de borde muestreada frente al anterior, se utiliza el anterior. Las advertencias y el reporte identifican esa decisión. Este control no convierte una aproximación pendiente en una traducción exacta.

## Texturas, memoria y conservación

Las coordenadas de interpolación de una región se comparten entre sus rectángulos. Cada rectángulo almacena un desplazamiento pequeño, evitando copiar toda la región miles de veces. Se reutiliza el cálculo afín de UV y se descartan del muestreo los triángulos cuya caja no intersecta el rectángulo. La búsqueda de adyacencias separa capas y rechaza aristas ambiguas, sin comparar cuadráticamente todos sus pares.

Las regiones unidas con UV remuestreadas reciben hasta cuatro veces la densidad base: con el ajuste predeterminado, 16 píxeles por unidad en lugar de 4. Esto reduce el error de fase introducido al unir varios mapas. Si el atlas no dispone de espacio, se reduce primero ese refuerzo (4, 3, 2, 1) antes de reducir la densidad base del mecanismo anterior. Las caras nativas conservan sus texels; el reporte registra el refuerzo y las dimensiones/densidades reales de cada parche derivado. Las posiciones y normales geométricas no cambian por este ajuste.

La exportación continúa procesando un modelo a la vez. No se agregaron dependencias de uso: NumPy y Pillow siguen siendo suficientes. El mayor detalle de algunas aproximaciones aumenta el número de caras, el tamaño de sus archivos y el tiempo de conversión; sigue vigente el límite por modelo.

Los originales no se modifican. Las superficies reconstruidas continúan en **Revisar** según la regla de 2.4.6, incluso cuando coinciden sus comprobaciones estáticas. Se conservan los casos de diagnóstico y los detalles de diferencias restantes.

## Alcance de «1:1»

La equivalencia de superficie se verifica sobre la geometría Bedrock exportada y decodificada. Se distingue de identidad de teselación, coincidencia de píxeles, fidelidad UV/material y ejecución dentro del juego. Una imagen sin grietas a cierta resolución no prueba exactitud del modelo completo.

Los polígonos arbitrarios que no pueden representarse exactamente mediante las caras rectangulares del destino siguen aproximados. `poly_mesh` permanece como respaldo diagnóstico: Microsoft lo documenta como obsoleto y sujeto a restricciones, por lo que no se presenta como una solución compatible universal. Fuentes oficiales y análisis del adjunto en `AUDITORIA_INDEPENDIENTE_V247.md` y `ANALISIS_RENDERS_V247.md`.

## Archivos principales

| Archivo | Cambio |
|---|---|
| `bridge/surface_regions.py` | Unión de regiones coplanares y conservación de límites/capas |
| `bridge/mesh_surface.py` | Regiones, UV originales, precisión y protección frente a regresiones |
| `bridge/surface_contours.py` | Anillos, huecos, presupuesto y mediciones por región |
| `bridge/surface_adapter.py` | Explicación de reconstrucción y decisiones de conservación |
| `web/render_config.js`, `web/render_dialog.js` | Control maestro, planificación de cambios y deshacer |
| `web/index.html`, `web/style.css` | Controles integrados y diseño adaptable |
| `bridge/__init__.py`, `bridge/render_export.py` | Versión 2.4.7 y versión del manifiesto obtenida del programa |

Las pruebas nuevas inspeccionan la salida real, sus píxeles y su descarga; no sustituyen el renderizador por imágenes simuladas. Resultados completos en `VALIDACION_V247.md`.
