# ModBridge Studio 2.4.2 — cambios sobre 2.4.1

## Base y alcance

Base aprobada: `ModBridge_Studio_v2.4.1_Solo_Modelos3D(1).zip`, 294 archivos, 5.257.014 bytes, SHA-256 `b4218cb86b055bb980af7d5f4c12fad637e2ca388e64cb231580a24ffcdb3ece`. Se comprobó el CRC, se analizó la estructura y se ejecutaron las 127 pruebas originales antes de implementar. El plan se presentó tras el análisis y el usuario autorizó expresamente todo el trabajo.

La herramienta continúa dedicada al port estático de modelos 3D. Se conservan los motores de conversión, las geometrías grandes, texturas, UV, seis vistas, visor WebGL, Alambre, Sólido, Texturas, Rayos X, Normales, cancelación, revisión individual y exportación parcial. No se añaden bloques, entidades de juego ni scripts de Minecraft.

## Funciones nuevas

- Cuatro filtros excluyentes basados en los colores de resultado existentes: verde (`verified_static`), ámbar (`review`), rojo (`unsupported` y `error`), turquesa (`no_renderable`). Los pendientes no forman una quinta categoría de resultado.
- Casilla «Modelo 3D extendido», combinable con color y búsqueda.
- Casilla «Ordenar A-Z», disponible desde la carga del JAR. Ordena por nombre mostrado y luego identificador completo, sin modificar el catálogo original.
- Contador de coincidencias sobre el total, actualizado al filtrar y al recibir resultados.
- Selección aplicada a todas las páginas del resultado filtrado; aviso de selecciones ocultas conservadas.

## Contrato de datos

El catálogo compacto pasa de `{id, slug, status}` a `{id, slug, status, extended3d}`. Se conserva el nombre y significado de los tres campos originales; el cuarto es un booleano. Los detalles geométricos, texturas y métricas siguen fuera de la respuesta compacta.

`extended3d` se obtiene del perfil ya calculado. Es verdadero si la fuente o el destino tiene medidas válidas y presenta `extent_over_30` o `outside_origin_bounds`. La falta de volumen de una cara plana, por sí sola, no activa el indicador. La marca describe tamaño o posición y no certifica conversión satisfactoria. Un modelo grande que requiere revisión o permanece en diagnóstico puede seguir marcado.

La función compartida de compactación conserva el indicador en `ready.json`, `ready.ndjson`, `completion.json`, `Studio.status()`, resultados normales y compactos y exportaciones completas o parciales. Los informes antiguos completos pueden recuperar la marca de su `model_profile`; una marca desconocida no se inventa a partir del nombre.

El navegador combina los catálogos de finalización y modelos listos, priorizando el resultado más reciente. Detecta cambios de estado o tamaño aunque el número de modelos permanezca igual. Los nuevos campos son aditivos; las rutas HTTP, los identificadores y el formato de modelos se mantienen.

## Corrección de la selección de conversión

Antes, el navegador enviaba solo el texto de búsqueda cuando no había selección. Ese mecanismo no podría representar filtros por resultado o tamaño. Ahora envía la lista exacta de identificadores que coinciden con los filtros. La lista vacía no dispara una petición que el servidor pudiera interpretar como «convertir todos».

Las selecciones explícitas se conservan aunque sus filas queden ocultas, como en la base; el contador informa de ello. Al cambiar recursos o iniciar un lote nuevo se restablecen color y tamaño para no aplicar datos obsoletos.

## Archivos y responsabilidades

| Archivo | Cambio |
|---|---|
| `bridge/catalog.py` | Nuevo contrato compacto e interpretación de `extended3d`. |
| `bridge/pipeline.py` | Escribe el indicador en informes y marcadores; usa la versión de aplicación centralizada. |
| `worker.py` | Usa la compactación compartida al terminar cualquier operación. |
| `app.py` | Conserva el indicador en la API completa y compacta; toma la versión central. |
| `bridge/__init__.py` | Versión de aplicación 2.4.2. |
| `web/library.js` | Lógica pura de filtros, ordenación, selección y combinación de catálogos. |
| `web/app.js` | Conecta controles y datos; actualiza contador y paginación; envía selección filtrada. |
| `web/index.html`, `web/style.css` | Controles, ayuda y estilos con iconos y paleta existentes. |
| `tests/test_app_v2.py` | Amplía la comprobación estricta del catálogo a cuatro campos y exige ausencia de métricas. |
| `tests/test_library_catalog.py` | Regresiones de tamaño, compactación, worker, CLI, vista individual y exportación parcial. |
| `tests/test_library.cjs` | Regresiones de filtros, A-Z, selección y actualización de metadatos, sin dependencias externas. |
| `tests/test_library_browser.cjs` | Pruebas de los controles en navegador, HTTP/worker real y casos de catálogo de 245 modelos. |
| README, guía inicial y documentación | Instrucciones y resultados de 2.4.2; historial preservado y referencias corregidas. |

El registro exacto de archivos añadidos, modificados y reubicados se genera en `COMPARACION_V241_V242.json`. El parche de texto acompaña ese registro. Los recursos vanilla y los módulos de geometría, renderizado, OBJ, paletas, sprites y visor 3D se conservan.

## Versionado y CLI

Aplicación: **2.4.2**. Geometría Bedrock: **1.21.0**. Previsualización interna: **2**. La base adjunta 2.4.1 no contiene `port_map`, `port_map['version']` ni `--port-mode`. La referencia inicial a esos elementos pertenecía a una base distinta y se documenta aquí, sin introducir formatos o argumentos ficticios.

Se conservan los argumentos reales de `convert`: `--input`, `--reference`, `--dependency`, `--mesh-mode {surface,exact}`, `--output`, `--model`, `--filter` y `--size`. `serve` mantiene `--port`, `--no-browser`, `--workspace` y las opciones de carga. No se cambian versiones de formatos ni identificadores al ordenar la biblioteca.

## Validación

Los resultados ejecutados y las limitaciones del entorno se detallan en `VALIDACION_V242.md` y `VALIDACION_V242.json`. No se sustituyen las comprobaciones geométricas por similitud de imagen y no se cambia el estado aproximado de los modelos OBJ. La comparación de geometrías y atlas entre 2.4.1 y 2.4.2 se conserva como evidencia adicional.
