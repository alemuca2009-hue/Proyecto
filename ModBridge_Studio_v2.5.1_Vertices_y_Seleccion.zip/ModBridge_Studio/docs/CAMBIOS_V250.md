# ModBridge Studio 2.5.0

## Controles de conversión

- **Pausar**, gris, cambia a **Continuar**, verde. La solicitud se aplica en el siguiente punto seguro; mientras tanto se muestra **Pausando…**. Al confirmar el trabajador, el estado es **Conversión en pausa**. Continuar utiliza el mismo proceso y conserva su avance.
- **Detener** sigue disponible durante la pausa. No es necesario continuar antes de cancelar.
- **Reiniciar seleccionados** procesa únicamente los identificadores marcados. Nunca utiliza los filtros como alternativa a una selección vacía. Sin selección, el botón está deshabilitado y al pasar el cursor se lee **Ocupas seleccionar modelos**; el aviso también está disponible al enfocar su contenedor con el teclado.
- El reinicio requiere que termine o se detenga cualquier tarea activa. Los resultados completos de los modelos no seleccionados se copian al nuevo lote sin reconvertirlos. El ZIP nuevo incluye esos resultados y los modelos recién procesados.
- Durante el reinicio se conservan los resultados previos hasta sustituirlos. Si se interrumpe, el ZIP previo se identifica como **Descargar ZIP anterior**. **Exportar terminados** permite crear un resultado parcial con los modelos completos del nuevo lote.

La pausa controla el trabajador de conversión, incluidas sus comparaciones y su empaquetado. El exportador independiente de renders por perfiles conserva su propio botón de cancelación; durante esa tarea la pausa principal está deshabilitada.

## Algoritmo separado y repasos

La conversión permanece en `conversion_engine/`. La base por cara y el atlas proceden de la 2.4.4. Sobre esa base se añade `adaptive.py`, sin volver a activar indiscriminadamente el motor de regiones de 2.4.5–2.4.8.

1. Genera el resultado base y decodifica la geometría Bedrock.
2. Comprueba de forma independiente si las superficies coinciden. Si coinciden, no repite la conversión.
3. Recupera grupos de caras solo si forman un rectángulo, mantienen orientación y multiplicidad, no contienen huecos y admiten una misma transformación UV afín continua. Los vértices y UV exteriores proceden de la fuente.
4. Realiza hasta dos repasos por defecto, con contornos más finos y mayores presupuestos. Cada candidato se construye por separado.
5. Acepta un candidato únicamente si no aumenta ni el área omitida ni la saliente, no reduce la densidad nominal de muestreo y reduce estrictamente la suma de errores. Si falla un intento, conserva el resultado anterior.
6. Termina al comprobar coincidencia o al agotar los intentos. Las aproximaciones siguen identificadas como tales; no se altera el original para hacer coincidir la comparación.

El reporte `adaptive_refinement` registra configuración, intentos, motivos de rechazo, resultado seleccionado y comprobación independiente. La interfaz muestra el número de repaso mientras se ejecuta.

## Coste y límites

Los repasos pueden producir más rectángulos, archivos mayores y conversiones más lentas. Dos intentos es un límite de trabajo, no una promesa de exactitud. Hay polígonos que no admiten una representación exacta mediante un número finito de rectángulos; una máscara transparente no elimina físicamente la superficie de un plano envolvente.

La coincidencia geométrica no garantiza igualdad de texeles ni ejecución en Minecraft. Las superficies adaptadas conservan la categoría **Revisar**. El modo **Solo exactos** mantiene su comportamiento de diagnóstico para las mallas no representables y no ejecuta estos repasos.

Versiones: aplicación y algoritmo **2.5.0**, base **2.4.4**, API del motor **1.1.0**. Se mantienen la biblioteca, el control maestro, los perfiles y el visor. Extrae la actualización en una carpeta nueva y vuelve a procesar el JAR fuente.
