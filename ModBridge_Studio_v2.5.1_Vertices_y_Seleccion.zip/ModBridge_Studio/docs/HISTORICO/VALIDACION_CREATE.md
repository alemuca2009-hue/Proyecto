# Validación realizada con los archivos suministrados

Se procesó el JAR `create-1.21.1-6.0.10.jar` completo y se analizó `create_addon.mcaddon` como referencia. La conversión se realizó sin un JAR cliente vanilla adicional: las dependencias ausentes se informan, no se inventan.

## Resultado del lote

| Resultado | Modelos |
|---|---:|
| Verificados estáticamente | 1.302 |
| Geometría producida, con revisión pendiente | 336 |
| No convertidos al destino compatible | 1.046 |
| Errores de ejecución por modelo | 0 |
| Total examinado | 2.684 |

Los 1.046 no convertidos se distribuyen en 759 padres ausentes, 161 ítems generados/renderizadores dinámicos, 85 recursos que utilizan mallas OBJ restringidas, 27 plantillas sin texturas asignadas y 14 recursos sin superficies estáticas. El número de recursos OBJ incluye herencia y composición: no equivale al número de archivos `.obj` distintos.

El lote incluye **48.312 PNG por lado y representación**: 2.684 modelos × 6 lados × 3 archivos (original, traducido, diferencia). También se incluyen láminas comparativas cuando existe geometría evaluable. Para recursos sin superficies disponibles se emplean imágenes de diagnóstico claramente identificadas; estas imágenes no cuentan como conversiones logradas.

La exportación de prueba contiene **1.442 entidades estáticas**. De ellas, 1.302 proceden de recursos verificados y 140 mantienen revisión por contexto, animación, tamaño u otros avisos. Se excluyen todos los recursos no convertidos y los que tienen texturas fuente ausentes. El manifiesto y las referencias entre geometría, entidad y atlas fueron comprobados automáticamente; el juego no se ejecutó.

## Casos reales comprobados

- `create:block/shaft`: conservación de las seis superficies y de las texturas de eje y tapas.
- `create:block/large_cogwheel`: conservación de las dimensiones originales; el addon aportado modifica algunas de estas dimensiones y por eso no se usa como patrón exacto.
- `create:block/basin/block`: elemento con Y invertido convertido mediante planos positivos, con superficie, normales y UV equivalentes.
- Piezas con coordenadas fraccionarias, rotaciones de 22,5° y 45°, y `rescale`.
- Ruedas OBJ: malla preservada para diagnóstico y edición, sin introducir `poly_mesh` en el addon importable.
- Texturas animadas y recursos vanilla ausentes: estados de revisión/no conversión en lugar de equivalencia falsa.

La regresión específica examinó **158 recursos resueltos con dimensiones invertidas**: 141 pasaron la validación estática y 17 quedaron para revisión por recursos/contexto. No hubo discrepancias de posiciones, normales o UV en la descomposición.

## Comprobaciones y correcciones

La batería final contiene **45 pruebas automáticas aprobadas**, con resultados esperados independientes del conversor para coordenadas asimétricas, pivotes y rotaciones; UV superior/inferior, UV invertidas/rotadas; escala real de texturas; alfa parcial y RGB invisible; caras omitidas; planos; atlas; JSON con comentarios de la referencia; extracción segura; empaquetado y rutas portables. Las pruebas alteran deliberadamente vértices y UV del resultado para comprobar que la validación detecta diferencias.

También se comprobó el ciclo HTTP real de cargar un recurso, convertirlo, consultar el progreso, descargar el ZIP y leer una imagen. Se verificaron restricciones de Host/origen/token, límites de carga y rutas maliciosas. El archivo ZIP pasó la comprobación CRC, todos los modelos tienen sus seis carpetas, los recursos originales exportados coinciden byte por byte con el JAR y los enlaces del IR y del addon apuntan a archivos existentes.

Durante el desarrollo se corrigieron la serialización de dimensiones negativas, la detección independiente de diferencias visuales, la selección de material con alfa parcial, las rutas exportadas, la notificación de cancelaciones, la exclusión de texturas de diagnóstico del addon y las colisiones de identificadores.

## Lo que no se ha probado

No se abrió Minecraft Java/Bedrock ni Blockbench en este entorno. No se certifican carga del pack, colisiones, iluminación, sombreado, descarte de caras traseras, transparencia ordenada, animación o mecánicas. Las imágenes fueron generadas por el rasterizador propio a 128 píxeles, con cámara y escala compartidas.

La interfaz superó validaciones de sintaxis y referencias HTML/JavaScript, y el backend pasó integración HTTP. La comprobación visual de la interfaz en navegador no pudo ejecutarse porque el entorno no contenía el binario de navegador requerido. No se presenta como un ensayo visual completado. El lanzador Windows se entrega como script, sin afirmar una ejecución nativa de Windows en este entorno Linux.

`VALIDACION.json` conserva el resumen verificable. Los informes completos por recurso están en `Resultado_Create_6.0.10/reportes/` dentro del ZIP de entrega.
