# ModBridge Studio 2.3 — modos 3D, rayos X y normales

## Controles

En **Geometría 3D**, la barra ofrece tres modos, en el orden de las referencias:

| Control | Resultado |
|---|---|
| Alambre | Aristas de los polígonos. Sin Rayos X se ocultan las aristas posteriores; con Rayos X se muestran con opacidad ajustable. |
| Sólido | Superficies con sombreado neutro, sin las texturas. |
| Texturas | Texturas reales del modelo y del atlas Bedrock, incluidas sus transparencias. |
| Rayos X, dos cuadrados superpuestos | Botón independiente de encendido/apagado. Hace transparentes las superficies y permite ver las aristas ocultas. El deslizador aparece solo mientras está activo. |
| Normales ON/OFF | Azul para el exterior de las caras y rojo para el interior. Apagarlo recupera el modo seleccionado. |

No se incorpora el cuarto círculo de renderizado de la referencia. Los tres
modos usan iconos circulares; Rayos X conserva el botón de cuadrados superpuestos.
El switch de Normales muestra explícitamente ON/OFF y una leyenda de colores.

Los controles conservan la paleta verde/lima del programa. Se sitúan encima de
los lienzos, en filas flexibles, sin cubrir el modelo. En pantallas pequeñas,
las vistas se apilan y los ajustes ocupan filas separadas.

Los cambios se aplican simultáneamente a Original Java y Traducido Bedrock.
Modo, Rayos X, opacidad y Normales se recuerdan en el navegador. Se migra la
preferencia anterior de texturas al modo equivalente. **Restablecer** solo
restaura la cámara. Las flechas permiten recorrer los modos con teclado.

## Implementación

- La orientación se determina por el orden original de los vértices y
  `gl_FrontFacing`. No se invierten caras automáticamente: una cara invertida
  debe seguir visible en rojo para poder diagnosticarla.
- Normales reemplaza temporalmente el color de las superficies. Con Alambre
  colorea sus aristas según la cara a la que pertenecen. Se ignoran las máscaras
  alpha mientras está activo para inspeccionar toda la superficie geométrica.
- El modo Alambre usa los perímetros originales. La triangulación interna de
  un cuadrilátero no añade una diagonal al visor.
- Una pasada de profundidad oculta las aristas posteriores cuando Rayos X está
  apagado. Al activarlo se dibujan también las ocultas con la opacidad indicada.
- Se conservan la oclusión por píxel y las pasadas de transparencia de 2.2.
  Las texturas solo se solicitan al necesitarlas; los recursos gráficos de un
  modelo se liberan al cambiar de selección.
- La conversión, las seis vistas de auditoría, los PNG y la geometría exportada
  no cambian al usar estos controles.

## Validación

- Pruebas de navegador con Chromium y WebGL por software: los tres modos,
  recuperación de las texturas, giro sincronizado, restablecimiento de cámara,
  persistencia de las preferencias y navegación por teclado.
- Comprobaciones de píxeles: azul exterior, rojo interior al girar la cámara,
  rojo con vértices invertidos, restauración de textura al apagar Normales,
  alambre sin diagonales, opacidad de Rayos X y revelado de aristas ocultas.
- Se mantienen las pruebas de profundidad independiente del orden de caras,
  agujeros alpha, mezcla semitransparente, orientación UV y texturas de tamaño
  no potencia de dos. Sin errores JavaScript ni WebGL.
- Se comprobaron controles sin intersecciones, fuera de los lienzos y sin
  desbordamiento horizontal en anchos de 1440, 1120, 900, 768, 660, 520, 390 y
  360 px, con ambos switches y sus ajustes visibles. Revisión visual en escritorio
  y móvil.

Los resultados exactos y la ejecución Python están en `VALIDACION_V23.json`.

```sh
python -m unittest discover -s tests -v
node tests/test_viewer_browser.cjs
```

La segunda orden es una prueba opcional para desarrollo y requiere Node,
Playwright y Chromium. No son dependencias para usar ModBridge. Puede indicarse
`CHROMIUM_EXECUTABLE` para seleccionar el navegador instalado.

## Límites conservados

- La orientación azul/rojo es una herramienta de inspección de caras, no una
  reparación de normales ni una representación de vectores con flechas.
- Rayos X mezcla caras semitransparentes ordenadas por su centro. Superficies
  que se intersectan pueden presentar el límite habitual de esa ordenación.
- El preview conserva su máximo de 4.000 caras por representación y avisa si
  se aligera. Las seis vistas y la exportación usan la geometría completa.
- El visor requiere WebGL. Las seis vistas siguen disponibles si falta soporte.
- La validación se realizó en Linux/Chromium; no se ejecutó Windows ni Minecraft
  Bedrock en este entorno.
