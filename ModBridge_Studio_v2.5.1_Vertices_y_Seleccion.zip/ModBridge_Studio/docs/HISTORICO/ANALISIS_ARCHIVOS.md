# Análisis de los archivos Create suministrados

Análisis estático de los dos archivos suministrados; no ejecución dentro de Minecraft ni descompilación completa.

## Inventario medido

| Recurso | Java JAR | Bedrock MCADDON |
|---|---:|---:|
| Archivos ZIP (incluidas carpetas) | 12536 | 2349 |
| Modelos JSON / archivos geométricos | 2684 | 211 |
| Definiciones geométricas Bedrock | — | 248 |
| OBJ / MTL | 39 / 27 | 0 / 0 |
| PNG totales | 1295 | 812 |
| Cubos Bedrock / poly_mesh | — | 3334 / 0 |
| Blockstates / animaciones | 643 | 43 |

Los 2.684 JSON no equivalen a 2.684 objetos visibles independientes: abundan la herencia, las variantes, las piezas parciales y los modelos de ítem. Hay 1.288 referencias directas a 26 nombres de padres ausentes del JAR; principalmente plantillas de Minecraft vanilla. Debe facilitarse el JAR cliente de la misma versión o un pack con esos recursos. No sustituir dependencias desconocidas por cubos genéricos sin señalarlo.

Se encontraron 43 declaraciones `neoforge:obj`, 7 `neoforge:composite`, 119 clases cuyo nombre termina en `Renderer` y 63 en `Visual`. Estas cantidades describen nombres/recursos, no un inventario certificado de todos los renderizadores dinámicos. El resto de JSON tampoco implica necesariamente que el aspecto final sea estático.

La geometría Bedrock tiene versiones 1.12.0 (71 definiciones), 1.21.0 (49), 1.21.20 (10) y 1.21.110 (118). El manifiesto de recursos pide motor 1.21.50 y el de comportamiento 1.26.0. Debe leerse el manifiesto real en lugar de deducir la compatibilidad por el nombre del archivo.

## Tamaños y formas fuera del cubo

Se encontraron 2.731 elementos declarados directamente en JSON Java: 762 tienen alguna coordenada fuera de [0,16], 113 tienen al menos un eje invertido y 4 usan `rescale`. Estos totales no incluyen duplicaciones por herencia ni los elementos dentro de composite. Hay giros de ±22,5° y ±45°. El addon tiene 33 cubos con tamaño negativo y ninguna malla `poly_mesh`; varias mallas OBJ fueron reconstruidas con cubos.

Las superficies de tamaño cero, los planos internos y los ejes invertidos necesitan preservar el orden de vértices, las caras declaradas y las UV; aplicar `min/max` y volver a generar seis caras destruye información. `rescale` requiere el factor secante en los ejes perpendiculares al giro. Los pivotes tienen que transformarse junto con la geometría.

Los OBJ deben conservar índices independientes de posición/UV/normal, materiales, grupos, signos, `flip_v` y triángulos/cuadriláteros. Sus unidades no son las mismas que los elementos JSON: el OBJ se expresa en bloques y requiere factor 16 para unidades del modelo. El JSON `neoforge:obj` no contiene los vértices; solo apunta a la malla y a la configuración.

## Comparaciones concretas

### shaft

Java: `assets/create/models/block/shaft.json`.

Bedrock: `Create(RE)/models/blocks/conductors/shaft.geo.json`.

Un cubo Java de dimensiones [4,16,4]. Dos geometrías Bedrock alternativas de un cubo cada una.

from [6,0,6] se centra en origin [-2,0,-2]; pivot [8,8,8] pasa a [0,8,0].

Bedrock aplica rotation [-90,0,0] o [-90,-90,0] para orientación de entidades; se requiere separar pose base, estado y animación.

La textura lateral se copia sin remuestreo. La tapa se gira 180° en el atlas. Todos los recortes medidos coinciden RGBA tras esa transformación.

**Resultado:** Conserva dimensiones y recortes analizados; no se declara equivalencia total de pose/animación.

### cogwheel

Java: `assets/create/models/block/cogwheel.json`.

Bedrock: `Create(RE)/models/blocks/conductors/gear.geo.json`.

Siete elementos Java y siete cubos Bedrock. Dientes [18,3,3] y [3,3,18], cuerpo [12,2.9,12], eje [4,16,4].

Rotaciones Java Y ±45° pasan a rotaciones combinadas Bedrock con X -90° y Z ±45°.

Java usa tres PNG para las caras: cogwheel 32×32, cogwheel_axis 16×16 y axis_top 16×16; Bedrock consolida en un PNG 32×32.

Se verificaron franja del eje, tapa, lateral y cara superior del diente por igualdad RGBA.

**Resultado:** Coincidencia parcial verificada; es necesario reconstruir matrices completas y las caras para una prueba total.

### large_cogwheel

Java: `assets/create/models/block/large_cogwheel.json`.

Bedrock: `Create(RE)/models/blocks/conductors/large_gear.geo.json`.

16 elementos Java; dientes Java miden 30×2.95×3 o 3×2.95×30.

En el addon se encuentran dientes [29.48268,2.95,2.99655] y [29.5,2.95,3], además de un hueso rotation con [0,0,11.25].

La textura principal Java es 32×32; atlas Bedrock 64×64. Más resolución de atlas no implica mayor resolución efectiva del texel.

**Resultado:** No es 1:1 dimensional con el archivo Java proporcionado. La diferencia es explícita; no se propone usar este port como verdad geométrica.

### basin

Java: `assets/create/models/block/basin/block.json`.

Bedrock: `Create(RE)/models/blocks/basin.geo.json`.

Tres elementos Java: exterior [16,14,16], interior [12.1,-14,12.1], base [12,2,12]. La coordenada Y invertida produce caras interiores.

El addon contiene ocho cubos: cuatro en hueso basin y cuatro en canal. El hueco se reconstruye con cubo positivo y una superficie plana de altura cero.

No comparar automáticamente el archivo completo Bedrock contra el único modelo block: agrega el canal.

PNG 32×32 Java y Bedrock idénticos RGBA, pero distintos bytes de archivo. Geometría Bedrock declara 16×16, por lo que UV debe escalarse respecto a ese tamaño declarado.

**Resultado:** Textura completa equivalente; geometría/ensamblaje distinto. No normalizar tamaños negativos sin preservar winding y UV.

### water_wheel

Java: `assets/create/models/block/water_wheel/wheel.json`, `assets/create/models/block/water_wheel/block.json`, `assets/create/models/block/water_wheel/item.json`, `assets/create/models/block/water_wheel/water_wheel.obj`.

Bedrock: `Create(RE)/models/blocks/generators/water_wheel.geo.json`.

Loader neoforge:obj con flip_v=true; OBJ contiene 808 posiciones, 1880 UV, 18 normales y 1276 caras.

OBJ usa mtllib water_wheel.mtl; map_Kd contiene alias #axis, #axis_top, #log, #metal y #planks. Resolver por el JSON de texturas heredado.

La madera oak_log/oak_planks procede de assets de Minecraft vanilla, ausentes en el JAR Create. El ítem usa spruce_log/spruce_planks.

Addon separa bloque de 9 cubos, entidad de 201 cubos e ítem de 210 cubos. El ítem aplica escala 0.93 en las piezas examinadas (16→14.88).

El OBJ tiene límites [-0.5,0,-0.5] a [1.5,1,1.5] en unidades OBJ (bloques), es decir dimensión 32×16×32 en unidades de modelo.

**Resultado:** La reconstrucción Bedrock no demuestra equivalencia del OBJ; es una conversión de malla a una unión de cubos y un ensamblaje dependiente de uso.

### crushing_wheel

Java: `assets/create/models/block/crushing_wheel/block.json`, `assets/create/models/block/crushing_wheel/item.json`, `assets/create/models/block/crushing_wheel/crushing_wheel.obj`.

Bedrock: `Create(RE)/models/blocks/machines/crushing_wheel.geo.json`.

OBJ contiene 242 posiciones, 156 UV, 25 normales y 268 caras. Límites [-0.570326,0,-0.570326] a [1.570326,1,1.570326].

Addon ofrece dos geometrías de 52 cubos cada una (normal e ítem).

El ítem utiliza escala 0.85: primer cubo normal [4,4,16], ítem [3.4,3.4,13.6]. Atlas de 64×64.

El número de cubos o de caras, por sí solo, no prueba equivalencia. La comparación debe hacerse sobre superficies con posiciones, normales, UV y cobertura.

**Resultado:** Representación alternativa que requiere validar malla y pose; no se puede afirmar 1:1 por coincidencia del nombre.

## Texturas: resultados y reglas de conversión

447 PNG del addon coinciden con alguna textura Java en dimensión y buffer RGBA decodificado. La igualdad de un hash de PNG no es necesaria: basin cambia la codificación PNG y conserva todos los píxeles. La coincidencia de píxeles no demuestra que el archivo esté asignado a las mismas caras.

| Recorte comprobado | Región Java (x0,y0,x1,y1) | Región Bedrock | Giro aplicado a Java | RGBA idéntico |
|---|---|---|---:|---|
| shaft_side | [6, 0, 10, 16] | [0, 0, 4, 16] | 0° | Sí |
| shaft_cap | [6, 6, 10, 10] | [4, 0, 8, 4] | 180° | Sí |
| cogwheel_shaft | [6, 0, 10, 16] | [0, 12, 4, 28] | 0° | Sí |
| cogwheel_cap | [6, 6, 10, 10] | [4, 18, 8, 22] | 180° | Sí |
| cogwheel_tooth | [14, 16, 32, 19] | [4, 12, 22, 15] | 0° | Sí |
| cogwheel_tooth_top | [14, 12, 32, 15] | [12, 8, 30, 11] | 0° | Sí |

Estos ensayos demuestran reempaquetado sin remuestreo de los recortes indicados; no prueban todos los píxeles de todos los modelos. El atlas puede cambiar dimensiones sin modificar resolución efectiva de las caras. Debe guardarse el PNG original intacto, registrar posición del recorte en el atlas y validar píxeles por cara después de aplicar UV/orientación. No usar interpolación bilineal ni compresión con pérdida.

En Java las UV JSON se expresan normalmente en el dominio 0–16 y se escalan por la resolución real de la textura. En Bedrock la escala se obtiene de texture_width/texture_height declarados en la geometría; estos valores pueden diferir del tamaño real del PNG. El addon basin evidencia esa diferencia. Los valores UV negativos, los giros 90/180/270° y las regiones invertidas deben interpretarse, no recortarse silenciosamente.

Los materiales MTL de Create usan `map_Kd #alias`; no tratar esos alias como rutas de archivos. Resolverlos mediante la herencia del JSON. Las referencias a `minecraft:` requieren recursos vanilla. Los `.png.mcmeta` con animación requieren retener todos los fotogramas y el tiempo; una imagen del primer frame es solo una referencia estática. Las texturas conectadas, el tinte, la luminosidad y la translucidez tienen lógica adicional y no quedan probados por conservar RGBA.

## Ensamblajes y comportamiento

Los blockstates Java seleccionan variantes por propiedades, giros x/y y multipart. Los renderizadores aportan piezas parciales en tiempo de ejecución. El addon usa entidades de representación, huesos, animaciones Molang y scripts; por ejemplo `q.property('create:rpm')` alimenta la rotación. La conversión de archivos geométricos no traduce automáticamente mecánicas, RPM, redes, inventarios ni clases Java.

Para comparar una rueda hay que distinguir soporte estático, pieza giratoria, ítem y pose. La rueda grande contiene 58 cubos para el bloque y 442 para entidad/ítem. El OBJ grande contiene 1.252 posiciones, 3.236 UV, 18 normales y 2.136 caras; sus límites son aproximadamente [-1.937501,-0.09375,-1.937501] a [2.9375,1.09375,2.9375]. Un solo cubo de bloque no puede sustituir ese conjunto a escala real.

## Validación propuesta

Primero reconstruir cada representación por separado hacia una malla intermedia: posiciones, índices de caras, normales, UV, material, transformaciones y procedencia. Después comparar dimensiones, posiciones transformadas, normales/orientación de superficie, áreas y asignación de píxeles. El límite visual compartido para ambas cámaras se obtiene de la unión de sus cajas; no autoencuadrar cada lado por separado, pues ocultaría errores de escala.

Las seis vistas son frontal, trasera, izquierda, derecha, superior e inferior. Deben compartir proyección ortográfica, escala, iluminación, pose y fotograma. Mantener las imágenes originales y traducidas separadas y producir además diferencia y superposición opcionales. Error visual bajo no sustituye la prueba geométrica: una cavidad o cara oculta podría no verse en las seis proyecciones.

Las salidas requieren estados distintos: verificado en el alcance estático, parcial con limitaciones, bloqueado por dependencia, y no soportado. No declarar 1:1 para renderizadores Java no ejecutados, mallas aproximadas o texturas ausentes. Debe existir reporte individual con propiedades preservadas, cambios, errores y tareas concretas para corregir.

## Compatibilidad de lectura y trazabilidad

Se detectaron 9 JSON Bedrock que no se leen como JSON estricto (tras retirar BOM). El parser debe aceptar comentarios y comas finales de manera consciente, sin sustituir cadenas de texto con expresiones regulares indiscriminadas. Los 211 archivos geométricos pudieron leerse para este inventario.

El archivo JSON adjunto conserva inventarios, rutas, tamaños, hashes de entrada, comparaciones por recorte y coincidencias RGBA. No se ha ejecutado Minecraft ni descompilado exhaustivamente el JAR en este análisis; los conteos y ejemplos son evidencias estáticas y reproducibles de los archivos entregados.

## Licencias incluidas en el original

`LICENSE.md_create-1.21.1` declara los recursos de `assets/` como All Rights Reserved y el resto del código como MIT. El manifiesto Bedrock atribuye el addon a Vatonage. Conservar atribuciones y separar el código nuevo de los recursos importados; la conversión local no concede permisos de redistribución.

## Transcripción de la licencia incluida

Fuente exacta: `LICENSE.md_create-1.21.1` dentro del JAR suministrado.

```text
# License Overview

## Assets License (All Rights Reserved)

All Rights Reserved

Copyright (c) The Create Team / The Creators of Create

This license applies to any files under the following directories:

- ./src/main/resources/assets/

---

## Code License (MIT)

All other files are licensed under the MIT License:

MIT License

Copyright (c) The Create Team / The Creators of Create

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

```
