# ModBridge Studio 2.0: correcciones verificadas

La revisión partió de los 1.046 archivos no convertidos y de los 336 con avisos en la primera entrega. No se cambió su etiqueta para simular éxito: se añadieron los adaptadores y recursos que faltaban, y se repitió la conversión.

## Deficiencias corregidas

1. **Dependencias vanilla no incluidas.** Se incorpora un paquete de 4,34 MB con los 8.447 recursos originales de `assets/minecraft` del cliente Java 1.21.1. El cliente se descargó desde la URL oficial de Mojang y su SHA-1 se comprobó contra el manifiesto oficial: `30c73b1c5da787909b2f73340419fdf13b9def88`. Los 2.684 recursos de Create ahora resuelven todos sus padres. La procedencia se conserva en `bridge/data/vanilla_1.21.1.zip/MODBRIDGE_VANILLA_PROVENANCE.json`. Las dependencias proporcionadas por el usuario tienen prioridad sobre este respaldo.

2. **Extrusión de sprites no implementada.** Los ítems `item/generated` y `item/handheld` ahora producen frente, dorso y bordes con el espesor, UV y tramos de contorno del algoritmo Java 1.21.1. Se contrastó con la clase oficial `gge` (ItemModelGenerator) mediante Vineflower. Se contemplan huecos, capas, resolución real, transparencia y signos de coordenadas. Los tintes que dependen de proveedores de color del juego siguen identificados como contexto pendiente.

3. **Texturas de atlas generadas ignoradas.** Se implementa `paletted_permutations`: fuentes de atlas apiladas, correspondencias RGB, alfa multiplicativo entero, preservación de RGB invisible y trazabilidad de la plantilla y ambas paletas. Se contrastó con la clase oficial `gqw` del cliente. Esto resuelve las 40 texturas de adornos de armadura que no existen como PNG independientes dentro del mod. Se conservan las fuentes originales y la receta; los PNG derivados se identifican como generados.

4. **OBJ únicamente exportado como `poly_mesh` restringido.** El modo predeterminado «Superficies aproximadas» produce planos rotados de geometría Bedrock normal, con máscaras RGBA que reproducen el contorno. Las 85 entradas OBJ antes bloqueadas se pudieron procesar en la regresión. El atlas derivado está remuestreado y la topología usa rectángulos: es una aproximación, nunca una equivalencia geométrica 1:1. «Solo exactos» conserva la política anterior y mantiene esas mallas pendientes. Los originales y una alternativa OBJ editable permanecen disponibles.

5. **Plantillas contadas como objetos terminados fallidos.** Se clasifican por evidencia sus hijos, descendientes concretos, blockstates y referencias. Una definición sin textura autónoma, utilizada por modelos concretos, se muestra como «Plantilla»; sus hijos se convierten por sus identificadores. Estas definiciones no se suman a conversiones logradas. Los recursos sin evidencia suficiente permanecen pendientes.

6. **Resultados antiguos después de cambiar entradas.** Cargar otra dependencia o referencia ahora invalida el ZIP, vistas y resultados anteriores. El cambio de entradas es transaccional: si el archivo no puede indexarse, se conserva el proyecto válido anterior. La interfaz observa una revisión de proyecto y no presenta verificaciones de entradas diferentes.

7. **Caras auxiliares OBJ dibujadas por error.** NeoForge omite mallas sin material. El lector anterior dibujaba 30 caras de bounding boxes de `mechanical_roller/wheel` en magenta y alteraba los límites del modelo. Se corrigió ese comportamiento; quedan sus 40 caras visibles y la textura real, preservando el OBJ fuente completo.

8. **Recursos antiguos sin atlas.** Se auditaron cuatro overlays que referencian una textura ausente del JAR. Los reportes enlazan los modelos actuales registrados, con hashes y evidencia de `AllPartialModels`; no se sustituye el original por otra geometría ni se inventa una textura.

## Pruebas

La batería ampliada pasó **103 pruebas automáticas**. Incluye las 45 anteriores y nuevos casos independientes para recursos oficiales, extrusión, paletas, máscaras y rotaciones de superficies, clasificación de plantillas, invalidación transaccional y selección del modo OBJ. También se verificaron la sintaxis JavaScript y los identificadores de los controles HTML.

La regresión geométrica utiliza el JSON Bedrock emitido, decodificado independientemente; no renderiza el original dos veces como si fueran dos representaciones. Las superficies aproximadas mantienen siempre `static_equivalence_passed=false` y `rgba_texels_preserved=false` para el atlas de destino. Las imágenes de diferencia no se borran ni se sustituyen por imágenes originales.

## Límite que se conserva explícito

Un JSON vacío utilizado por un renderer o fluido no contiene la geometría final del objeto. Una plantilla sin asignaciones de textura tampoco determina una apariencia única. Resolver esos casos exige una instancia concreta o un adaptador que capture la salida del motor Java para un estado definido. No se fabrica un cubo ni se elige una textura arbitraria para anunciar que se convirtió todo.

Los materiales, animaciones, física y mecánicas de Create no son un port automático. Se generan modelos y un addon de entidades estáticas para prueba; Minecraft Bedrock y Blockbench no se ejecutaron en este entorno. La descarga del navegador de pruebas falló con una respuesta «Site Unavailable», por lo que tampoco se afirma QA visual de la interfaz.

El respaldo vanilla está fijado a **Java 1.21.1**. Para mods de otra versión se deben aportar sus recursos correspondientes con prioridad, y revisar cualquier cambio de formato. Los recursos importados de Mojang/Create conservan su autoría; no forman parte de la licencia MIT del código nuevo.
