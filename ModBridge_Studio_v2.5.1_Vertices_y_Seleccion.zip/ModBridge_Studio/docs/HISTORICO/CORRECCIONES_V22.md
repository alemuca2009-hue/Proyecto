# ModBridge Studio 2.2 — visor 3D y texturas opcionales

## Uso

Abre un modelo con **Ver este modelo**, entra en **Geometría 3D** y usa el
switch **Mostrar texturas**, junto a **Restablecer**. Activado muestra las
texturas originales y el atlas Bedrock; desactivado muestra geometría gris.
Afecta a las dos vistas, no requiere reconversión y recuerda tu preferencia
en el navegador. Las cámaras siguen sincronizadas.

Extrae el ZIP en una carpeta nueva y abre `INICIAR_WINDOWS.bat`. Se conservan
los archivos de trabajo del proyecto aportado. No se redistribuye el entorno
`.venv` de otra máquina: el lanzador lo prepara con Python en tu equipo.

## Correcciones

- El preview anterior descartaba UV y referencias de texturas. Ahora conserva
  las UV por vértice y las rutas relativas a los PNG de cada modelo. Los
  previews anteriores se actualizan al solicitarlos, sin modificar los IR.
- Se sustituye el dibujo de polígonos Canvas 2D ordenados por profundidad media
  por WebGL con buffer de profundidad por píxel. Los modelos se encuadran usando
  los mismos límites y escala, sin recortar la vista inicial.
- Las texturas se cargan localmente bajo demanda y conservan su resolución.
  Muestreo por vecino más cercano, sin desenfoque, inversión vertical ni CDN.
  Se mantienen las UV invertidas/rotadas tal como aparecen en el IR.
- Los texels transparentes no ocultan la geometría posterior. Los semitransparentes
  se componen en una pasada separada, detrás hacia delante.
- Cambiar de modelo libera buffers y texturas anteriores y descarta cargas
  pendientes. Las URL identifican la ejecución para evitar texturas de una
  conversión anterior. Las rutas no publican archivos ajenos al modelo.
- Se recuperan las referencias de texturas de IR trasladados desde Windows,
  siempre dentro del directorio del propio modelo.
- Los registros aportados mostraban `PermissionError: [WinError 5]` al reemplazar
  `progress.json`. La escritura atómica ahora utiliza temporales únicos y
  reintentos breves ante bloqueos transitorios. Un fallo permanente sigue
  notificándose y conserva la versión anterior del archivo.
- El switch funciona con teclado y tiene nombre accesible. En pantallas pequeñas,
  los dos modelos se muestran uno debajo del otro.

## Validación realizada

- 120 pruebas Python aprobadas, incluidas 9 de texturas, migración, rutas HTTP
  y reintentos de escritura. Las comprobaciones existentes de conversión,
  exportación y cancelación siguen pasando.
- Chromium con WebGL por software: switch, recuperación de los píxeles de las
  texturas al activarlo de nuevo, giro de ambas cámaras, Restablecer,
  persistencia al recargar y diseño móvil de 390 px sin desbordamiento horizontal.
- Comprobaciones de píxeles: oclusión independiente del orden de caras, agujeros
  alpha, composición semitransparente y orientación de las cuatro esquinas de
  una textura de tamaño no potencia de dos. Sin errores JavaScript ni WebGL.
- 107 modelos de las ejecuciones incluidas: generación del nuevo preview y
  resolución de todas sus referencias PNG dentro de sus respectivas carpetas.
- Se conservan las seis vistas y su motor independiente de auditoría.

Ejecutar pruebas Python:

```sh
python -m unittest discover -s tests -v
```

Prueba opcional de navegador, con Node, Playwright y Chromium instalados:

```sh
node tests/test_viewer_browser.cjs
```

Esta prueba no es una dependencia para ejecutar ModBridge. Se puede indicar
`CHROMIUM_EXECUTABLE` para usar un Chromium ya instalado.

## Límites

- El visor requiere WebGL/aceleración gráfica. Si no está disponible, se muestra
  un aviso y las seis vistas continúan disponibles.
- Se conserva el límite previo de 4.000 caras por representación. La interfaz
  avisa si se ha aligerado; la validación, seis vistas y exportación usan el
  modelo completo. No se modifican la geometría ni los PNG exportados.
- La transparencia interactiva se ordena por cara; superficies semitransparentes
  que se cruzan pueden requerir la auditoría de seis vistas para su comparación.
- Si una textura no existe, carece de UV válidas o supera el límite de tamaño
  de la GPU, la cara se muestra en gris con aviso. No se reduce silenciosamente.
- Las texturas animadas muestran el fotograma estático extraído por el conversor.
- Las pruebas se realizaron en Linux/Chromium; el bloqueo de Windows se comprobó
  por simulación de PermissionError. No se ejecutó Windows ni Minecraft Bedrock.
  No se certifican lógica, animaciones o comportamiento del mod dentro del juego.

Referencia técnica del renderizador: [MDN — texturas en WebGL](https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/Tutorial/Using_textures_in_WebGL).
