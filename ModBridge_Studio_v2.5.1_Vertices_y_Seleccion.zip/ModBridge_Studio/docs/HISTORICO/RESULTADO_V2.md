# Resultado de la versión 2.0 con Create 6.0.10

Se repitió el lote de 2.684 recursos con los archivos aportados. Las correcciones permiten exportar **2.638 modelos con geometría y texturas resueltas** al addon de entidades de prueba. Esto no certifica su comportamiento en Minecraft.

| Estado de los archivos examinados | Cantidad |
|---|---:|
| Geometría/texturas verificadas estáticamente | 2.230 |
| Geometría y texturas disponibles, con revisión de contexto/materiales/aproximación | 408 |
| Geometría disponible, pero atlas fuente inexistente | 4 |
| Plantillas abstractas o recurso deliberadamente invisible | 35 |
| Recursos que requieren geometría, asignaciones o contexto adicional | 7 |
| Total conservado y reportado | 2.684 |

Los 408 revisables incluyen **85 aproximaciones de mallas OBJ** mediante planos con máscaras. Esas 85 no conservan topología poligonal ni texels derivados 1:1 y nunca se etiquetan como verificadas. Las demás revisiones incluyen tintes, composición, animación y límites de bloque; sus geometrías pueden verse como entidades estáticas.

Respecto de la primera entrega, los verificados pasan de 1.302 a 2.230 y las entidades de muestra con texturas resueltas de 1.442 a 2.638. Se resolvieron los padres vanilla y las 40 texturas de paletas ausentes. Las 30 caras auxiliares de la rueda mecánica ya no se dibujan indebidamente.

## Lo que aún requiere contexto

- `create:block/belt/particle`: descriptor sin superficie final.
- `create:block/chocolate` y `create:block/honey`: contexto de renderizado de fluidos.
- `create:block/factory_gauge/block`: geometría aportada por el ensamblaje/renderizador.
- `create:block/ctblock`, `create:block/overgrown`, `create:block/paved_slab`: asignaciones de textura no determinadas para una instancia autónoma.

Los cuatro modelos antiguos con atlas ausente son `create:block/track/assembly_overlay`, `station_overlay`, `station_overlay_ascending` y `station_overlay_diagonal`. Sus reportes muestran los recursos registrados bajo `create:block/track_overlay/assembling` y `create:block/track_overlay/station`, que sí tienen texturas. Sus geometrías difieren: reemplazarlas automáticamente no sería una traducción 1:1.

Las 35 definiciones no renderizables corresponden a 34 plantillas con hijos concretos y `create:block/fake_track`, que hereda el modelo invisible `minecraft:block/air`. No se suman a conversiones exitosas ni se fabrica una superficie para ellas.

## Evidencia entregada

- 103 pruebas automáticas aprobadas.
- 48.312 PNG organizados en seis lados por recurso y tres representaciones por lado.
- Validación independiente de geometría y UV, comparación visual y métricas por modelo.
- Recursos originales comprobados contra los archivos de origen; recetas y hashes de las paletas generadas.
- 2.638 entidades con referencias válidas a geometría y atlas, sin `poly_mesh` ni tamaños negativos en el pack.
- Diagnósticos de `poly_mesh` guardados fuera de la carpeta de geometría destinada al juego.
- Estado completo en `VALIDACION_V2.json` y en cada reporte exportado.

Las vistas son renders del programa, no capturas de Minecraft. La validación dentro de Bedrock y la comprobación visual de la interfaz en un navegador siguen pendientes; el backend y sus controles se probaron mediante HTTP real.
