# Investigación técnica: Java → Bedrock

Fecha de consulta: 3 de noviembre de 2026. Alcance: recursos geométricos; no conversión del código Java de un mod ni de sus mecánicas.

## Decisión de compatibilidad

El resultado normal debe usar cubos con UV por cara y pivotes, dentro de `minecraft:geometry`. Una forma irregular construida con cuboides rotados sigue siendo representable. Una malla triangular arbitraria exige otro tratamiento: conservar el original y la representación intermedia editable, detectar si admite descomposición exacta en cuboides; si no, ofrecer una aproximación explícita o adaptación manual. No publicar `poly_mesh` como salida compatible por defecto. Microsoft registra GEOFMT101 como error para esa característica restringida, y la documentación moderna la declara obsoleta y generadora de errores en contenido nuevo. Su mera presencia en un esquema no garantiza compatibilidad de juego. [S3, S4]

## Coordenadas y UV

La implementación independiente `mc-model-geo`, que documenta su adaptación de los codecs Blockbench, describe este convenio: centrar X y Z de Java restando 8 y después reflejar X al serializar Bedrock. Para `from=f`, `to=t`, pivote `p`, se obtiene `origin=[8-t.x,f.y,f.z-8]`, `size=t-f`, `pivot=[8-p.x,p.y,p.z-8]`. Las rotaciones se serializan como `[-rx,-ry,rz]`. No se intercambian las claves nominales de las caras en ese codec. Las UV se convierten a píxeles según la resolución real; caras superior e inferior usan el extremo opuesto y tamaños UV negativos. [S6]

La geometría oficial 1.21.0 admite UV por cara y rotaciones UV de 0, 90, 180 y 270 grados. El orden de rotación de cubos y huesos es X, luego Y, luego Z, en grados. El pivote especificado es el centro de giro; si falta en un cubo, se utiliza su centro. Omitir una cara del mapa UV evita que se dibuje. Debe conservarse esa omisión en lugar de generar seis caras indiscriminadamente. [S1]

El propio código de Blockbench incluye un ejemplo con `uv_size` negativo en ambas componentes de `up` y `down`. Esa evidencia es especialmente útil para detectar un decoder Bedrock que incorrectamente imponga UV positivas. [S7]

**Advertencia metodológica:** las fórmulas anteriores son un convenio de intercambio coherente con Blockbench. Comparar dos representaciones con una misma transformación errónea puede producir un falso positivo. Debe existir un fixture asimétrico, independiente, con resultados numéricos previstos y una comprobación externa en Blockbench/Bedrock. Las imágenes obtenidas por el renderizador propio son referencias de auditoría, no capturas del motor del juego.

## Tamaño, rotación y superficies especiales

Los bloques personalizados tienen límites adicionales al archivo de geometría: tamaño máximo 30×30×30 píxeles, límites absolutos ±30 respecto del origen inferior central e intersección de al menos un píxel por eje con la región base. La validación debe evaluar los límites después de aplicar rotaciones, no únicamente `origin+size`. La geometría fuera del perfil de bloque debe guardarse sin reducirla silenciosamente; se puede proponer su uso como geometría de entidad o una composición de varios bloques, que exige integración específica. [S2]

`rescale` de Java debe resolverse en la geometría antes de exportar: para una rotación válida de un solo eje, el factor de compensación en los dos ejes perpendiculares es `1/cos(|ángulo|)`, respecto del pivote. Para 45° es √2. Las UV permanecen vinculadas a las mismas esquinas. Esta regla debe comprobarse contra vértices esperados; ignorarla cambia el volumen del modelo aunque la silueta parezca semejante. Para entradas no estándar, no asumir que el mismo algoritmo reproduce un loader particular.

Los elementos planos, coordenadas fraccionarias y partes que sobresalen del bloque no deben redondearse, engrosarse ni normalizarse. Un elemento plano puede ser intencional; su visibilidad depende también del material y del descarte de caras traseras. Debe conservarse la evidencia y verificarse por separado la compatibilidad del objetivo.

## Texturas y materiales

La conservación de píxeles requiere copiar las imágenes originales byte a byte y usar un atlas adicional sin reescalado, filtrado, cuantización, conversión de alfa ni rotación destructiva de los recursos. El atlas puede almacenar los originales a escala 1:1 y trasladar sus UV. Deben registrarse tamaño original, modo, hash del archivo y hash de píxeles RGBA. Cuando hay varias resoluciones, cada textura utiliza su propia escala UV de 16 unidades Java a ancho/alto real. Los rangos UV invertidos son válidos; el atlas no debe recortarlos inadvertidamente.

Una textura RGBA idéntica no garantiza el mismo aspecto si cambia el material. `opaque` no conserva transparencia; `alpha_test` conserva recorte binario pero no translucidez; `blend` permite alfa parcial. Iluminación direccional, oclusión ambiental, doble cara, emisión y tinte requieren decisiones explícitas. [S8]

Java utiliza metadatos `.mcmeta`; Bedrock concentra animaciones de texturas de bloques en `flipbook_textures.json`. Copiar la tira vertical sin traducir la animación no reproduce el recurso animado. [S5] La descripción oficial de flipbooks incluye orden de frames, ticks por frame y mezcla entre frames. [S9] La primera versión del conversor puede preservar la tira completa y renderizar un frame identificado, siempre que el reporte marque que la equivalencia temporal no está validada. No debe marcar como 1:1 una animación congelada. Para múltiples texturas animadas con tiempos distintos, un atlas estático no basta.

## Loaders, modelos compuestos y renderizadores

La documentación de NeoForge 1.21–1.21.1 confirma que un loader puede ignorar los campos del modelo convencional y generar `BakedModel` en memoria. OBJ utiliza `.obj` y `.mtl`, permite formas arbitrarias e incluye opciones de inversión V, sombreado y culling. Los modelos compuestos contienen hijos y visibilidad. El modelo dinámico puede depender del estado, azar, datos adicionales y tipo de render. Por ello, leer todos los JSON no prueba que se hayan extraído todas las superficies que aparecen en juego. [S10]

Para Create, el inventario debe conectar cada JSON con loaders, blockstates, parciales y clases de render. El reporte debe diferenciar el modelo estático extraído de la máquina ensamblada o animada. Convertir por separado un engranaje y su eje no reconstruye automáticamente el bloque completo ni su movimiento. La captura exacta de una salida procedural exige un adaptador que ejecute el motor Java con sus dependencias y exporte los quads para un estado documentado.

## Verificación propuesta

Se necesitan al menos tres resultados independientes: equivalencia matemática del recurso estático, equivalencia de mapeo/píxeles de textura y validación dentro del juego. El primero puede automatizarse mediante vértices transformados, conectividad de caras, normales y asignaciones UV. El segundo compara las coordenadas fuente y los texels asignados, no solo la imagen final. El tercero permanece pendiente hasta comprobar el paquete en la versión objetivo.

Las seis vistas deben compartir centro, escala ortográfica, límites, resolución, fondo y luz. Para cada par se debe calcular diferencia RGBA y conservar original, traducido, diferencia y opcionalmente superposición. SSIM o porcentaje de píxeles iguales son diagnósticos visuales; no sustituyen la comparación geométrica. La cámara no debe reencuadrar cada representación por separado porque ocultaría errores de escala o traslación.

## Fixtures independientes de prueba

1. **Cubo completo:** Java de `[0,0,0]` a `[16,16,16]`. Bedrock esperado `origin=[-8,0,-8]`, `size=[16,16,16]`. Todos los vértices en el IR deben cubrir X/Z -8..8 e Y 0..16.
2. **Cubo asimétrico:** Java `from=[1,2,3]`, `to=[5,9,14]`. Bedrock esperado `origin=[3,2,-5]`, `size=[4,7,11]`. Usar seis colores y una flecha distinta por cara, evitando simetrías que oculten espejos.
3. **Pivote fuera del centro:** el mismo cubo, pivote Java `[4,5,6]`, X=22.5°. Bedrock esperado `pivot=[4,5,-2]`, `rotation=[-22.5,0,0]`. Repetir Y=-45° y Z=45°; comprobar extremos con cálculo trigonométrico independiente.
4. **Rescale de 45°:** prisma fino rotado Y. Sus distancias locales X/Z al pivote se multiplican por √2 antes del giro. Probar pivote desplazado para evitar el falso positivo del centro.
5. **UV y resolución:** textura 32×64 con cara Java UV `[2,3,10,13]`: rectángulo en píxeles `[4,12,20,52]`; lateral `uv=[4,12],uv_size=[16,40]`; superior/inferior `uv=[20,52],uv_size=[-16,-40]`. Repetir 90/180/270 grados y rangos U/V invertidos.
6. **Omisión de caras:** solo `north` y `up` presentes. El exportado debe contener exactamente esas dos claves. Cara invisible no equivale a cara texturada transparente si cambian culling/material.
7. **Herencia:** padre geométrico, hijo que reasigna `#side`, cadena de tres alias y ciclo de alias. Los ciclos y padres ausentes deben ser errores explicados, no recursos inventados.
8. **Alfa:** cuadrícula con alfa 0, 64, 128, 255. Hash RGBA de cada textura original idéntico; atlas con esos mismos valores. Perfil de material conserva alfa parcial mediante blend o lo reporta incompatible.
9. **Tamaño:** geometría con extensión 31 en un eje falla el perfil de bloque pero no se escala ni trunca. Una pieza de extensión 30 con coordenada máxima 31 también falla límites absolutos.
10. **OBJ triangular:** tres vértices, UV y normales no axis-aligned. El IR conserva los datos y se reporta necesidad de adaptación; no debe aparecer un cubo de reemplazo aprobado como exacto.
11. **Loader desconocido:** JSON con elementos y `loader=custom:dynamic`. No convertirlo como modelo vanilla aprobado: el loader podría reemplazar los elementos.
12. **Prueba negativa de validación:** alterar 0.25 una coordenada del archivo Bedrock ya exportado. La comparación matemática y al menos una vista deben detectar la alteración. Cambiar una UV y un canal alfa para comprobar también esas rutas.
13. **Encuadre:** traslación deliberada del resultado de un píxel; todas las cámaras usan el AABB conjunto para que el desplazamiento permanezca visible.
14. **Animación:** tira con tres frames y tiempos 1, 2, 5. Si solo se genera pose estática, el estado debe ser `revisión requerida`, nunca equivalencia temporal completa.

## Fuentes primarias consultadas

S1. Microsoft. Geometry 1.21.0 schema. https://learn.microsoft.com/en-us/minecraft/creator/reference/content/schemasreference/schemas/minecraftschema_geometry_1.21.0?view=minecraft-bedrock-stable

S2. Microsoft. Advanced Block Visuals: Sizing and Culling. https://learn.microsoft.com/minecraft/creator/documents/customblockoversized

S3. Microsoft. Geometry validation: GEOFMT101. https://learn.microsoft.com/en-us/minecraft/creator/reference/content/mctoolsvalreference/geofmt?view=minecraft-bedrock-stable

S4. Microsoft. Geometry visual reference 1.12.0; estado deprecated de poly_mesh. https://learn.microsoft.com/en-us/minecraft/creator/reference/content/visualreference/geometry.v1.12.0?view=minecraft-bedrock-stable

S5. Microsoft. Converting Texture Packs. https://learn.microsoft.com/en-us/minecraft/creator/documents/convertingtexturepacks?view=minecraft-bedrock-stable

S6. EaseCation. Implementación mc-model-geo y documentación del convenio de Blockbench. https://github.com/EaseCation/mc-model-geo

S7. JannisX11/Blockbench. Ejemplo de geometría en el código fuente. https://github.com/JannisX11/blockbench/blob/master/js/formats/bedrock/bedrock_multi_file.ts

S8. Microsoft. Material Instances and Render Lighting Options. https://learn.microsoft.com/en-us/minecraft/creator/documents/customblockrenderlighting?view=minecraft-bedrock-stable

S9. Microsoft. Create an Animated Block Texture. https://learn.microsoft.com/en-us/minecraft/creator/documents/createanimatedblocktexture?view=minecraft-bedrock-stable

S10. NeoForged. Custom Model Loaders para 1.21–1.21.1. https://docs.neoforged.net/docs/1.21.1/resources/client/models/modelloaders/

Nota de alcance de fuentes: las páginas de Microsoft pueden mezclar una revisión moderna del texto con una versión de formato anterior. Para reproducibilidad, debe conservarse el perfil de salida elegido y no equiparar la existencia de un campo en el esquema con soporte universal en el motor.

S11. Microsoft. Materials and Material Files. https://learn.microsoft.com/en-us/minecraft/creator/documents/material-files?view=minecraft-bedrock-stable

Comprobación adicional para el paquete de entidades de muestra: la documentación enumera `entity_alphablend` como material vanilla con mezcla; corresponde seleccionarlo si el atlas contiene alfa parcial. `entity_alphatest` sirve para recorte binario. Esta selección mejora la preservación de transparencia, pero aún necesita verificación del resultado en juego. [S11]
