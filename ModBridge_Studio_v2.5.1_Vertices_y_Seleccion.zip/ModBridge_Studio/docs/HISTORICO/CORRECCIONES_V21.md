# ModBridge Studio 2.1

Esta actualización corrige el consumo temporal de memoria, la detención tardía y la espera del visor. Conserva las conversiones, las comprobaciones de fidelidad y los avisos de v2.

## Cambios de uso

- **Ver este modelo:** genera únicamente el modelo seleccionado, sus seis vistas y su reporte. No espera a procesar todo el mod ni comprime un ZIP.
- **Seis vistas:** original y traducido, frontal, trasera, izquierda, derecha, superior e inferior, superposición y mapa de diferencias.
- **Geometría 3D:** cámaras sincronizadas para girar las dos representaciones. Es un visor geométrico sin texturas; las imágenes de seis lados sí llevan texturas.
- **Resultados progresivos:** cada modelo terminado aparece antes de finalizar el lote. Los archivos provisionales no se publican como modelos listos.
- **Detener:** termina el proceso activo sin esperar a completar el modelo o la compresión. Las vistas ya terminadas se conservan. El modelo interrumpido se omite del ZIP parcial.
- **Exportar terminados:** crea el ZIP parcial solo cuando se solicita. La exportación también se puede detener. El ZIP definitivo se publica mediante cambio de nombre únicamente después de cerrarlo correctamente.
- La lista muestra 100 modelos por página. La búsqueda y «Seleccionar búsqueda» abarcan todos los resultados, no solo la página.

## Causas y correcciones

| Causa en v2 | Corrección |
| --- | --- |
| Todos los fragmentos transparentes se acumulaban en RAM y luego se concatenaban. | Render por regiones adaptativas, con un presupuesto de 262.144 fragmentos temporales. Conserva el orden y todas las capas. Un caso patológico que excede el presupuesto en un solo píxel produce un error explícito. |
| La composición buscaba cada capa recorriendo repetidamente todos los fragmentos. | Agrupación por capa y por píxel, sin ese recorrido repetido. |
| Las texturas se decodificaban otra vez al validar la geometría. | Reutilización de los mismos arrays dentro de la comparación; análisis de alfa por franjas y una vez por textura. |
| Cachés de JSON y modelos resueltos crecían con todo el mod. | Caché LRU de 128 JSON con presupuesto estimado de 8 MiB y caché de 32 modelos resueltos; catálogo de relaciones sin duplicar las definiciones completas. |
| El hilo de conversión compartía el proceso con el servidor y solo consultaba Detener entre modelos. | Un proceso independiente, un trabajo a la vez; terminación y escalada a cierre forzado si no sale. La interfaz permanece disponible y el sistema recupera la memoria del proceso terminado. |
| Detener iniciaba automáticamente la compresión del ZIP. | Detención y exportación son operaciones independientes. |
| El visor solo se habilitaba al acabar todo el lote. | Catálogo incremental de modelos completos y vistas individuales bajo demanda. |
| El navegador recibía los dos IR completos para mostrar simples PNG y reconstruía miles de filas. | Metadatos ligeros, geometría bajo demanda, peticiones obsoletas cancelables y paginación. |

La vista 3D interactiva limita el número de caras a 4.000 por representación y muestra un aviso cuando se aligera. Los archivos exportados, las seis imágenes y las comprobaciones matemáticas siguen usando la geometría completa. La resolución y los píxeles de las texturas fuente no se reducen para lograr estas mejoras.

El presupuesto de fragmentos no es un límite global de RAM: el tamaño de la geometría, los atlas, los archivos fuente y los reportes también consume memoria.

## Mediciones

Ensayo sintético de planos transparentes superpuestos a 192 × 192 píxeles. Cada medición usa un proceso de rasterizado independiente en Linux. No mide el navegador ni todo el lote Create. Son observaciones individuales; los tiempos dependen del equipo.

| Carga | Tiempo v2 | Tiempo v2.1 | RAM pico v2 | RAM pico v2.1 |
| --- | ---: | ---: | ---: | ---: |
| 64 capas | 1,117 s | 0,634 s | 141,66 MiB | 33,48 MiB |
| 192 capas | 6,391 s | 2,674 s | 369,38 MiB | 35,08 MiB |

En ambas cargas los bytes RGBA de salida coincidieron exactamente con v2. Una comparación adicional de 45 planos rotados, con texturas opacas, recortadas y semitransparentes, produjo cero píxeles diferentes en las seis cámaras. Los hashes están en `VALIDACION_V21.json`.

## Verificación

- 111 pruebas automatizadas aprobadas: conversión, herencia, UV, normales, transparencia, portabilidad del ZIP, rutas seguras, cancelación, reinicio, recursos acotados y vistas progresivas.
- Reejecución final de las 8 pruebas de controles de rendimiento: aprobadas, incluida la conservación del total del lote después de usar una vista individual y exportar lo terminado.
- Chromium: catálogo de 207 modelos paginado, vista individual, seis lados, superposición, giro de geometría, vista lista durante un lote, detención y descarga de un ZIP parcial válido. Cero errores JavaScript.
- Detención visible en la última prueba del navegador: **417 ms**, mientras se procesaba un modelo pesado; el proceso terminó y quedaron disponibles las vistas del modelo anterior.
- Se verificó el contenido de los archivos comprimidos y que la exportación parcial no incorporara el modelo interrumpido.

Los ensayos se hicieron con fixtures y recursos incluidos. El ZIP aportado contiene el programa, no los JAR completos de Create ni el addon de referencia. No se volvió a ejecutar aquí un lote completo de Create, Windows ni Minecraft Bedrock. Los informes V1/V2 se conservan como antecedentes y no representan una nueva validación de esos entornos.

Para ejecutar la suite:

```bash
python -m unittest discover -s tests -v
```

Los resultados estáticos no certifican equivalencia funcional en el juego. Se conservan los avisos de mallas OBJ aproximadas, recursos faltantes, renderizadores personalizados y estados pendientes de revisión.
