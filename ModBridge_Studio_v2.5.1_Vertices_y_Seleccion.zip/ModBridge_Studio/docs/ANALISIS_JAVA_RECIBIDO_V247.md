# Comprobación de ModBridge_renders (2).zip

El nuevo archivo contiene renders de Java, pero no todos corresponden a Java. El manifiesto de exportación indica **ModBridge 2.4.6** y los mismos **87 modelos** del ZIP anterior.

| Perfil | Representación | Modo | Parámetros | Imágenes |
|---|---|---|---|---:|
| Perfil 1 | Java original | Alambre | Rayos X, opacidad 0,35 | 522 |
| Perfil 2 | Bedrock traducido | Alambre | Sin Rayos X ni Normales | 522 |
| Perfil 3 | Bedrock traducido | Sólido | Sin Rayos X ni Normales | 522 |

Cada perfil incluye las seis direcciones, a 192 × 192 px. El ZIP tiene **1.566 PNG**: **522 Java y 1.044 Bedrock**. No contiene renders en modo Texturas. El CRC, los hashes del manifiesto y las dimensiones son correctos; no hay imágenes vacías ni errores declarados.

## Comparación con el primer archivo

Los **1.044 PNG de Bedrock son idénticos byte a byte** a los del primer `ModBridge_renders.zip`. Por tanto, el nuevo contenido útil es el Perfil 1 original, que sustituye al anterior Perfil 1 traducido conservando las mismas perspectivas, Rayos X y opacidad.

Eso permite formar **522 parejas Java/Bedrock con ajustes coincidentes** entre ambos ZIP. De esas parejas, 82 coinciden píxel a píxel y 440 presentan diferencias. Las diferencias en Alambre pueden deberse a aristas o descomposición de la superficie: no prueban por sí solas pérdida de área, error UV o incompatibilidad en el juego. Tampoco una pareja idéntica certifica el modelo 3D completo.

## Comprobación independiente de procedencia

Se volvieron a renderizar las seis vistas originales de ocho modelos de diagnóstico con el motor real del programa y el encuadre común de Java/Bedrock:

- Válvula negra.
- Rueda del transportador de cadenas.
- Rueda trituradora.
- Volante.
- Rueda de agua grande.
- Rueda motriz del bogey.
- Rueda de agua pequeña.
- Rodillo mecánico.

**Las 48 imágenes generadas coinciden píxel a píxel con las recibidas.** La fuente es el mismo JAR `create-1.21.1-6.0.10.jar` empleado en la auditoría 2.4.7. Esto confirma que los originales utilizados en esas comparaciones corresponden al nuevo adjunto. No se ha identificado una fuente Java distinta ni un defecto geométrico nuevo a partir de este archivo.

SHA-256 del ZIP recibido: `79f55caef78add3e47a38c936f0e5aa25c1c44b44d311f613e4f7ad5fb8040f1`.

Los detalles por imagen y las comprobaciones están en `ANALISIS_JAVA_RECIBIDO_V247.json`. El archivo del usuario se mantuvo intacto. Esta comprobación no equivale a ejecución dentro de Minecraft Java o Bedrock.
