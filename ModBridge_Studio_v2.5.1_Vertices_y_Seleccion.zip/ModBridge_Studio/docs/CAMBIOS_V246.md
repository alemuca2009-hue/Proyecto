# ModBridge Studio 2.4.6 · Perfiles de render

Base: proyecto completo 2.4.5 «Geometría reconstruida». Se conservan los formatos, los lanzadores, los recursos, los ejemplos históricos y las funcionalidades de conversión e inspección.

## Reclasificación sin alterar las fuentes

El mismo criterio que activa «SUPERFICIES RECONSTRUIDAS» obliga ahora a `review`: `target_kind = surface_reconstructed`, o `surface_approximation` con `metrics.surface.exact_geometry = true`. Esta regla se aplica antes de promover un resultado a verificado. Las métricas coincidentes siguen visibles.

Los resultados compactos antiguos se hidratan desde su reporte para recuperar las etiquetas de análisis y la clasificación actual. Esta consulta no reescribe ni los archivos originales ni sus fechas. Los ZIP descargados antes de actualizar y los ejemplos históricos permanecen intactos.

## Filtros de análisis

Avanzados empieza contraído. Las opciones proceden de los estados ya mostrados en las tarjetas y los tipos de destino existentes; no se crean resultados analíticos nuevos.

| Categoría | Opciones existentes expuestas |
|---|---|
| Geometría | Sin comparar; Coincidente; Diferencias detectadas; Error de vértices; Verificada; Consultar reporte; Superficies reconstruidas; Aproximación de superficies; Malla experimental; block_or_entity_geometry; entity_geometry |
| Texturas | Sin comparar; Faltan texturas; UV sin verificar; Diferencias UV/material; Píxeles conservados; Revisar diferencias; Verificadas; Consultar reporte |

Selecciones de una categoría: cualquiera de las casillas marcadas. Entre categorías: deben cumplirse ambas. Se conservan búsqueda, ordenación, colores, modelos extendidos y selección explícita.

## Configurador y exportador conectados

La ventana incluye Modelos, Perfiles, Perspectivas, Visualización, Parámetros, Resumen y Exportación. Se pueden asignar perfiles distintos a cada modelo, añadirlos, duplicarlos, eliminarlos y revisar su configuración antes de generar. Un perfil contiene sus vistas, modos, parámetros, opacidad, resolución y representación original/traducida.

| Selección de parámetros | Variantes por vista y modo |
|---|---|
| Ninguno | Una, sin parámetros |
| Rayos X | Una, solo Rayos X |
| Normales | Una, solo Normales |
| Ambas casillas | Una, Rayos X y Normales simultáneamente |
| Generar las 3 combinaciones | Tres: Rayos X; Normales; ambas |

Cada modo produce un PNG separado. Se deduplican configuraciones equivalentes por modelo, representación, resolución, vista, modo, parámetros y opacidad efectiva. La primera asignación conserva la imagen; el resumen y manifiesto indican las referencias duplicadas. No se crean carpetas vacías.

Estructura: `RENDERS_EXPORTADOS/MAESTRA_…/MODELO_…/PERFIL_…/modelo_perspectiva_modo_estado_rayosx_estado_normales.png`. El manifiesto registra configuración, rutas, SHA256, incidencias y destino diagnóstico cuando corresponde. Los nombres se normalizan a ASCII y las carpetas incluyen identificadores cortos para evitar colisiones.

## Motor y conservación

El render reutiliza las cámaras ortográficas, rasterización, triangulación y texturas del motor existente. Alambre dibuja los contornos reales y respeta profundidad; Sólido utiliza las superficies reales; Texturas utiliza UV y PNG del modelo. Rayos X modifica la transparencia y visibilidad de aristas ocultas. Normales usa azul exterior/rojo interior, como el visor existente. No se renderizan capturas de la interfaz.

Se usa la geometría completa, sin el recorte de previsualización del visor. Se procesa un modelo a la vez, se reutilizan sus recursos entre imágenes y se liberan antes del siguiente. El rango de resolución del configurador es 64–512 px; hereda inicialmente la resolución principal.

La preparación de modelos pendientes y los PNG se realizan en un proceso independiente, dentro del espacio de trabajo de la exportación. No sustituyen el resultado de conversión ni la biblioteca. Los recursos de modelos ya preparados se abren en modo de lectura. Las entradas erróneas no detienen los demás modelos. Los fallos de escritura del ZIP sí impiden publicar un archivo incompleto. La cancelación no ofrece un ZIP parcial como terminado.

## Archivos principales

| Archivo | Responsabilidad |
|---|---|
| `bridge/verification.py`, `bridge/catalog.py`, `bridge/analysis_states.py` | Clasificación y etiquetas existentes |
| `bridge/render_modes.py` | Alambre, Sólido, Texturas, Rayos X y Normales sobre IR completo |
| `bridge/render_export.py` | Plan, deduplicación, rutas, imágenes, manifiesto y ZIP comprobado |
| `bridge/render_jobs.py`, `render_worker.py` | Ejecución aislada, preparación por modelo, progreso y cancelación |
| `app.py` | Integración HTTP, protección existente de solicitudes y compatibilidad con reportes antiguos |
| `web/render_config.js`, `web/render_dialog.js` | Cálculo del resumen e interacción del configurador |
| `web/index.html`, `web/app.js`, `web/library.js`, `web/style.css` | Avanzados, filtros, estados e integración visual |

La conversión geométrica de 2.4.5 no se sustituye. Las aproximaciones y mallas diagnósticas conservan sus limitaciones. Los renders representan recursos estáticos; no certifican el funcionamiento dentro de Minecraft.
