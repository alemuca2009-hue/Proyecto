# Análisis independiente de ModBridge_renders.zip

## Alcance e integridad

El archivo contiene **1.566 PNG de 192 × 192 px**, correspondientes a **87 modelos** y tres perfiles: seis vistas de alambre con Rayos X, seis de alambre normal y seis de sólido. Todos son renders de la representación traducida. El CRC del ZIP, los 1.566 hashes del manifiesto y las dimensiones son correctos. No hay imágenes vacías ni fallos de render declarados.

El manifiesto identifica 65 modelos `surface_approximation`, 21 `surface_reconstructed` y uno `block_or_entity_geometry`. Este ZIP no contiene geometría fuente, texturas, vistas originales ni métricas independientes de superficie. Por ello, sus imágenes por sí solas no permiten certificar una traducción geométrica 1:1 ni fidelidad de UV/material.

## Hallazgos contrastados

Se consultaron reportes y geometrías completas de 41 modelos de la validación previa 2.4.5, asociados al JAR local `create-1.21.1-6.0.10.jar`. Para ocho modelos representativos se volvió a renderizar el IR traducido con el motor 2.4.6 y se obtuvo igualdad exacta de píxeles con los PNG enviados. Esto vincula esas ocho comparaciones con los defectos realmente visibles en el archivo del usuario.

Con el mismo encuadre se renderizó el IR original en modo Sólido. Las diferencias de las vistas analizadas son únicamente píxeles de superficie que existen en el original y desaparecen en el traducido: no se detectaron píxeles añadidos fuera de la cobertura original. Se ven líneas discontinuas y grietas diagonales interiores en válvulas, ruedas y rodillos.

| Modelo | Vista analizada | Píxeles de cobertura perdidos a 192 px | Diferencia de área geométrica del reporte previo | Caras originales → traducidas |
|---|---|---:|---:|---:|
| `create:block/black_valve_handle` | superior | 62 | 0.134936% | 60 → 1082 |
| `create:block/chain_conveyor/wheel` | superior | 99 | 0.370761% | 84 → 7652 |
| `create:block/crushing_wheel/block` | superior | 108 | 0.497817% | 268 → 12000 |
| `create:block/flywheel/block` | superior | 34 | 0.253542% | 164 → 5631 |
| `create:block/large_water_wheel/block` | superior | 48 | 1.002686% | 2136 → 12000 |
| `create:block/track/bogey/bogey_drive_wheel` | izquierda | 15 | 1.417561% | 352 → 11999 |
| `create:block/water_wheel/wheel` | superior | 64 | 0.731818% | 1276 → 12000 |
| `create:block/mechanical_roller/wheel` | frontal | 179 | 0.338783% | 40 → 2876 |

Los píxeles son una medida de esa vista y resolución; no equivalen al porcentaje de superficie 3D. Los porcentajes de área provienen del reporte independiente anterior, no se deducen de las imágenes. La igualdad de píxeles con la reconstrucción 2.4.6 se comprobó en las ocho vistas de esta tabla.

## Causa y prioridades

1. **Descomposición interior de polígonos:** el método `interior_contour_strips` conserva rectángulos completamente interiores, pero no cubre exactamente bordes diagonales ni triángulos. Esa pérdida deja huecos compartidos. El rodillo presenta 179 píxeles faltantes en su vista frontal incluso sin agotar el presupuesto de rectángulos: aumentar el límite no es una solución 1:1.
2. **Presupuesto en mallas complejas:** la rueda de agua, la rueda trituradora y otras alcanzan 12.000 rectángulos. La rueda motriz del bogey usa 11.999 y tiene una diferencia de área del 1,417561%; el presupuesto reduce aún más las subdivisiones disponibles. La geometría aumenta de cientos de caras a miles sin volverse exacta.
3. **Mantener las formas del original:** las ruedas y válvulas ya tienen contornos poligonales/octogonales en Java. Redondearlos sería una alteración adicional, no una corrección.
4. **Conservar límites de evidencia:** los 21 modelos reconstruidos deben seguir en Revisar según la regla 2.4.6. Una mejora visual en una vista no demuestra exactitud del modelo completo. Debe verificarse el resultado exportado decodificado, UV/material y seis direcciones, separando compatibilidad de formato y ejecución real en Bedrock.

## Artefactos de revisión

- `RENDERS_RECIBIDOS_V247.json`: inventario saneado, perfiles, métricas y las ocho comparaciones.
- `MODELOS_REVISADOS_V247.txt`: los 87 identificadores exactos del ZIP.
- `GEOMETRIA_RECIBIDA_V247.png`: original sólido, sólido del ZIP, cobertura perdida resaltada, alambre y alambre con Rayos X.
- `GEOMETRIA_RECIBIDA_V247.json`: mediciones por comparación.

Estas láminas provienen exclusivamente de los PNG y los renderizadores reales del proyecto, no de imágenes generadas ni reconstrucciones artísticas. No se modificó ningún archivo fuente del programa ni del usuario.
