# Análisis y restauración del motor 2.4.4

## Decisión aplicada

ModBridge Studio **2.4.9** conserva los controles de la aplicación actual y vuelve al algoritmo **2.4.4**. La petición prioriza recuperar ese comportamiento y facilitar su edición. La pérdida de superficie que ya existía en 2.4.4 queda pendiente, tal como se solicitó.

La fuente de restauración fue `ModBridge_Studio_v2.4.4_Biblioteca_Modelos3D.zip`, SHA-256 `384bb0293193025f58d7ed86fd8e75be25f1e0add89647b241633ed576c87836`.

## Diferencias encontradas en el código

| Etapa | Algoritmo 2.4.4 restaurado | Algoritmo 2.4.8 retirado |
|---|---|---|
| Lectura de Java, OBJ, recursos, cubos y coordenadas | Mismo código base de `geometry.py` y recursos. | No era la diferencia principal. |
| Tratamiento de la malla | Construye un parche por cara; usa la arista más larga como eje local. | Intenta reconstruir rectángulos y regiones coplanares de varias caras. |
| Contornos | Franjas interiores; acepta refinamiento si alcanza cobertura mínima y cabe en el presupuesto. | Evalúa alternativas de reconstrucción y distintos niveles de detalle. |
| Límite de detalle | 3500 como presupuesto de refinamiento; hasta 128 franjas por polígono. | Planificación hasta 12.000 rectángulos. |
| Cuando no alcanza el refinamiento | Recupera el rectángulo de la cara con su máscara alpha. | Trata de mantener rectángulos interiores y contabiliza el área omitida. |
| Texturas superficiales | Atlas nuevo remuestreado, con densidad inicial 4. | Mezcla transferencia UV nativa y remuestreo según el caso. |
| Resultado declarado | `surface_approximation`, requiere revisión. | Puede distinguir reconstrucciones exactas de otras aproximadas. |

Estas diferencias explican cambios de teselación, contorno y apariencia. No se concluye que una sola métrica de área determine cuál se ve mejor para todos los modelos. Un plano envolvente puede conservar la apariencia en textura mediante transparencia y, a la vez, sobresalir en sólido/alambre.

La restauración vuelve a la decisión original por cara. **No promete que la malla de salida conserve todos los vértices o la conectividad original:** estos se preservan íntegros en los archivos fuente/IR, mientras que los planos Bedrock son otra representación.

## Separación implementada

La carpeta `conversion_engine/` contiene la conversión, lectura de recursos, UV, atlas, contornos, triangulación, recetas estáticas, copias editables, perfil de tamaño y límites de visibilidad. Incluye API Python, terminal y configuración JSON propia. Puede ejecutarse sin la aplicación ni su servidor.

La conversión normal y la preparación de modelos para renders llaman a `convert_in_pack`. `bridge/` conserva alias compatibles para llamadas antiguas. Las vistas, comprobaciones independientes, interfaz, control maestro, selección de modelos y organización de exportaciones permanecen en la aplicación.

Los algoritmos retirados y sus pruebas específicas se conservan en `HISTORICO/MOTOR_245_248_RETIRADO.zip`. No se importan en ejecución. Las pruebas que exigían las uniones/nuevas UV de esas versiones se sustituyen por la referencia original 2.4.4; mantener esas expectativas habría contradicho la restauración solicitada.

## Cambios de integración que no alteran la geometría original

- Parámetros antes constantes pasan a `settings.json`, con los valores originales.
- La triangulación se extrae del renderer sin cambiar su cuerpo.
- El perfil final y los límites de visibilidad se incluyen dentro de la API; antes se completaban en el pipeline.
- La adaptación calcula y decodifica su salida antes de mover los respaldos. Un error de cálculo conserva utilizables el atlas y la malla de diagnóstico.
- Cada conversión registra la firma del motor/configuración; los renders no reutilizan un resultado de otra firma o de otro modo.
- La API rechaza salidas ocupadas para evitar mezclas con una conversión anterior.

Las comprobaciones visuales de la aplicación se conservan. Los reportes pueden incluir más información que en 2.4.4; la prueba de equivalencia se hace sobre los archivos geométricos, UV, atlas, datos intermedios y fuentes.

## Trabajo geométrico que queda para después

Revisar `surface_contours.py` y `mesh_surface.py`: cobertura de franjas, caras oblicuas, máscaras que no recortan la geometría y reducción de densidad cuando el atlas se llena. Ninguno de estos comportamientos se reemplazó por otra reparación en esta entrega.
