# Validación de ModBridge Studio 2.4.3

## Resultado

| Comprobación | Resultado |
|---|---|
| Suite Python completa | 142 pruebas correctas, 0 fallos. |
| Lógica de biblioteca y tarjetas en Node | 13 pruebas correctas, 0 fallos. |
| Sintaxis JavaScript | app.js, library.js y viewer.js correctos. |
| Conversión real del JAR de demostración | 6 modelos procesados en ambas versiones. |
| Archivos de geometría y atlas frente a 2.4.2 | 18 de 18 idénticos byte por byte. |

El modelo extendido `demo:block/fuera_del_bloque` y el modelo normal
`demo:block/plano` cambian de `review` a `verified_static`. Ambos muestran
«Coincidente» y «Píxeles conservados». La malla aproximada
`demo:block/malla_triangular` conserva `review`, con ambas métricas negativas.
Los otros tres modelos ya verificados conservan su estado.

## Cobertura de la nueva regla

- Modelos normales y extendidos; avisos y diferencias rasterizadas conservados.
- Evidencia ausente, negativa o no booleana: no provoca promoción.
- Texturas faltantes en original o destino: no provoca promoción.
- Alias y prioridad de campos equivalentes a las tarjetas visibles.
- Estados de error, no convertido y plantilla sin cambios.
- Worker real, catálogo compacto, procesamiento individual y por lotes, CLI y API.
- Reportes antiguos reexportados: JSON, CSV, HTML, estado por modelo y contadores
  usan la misma clasificación, sin alterar el reporte fuente ni los recursos.
- Código real de `renderMetrics` ejecutado con Node sobre seis conversiones
  reales; los modelos que cumplen las tarjetas aparecen en Verificados y no
  en Revisar. Se comprueba también el filtro combinado con modelo extendido.

La prueba de la versión anterior que exigía dejar en revisión cualquier
render diferente se actualizó al criterio solicitado: si ambas tarjetas pasan,
el modelo se verifica y las diferencias rasterizadas siguen en el reporte.

## Evidencia reproducible

- `pruebas_python_v243.txt`: ejecución completa de Python.
- `pruebas_biblioteca_node_v243.txt`: ejecución de JavaScript.
- `COMPARACION_DEMO_V243.json`: estados antes/después y hashes de 18 recursos.
- `CAMBIOS_CODIGO_V242_V243.patch`: diferencias de código y guías frente al ZIP original.
- `VALIDACION_V243.json`: resultados estructurados y entorno.

## Límites del entorno

Se ejecutó en Linux, sin Windows ni Minecraft. Chromium no está instalado;
no se ejecutaron las suites opcionales de navegador. La comprobación de
las tarjetas utiliza el código real de la interfaz con elementos DOM mínimos
simulados, por lo que no certifica el aspecto visual del navegador.

Las dependencias declaradas se mantienen. El entorno de pruebas disponible
usa Pillow 13.0.0 y NumPy 2.3.5; el lanzador conserva su restricción Pillow <13.

Las muestras Water Wheel y los informes de 2.4.2 permanecen como evidencia
histórica; sus resultados no se presentan como nuevas ejecuciones.
