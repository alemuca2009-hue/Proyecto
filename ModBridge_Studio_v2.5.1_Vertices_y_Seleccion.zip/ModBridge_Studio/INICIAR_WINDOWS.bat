@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Se necesita Python 3.10 o posterior. Instalar desde https://www.python.org/downloads/
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" py -3 -m venv .venv
".venv\Scripts\python.exe" -c "import numpy, PIL" >nul 2>nul
if errorlevel 1 (
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 (
    echo No fue posible instalar las dependencias. Revisar conexion a internet.
    pause
    exit /b 1
  )
)
".venv\Scripts\python.exe" app.py serve
pause
