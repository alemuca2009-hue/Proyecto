"""Final library status from the same evidence shown by the metric cards.

Reconstructed surfaces always remain in review. Other review models can be
promoted. Size, warnings and raster differences
remain diagnostics. New independent UV/material failures veto promotion and
invalidate stale verified statuses; legacy reports retain their metric rule.
The original metrics (including UV/six-view checks) are never rewritten.
"""

GEOMETRY_KEYS = ('surface_geometry_equal', 'equivalent', 'geometry_equal',
                 'geometry_match', 'geometry_exact', 'same_geometry')
TEXTURE_KEYS = ('rgba_texels_preserved', 'texels_equal', 'textures_equal',
                'texture_pixels_equal', 'texture_match', 'pixel_exact', 'texture_exact')


def _first_present(mapping, keys):
    for key in keys:
        if key in mapping:
            return mapping[key]
    return None


def _metric_object(metrics, *keys):
    # An empty object is still an explicit object in web/app.js. Do not fall
    # through to other evidence when a nested metric object exists but is empty.
    for key in keys:
        value = metrics.get(key)
        if isinstance(value, dict):
            return value
    return metrics



def has_reconstructed_surface_notice(report):
    """Match the inspector's existing SUPERFICIES RECONSTRUIDAS banner.

    The compact flag carries this decision through worker/status projections;
    native cuboids with unrelated exact-geometry metrics are not affected.
    """
    if report.get('requires_surface_review') is True:
        return True
    kind=report.get('target_kind')
    if kind=='surface_reconstructed':
        return True
    metrics=report.get('metrics') or {}
    surface=metrics.get('surface') if isinstance(metrics,dict) else None
    return bool(kind=='surface_approximation' and isinstance(surface,dict)
                and surface.get('exact_geometry') is True)


def final_status(report):
    """Resolve final static status without mutating report evidence.

    Keep key precedence and strict boolean comparisons aligned with
    renderMetrics in web/app.js: matching geometry, preserved pixels and
    no explicit failure of the independent UV/material mapping proof.
    """
    # 2.4.6: reconstructed surfaces remain reviewable even when geometry and
    # UV checks pass. This changes classification only, never their evidence.
    if has_reconstructed_surface_notice(report):
        return 'review'
    status = report.get('status')
    if status not in ('review', 'verified_static'):
        return status
    metrics = report.get('metrics') or {}
    if not isinstance(metrics, dict):
        return status
    geometry = _metric_object(metrics, 'geometry_independent', 'geometry')
    textures = _metric_object(metrics, 'textures')
    # A copied PNG does not prove its assignment to surfaces. New reports carry
    # an independent UV/material proof; an explicit failure also invalidates a
    # stale verified report during re-export. Legacy reports retain their rule.
    if geometry.get('uv_mapping_check_passed') is False:
        return 'review'
    if status == 'verified_static':
        return status
    visual = metrics.get('six_views') or {}
    missing = visual.get('missing_textures') or {}
    if missing.get('original') or missing.get('translated'):
        return status
    if (_first_present(geometry, GEOMETRY_KEYS) is True
            and _first_present(textures, TEXTURE_KEYS) is True):
        return 'verified_static'
    return status
