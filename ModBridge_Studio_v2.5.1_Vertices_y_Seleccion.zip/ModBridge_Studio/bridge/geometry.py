"""Compatibility import; edit conversion_engine/geometry.py instead."""
import sys
from conversion_engine import geometry as _implementation
sys.modules[__name__] = _implementation
