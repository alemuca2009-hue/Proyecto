"""Compatibility import; edit conversion_engine/palettes.py instead."""
import sys
from conversion_engine import palettes as _implementation
sys.modules[__name__] = _implementation
