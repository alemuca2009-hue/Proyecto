"""Compatibility import; edit conversion_engine/editable.py instead."""
import sys
from conversion_engine import editable as _implementation
sys.modules[__name__] = _implementation
