"""Read-only filters projected from the analysis states already displayed in 2.4.5.

Filter IDs are selectors, never replacement statuses or invented measurements.
The first tag in each category follows the corresponding metric card exactly.
Additional geometry tags expose the existing target_kind values.
"""
import math
from .verification import (GEOMETRY_KEYS, TEXTURE_KEYS, _first_present,
                           _metric_object, final_status, has_reconstructed_surface_notice)

ANALYSIS_FILTERS = {
    'geometry': [
        {'id':'unreviewed','label':'Sin comparar','source':'Modelo sin resultado'},
        {'id':'matching','label':'Coincidente','source':'Comprobación de geometría = true'},
        {'id':'different','label':'Diferencias detectadas','source':'Comprobación de geometría = false'},
        {'id':'vertex_error','label':'Error: … px','source':'Error de vértices numérico sin coincidencia declarada'},
        {'id':'verified','label':'Verificada','source':'Estado verificado sin métrica de geometría explícita'},
        {'id':'report','label':'Consultar reporte','source':'Sin conclusión explícita de geometría'},
        {'id':'surface_reconstructed','label':'Superficies · reconstruidas','source':'Aviso SUPERFICIES RECONSTRUIDAS'},
        {'id':'surface_approximation','label':'Superficies · aproximación','source':'target_kind = surface_approximation'},
        {'id':'experimental_poly_mesh','label':'Malla experimental · diagnóstico','source':'target_kind = experimental_poly_mesh'},
        {'id':'block_or_entity_geometry','label':'block_or_entity_geometry','source':'Destino mostrado en el reporte'},
        {'id':'entity_geometry','label':'entity_geometry','source':'Destino mostrado en el reporte'},
    ],
    'textures': [
        {'id':'unreviewed','label':'Sin comparar','source':'Modelo sin resultado'},
        {'id':'missing','label':'Faltan texturas','source':'Texturas faltantes en original o destino'},
        {'id':'uv_unverified','label':'UV sin verificar','source':'Comprobación UV explícitamente omitida'},
        {'id':'uv_difference','label':'Diferencias UV/material','source':'Comprobación UV/material fallida'},
        {'id':'pixels_preserved','label':'Píxeles conservados','source':'Texels RGBA conservados = true'},
        {'id':'different','label':'Revisar diferencias','source':'Texels RGBA conservados = false'},
        {'id':'verified','label':'Verificadas','source':'Estado verificado sin métrica de textura explícita'},
        {'id':'report','label':'Consultar reporte','source':'Sin conclusión explícita de texturas'},
    ],
}
_ALLOWED = {category:{option['id'] for option in options}
            for category,options in ANALYSIS_FILTERS.items()}
_NATIVE_KINDS = {'surface_approximation','experimental_poly_mesh',
                 'block_or_entity_geometry','entity_geometry'}
_ERROR_KEYS = ('max_vertex_error','max_vertex_error_px','max_position_error',
               'vertex_max_error','vertex_error_max')


def _object(value):
    return value if isinstance(value,dict) else {}


def _numeric(value):
    if isinstance(value,bool) or not isinstance(value,(int,float)):
        return False
    try:return math.isfinite(value)
    except OverflowError:return False


def analysis_states(report=None):
    """Return small analysis tags without changing any source report or model."""
    if report is None:
        return {'geometry':['unreviewed'],'textures':['unreviewed']}
    # A repeated compact operation must preserve the already-computed facets.
    # Full metric evidence always takes precedence if present.
    existing=report.get('analysis')
    if 'metrics' not in report and isinstance(existing,dict):
        result={}
        for category in ('geometry','textures'):
            values=existing.get(category)
            result[category]=list(dict.fromkeys(
                value for value in values if isinstance(value,str) and value in _ALLOWED[category]
            )) if isinstance(values,list) else []
        if has_reconstructed_surface_notice(report) and 'surface_reconstructed' not in result['geometry']:
            result['geometry'].append('surface_reconstructed')
        return result
    metrics=_object(report.get('metrics'))
    geometry=_metric_object(metrics,'geometry_independent','geometry')
    textures=_metric_object(metrics,'textures')
    status=final_status(report)
    match=_first_present(geometry,GEOMETRY_KEYS)
    error=metrics.get('max_vertex_error_pixels')
    if error is None:error=_first_present(geometry,_ERROR_KEYS)
    if match is True:geometry_tag='matching'
    elif match is False:geometry_tag='different'
    elif _numeric(error):geometry_tag='vertex_error'
    elif status=='verified_static':geometry_tag='verified'
    else:geometry_tag='report'
    visual=_object(metrics.get('six_views'))
    missing=_object(visual.get('missing_textures'))
    uv_failed=geometry.get('uv_mapping_check_passed') is False
    tex_match=_first_present(textures,TEXTURE_KEYS)
    if missing.get('original') or missing.get('translated'):texture_tag='missing'
    elif uv_failed and geometry.get('uv_mapping_check_performed') is False:texture_tag='uv_unverified'
    elif uv_failed:texture_tag='uv_difference'
    elif tex_match is True:texture_tag='pixels_preserved'
    elif tex_match is False:texture_tag='different'
    elif status=='verified_static':texture_tag='verified'
    else:texture_tag='report'
    result={'geometry':[geometry_tag],'textures':[texture_tag]}
    if has_reconstructed_surface_notice(report):
        result['geometry'].append('surface_reconstructed')
    elif report.get('target_kind') in _NATIVE_KINDS:
        result['geometry'].append(report['target_kind'])
    return result
