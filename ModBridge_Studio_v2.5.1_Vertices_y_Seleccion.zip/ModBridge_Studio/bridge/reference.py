"""Read-only structural audit of an existing Bedrock addon; never executes scripts."""
from __future__ import annotations
import hashlib, io, json, re, zipfile
from collections import Counter
from pathlib import PurePosixPath
from PIL import Image


def jsonc(data):
    """Remove JSON comments/trailing commas while preserving quoted strings."""
    text = data.decode('utf-8-sig') if isinstance(data, bytes) else data
    text = re.sub(r'"(?:\\.|[^"\\])*"|//[^\n\r]*|/\*[\s\S]*?\*/',
                  lambda m: m.group(0) if m.group(0).startswith('"') else '', text)
    # Do not modify a comma followed by } inside a quoted string.
    text = re.sub(r'"(?:\\.|[^"\\])*"|,\s*(?=[}\]])',
                  lambda m: m.group(0) if m.group(0).startswith('"') else '', text)
    return json.loads(text)


def pixel_hash(data):
    with Image.open(io.BytesIO(data)) as image:
        image = image.convert('RGBA')
        return hashlib.sha256(str(image.size).encode() + image.tobytes()).hexdigest(), list(image.size)


def archive_entries(path):
    """Yield safe archive members incl. nested mcpack; bounded against ZIP bombs."""
    budget = [0, 0]
    def visit(z, prefix='', depth=0):
        for entry in z.infolist():
            if entry.is_dir(): continue
            name = PurePosixPath(entry.filename.replace('\\', '/'))
            if name.is_absolute() or '..' in name.parts or ':' in str(name):
                raise ValueError('Ruta insegura en el archivo: ' + str(name))
            budget[0] += 1; budget[1] += entry.file_size
            if budget[0] > 100000 or budget[1] > 2_000_000_000 or entry.file_size > 128_000_000:
                raise ValueError('El archivo excede los límites de lectura segura.')
            data = z.read(entry)
            if str(name).endswith(('.mcpack', '.zip')) and depth < 2:
                with zipfile.ZipFile(io.BytesIO(data)) as nested:
                    yield from visit(nested, prefix + str(name) + '/', depth + 1)
            else: yield prefix + str(name), data
    with zipfile.ZipFile(path) as z: yield from visit(z)


class ReferenceAddon:
    def __init__(self, path):
        self.path = str(path); self.geometries = []; self.texture_hashes = {}; self.errors = []
        counts = Counter(); formats = Counter(); negative = 0
        wheel_documents={}; paths=set()
        for name, data in archive_entries(path):
            paths.add(name)
            counts[PurePosixPath(name).suffix] += 1
            if name.endswith('.png'):
                try:
                    digest, size = pixel_hash(data)
                    self.texture_hashes.setdefault(digest, []).append({'path':name,'size':size})
                except Exception as e: self.errors.append({'path':name,'error':str(e)})
            elif name.endswith('.json'):
                try: obj = jsonc(data)
                except (ValueError, UnicodeError) as e:
                    self.errors.append({'path':name,'error':str(e)}); continue
                if not isinstance(obj, dict): continue
                if 'water_wheel' in name:
                    wheel_documents[name]=obj
                gs = obj.get('minecraft:geometry', [])
                if not isinstance(gs, list): continue
                for g in gs:
                    if not isinstance(g, dict): continue
                    desc = g.get('description', {})
                    cubes = [c for b in g.get('bones',[]) for c in b.get('cubes',[])]
                    negative += sum(any(v<0 for v in c.get('size',[])) for c in cubes)
                    formats[str(obj.get('format_version','?'))] += 1
                    self.geometries.append({'path':name,'identifier':desc.get('identifier',''),
                        'bones':len(g.get('bones',[])), 'cubes':len(cubes),
                        'texture_size':[desc.get('texture_width'),desc.get('texture_height')],
                        'has_poly_mesh':any('poly_mesh' in b for b in g.get('bones',[]))})
        from .wheel_audit import audit_water_wheels
        self.water_wheels=audit_water_wheels(wheel_documents, paths)
        self.summary = {'name':PurePosixPath(str(path)).name, 'files':sum(counts.values()),
            'geometry_definitions':len(self.geometries), 'png_files':counts['.png'],
            'scripts':counts['.js'],'geometry_formats':dict(formats),
            'negative_size_cubes':negative,'parse_errors':len(self.errors),
            'water_wheel_profiles':len(self.water_wheels['wheels'])}

    def candidates(self, model_id):
        words = [x for x in re.split(r'[/.:]',model_id) if x not in {'block','item','create','model'}]
        names = [w for w in words if w not in {'block','item','base','shaft','top','bottom'}] or words
        found=[]
        for g in self.geometries:
            hay=g['identifier'].lower()+' '+g['path'].lower()
            matches=[w for w in names if len(w)>2 and w.lower() in hay]
            if matches:
                found.append(dict(g,match='name_candidate',score=max(map(len,matches)),
                    note='Coincidencia de nombre; no demuestra equivalencia ni composición correcta.'))
        return sorted(found,key=lambda g:(-g['score'],g['identifier']))[:8]

    def compare_texture(self, data):
        try: digest,_=pixel_hash(data); return self.texture_hashes.get(digest,[])
        except Exception: return []

    def to_dict(self):
        return {'summary':self.summary,'geometries':self.geometries,'errors':self.errors,'water_wheels':self.water_wheels}
