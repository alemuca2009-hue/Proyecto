"""Small, shared report contract for the worker and model library.

Size is a property of the model, not a claim that conversion succeeded.
Do not include meshes, texture paths or detailed metrics in this catalogue.
"""
from .verification import final_status, has_reconstructed_surface_notice
from .analysis_states import analysis_states


def is_extended3d(report):
    explicit = report.get('extended3d')
    if isinstance(explicit, bool):
        return explicit
    profile = report.get('model_profile') or {}
    if not isinstance(profile, dict):
        return False
    for side in ('source', 'target'):
        size = profile.get(side) or {}
        if (isinstance(size, dict) and size.get('valid') is True
                and any(reason in ('extent_over_30', 'outside_origin_bounds')
                        for reason in (size.get('reasons') or []))):
            return True
    return False


def compact_report(report):
    """Keep these keys in every compact path, including legacy full reports."""
    return {**{key: report.get(key) for key in ('id', 'slug')},
            'status': final_status(report),
            'extended3d': is_extended3d(report),
            'analysis': analysis_states(report),
            'requires_surface_review': has_reconstructed_surface_notice(report)}
