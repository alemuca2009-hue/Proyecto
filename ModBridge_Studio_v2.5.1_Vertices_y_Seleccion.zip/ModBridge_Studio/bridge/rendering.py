"""Deterministic, offline orthographic comparisons of independently decoded meshes.

IR vertices use centered Java space (x - 8, y, z - 8); UVs are in pixels.
Views use double-sided surfaces and neutral unlit illumination on transparency.
These are diagnostic static views, not a simulation of either game's renderer.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image, ImageChops, ImageDraw
from .control import checkpoint

VIEWS = {
    "frontal": ((1, 0, 0), (0, 1, 0), (0, 0, -1)),
    "trasera": ((-1, 0, 0), (0, 1, 0), (0, 0, 1)),
    "izquierda": ((0, 0, -1), (0, 1, 0), (-1, 0, 0)),
    "derecha": ((0, 0, 1), (0, 1, 0), (1, 0, 0)),
    "superior": ((1, 0, 0), (0, 0, -1), (0, 1, 0)),
    "inferior": ((1, 0, 0), (0, 0, 1), (0, -1, 0)),
}
VIEW_LABELS = {
    "frontal": "Frontal (norte / -Z)",
    "trasera": "Trasera (sur / +Z)",
    "izquierda": "Izquierda (oeste / -X)",
    "derecha": "Derecha (este / +X)",
    "superior": "Superior (+Y)",
    "inferior": "Inferior (-Y)",
}


def _faces(ir: dict) -> list[dict]:
    return ir.get("faces", [])


def _actual_bounds(ir: dict) -> np.ndarray:
    points = [p for f in _faces(ir) for p in f.get("vertices", [])]
    if points:
        a = np.asarray(points, dtype=np.float64)
        if a.ndim != 2 or a.shape[1] != 3 or not np.isfinite(a).all():
            raise ValueError("La geometría contiene coordenadas inválidas o no finitas")
        return np.array([a.min(axis=0), a.max(axis=0)])
    return np.zeros((2, 3), dtype=np.float64)


def combined_bounds(*irs: dict) -> list[list[float]]:
    nonempty = [_actual_bounds(ir) for ir in irs if _faces(ir)]
    if not nonempty:
        return [[-8.0, 0.0, -8.0], [8.0, 16.0, 8.0]]
    return [np.min([x[0] for x in nonempty], axis=0).tolist(),
            np.max([x[1] for x in nonempty], axis=0).tolist()]


def _texture_path(value: Any) -> str | Path | None:
    if isinstance(value, (str, Path)):
        return value
    if isinstance(value, dict):
        return value.get("path") or value.get("file")
    return None


def _load_textures(ir: dict) -> tuple[dict[str, np.ndarray], list[str]]:
    textures: dict[str, np.ndarray] = {}
    missing = []
    for key in {str(f.get("texture", "")) for f in _faces(ir)}:
        value = ir.get("textures", {}).get(key)
        if ir.get("texture_metadata", {}).get(key, {}).get("missing"):
            missing.append(key)
        try:
            if isinstance(value, Image.Image):
                im = value.convert("RGBA")
            elif isinstance(value, np.ndarray):
                im = Image.fromarray(value.astype(np.uint8)).convert("RGBA")
            else:
                path = _texture_path(value)
                if path is None:
                    raise OSError("Sin ruta de textura")
                with Image.open(path) as opened:
                    im = opened.convert("RGBA")
            textures[key] = np.asarray(im, dtype=np.uint8)
        except (OSError, ValueError, TypeError):
            # An explicit diagnostic placeholder, never a successful texture match.
            if key not in missing:
                missing.append(key)
            a = np.zeros((16, 16, 4), dtype=np.uint8)
            yy, xx = np.indices((16, 16))
            a[:, :, 0] = np.where(((xx // 4 + yy // 4) % 2) == 0, 255, 50)
            a[:, :, 2] = np.where(((xx // 4 + yy // 4) % 2) == 0, 255, 50)
            a[:, :, 3] = 255
            textures[key] = a
    return textures, missing


from conversion_engine.triangulation import _triangulate


def _prepare_faces(ir: dict, textures: dict) -> list[tuple]:
    prepared = []
    for face in _faces(ir):
        vertices = np.asarray(face.get("vertices", []), dtype=np.float64)
        uv = np.asarray(face.get("uv", []), dtype=np.float64)
        if len(vertices) < 3 or vertices.shape != (len(vertices), 3):
            continue
        if uv.shape != (len(vertices), 2):
            uv = np.zeros((len(vertices), 2), dtype=np.float64)
        if not np.isfinite(vertices).all() or not np.isfinite(uv).all():
            raise ValueError("Coordenadas o UV no finitos")
        texture = textures.get(str(face.get("texture", "")))
        if texture is not None:
            prepared.append((vertices, uv, texture, _triangulate(vertices)))
    return prepared


def _translucent_flags(textures):
    flags={}
    for texture in textures.values():
        found=False
        # Avoid multiple full-size boolean arrays for large RGBA atlases.
        for row in range(0,texture.shape[0],128):
            checkpoint()
            alpha=texture[row:row+128,:,3]
            if np.any((alpha>0)&(alpha<255)):
                found=True;break
        flags[id(texture)]=found
    return flags


# Upper bound on simultaneously buffered translucent fragments, independent of
# model depth complexity. Exact per-pixel compositing, no dropped layers.
TRANSPARENCY_FRAGMENT_BUDGET = 262144


def render_view(ir: dict, view: str, size: int = 192,
                bounds: list[list[float]] | None = None, *,
                _textures=None, _prepared=None, _stats=None, _alpha_flags=None,
                _depth_output=None) -> Image.Image:
    if view not in VIEWS:
        raise ValueError(f"Vista desconocida: {view}")
    if not 32 <= int(size) <= 2048:
        raise ValueError("El tamaño de vista debe estar entre 32 y 2048 píxeles")
    checkpoint()
    size = int(size)
    if _depth_output is not None:
        if not isinstance(_depth_output, np.ndarray) or _depth_output.shape != (size, size):
            raise ValueError("El destino de profundidad debe coincidir con la resolución")
        _depth_output.fill(-np.inf)
    bounds_array = np.asarray(bounds if bounds is not None else combined_bounds(ir), dtype=np.float64)
    if bounds_array.shape != (2, 3) or not np.isfinite(bounds_array).all():
        raise ValueError("Límites de cámara inválidos")
    center = (bounds_array[0] + bounds_array[1]) / 2
    extent = max(float(np.max(bounds_array[1] - bounds_array[0])), 1e-9)
    scale = size * 0.84 / extent
    basis = np.asarray(VIEWS[view], dtype=np.float64)
    textures = _textures if _textures is not None else _load_textures(ir)[0]
    prepared = _prepared if _prepared is not None else _prepare_faces(ir, textures)
    alpha_flags = _alpha_flags if _alpha_flags is not None else _translucent_flags(textures)
    triangles = []
    for vertices, uv, tex, indices in prepared:
        checkpoint()
        projected = (vertices - center) @ basis.T
        projected[:, 0] = size / 2 + projected[:, 0] * scale
        projected[:, 1] = size / 2 - projected[:, 1] * scale
        for triangle in indices:
            ix = np.asarray(triangle); points = projected[ix]
            x0 = max(0, int(math.floor(float(points[:, 0].min()) - .5)))
            x1 = min(size - 1, int(math.ceil(float(points[:, 0].max()) - .5)))
            y0 = max(0, int(math.floor(float(points[:, 1].min()) - .5)))
            y1 = min(size - 1, int(math.ceil(float(points[:, 1].max()) - .5)))
            denom = ((points[1, 1] - points[2, 1]) * (points[0, 0] - points[2, 0]) +
                     (points[2, 0] - points[1, 0]) * (points[0, 1] - points[2, 1]))
            if x0 <= x1 and y0 <= y1 and abs(float(denom)) >= 1e-12:
                triangles.append((points, uv[ix], tex, denom, (x0, y0, x1, y1), alpha_flags[id(tex)]))
    output = np.zeros((size, size, 4), dtype=np.uint8)
    stats = {'peak_transparent_fragments': 0, 'tiles': 0, 'fragment_budget': TRANSPARENCY_FRAGMENT_BUDGET}

    def draw_region(region, candidates):
        checkpoint()
        left, top, right, bottom = region
        estimated = sum((min(right, t[4][2])-max(left,t[4][0])+1) *
                        (min(bottom,t[4][3])-max(top,t[4][1])+1) for t in candidates if t[5])
        if estimated > TRANSPARENCY_FRAGMENT_BUDGET and (right > left or bottom > top):
            if right-left >= bottom-top:
                middle=(left+right)//2; regions=((left,top,middle,bottom),(middle+1,top,right,bottom))
            else:
                middle=(top+bottom)//2; regions=((left,top,right,middle),(left,middle+1,right,bottom))
            for r in regions:
                active=[t for t in candidates if t[4][0]<=r[2] and t[4][2]>=r[0] and t[4][1]<=r[3] and t[4][3]>=r[1]]
                if active:draw_region(r,active)
            return
        if estimated > TRANSPARENCY_FRAGMENT_BUDGET:
            raise ValueError('Más de 65.536 capas translúcidas en un píxel; se detiene esta vista para respetar el presupuesto de memoria, sin descartar caras.')
        stats['tiles'] += 1
        width=right-left+1; height=bottom-top+1
        zbuffer=np.full((height,width),-np.inf,dtype=np.float64)
        tile=output[top:bottom+1,left:right+1]
        transparent=[]; fragment_count=0
        for p,tuv,tex,denom,box,_ in candidates:
            checkpoint()
            x0=max(left,box[0]);x1=min(right,box[2]);y0=max(top,box[1]);y1=min(bottom,box[3])
            yy,xx=np.mgrid[y0:y1+1,x0:x1+1];px,py=xx+.5,yy+.5
            a=((p[1,1]-p[2,1])*(px-p[2,0])+(p[2,0]-p[1,0])*(py-p[2,1]))/denom
            b=((p[2,1]-p[0,1])*(px-p[2,0])+(p[0,0]-p[2,0])*(py-p[2,1]))/denom
            c=1-a-b;mask=(a>=-1e-10)&(b>=-1e-10)&(c>=-1e-10)
            if not mask.any():continue
            sx,sy=xx[mask]-left,yy[mask]-top;bary=np.stack((a[mask],b[mask],c[mask]),axis=-1)
            depth=bary@p[:,2];visible=depth>=zbuffer[sy,sx]-1e-9
            if not visible.any():continue
            sx,sy,depth,bary=sx[visible],sy[visible],depth[visible],bary[visible]
            texuv=bary@tuv
            tx=np.clip(np.floor(texuv[:,0]+1e-9).astype(np.int64),0,tex.shape[1]-1)
            ty=np.clip(np.floor(texuv[:,1]+1e-9).astype(np.int64),0,tex.shape[0]-1)
            rgba=tex[ty,tx];alpha=rgba[:,3]
            opaque=(alpha==255)&(depth>zbuffer[sy,sx]+1e-10)
            if opaque.any():zbuffer[sy[opaque],sx[opaque]]=depth[opaque];tile[sy[opaque],sx[opaque]]=rgba[opaque]
            translucent=(alpha>0)&(alpha<255)
            if translucent.any():
                transparent.append((sy[translucent]*width+sx[translucent],depth[translucent],rgba[translucent]))
                fragment_count+=int(translucent.sum())
        stats['peak_transparent_fragments']=max(stats['peak_transparent_fragments'],fragment_count)
        if transparent:_composite_transparent(tile,zbuffer,transparent)
        if _depth_output is not None:
            _depth_output[top:bottom+1,left:right+1] = zbuffer
    if triangles:draw_region((0,0,size-1,size-1),triangles)
    if _stats is not None:_stats.update(stats)
    return Image.fromarray(output,"RGBA")


def _composite_transparent(output: np.ndarray, zbuffer: np.ndarray,
                           fragments: list[tuple[np.ndarray, np.ndarray, np.ndarray]]) -> None:
    pixels = np.concatenate([x[0] for x in fragments])
    depths = np.concatenate([x[1] for x in fragments])
    colors = np.concatenate([x[2] for x in fragments])
    visible = depths >= zbuffer.ravel()[pixels] - 1e-9
    pixels, depths, colors = pixels[visible], depths[visible], colors[visible]
    if not len(pixels):
        return
    # Per-pixel order from far to near, stable on equal depths.
    order = np.lexsort((depths, pixels))
    pixels, depths, colors = pixels[order], depths[order], colors[order]
    duplicate = np.zeros(len(pixels), dtype=bool)
    if len(pixels) > 1:
        duplicate[1:] = ((pixels[1:] == pixels[:-1]) &
                         (np.abs(depths[1:] - depths[:-1]) <= 1e-9) &
                         np.all(colors[1:] == colors[:-1], axis=1))
    pixels, colors = pixels[~duplicate], colors[~duplicate]
    starts = np.r_[0, np.where(pixels[1:] != pixels[:-1])[0] + 1]
    counts = np.diff(np.r_[starts, len(pixels)])
    ranks = np.arange(len(pixels)) - np.repeat(starts, counts)
    dst = output.reshape(-1, 4).astype(np.float64) / 255
    # Premultiplied-alpha compositing prevents dark fringes on transparency.
    dst[:, :3] *= dst[:, 3:4]
    src = colors.astype(np.float64) / 255
    src[:, :3] *= src[:, 3:4]
    rank_order = np.argsort(ranks, kind='stable')
    boundaries = np.r_[0, np.where(np.diff(ranks[rank_order]) != 0)[0] + 1, len(ranks)]
    for begin, end in zip(boundaries[:-1], boundaries[1:]):
        checkpoint()
        indices = rank_order[begin:end]
        pix = pixels[indices]
        dst[pix, :3] = src[indices, :3] + dst[pix, :3] * (1 - src[indices, 3:4])
        dst[pix, 3] = src[indices, 3] + dst[pix, 3] * (1 - src[indices, 3])
    nonzero = dst[:, 3] > 0
    dst[nonzero, :3] /= dst[nonzero, 3:4]
    output[:] = np.clip(np.rint(dst * 255), 0, 255).astype(np.uint8).reshape(output.shape)


def image_metrics(original: Image.Image, translated: Image.Image) -> dict:
    a = np.asarray(original.convert("RGBA"), dtype=np.int16)
    b = np.asarray(translated.convert("RGBA"), dtype=np.int16)
    if a.shape != b.shape:
        raise ValueError("Las imágenes comparadas deben tener idénticas dimensiones")
    diff = np.abs(a - b)
    mismatch = np.any(diff != 0, axis=2)
    union = (a[:, :, 3] != 0) | (b[:, :, 3] != 0)
    union_count = int(union.sum())
    # RGBA is reported, and visible premultiplied colors avoid counting hidden RGB.
    af = a.astype(float) / 255
    bf = b.astype(float) / 255
    af[:, :, :3] *= af[:, :, 3:4]
    bf[:, :, :3] *= bf[:, :, 3:4]
    pdiff = np.abs(af - bf)
    return {
        "rgba_mae": float(diff.mean()),
        "max_channel_difference": int(diff.max(initial=0)),
        "mismatch_pixels": int(mismatch.sum()),
        "total_pixels": int(mismatch.size),
        "visible_union_pixels": union_count,
        "mismatch_fraction": float(mismatch.mean()),
        "visible_mismatch_fraction": float(mismatch[union].mean()) if union_count else 0.0,
        "alpha_mae": float(diff[:, :, 3].mean()),
        "premultiplied_mae": float(pdiff.mean()),
        "pixel_identical": bool(not mismatch.any()),
    }


def _checkerboard(im: Image.Image) -> Image.Image:
    yy, xx = np.indices((im.height, im.width))
    level = np.where(((xx // 12 + yy // 12) % 2) == 0, 232, 246).astype(np.uint8)
    bg = np.dstack((level, level, level, np.full_like(level, 255)))
    return Image.alpha_composite(Image.fromarray(bg, "RGBA"), im.convert("RGBA"))


def compare_views(original_ir: dict, bedrock_ir: dict, out_dir: str | Path,
                  size: int = 192) -> dict:
    """Write six aligned pairs, differences and a contact sheet with metrics."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    bounds = combined_bounds(original_ir, bedrock_ir)
    original_textures, original_missing = _load_textures(original_ir)
    target_textures, target_missing = _load_textures(bedrock_ir)
    original_alpha=_translucent_flags(original_textures)
    target_alpha=_translucent_flags(target_textures)
    original_prepared = _prepare_faces(original_ir, original_textures)
    target_prepared = _prepare_faces(bedrock_ir, target_textures)
    result = {
        "size": int(size), "bounds": bounds,
        "method": "orthographic_nearest_rgba_unlit_double_sided",
        "camera_scale": "one shared scale for all views and both models",
        "view_axes": {k: {"screen_right": list(v[0]), "screen_up": list(v[1]), "camera_from": list(v[2])} for k, v in VIEWS.items()},
        "missing_textures": {"original": original_missing, "translated": target_missing},
        "limitations": [
            "Comparación estática de superficies a doble cara con iluminación ambiental neutra; no ejecuta Minecraft.",
            "Las seis vistas no prueban por sí solas equivalencia geométrica, animación, materiales, tintes o comportamiento.",
            "Muestreo nearest; UV fuera de la textura se limitan al borde y requieren revisión.",
        ],
        "views": {},
    }
    sheet = Image.new("RGB", (size * 3, (size + 42) * 6 + 32), (20, 26, 39))
    draw = ImageDraw.Draw(sheet)
    draw.text((10, 10), "ORIGINAL JAVA", fill=(225, 234, 246))
    draw.text((size + 10, 10), "TRADUCIDO BEDROCK", fill=(225, 234, 246))
    draw.text((size * 2 + 10, 10), "DIFERENCIA RGBA", fill=(225, 234, 246))
    for row, name in enumerate(VIEWS):
        checkpoint()
        folder = out / name
        folder.mkdir(parents=True, exist_ok=True)
        a = render_view(original_ir, name, size, bounds, _textures=original_textures, _prepared=original_prepared, _alpha_flags=original_alpha)
        b = render_view(bedrock_ir, name, size, bounds, _textures=target_textures, _prepared=target_prepared, _alpha_flags=target_alpha)
        a.save(folder / "original.png")
        b.save(folder / "traducido.png")
        # A visible heat map includes differences solely in alpha as well as RGB.
        delta = np.abs(np.asarray(a).astype(np.int16) - np.asarray(b).astype(np.int16))
        strength = delta.max(axis=2).astype(np.uint8)
        heat = np.zeros((size, size, 4), dtype=np.uint8)
        heat[:, :, 0] = strength
        heat[:, :, 1] = strength // 3
        heat[:, :, 3] = 255
        difference = Image.fromarray(heat, "RGBA")
        difference.save(folder / "diferencia.png")
        metrics = image_metrics(a, b)
        metrics["paths"] = {"original": f"{name}/original.png", "translated": f"{name}/traducido.png", "difference": f"{name}/diferencia.png"}
        result["views"][name] = metrics
        top = row * (size + 42) + 32
        for col, im in enumerate((a, b, difference)):
            sheet.paste(_checkerboard(im).convert("RGB"), (col * size, top + 22))
        draw.text((10, top + 4), VIEW_LABELS[name], fill=(225, 234, 246))
        draw.text((size + 10, top + 4), f'{metrics["mismatch_pixels"]} pixeles distintos', fill=(162, 190, 222))
    result["has_source_geometry"] = bool(_faces(original_ir))
    result["has_target_geometry"] = bool(_faces(bedrock_ir))
    result["all_views_pixel_identical"] = bool(_faces(original_ir) and _faces(bedrock_ir)) and all(v["pixel_identical"] for v in result["views"].values()) and not (original_missing or target_missing)
    result["rgba_mae_mean"] = float(np.mean([v["rgba_mae"] for v in result["views"].values()]))
    result["contact_sheet"] = "comparacion_seis_vistas.png"
    result["geometry"] = compare_geometry(original_ir, bedrock_ir, _source_textures=(original_textures,original_missing), _target_textures=(target_textures,target_missing))
    sheet.save(out / result["contact_sheet"])
    (out / "comparacion.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    return result


def _face_signature(face: dict, tolerance: float) -> tuple:
    vertices = np.asarray(face.get("vertices", []), dtype=float)
    if vertices.size == 0:
        return ()
    rounded = [tuple(int(round(float(c) / tolerance)) for c in p) for p in vertices]
    # Cyclic origin and winding independent: compare surfaces, not list order.
    candidates = [tuple(rounded[i:] + rounded[:i]) for i in range(len(rounded))]
    reverse = list(reversed(rounded))
    candidates += [tuple(reverse[i:] + reverse[:i]) for i in range(len(reverse))]
    return min(candidates)


def _normal(face: dict) -> np.ndarray:
    value = face.get("normal")
    if value is not None:
        normal = np.asarray(value, dtype=float)
    else:
        verts = np.asarray(face.get("vertices", []), dtype=float)
        normal = np.cross(verts[1] - verts[0], verts[2] - verts[0]) if len(verts) >= 3 else np.zeros(3)
    length = np.linalg.norm(normal)
    return normal / length if length > 1e-15 else normal


def _align_vertex_indices(a: dict, b: dict, tolerance: float) -> list[int] | None:
    va, vb = np.asarray(a.get("vertices", []), dtype=float), np.asarray(b.get("vertices", []), dtype=float)
    if va.shape != vb.shape:
        return None
    indices = []
    available = set(range(len(vb)))
    for p in va:
        candidates = [(float(np.linalg.norm(p - vb[i])), i) for i in available]
        if not candidates:
            return None
        distance, i = min(candidates)
        if distance > tolerance * math.sqrt(3) * 1.01:
            return None
        indices.append(i)
        available.remove(i)
    return indices


def _surface_area(ir: dict) -> float:
    area = 0.0
    for f in _faces(ir):
        vertices = np.asarray(f.get("vertices", []), dtype=float)
        for indices in _triangulate(vertices):
            a, b, c = vertices[list(indices)]
            area += float(np.linalg.norm(np.cross(b - a, c - a))) / 2
    return area


def _texture_sample_signature(face: dict, textures: dict, order: list[int] | None = None) -> np.ndarray | None:
    """Fixed barycentric samples detect assignment/rotation; not a proof of all texels."""
    uv = np.asarray(face.get("uv", []), dtype=float)
    if order is not None:
        uv = uv[order]
    tex = textures.get(str(face.get("texture", "")))
    if tex is None or uv.ndim != 2 or uv.shape[1] != 2 or len(uv) < 3:
        return None
    samples = []
    # Sample interior only; UV border ownership is convention-dependent.
    for i in range(1, len(uv) - 1):
        tri = uv[[0, i, i + 1]]
        weights = []
        for a in range(1, 8):
            for b in range(1, 8 - a):
                weights.append([a / 8, b / 8, (8 - a - b) / 8])
        coords = np.asarray(weights) @ tri
        x = np.clip(np.floor(coords[:, 0] + 1e-9).astype(int), 0, tex.shape[1] - 1)
        y = np.clip(np.floor(coords[:, 1] + 1e-9).astype(int), 0, tex.shape[0] - 1)
        samples.append(tex[y, x])
    return np.concatenate(samples) if samples else None


def _oriented_surface_comparison(source_faces, target_faces, tolerance):
    """Compare bounded planar surface chains, independently of triangulation.

    For each oriented plane, cancel shared polygon edges as signed intervals
    on their supporting lines. Equal remaining boundaries imply equal planar
    coverage *with multiplicity*. Thus duplicate faces, holes, reversed normals
    and overhanging masked rectangles cannot disappear in a boolean union.
    """
    planes = []
    invalid = {"original": [], "translated": []}
    for side, faces, sign in (("original", source_faces, 1), ("translated", target_faces, -1)):
        for index, face in enumerate(faces):
            checkpoint()
            vertices = np.asarray(face.get("vertices", []), dtype=float)
            normal = _normal(face)
            if (vertices.ndim != 2 or vertices.shape[1:] != (3,) or len(vertices) < 3
                    or not np.isfinite(vertices).all() or not np.isfinite(normal).all()
                    or np.linalg.norm(normal) < .5):
                invalid[side].append(index)
                continue
            distance = float(vertices[0] @ normal)
            if np.max(np.abs(vertices @ normal - distance)) > tolerance:
                invalid[side].append(index)
                continue
            # Reject zero-area/invalid polygons; a boundary identity must not
            # silently approve faces the renderer could not triangulate.
            triangles = _triangulate(vertices)
            signed_area = sum(np.cross(a, b) for a, b in zip(vertices, np.roll(vertices, -1, axis=0)))
            triangle_area = sum(float(np.linalg.norm(np.cross(vertices[b]-vertices[a], vertices[c]-vertices[a])))
                                for a, b, c in triangles)
            if (not triangles or triangle_area <= 1e-12
                    or abs(abs(float(signed_area @ normal)) - triangle_area) > max(1e-10, triangle_area * 1e-9)):
                invalid[side].append(index)
                continue
            if float(signed_area @ normal) < 0:
                vertices = vertices[::-1]
            plane = next((g for g in planes if np.linalg.norm(g["normal"]-normal) <= tolerance
                          and np.max(np.abs(vertices @ g["normal"]-g["distance"])) <= tolerance), None)
            if plane is None:
                plane = {"normal":normal, "distance":distance,
                         "drop":int(np.argmax(np.abs(normal))), "lines":[]}
                planes.append(plane)
            xy = np.delete(vertices, plane["drop"], axis=1)
            for a, b in zip(xy, np.roll(xy, -1, axis=0)):
                delta = b-a
                length = float(np.linalg.norm(delta))
                if length <= tolerance:
                    continue
                direction = delta/length
                if direction[0] < -tolerance or (abs(direction[0]) <= tolerance and direction[1] < 0):
                    direction = -direction
                perpendicular = np.array([-direction[1], direction[0]])
                line = next((g for g in plane["lines"]
                             if np.linalg.norm(g["direction"]-direction) <= tolerance
                             and max(abs(float(a @ g["perpendicular"])-g["offset"]),
                                     abs(float(b @ g["perpendicular"])-g["offset"])) <= tolerance), None)
                if line is None:
                    line = {"direction":direction, "perpendicular":perpendicular,
                            "offset":float(a @ perpendicular), "events":[]}
                    plane["lines"].append(line)
                t0, t1 = float(a @ line["direction"]), float(b @ line["direction"])
                weight = sign if t1 > t0 else -sign
                line["events"].extend(((min(t0,t1),weight), (max(t0,t1),-weight)))
    unmatched = 0.0
    mismatched_intervals = 0
    for plane in planes:
        # Projection loses at most sqrt(3) in length; restore the actual 3D
        # length using the plane equation for each supporting direction.
        n = plane["normal"]
        kept = np.delete(n, plane["drop"])
        for line in plane["lines"]:
            events = sorted(line["events"])
            merged = []
            for coordinate, delta in events:
                if merged and coordinate-merged[-1][0] <= tolerance:
                    merged[-1][1] += delta
                else:
                    merged.append([coordinate,delta])
            balance = 0
            scale = math.sqrt(1+(float(kept @ line["direction"])/float(n[plane["drop"]]))**2)
            for i, (coordinate, delta) in enumerate(merged):
                balance += delta
                if i+1 < len(merged) and balance:
                    length = (merged[i+1][0]-coordinate)*scale
                    if length > tolerance:
                        unmatched += length*abs(balance)
                        mismatched_intervals += 1
    return {"equal":bool(source_faces and target_faces and not any(invalid.values()) and not mismatched_intervals),
            "oriented_plane_count":len(planes), "invalid_surface_faces":invalid,
            "unmatched_boundary_length_model_units":float(unmatched),
            "unmatched_boundary_interval_count":mismatched_intervals}


def _uv_mapping_comparison(source, target, source_textures, target_textures, tolerance):
    """Conservative independent proof for native copied-tile UV mappings.

    Derive affine maps from actual polygons, locate the implied integer atlas
    translation, compare the complete RGBA tile, then compare oriented surface
    coverage per material/map. Raster samples or atlas metadata are not proof.
    Non-affine polygons are split into the renderer's actual triangles.
    """
    source_groups = []
    key_to_group = {}
    invalid_source = []
    invalid_target = []

    def triangles(ir):
        for face_index, face in enumerate(_faces(ir)):
            vertices = np.asarray(face.get("vertices", []), dtype=float)
            uv = np.asarray(face.get("uv", []), dtype=float)
            normal = _normal(face)
            texture = str(face.get("texture", ""))
            if (vertices.ndim != 2 or vertices.shape[1:] != (3,) or uv.shape != (len(vertices),2)
                    or not np.isfinite(vertices).all() or not np.isfinite(uv).all()
                    or not np.isfinite(normal).all() or np.linalg.norm(normal) < .5):
                yield face_index, None
                continue
            drop = int(np.argmax(np.abs(normal)))
            for indices in _triangulate(vertices):
                points, coords = vertices[list(indices)], uv[list(indices)]
                xy = np.delete(points,drop,axis=1)
                try:
                    matrix = np.linalg.solve(np.column_stack((xy,np.ones(3))),coords)
                except np.linalg.LinAlgError:
                    yield face_index, None
                    continue
                triangle = {"vertices":points.tolist(), "normal":normal.tolist()}
                yield face_index, (triangle,texture,normal,float(points[0] @ normal),drop,matrix,coords)

    for face_index, item in triangles(source):
        if item is None:
            invalid_source.append(face_index)
            continue
        triangle,texture,normal,distance,drop,matrix,coords = item
        pixels = source_textures.get(texture)
        if (pixels is None or coords.min() < -tolerance
                or coords[:,0].max() > pixels.shape[1]+tolerance
                or coords[:,1].max() > pixels.shape[0]+tolerance):
            invalid_source.append(face_index)
            continue
        key = (texture,drop,tuple(np.round(normal,7)),round(distance,7),tuple(np.round(matrix.ravel(),7)))
        index = key_to_group.get(key)
        if index is None:
            index = len(source_groups);key_to_group[key] = index
            source_groups.append({"texture":texture,"normal":normal,"distance":distance,
                                  "drop":drop,"matrix":matrix,"original":[],"translated":[]})
        source_groups[index]["original"].append(triangle)
    if not source_groups:
        return {"uv_mapping_check_passed":False,"uv_mapping_method":"copied_tiles_affine_translation",
                "uv_mapping_unmatched_source_faces":sorted(set(invalid_source)),
                "uv_mapping_unmatched_target_faces":list(range(len(_faces(target)))),
                "uv_mapping_texture_tiles_checked":0}
    normals = np.asarray([g["normal"] for g in source_groups])
    distances = np.asarray([g["distance"] for g in source_groups])
    drops = np.asarray([g["drop"] for g in source_groups])
    derivatives = np.asarray([g["matrix"][:2] for g in source_groups])
    tile_checks = {}
    for face_index, item in triangles(target):
        checkpoint()
        if item is None:
            invalid_target.append(face_index)
            continue
        triangle,texture,normal,distance,drop,matrix,coords = item
        target_pixels = target_textures.get(texture)
        if target_pixels is None:
            invalid_target.append(face_index)
            continue
        candidates = np.flatnonzero((drops == drop)
                    & (np.max(np.abs(normals-normal),axis=1) <= tolerance)
                    & (np.abs(distances-distance) <= tolerance)
                    & (np.max(np.abs(derivatives-matrix[:2]),axis=(1,2)) <= min(tolerance,1e-7)))
        found = False
        for index in candidates:
            group = source_groups[index]
            offset = matrix[2]-group["matrix"][2]
            rounded = np.rint(offset)
            if np.max(np.abs(offset-rounded)) > min(tolerance,1e-6):
                continue
            x,y = map(int,rounded)
            original_pixels = source_textures[group["texture"]]
            h,w = original_pixels.shape[:2]
            key = (group["texture"],texture,x,y)
            if key not in tile_checks:
                tile_checks[key] = (x >= 0 and y >= 0 and x+w <= target_pixels.shape[1]
                                   and y+h <= target_pixels.shape[0]
                                   and np.array_equal(original_pixels,target_pixels[y:y+h,x:x+w]))
            if not tile_checks[key]:
                continue
            group["translated"].append(triangle)
            found = True
            break
        if not found:
            invalid_target.append(face_index)
    coverage_failures = 0
    for group in source_groups:
        if not _oriented_surface_comparison(group["original"],group["translated"],tolerance)["equal"]:
            coverage_failures += 1
    return {"uv_mapping_check_passed":bool(not invalid_source and not invalid_target and not coverage_failures),
            "uv_mapping_method":"copied_tiles_affine_translation",
            "uv_mapping_unmatched_source_faces":sorted(set(invalid_source)),
            "uv_mapping_unmatched_target_faces":sorted(set(invalid_target)),
            "uv_mapping_coverage_mismatch_groups":coverage_failures,
            "uv_mapping_texture_tiles_checked":len(tile_checks),
            "uv_mapping_scope":"UV afines, textura RGBA completa copiada sin remuestreo y cobertura por material; no certifica animación ni sombreado runtime."}


def compare_geometry(source: dict, target: dict, tolerance: float = 1e-5, *, _source_textures=None, _target_textures=None) -> dict:
    """Compare emitted/decoded face surfaces, dimensions and normals.

    Report tessellation identity separately from oriented planar coverage.
    Boundary cancellation permits exact triangle-to-rectangle reconstruction,
    while retaining normal orientation, holes and overlapping multiplicity.
    Texture samples remain supplemental evidence, not a texel proof.
    """
    if tolerance <= 0:
        raise ValueError("La tolerancia debe ser positiva")
    from collections import defaultdict

    sa, ta = _faces(source), _faces(target)
    sb, tb = _actual_bounds(source), _actual_bounds(target)
    target_groups = defaultdict(list)
    for i, face in enumerate(ta):
        target_groups[_face_signature(face, tolerance)].append(i)
    matched = []
    missing_source = []
    for i, face in enumerate(sa):
        candidates = target_groups.get(_face_signature(face, tolerance), [])
        chosen = None
        ordered_candidates = sorted(candidates, key=lambda j: float(np.linalg.norm(_normal(face) - _normal(ta[j]))))
        for j in ordered_candidates:
            if _align_vertex_indices(face, ta[j], tolerance) is not None:
                chosen = j
                break
        if chosen is None:
            missing_source.append(i)
        else:
            candidates.remove(chosen)
            matched.append((i, chosen))
    extra_target = [j for values in target_groups.values() for j in values]
    max_vertex_error = 0.0
    max_normal_error = 0.0
    normals_changed = 0
    texture_mismatch = 0
    samples_compared = 0
    st, sm = _source_textures if _source_textures is not None else _load_textures(source)
    tt, tm = _target_textures if _target_textures is not None else _load_textures(target)
    for i, j in matched:
        checkpoint()
        a, b = sa[i], ta[j]
        order = _align_vertex_indices(a, b, tolerance)
        assert order is not None
        av, bv = np.asarray(a["vertices"]), np.asarray(b["vertices"])[order]
        max_vertex_error = max(max_vertex_error, float(np.max(np.abs(av - bv), initial=0)))
        normal_error = float(np.linalg.norm(_normal(a) - _normal(b)))
        max_normal_error = max(max_normal_error, normal_error)
        normals_changed += int(normal_error > tolerance)
        aa, bb = _texture_sample_signature(a, st), _texture_sample_signature(b, tt, order)
        if aa is not None and bb is not None and aa.shape == bb.shape:
            texture_mismatch += int(np.any(aa != bb, axis=1).sum())
            samples_compared += len(aa)
    bounds_error = float(np.max(np.abs(sb - tb)))
    tessellation_equal = bool(sa and ta and not missing_source and not extra_target and bounds_error <= tolerance and not normals_changed)
    source_area, target_area = _surface_area(source), _surface_area(target)
    area_error = abs(source_area-target_area)
    area_tolerance = tolerance*max(1.0,math.sqrt(source_area),math.sqrt(target_area))
    # An independently decoded area mismatch already disproves surface
    # equivalence. Avoid constructing thousands of line arrangements solely to
    # rediscover that fact, especially for finely stepped approximations.
    detailed_surface_check = bool(tessellation_equal or area_error <= area_tolerance)
    if detailed_surface_check:
        surface = _oriented_surface_comparison(sa, ta, tolerance)
        surface_method = "oriented_planar_boundaries"
        surface_reason = "Bordes orientados, planos y multiplicidad comparados."
    else:
        surface = {"equal":False,"unmatched_boundary_length_model_units":None,
                   "unmatched_boundary_interval_count":None,"oriented_plane_count":None,
                   "invalid_surface_faces":None}
        surface_method = "surface_area_mismatch"
        surface_reason = "Las áreas decodificadas difieren; el análisis detallado de bordes no es necesario para rechazar equivalencia."
    geometry_equal = bool(surface["equal"] and bounds_error <= tolerance)
    if geometry_equal:
        uv_mapping = _uv_mapping_comparison(source,target,st,tt,tolerance)
        uv_mapping["uv_mapping_check_performed"] = True
        if sm or tm:
            uv_mapping["uv_mapping_check_passed"] = False
    else:
        # This proof includes material/map coverage over the whole surface;
        # unequal coverage cannot pass even when retained patches copy texels.
        uv_mapping = {"uv_mapping_check_passed":False,"uv_mapping_check_performed":False,
                      "uv_mapping_method":"not_evaluated_surface_mismatch",
                      "uv_mapping_reason":"La equivalencia de superficie no pasó; no se certifica la asignación completa de material/UV.",
                      "uv_mapping_unmatched_source_faces":None,"uv_mapping_unmatched_target_faces":None,
                      "uv_mapping_texture_tiles_checked":0}
    return {
        **uv_mapping,
        "tolerance_model_units": tolerance,
        "source_face_count": len(sa), "target_face_count": len(ta),
        "matched_faces": len(matched),
        "unmatched_source_faces": missing_source, "unmatched_target_faces": extra_target,
        "source_bounds": sb.tolist(), "target_bounds": tb.tolist(),
        "source_dimensions": (sb[1] - sb[0]).tolist(),
        "target_dimensions": (tb[1] - tb[0]).tolist(),
        "bounds_max_absolute_error": bounds_error,
        "matched_vertices_max_absolute_error": max_vertex_error,
        "matched_normals_max_vector_error": max_normal_error,
        "changed_normals": normals_changed,
        "source_surface_area": source_area,
        "target_surface_area": target_area,
        "surface_area_absolute_error": area_error,
        "surface_area_tolerance": area_tolerance,
        "surface_geometry_equal": geometry_equal,
        "tessellation_equal": tessellation_equal,
        "surface_comparison_method": surface_method,
        "surface_comparison_reason": surface_reason,
        "surface_boundary_check_performed": detailed_surface_check,
        "unmatched_boundary_length_model_units": surface["unmatched_boundary_length_model_units"],
        "unmatched_boundary_interval_count": surface["unmatched_boundary_interval_count"],
        "oriented_plane_count": surface["oriented_plane_count"],
        "invalid_surface_faces": surface["invalid_surface_faces"],
        "texture_samples_compared": samples_compared,
        "texture_samples_different": texture_mismatch,
        "texture_sample_check_passed": bool(samples_compared > 0 and texture_mismatch == 0 and not sm and not tm),
        "missing_textures": {"original": sm, "translated": tm},
        "is_runtime_equivalence_proof": False,
        "scope": "Superficies orientadas comparadas por sus bordes; teselación por separado. La comprobación UV independiente exige mapas afines y copias RGBA completas; muestras y vistas son diagnósticos.",
    }
