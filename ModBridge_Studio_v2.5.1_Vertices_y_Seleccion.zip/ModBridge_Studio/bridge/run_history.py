"""Carry completed, unselected models into a new restart batch."""
import json
import shutil
from pathlib import Path
from .control import checkpoint
from .pack import write_json
from conversion_engine import model_slug


def retain_models(entries, destination, ready=None):
    reports = []
    for mid, directory in entries.items():
        checkpoint()
        source = Path(directory).resolve()
        target = Path(destination).resolve()/'models'/model_slug(mid)
        report = json.loads((source/'report.json').read_text(encoding='utf-8'))
        if report.get('id') != mid or not (source/'ready.json').is_file():
            raise ValueError('Solo se conservan modelos terminados del proyecto actual.')
        def copy_file(a,b):
            checkpoint()
            return shutil.copy2(a,b)
        shutil.copytree(source, target, copy_function=copy_file)
        def relocate(value):
            if isinstance(value, dict):return {k:relocate(v) for k,v in value.items()}
            if isinstance(value, list):return [relocate(v) for v in value]
            if isinstance(value, str):return value.replace(str(source),str(target))
            return value
        for file in target.rglob('*.json'):
            checkpoint()
            # Source assets remain byte-for-byte untouched.
            if 'originals' in file.relative_to(target).parts:continue
            try:value=json.loads(file.read_text(encoding='utf-8'))
            except (ValueError, UnicodeError):continue
            write_json(file,relocate(value))
        report=relocate(report);reports.append(report)
        if ready:ready(json.loads((target/'ready.json').read_text(encoding='utf-8')))
    return reports
