"""Explicit render profiles, deterministic deduplication and streamed ZIP output.

Planning reads only client configuration and server-owned catalogue descriptors.
Execution loads one model at a time; client data never supplies filesystem paths.
All source resources remain read-only. Only a completed temporary ZIP is published.
"""
from __future__ import annotations

import hashlib
import io
import json
import math
import re
import secrets
import unicodedata
import zipfile
from pathlib import Path
from PIL.PngImagePlugin import PngInfo

from . import __version__
from .control import ConversionCancelled, cancellation, checkpoint
from .rendering import combined_bounds
from .render_annotations import count_vertices, annotate_vertex_count, VERTEX_COUNT_METHOD

VIEWS = ('superior', 'inferior', 'izquierda', 'derecha', 'frontal', 'trasera')
MODES = ('wireframe', 'solid', 'texture')
VIEW_NAMES = dict(zip(VIEWS, ('arriba', 'abajo', 'izquierda', 'derecha', 'enfrente', 'atras')))
MODE_NAMES = {'wireframe': 'alambre', 'solid': 'solido', 'texture': 'texturas'}
MAX_PROFILES = 32
MAX_REQUESTED_IMAGES = 100000
ROOT_DIRECTORY = 'RENDERS_EXPORTADOS'
_DEVICE = re.compile(r'^(con|prn|aux|nul|com[0-9]|lpt[0-9])$', re.I)


class ExportDestinationError(ValueError):
    """A caller attempted to write an export into read-only model resources."""


def _check_destination(destination, modeldir):
    root = Path(modeldir).resolve()
    if destination == root or destination.is_relative_to(root):
        raise ExportDestinationError('La exportación debe guardarse fuera de los recursos originales del modelo.')


def _text(value, label, *, default=None, maximum=300):
    if value is None and default is not None:
        value = default
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError(f'{label}: se requiere texto no vacío de hasta {maximum} caracteres.')
    return value.strip()


def _ordered_choices(values, choices, label):
    if not isinstance(values, list) or not values:
        raise ValueError(f'{label}: selecciona al menos una opción.')
    if any(not isinstance(value, str) or value not in choices for value in values):
        raise ValueError(f'{label}: contiene una opción no válida.')
    return list(dict.fromkeys(values))


def _flag(profile, key):
    value = profile.get(key, False)
    if not isinstance(value, bool):
        raise ValueError(f'{key}: debe ser verdadero o falso.')
    return value


def _number(value, label, minimum, maximum, *, integer=False):
    if isinstance(value, bool):
        raise ValueError(f'{label}: valor numérico no válido.')
    try:
        result = float(value)
    except (TypeError, ValueError):
        raise ValueError(f'{label}: valor numérico no válido.') from None
    if (not math.isfinite(result) or not minimum <= result <= maximum
            or (integer and not result.is_integer())):
        raise ValueError(f'{label}: usa un valor {"entero " if integer else ""}entre {minimum} y {maximum}.')
    return int(result) if integer else result


def parameter_combinations(profile):
    """Three-combination mode overrides the two manual switches, never adds baseline."""
    if profile['three_combinations']:
        return [(True, False), (False, True), (True, True)]
    return [(profile['xray'], profile['normals'])]


def _slug(value, maximum):
    normalized = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('ascii')
    result = re.sub(r'[^a-z0-9]+', '_', normalized.lower()).strip('_')[:maximum].rstrip('_')
    result = result or 'sin_nombre'
    if _DEVICE.fullmatch(result):
        result = 'modelo_' + result
    return result[:maximum]


class _Names:
    """Case-insensitive uniqueness even if two names or short hashes collide."""
    def __init__(self):
        self.assigned = {}
        self.used = set()

    def get(self, identity, label, prefix, maximum):
        if identity in self.assigned:
            return self.assigned[identity]
        digest = hashlib.sha256(identity.encode('utf-8')).hexdigest()[:8]
        base = prefix + _slug(label, maximum) + '_' + digest
        result = base
        suffix = 2
        while result.casefold() in self.used:
            result = base + '_' + str(suffix)
            suffix += 1
        self.used.add(result.casefold())
        self.assigned[identity] = result
        return result


def plan_render_export(config, available_models):
    """Return JSON-safe plan and exact counts without opening any model files.

    ``available_models`` is a trusted mapping of catalogue ID to descriptor. A
    descriptor can contain ``name``, ``master`` and a server-resolved ``modeldir``.
    The last field is deliberately omitted from the returned plan.
    """
    if not isinstance(config, dict) or not isinstance(available_models, dict):
        raise ValueError('La configuración o el catálogo de renders no es válido.')
    mesh_mode = config.get('mesh_mode', 'surface')
    if mesh_mode not in ('surface', 'exact'):
        raise ValueError('Modo de malla inválido: usar surface o exact.')
    definitions = config.get('profiles')
    selections = config.get('models')
    if not isinstance(definitions, list) or not 1 <= len(definitions) <= MAX_PROFILES:
        raise ValueError(f'Define entre 1 y {MAX_PROFILES} perfiles de renderizado.')
    if not isinstance(selections, list) or not selections:
        raise ValueError('Selecciona al menos un modelo para generar renders.')
    raw_profiles = {}
    for profile in definitions:
        if not isinstance(profile, dict):
            raise ValueError('Cada perfil debe contener una configuración válida.')
        pid = _text(profile.get('id'), 'Identificador del perfil', maximum=80)
        if pid in raw_profiles:
            raise ValueError('Hay identificadores de perfil duplicados.')
        raw_profiles[pid] = profile
    models = []
    used_ids = set()
    for selection in selections:
        if not isinstance(selection, dict):
            raise ValueError('Cada modelo seleccionado debe incluir su identificador y perfiles.')
        mid = _text(selection.get('id'), 'Identificador del modelo', maximum=1024)
        if mid not in available_models:
            raise ValueError('La selección contiene un modelo inexistente: ' + mid)
        if mid in used_ids:
            raise ValueError('Un modelo no puede aparecer dos veces en la selección: ' + mid)
        descriptor = available_models[mid]
        if not isinstance(descriptor, dict):
            raise ValueError('El catálogo contiene un descriptor de modelo no válido.')
        profile_ids = _ordered_choices(selection.get('profile_ids'), raw_profiles, 'Perfiles del modelo ' + mid)
        used_ids.add(mid)
        name = _text(descriptor.get('name'), 'Nombre del modelo', default=mid.rsplit('/', 1)[-1], maximum=1024)
        master = _text(selection.get('master', descriptor.get('master')), 'Maestra', default='Maestra', maximum=300)
        models.append({'id': mid, 'name': name, 'master': master, 'profile_ids': profile_ids})
    used_profiles = list(dict.fromkeys(pid for model in models for pid in model['profile_ids']))
    profiles = {}
    for pid in used_profiles:
        raw = raw_profiles[pid]
        profile = {
            'id': pid, 'name': _text(raw.get('name'), 'Nombre del perfil', default=pid, maximum=120),
            'views': _ordered_choices(raw.get('views'), VIEWS, 'Perspectivas del perfil ' + pid),
            'modes': _ordered_choices(raw.get('modes'), MODES, 'Visualización del perfil ' + pid),
            'xray': _flag(raw, 'xray'), 'normals': _flag(raw, 'normals'),
            'three_combinations': _flag(raw, 'three_combinations'),
            'size': _number(raw.get('size', 192), 'Resolución', 64, 512, integer=True),
            'opacity': _number(raw.get('opacity', .35), 'Opacidad de Rayos X', .05, .95),
            'representation': raw.get('representation', 'translated'),
        }
        if profile['representation'] not in ('original', 'translated', 'comparison'):
            raise ValueError('Representación inválida: usar original, translated o comparison.')
        profiles[pid] = profile
    master_names = _Names()
    model_names = {}
    profile_names = {}
    jobs, duplicates, assignments, comparison_pairs = [], [], [], []
    keys = {}
    all_views, all_modes, all_combinations = set(), set(), set()
    requested = 0
    for model in models:
        master_dir = master_names.get(model['master'], model['master'], 'MAESTRA_', 14)
        names = model_names.setdefault(master_dir, _Names())
        model_dir = names.get(model['id'], model['name'], 'MODELO_', 22)
        model['directory'] = '/'.join((ROOT_DIRECTORY, master_dir, model_dir))
        names = profile_names.setdefault(model['id'], _Names())
        for pid in model['profile_ids']:
            profile = profiles[pid]
            profile_dir = names.get(pid, profile['name'], 'PERFIL_', 12)
            assignment = {'model_id': model['id'], 'profile_id': pid, 'image_count': 0,
                          'duplicate_count': 0, 'requested_image_count': 0}
            assignments.append(assignment)
            flags = parameter_combinations(profile)
            all_views.update(profile['views']); all_modes.update(profile['modes']); all_combinations.update(flags)
            for view in profile['views']:
                for mode in profile['modes']:
                    for xray, normals in flags:
                        comparing = profile['representation'] == 'comparison'
                        representations = ('original', 'translated') if comparing else (profile['representation'],)
                        pair = {'model_id': model['id'], 'profile_id': pid, 'view': view, 'mode': mode,
                                'xray': xray, 'normals': normals, 'opacity': profile['opacity'],
                                'size': profile['size']} if comparing else None
                        for representation in representations:
                            requested += 1
                            if requested > MAX_REQUESTED_IMAGES:
                                raise ValueError(f'La selección supera {MAX_REQUESTED_IMAGES:,} combinaciones; divide la exportación en varios lotes.')
                            assignment['requested_image_count'] += 1
                            effective_opacity = profile['opacity'] if xray else None
                            key = (model['id'], representation, profile['size'], view,
                                   mode, xray, normals, effective_opacity)
                            if key in keys:
                                assignment['duplicate_count'] += 1
                                duplicates.append({'model_id': model['id'], 'profile_id': pid,
                                                   'view': view, 'mode': mode, 'xray': xray, 'normals': normals,
                                                   'representation': representation,
                                                   'same_as': keys[key]['path'], 'owner_profile_id': keys[key]['profile_id']})
                            else:
                                filename = '_'.join((_slug(model['name'], 22), VIEW_NAMES[view], MODE_NAMES[mode],
                                                     'rayosx' if xray else 'sin_rayosx',
                                                     'normales' if normals else 'sin_normales'))
                                if comparing:
                                    filename += '_java' if representation == 'original' else '_bedrock'
                                path = '/'.join((model['directory'], profile_dir, filename + '.png'))
                                job = {'model_id': model['id'], 'profile_id': pid, 'path': path,
                                       'view': view, 'mode': mode, 'xray': xray, 'normals': normals,
                                       'opacity': profile['opacity'], 'size': profile['size'],
                                       'representation': representation}
                                jobs.append(job); keys[key] = job; assignment['image_count'] += 1
                            if pair is not None:
                                side = 'java' if representation == 'original' else 'bedrock'
                                pair[side + '_path'] = keys[key]['path']
                                pair[side + '_owner_profile_id'] = keys[key]['profile_id']
                        if pair is not None:
                            comparison_pairs.append(pair)
    paths = [job['path'].casefold() for job in jobs]
    if len(paths) != len(set(paths)):
        raise ValueError('Se detectó una colisión de nombres en las imágenes; renombra los perfiles.')
    summary = {'model_count': len(models), 'profile_count': len(profiles),
               'view_count': len(all_views), 'mode_count': len(all_modes),
               'combination_count': len(all_combinations), 'image_count': len(jobs),
               'duplicate_count': len(duplicates), 'requested_image_count': requested,
               'comparison_pair_count': len(comparison_pairs), 'assignments': assignments}
    return {'models': models, 'profiles': list(profiles.values()), 'jobs': jobs, 'mesh_mode': mesh_mode,
            'duplicates': duplicates, 'comparison_pairs': comparison_pairs,
            'summary': summary, 'total_images': len(jobs)}


def _safe_texture(modeldir, value):
    if isinstance(value, dict):
        value = value.get('path') or value.get('file')
    if not isinstance(value, str) or not value:
        return None
    root = Path(modeldir).resolve()
    value = value.replace('\\', '/')
    candidates = [root / value]
    marker = '/models/' + root.name + '/'
    if marker in value:
        candidates.append(root / value.rsplit(marker, 1)[1])
    if '/originals/' in value:
        candidates.append(root / 'originals' / value.rsplit('/originals/', 1)[1])
    if Path(value).name in ('atlas.png', 'source_mesh_atlas.png'):
        candidates.append(root / Path(value).name)
    for candidate in candidates:
        try:
            path = candidate.resolve()
            if path.is_relative_to(root) and path.suffix.lower() == '.png' and path.is_file():
                return str(path)
        except (OSError, RuntimeError, ValueError):
            continue
    return None


def load_render_ir(modeldir, representation):
    """Load full geometry and remap only texture paths contained in this model."""
    if representation not in ('original', 'translated'):
        raise ValueError('Representación de render no válida.')
    root = Path(modeldir).resolve()
    path = (root / ('ir_original.json' if representation == 'original' else 'ir_bedrock.json')).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        raise ValueError('No hay geometría disponible para la representación ' + representation + '.')
    with path.open(encoding='utf-8') as stream:
        ir = json.load(stream)
    if not isinstance(ir, dict) or not isinstance(ir.get('faces'), list) or not ir['faces']:
        raise ValueError('El modelo no contiene superficies para la representación ' + representation + '.')
    if not isinstance(ir.get('textures', {}), dict):
        raise ValueError('El mapa de texturas del modelo no es válido.')
    ir['textures'] = {key: _safe_texture(root, value) for key, value in ir.get('textures', {}).items()}
    # Validates coordinate finiteness before it can affect a common camera.
    combined_bounds(ir)
    return ir


def _record_model_metadata(model, descriptor, modeldir):
    # Labels identify what the real IR represents; a diagnostic mesh must never
    # be mistaken for a working Bedrock conversion just because its PNG exists.
    report = {}
    path = (modeldir / 'report.json').resolve()
    if path.is_relative_to(modeldir) and path.is_file():
        try:
            with path.open(encoding='utf-8') as source:
                value = json.load(source)
            if isinstance(value, dict):
                report = value
        except (OSError, ValueError, TypeError):
            pass
    for key in ('target_kind', 'status'):
        value = descriptor.get(key) or report.get(key)
        if isinstance(value, str) and value:
            model[key] = value
    if isinstance(report.get('conversion_engine'), dict):
        model['conversion_engine'] = report['conversion_engine']
    if 'target_kind' in model:
        model['translated_diagnostic_only'] = model['target_kind'] == 'experimental_poly_mesh'


def export_renders(config, available_models, destination, progress=None, cancel=None, prepare_model=None):
    """Render selected profiles into an atomic ZIP, retaining per-image failures.

    ``prepare_model(id, descriptor)`` may prepare an unconverted model in a
    caller-owned workspace and return its trusted descriptor with ``modeldir``.
    No geometry is generated by this module and no client path is accepted.
    ``failed`` counts images; ``errors`` contains grouped model/profile failures.
    """
    from .render_modes import ProfileRenderer
    plan = plan_render_export(config, available_models)
    destination = Path(destination).resolve()
    for model in plan['models']:
        modeldir = available_models[model['id']].get('modeldir')
        if modeldir:
            _check_destination(destination, modeldir)
    destination.mkdir(parents=True, exist_ok=True)
    archive = destination / 'renders.zip'
    temporary = destination / ('renders_' + secrets.token_hex(8) + '.tmp.zip')
    profiles = {p['id']: p for p in plan['profiles']}
    grouped = {model['id']: [] for model in plan['models']}
    for job in plan['jobs']:
        grouped[job['model_id']].append(job)
    generated = failed = processed = 0
    errors, images = [], []

    def emit(model=None, profile_id=None, message='Generando renders'):
        if progress:
            progress({'state': 'running', 'progress': processed, 'total': plan['total_images'],
                      'current': model['id'] if model else '', 'current_model': model['name'] if model else '',
                      'current_profile': profiles[profile_id]['name'] if profile_id else '',
                      'model_id': model['id'] if model else '', 'profile_id': profile_id or '',
                      'generated': generated, 'failed': failed, 'message': message})

    def error_message(error, root=None):
        message = str(error)
        if root:
            message = message.replace(str(root), '<carpeta_modelo>')
        return type(error).__name__ + ': ' + message

    try:
        with cancellation(cancel):
            checkpoint()
            emit(message='Preparando la exportación de renders')
            with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
                for model in plan['models']:
                    checkpoint()
                    model_jobs = grouped[model['id']]
                    descriptor = dict(available_models[model['id']])
                    root = None
                    emit(model, message='Preparando modelo para renderizar')
                    try:
                        if prepare_model:
                            prepared = prepare_model(model['id'], descriptor)
                            if prepared is not None:
                                if not isinstance(prepared, dict):
                                    raise ValueError('La preparación del modelo devolvió un descriptor no válido.')
                                descriptor = prepared
                        checkpoint()
                        if not descriptor.get('modeldir'):
                            raise ValueError('El modelo aún no tiene geometría preparada para renderizar.')
                        root = Path(descriptor['modeldir']).resolve()
                        _check_destination(destination, root)
                        _record_model_metadata(model, descriptor, root)
                        irs, load_errors = {}, {}
                        for representation in ('original', 'translated'):
                            try:
                                irs[representation] = load_render_ir(root, representation)
                            except (OSError, ValueError, TypeError) as error:
                                load_errors[representation] = error_message(error, root)
                        if not irs:
                            raise ValueError('Ninguna representación contiene geometría válida.')
                        bounds = combined_bounds(*irs.values())
                        # Both representations share this exact camera extent;
                        # independent auto-fit could otherwise hide scale errors.
                        model['render_bounds'] = bounds
                        model['vertex_counts'] = {representation: count_vertices(ir) for representation, ir in irs.items()}
                        renderers = {}
                        renderer_errors = dict(load_errors)
                        needed = set(job['representation'] for job in model_jobs)
                        for representation in needed:
                            if representation in irs:
                                try:
                                    renderers[representation] = ProfileRenderer(irs[representation], bounds=bounds)
                                except (OSError, ValueError, TypeError) as error:
                                    renderer_errors[representation] = error_message(error, root)
                    except (ConversionCancelled, ExportDestinationError):
                        raise
                    except Exception as error:
                        count = len(model_jobs)
                        failed += count; processed += count
                        errors.append({'model_id': model['id'], 'profile_id': None, 'affected_images': count,
                                       'error': error_message(error, root)})
                        emit(model, message='No se pudo preparar este modelo; se continúa con los demás')
                        continue
                    for job in model_jobs:
                        checkpoint()
                        emit(model, job['profile_id'])
                        image = None
                        try:
                            representation = job['representation']
                            if representation not in renderers:
                                raise ValueError(str(renderer_errors.get(representation, 'Representación no disponible.')))
                            image = renderers[representation].render(job['view'], size=job['size'], mode=job['mode'],
                                                                   xray=job['xray'], normals=job['normals'], opacity=job['opacity'])
                            vertex_count = model['vertex_counts'][representation]
                            annotation = annotate_vertex_count(image, vertex_count)
                            png_info = PngInfo()
                            png_info.add_text('VertexCount', str(vertex_count))
                            png_info.add_text('VertexCountMethod', VERTEX_COUNT_METHOD)
                            png_info.add_text('Representation', representation)
                            buffer = io.BytesIO()
                            image.save(buffer, format='PNG', pnginfo=png_info)
                            payload = buffer.getvalue()
                            if image.size != (job['size'], job['size']):
                                raise ValueError('El motor devolvió una resolución diferente de la solicitada.')
                        except ConversionCancelled:
                            raise
                        except Exception as error:
                            failed += 1
                            errors.append({'model_id': model['id'], 'profile_id': job['profile_id'],
                                           'path': job['path'], 'affected_images': 1,
                                           'representation': job['representation'],
                                           'error': error_message(error, root)})
                        else:
                            # ZIP I/O failures are fatal: do not advertise a damaged archive.
                            output.writestr(job['path'], payload)
                            generated += 1
                            images.append({**job, 'sha256': hashlib.sha256(payload).hexdigest(),
                                           'vertex_count': vertex_count, 'vertex_annotation': annotation,
                                           'diagnostic_only': job['representation'] == 'translated' and
                                                              model.get('translated_diagnostic_only', False)})
                        finally:
                            close = getattr(image, 'close', None)
                            if close:
                                close()
                        processed += 1
                        emit(model, job['profile_id'])
                    # Drop full model geometry, prepared triangles and textures before the next model.
                    del irs, renderers, renderer_errors, load_errors, bounds
                checkpoint()
                image_paths = {image['path'] for image in images}
                models_by_id = {model['id']: model for model in plan['models']}
                comparison_pairs = []
                for pair in plan['comparison_pairs']:
                    java_available = pair['java_path'] in image_paths
                    bedrock_available = pair['bedrock_path'] in image_paths
                    comparison_pairs.append({**pair, 'java_available': java_available,
                                             'bedrock_available': bedrock_available,
                                             'status': 'complete' if java_available and bedrock_available else
                                                       'partial' if java_available or bedrock_available else 'failed',
                                             'bedrock_diagnostic_only': models_by_id[pair['model_id']].get(
                                                 'translated_diagnostic_only', False)})
                summary = {**plan['summary'], 'generated': generated, 'failed': failed,
                           'duplicates_skipped': len(plan['duplicates']), 'cancelled': False,
                           'all_failed': generated == 0, 'has_errors': bool(errors),
                           'comparison_complete_pairs': sum(pair['status'] == 'complete' for pair in comparison_pairs),
                           'comparison_partial_pairs': sum(pair['status'] == 'partial' for pair in comparison_pairs),
                           'comparison_failed_pairs': sum(pair['status'] == 'failed' for pair in comparison_pairs)}
                manifest = {'format_version': 1, 'application_version': __version__, 'mesh_mode': plan['mesh_mode'],
                            'summary': summary, 'models': plan['models'], 'profiles': plan['profiles'],
                            'images': images, 'duplicates': plan['duplicates'], 'errors': errors,
                            'comparison_pairs': comparison_pairs,
                            'vertex_count_method': VERTEX_COUNT_METHOD,
                            'deduplication': 'First selected profile owns identical render settings; duplicates reference its path.',
                            'image_scope': 'Full model IR; orthographic renders, not UI screenshots or in-game captures.'}
                output.writestr(ROOT_DIRECTORY + '/manifiesto.json', json.dumps(manifest, ensure_ascii=False, indent=2, allow_nan=False))
            checkpoint()
            with zipfile.ZipFile(temporary) as check:
                bad = check.testzip()
                if bad:
                    raise ValueError('La comprobación CRC del ZIP falló: ' + bad)
            checkpoint()
            temporary.replace(archive)
            return {'archive': str(archive), 'summary': summary, 'generated': generated,
                    'failed': failed, 'errors': errors, 'duplicates_skipped': len(plan['duplicates']),
                    'total_images': plan['total_images']}
    finally:
        temporary.unlink(missing_ok=True)
