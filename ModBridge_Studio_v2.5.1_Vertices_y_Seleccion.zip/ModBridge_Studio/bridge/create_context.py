"""Source-backed hints for legacy Create resources with unresolved context.

No texture or geometry substitution occurs here. Registry evidence is extracted
from the supplied JAR's class-file constant pool without executing Java code.
"""
from __future__ import annotations
import hashlib
import struct
from .resources import asset_path

_LEGACY_OVERLAYS={
    'create:block/track/assembly_overlay':'create:block/track_overlay/assembling',
    'create:block/track/station_overlay':'create:block/track_overlay/station',
    'create:block/track/station_overlay_ascending':'create:block/track_overlay/station',
    'create:block/track/station_overlay_diagonal':'create:block/track_overlay/station',
}
_REGISTRY='com/simibubi/create/AllPartialModels.class'
_MISSING='create:block/track'


def class_utf8_constants(data):
    """Read bounded JVM constant-pool UTF-8 entries (no bytecode execution)."""
    if len(data)<10 or data[:4]!=b'\xca\xfe\xba\xbe':raise ValueError('Invalid class-file header')
    count=struct.unpack_from('>H',data,8)[0];offset=10;index=1;values=[]
    while index<count:
        if offset>=len(data):raise ValueError('Truncated class-file pool')
        tag=data[offset];offset+=1
        if tag==1:
            if offset+2>len(data):raise ValueError('Truncated UTF length')
            size=struct.unpack_from('>H',data,offset)[0];offset+=2
            if offset+size>len(data):raise ValueError('Truncated UTF constant')
            values.append(data[offset:offset+size].decode('utf-8','replace'));offset+=size
        elif tag in (3,4,9,10,11,12,17,18):offset+=4
        elif tag in (5,6):offset+=8;index+=1
        elif tag in (7,8,16,19,20):offset+=2
        elif tag==15:offset+=3
        else:raise ValueError('Unknown constant-pool tag '+str(tag))
        if offset>len(data):raise ValueError('Truncated class-file entry')
        index+=1
    return values


def create_model_context(pack, model_id):
    """Return audited related resources for four legacy overlays, or None.

    The result is a diagnostic, not authorization to replace a source texture.
    It never marks a resource converted or excludes it from pending coverage.
    """
    related=_LEGACY_OVERLAYS.get(model_id)
    if related is None or pack.exists(asset_path(_MISSING,'textures','.png')):return None
    path=asset_path(model_id)
    if not pack.exists(path):return None
    raw=pack.read_json(path)
    if not isinstance(raw,dict) or _MISSING not in raw.get('textures',{}).values():return None
    if not pack.exists(_REGISTRY):return None
    registry=pack.read_bytes(_REGISTRY)
    try:constants=set(class_utf8_constants(registry))
    except ValueError:return None
    literal=related.split(':block/',1)[1]
    related_path=asset_path(related)
    if literal not in constants or not pack.exists(related_path):return None
    replacement=pack.read_json(related_path)
    if not isinstance(replacement,dict):return None
    declared={k:v for k,v in replacement.get('textures',{}).items() if isinstance(v,str) and not v.startswith('#')}
    resources=[]
    for identifier in sorted(set(declared.values())):
        tex_path=asset_path(identifier,'textures','.png')
        resources.append({'id':identifier,'path':tex_path,'available':pack.exists(tex_path)})
    return {
        'kind':'legacy_atlas_unresolved','conversion_success':False,
        'coverage_eligible':True,'equivalent_replacement':False,
        'missing_texture':_MISSING,
        'source_resource':{'path':path,'sha256':hashlib.sha256(pack.read_bytes(path)).hexdigest()},
        'registry_evidence':{'path':_REGISTRY,'sha256':hashlib.sha256(registry).hexdigest(),
            'related_model_path_constant':literal,
            'scope':'Literal de ruta presente en el registro AllPartialModels del JAR; no es prueba de equivalencia entre modelos.'},
        'related_models':[{'id':related,'path':related_path,
            'sha256':hashlib.sha256(pack.read_bytes(related_path)).hexdigest(),
            'declared_textures':declared,'texture_resources':resources,
            'source_element_count':len(raw.get('elements',[])),
            'related_element_count':len(replacement.get('elements',[]))}],
        'reason':'El JSON legado usa create:block/track, ausente en el JAR. El registro de parciales contiene otro modelo de overlay con texturas existentes y geometría distinta. Se enlaza para revisión; no se sustituye automáticamente ni se afirma equivalencia 1:1.'
    }
