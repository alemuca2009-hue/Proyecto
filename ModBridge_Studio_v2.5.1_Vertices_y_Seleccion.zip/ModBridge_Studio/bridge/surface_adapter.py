"""Compatibility import; edit conversion_engine/surface_adapter.py instead."""
import sys
from conversion_engine import surface_adapter as _implementation
sys.modules[__name__] = _implementation
