"""Compatibility import; edit conversion_engine/vanilla.py instead."""
import sys
from conversion_engine import vanilla as _implementation
sys.modules[__name__] = _implementation
