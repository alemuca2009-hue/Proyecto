"""Bounded browser geometry. Export and fidelity checks always use the full mesh."""
import math
from pathlib import Path
from .pipeline import read_json
from .pack import write_json

MAX_PREVIEW_FACES=12000
PREVIEW_VERSION=4


def texture_path(modeldir, value):
    """Resolve only PNGs inside this model, including relocated Windows runs."""
    if not isinstance(value, str) or not value:
        return None
    root=Path(modeldir).resolve()
    value=value.replace('\\', '/')
    candidates=[root/value]
    # IR files from older releases used absolute paths. Keep the suffix after
    # this model's own directory, never resolve an arbitrary external file.
    marker='/models/'+root.name+'/'
    if marker in value:
        candidates.append(root/value.rsplit(marker, 1)[1])
    for candidate in candidates:
        path=candidate.resolve()
        if path.is_relative_to(root) and path.suffix.lower()=='.png' and path.is_file():
            return path
    return None


def read_preview(modeldir):
    data=read_json(Path(modeldir)/'preview.json', {})
    return data if data.get('preview_version')==PREVIEW_VERSION else build_preview(modeldir)

def build_preview(modeldir):
    modeldir=Path(modeldir)
    result={'preview_version':PREVIEW_VERSION}; low=[math.inf]*3; high=[-math.inf]*3
    for name,filename in [('original_ir','ir_original.json'),('bedrock_ir','ir_bedrock.json')]:
        ir=read_json(modeldir/filename,{});faces=ir.get('faces',[]);count=len(faces)
        step=max(1,math.ceil(count/MAX_PREVIEW_FACES))
        sampled=[]
        for i,face in enumerate(faces):
            vertices=face.get('vertices',[])
            if len(vertices)<3 or any(len(v)!=3 or any(not isinstance(x,(float,int)) or not math.isfinite(x) for x in v) for v in vertices):
                continue
            for vertex in vertices:
                for axis,value in enumerate(vertex[:3]):
                    low[axis]=min(low[axis],value);high[axis]=max(high[axis],value)
            if i%step==0:
                preview_face={'vertices':vertices,'texture':face.get('texture')}
                if isinstance(face.get('wire_edges'),list):
                    preview_face['wire_edges']=face['wire_edges']
                uv=face.get('uv',[])
                if len(uv)==len(vertices) and all(len(p)==2 and all(isinstance(x,(float,int)) and math.isfinite(x) for x in p) for p in uv):
                    preview_face['uv']=uv
                sampled.append(preview_face)
        textures={}
        for key in {f.get('texture') for f in sampled}:
            path=texture_path(modeldir,ir.get('textures',{}).get(key))
            if path is not None:
                textures[key]=path.relative_to(modeldir.resolve()).as_posix()
        result[name]={'faces':sampled,'textures':textures,'face_count':count,'preview_simplified':step>1,'preview_face_limit':MAX_PREVIEW_FACES}
    if not all(math.isfinite(v) for v in low+high):low,high=[-8,0,-8],[8,16,8]
    result['preview_bounds']={'min':low,'max':high,'center':[(a+b)/2 for a,b in zip(low,high)],'span':max(1,math.dist(low,high))}
    write_json(modeldir/'preview.json',result)
    return result
