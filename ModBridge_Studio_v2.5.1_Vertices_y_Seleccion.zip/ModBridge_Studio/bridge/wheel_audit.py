"""Read explicit Bedrock references; never infer identity from similar names."""
import itertools
import numpy as np
from .geometry import _rotate
from .model_profile import size_profile


def geometry_bounds(geo):
    bones={b['name']:b for b in geo.get('bones',[])}
    points=[]
    def bone_transform(vertices,name,chain=()):
        if name in chain: raise ValueError('Ciclo de huesos en referencia')
        b=bones[name];p=b.get('pivot',[0,0,0]);r=b.get('rotation',[0,0,0])
        vertices=_rotate(vertices,[-p[0],p[1],p[2]],[-r[0],-r[1],r[2]])
        parent=b.get('parent')
        return bone_transform(vertices,parent,chain+(name,)) if parent in bones else vertices
    for b in bones.values():
        for c in b.get('cubes',[]):
            origin=np.asarray(c['origin'],dtype=float);size=np.asarray(c['size'],dtype=float)
            inflate=c.get('inflate',b.get('inflate',0))
            vertices=np.asarray(list(itertools.product(*zip(origin-inflate,origin+size+inflate))))*[-1,1,1]
            p=c.get('pivot',[0,0,0]);r=c.get('rotation',[0,0,0])
            vertices=_rotate(vertices,[-p[0],p[1],p[2]],[-r[0],-r[1],r[2]])
            points.extend(bone_transform(vertices,b['name']).tolist())
    if not points:return None
    points=np.asarray(points)
    return [points.min(axis=0).tolist(),points.max(axis=0).tolist()]


def audit_water_wheels(documents, paths):
    clients={};blocks={};geometries={};controllers={}
    for path,obj in documents.items():
        for key,index in [('minecraft:client_entity',clients),('minecraft:block',blocks)]:
            item=obj.get(key,{})
            identifier=item.get('description',{}).get('identifier')
            if identifier:index[identifier]=(path,item)
        for geo in obj.get('minecraft:geometry',[]) if isinstance(obj.get('minecraft:geometry',[]),list) else []:
            identifier=geo.get('description',{}).get('identifier')
            if identifier:geometries[identifier]=(path,geo)
        controllers.update({k:(path,v) for k,v in obj.get('render_controllers',{}).items()})
    wheels=[]
    for block_id in ('create:water_wheel','create:large_water_wheel'):
        entity_id=block_id+'_entity'
        if block_id not in blocks or entity_id not in clients:continue
        bp,block=blocks[block_id];cp,client=clients[entity_id]
        desc=client['description'];gc=block.get('components',{}).get('minecraft:geometry',{})
        block_gid=gc if isinstance(gc,str) else gc.get('identifier')
        roles={'block':block_gid,'entity':desc.get('geometry',{}).get('default')}
        item_geo=block.get('components',{}).get('minecraft:item_visual',{}).get('geometry',{})
        roles['item']=item_geo if isinstance(item_geo,str) else item_geo.get('identifier')
        measured={}
        for role,gid in roles.items():
            if gid in geometries:
                path,geo=geometries[gid]
                measured[role]={'path':path,'identifier':gid,'profile':size_profile(geometry_bounds(geo)),
                    'cubes':sum(len(b.get('cubes',[])) for b in geo.get('bones',[])),
                    'visible_bounds':{k:v for k,v in geo['description'].items() if k.startswith('visible_bounds')}}
        rc_ids=[x for x in desc.get('render_controllers',[]) if isinstance(x,str)]
        rc=next((controllers[i] for i in rc_ids if i in controllers),None)
        order=rc[1].get('arrays',{}).get('textures',{}).get('Array.wood',[]) if rc else []
        variants=[]
        for index,name in enumerate(order):
            key=name.split('.')[-1];tex=desc.get('textures',{}).get(key,'')
            root=cp.split('/entity/',1)[0]
            variants.append({'index':index,'wood':key,'texture':tex,'exists':root+'/'+tex+'.png' in paths})
        wheels.append({'block_id':block_id,'entity_id':entity_id,'block_file':bp,'client_file':cp,
            'geometries':measured,'render_controller':{'id':rc_ids,'path':rc[0] if rc else None},
            'wood_variants':variants,'unique_variant_textures':len(set(v['texture'] for v in variants)),
            'block_materials':block.get('components',{}).get('minecraft:material_instances',{}),
            'geometry_role':'entity','equivalent_to_java':False})
    return {'wheels':wheels,'scope':'geometry_reference_only',
            'runtime_tested':False,'note':'Enlaces JSON explícitos del addon. Medidas en pose base, con rotaciones estáticas; no son límites de colisión ni prueba de equivalencia Java.'}
