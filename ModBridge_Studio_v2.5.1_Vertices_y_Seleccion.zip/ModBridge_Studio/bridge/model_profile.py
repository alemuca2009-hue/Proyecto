"""Compatibility import; edit conversion_engine/model_profile.py instead."""
import sys
from conversion_engine import model_profile as _implementation
sys.modules[__name__] = _implementation
