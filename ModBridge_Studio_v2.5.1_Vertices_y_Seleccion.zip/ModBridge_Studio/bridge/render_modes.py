"""Configurable PNG rendering from full model IR, without browser screenshots.

Filled surfaces reuse the existing bounded, nearest-RGBA orthographic renderer.
Wire lines use real polygon edges and the same camera/depth prepass. Normals
follow the inspector convention (blue front / red back); X-ray blends actual
surface layers and reveals hidden edges. Nothing writes to the source IR.
"""
from __future__ import annotations

import math
import numpy as np
from PIL import Image

from .control import checkpoint
from .rendering import (VIEWS, combined_bounds, _load_textures, _triangulate,
                        _translucent_flags, render_view)

MODES = ('wireframe', 'solid', 'texture')
FRONT_COLOR = (41, 102, 255)
BACK_COLOR = (255, 51, 61)
EDGE_COLOR = (176, 214, 143)
SOLID_COLOR = np.array([.69, .74, .70])
LIGHT = np.array([-.35, .8, -.48])


def _color_texture(rgb, alpha=255):
    return np.asarray([[list(rgb) + [alpha]]], dtype=np.uint8)


def _normal(vertices, triangles):
    # Winding, not user-supplied shading normals, determines front/back.
    for indices in triangles:
        a, b, c = vertices[list(indices)]
        normal = np.cross(b-a, c-a)
        length = float(np.linalg.norm(normal))
        if length > 1e-12:
            return normal / length
    return np.zeros(3)


class ProfileRenderer:
    """One-model renderer; caches textures and at most one depth image.

    Instantiate once per model/representation when exporting many profiles.
    Discard it before loading the next model to keep memory bounded.
    """
    def __init__(self, ir, bounds=None):
        if not isinstance(ir, dict) or not isinstance(ir.get('faces'), list) or not ir['faces']:
            raise ValueError('El modelo no contiene geometría para generar renders.')
        self.ir = ir
        self.bounds = np.asarray(bounds if bounds is not None else combined_bounds(ir), dtype=float)
        if (self.bounds.shape != (2, 3) or not np.isfinite(self.bounds).all()
                or np.any(self.bounds[1] < self.bounds[0])):
            raise ValueError('Límites de cámara inválidos.')
        self.center = self.bounds.mean(axis=0)
        self.extent = max(float(np.max(self.bounds[1]-self.bounds[0])), 1e-9)
        self.faces = []
        self.textures = None
        self._depth_key = None
        self._depth = None
        self._white = _color_texture((255, 255, 255))
        for face in ir['faces']:
            checkpoint()
            vertices = np.asarray(face.get('vertices', []), dtype=float)
            if (vertices.ndim != 2 or vertices.shape[1:] != (3,) or len(vertices) < 3
                    or not np.isfinite(vertices).all()):
                raise ValueError('La geometría contiene vértices inválidos.')
            triangles = _triangulate(vertices)
            normal = _normal(vertices, triangles)
            if not triangles or np.linalg.norm(normal) < .5:
                continue  # Zero-area faces do not contain any drawable surface.
            uv = np.asarray(face.get('uv', []), dtype=float)
            has_uv = uv.shape == (len(vertices), 2) and np.isfinite(uv).all()
            edges = face.get('wire_edges')
            if edges is None:
                edges = [[a, b] for a, b in zip(vertices, np.roll(vertices, -1, axis=0))]
            edge_array = np.asarray(edges, dtype=float)
            if not len(edge_array):
                edge_array = np.empty((0, 2, 3), dtype=float)
            if edge_array.shape != (len(edge_array), 2, 3) or not np.isfinite(edge_array).all():
                raise ValueError('El contorno de alambre contiene aristas inválidas.')
            self.faces.append({'vertices': vertices, 'uv': uv if has_uv else np.zeros((len(vertices), 2)),
                               'has_uv': has_uv, 'triangles': triangles, 'normal': normal,
                               'texture': str(face.get('texture', '')), 'edges': edge_array})
        if not self.faces:
            raise ValueError('El modelo no contiene superficies de área positiva.')
        self._opaque_prepared = [(f['vertices'], f['uv'], self._white, f['triangles']) for f in self.faces]

    def _load(self):
        if self.textures is None:
            textures, missing = _load_textures(self.ir)
            if missing:
                raise ValueError('No se puede generar Texturas: faltan texturas: ' + ', '.join(sorted(missing)))
            if any(not f['has_uv'] for f in self.faces):
                raise ValueError('No se puede generar Texturas: una superficie carece de UV válidas.')
            self.textures = textures
        return self.textures

    def _prepared(self, view, mode, xray, normals, opacity):
        textures = self._load() if mode == 'texture' and not normals else {}
        derived = {}
        color_cache = {}
        prepared = []
        for face in self.faces:
            checkpoint()
            if normals:
                front = float(face['normal'] @ np.asarray(VIEWS[view][2])) >= 0
                rgb = FRONT_COLOR if front else BACK_COLOR
                alpha = int(round(opacity*255)) if xray else 255
                key = (*rgb, alpha)
                if key not in color_cache:
                    color_cache[key] = _color_texture(rgb, alpha)
                texture = color_cache[key]
            elif mode == 'solid':
                shade = .58 + .42*abs(float(face['normal'] @ LIGHT))
                rgb = tuple(np.clip(np.rint(SOLID_COLOR*shade*255), 0, 255).astype(int))
                alpha = int(round(opacity*255)) if xray else 255
                key = (*rgb, alpha)
                if key not in color_cache:
                    color_cache[key] = _color_texture(rgb, alpha)
                texture = color_cache[key]
            else:
                key = face['texture']
                texture = textures[key]
                if xray:
                    if key not in derived:
                        copy = texture.copy()
                        copy[:, :, 3] = np.rint(copy[:, :, 3].astype(float)*opacity).astype(np.uint8)
                        derived[key] = copy
                    texture = derived[key]
            prepared.append((face['vertices'], face['uv'], texture, face['triangles']))
        unique = {id(p[2]):p[2] for p in prepared}
        return prepared, unique, _translucent_flags(unique)

    def _depth_for(self, view, size):
        key = (view, size)
        if self._depth_key != key:
            depth = np.full((size, size), -np.inf)
            render_view(self.ir, view, size, self.bounds, _textures={'white':self._white},
                        _prepared=self._opaque_prepared, _alpha_flags={id(self._white):False},
                        _depth_output=depth)
            self._depth_key, self._depth = key, depth
        return self._depth

    def _edges(self, image, view, size, xray, normals, opacity):
        output = np.asarray(image).copy()
        depth = self._depth_for(view, size)
        basis = np.asarray(VIEWS[view], dtype=float)
        scale = size*.84/self.extent
        # Blue/outward edges are painted last on shared boundaries, like WebGL.
        ordered = sorted(self.faces, key=lambda f:float(f['normal'] @ basis[2]))
        for hidden in ((True, False) if xray else (False,)):
            # One depth image per line pass, not one image per polygon.
            line_depth = np.full((size, size), -np.inf)
            for face in ordered:
                checkpoint()
                normal = face['normal'] @ basis.T
                rgb = (FRONT_COLOR if normal[2] >= 0 else BACK_COLOR) if normals else EDGE_COLOR
                alpha = opacity if hidden else 1.
                for edge in face['edges']:
                    projected = (edge-self.center) @ basis.T
                    projected[:, 0] = size/2 + projected[:, 0]*scale
                    projected[:, 1] = size/2 - projected[:, 1]*scale
                    delta = projected[1]-projected[0]
                    # Clip in screen space before allocating samples; a custom
                    # framing cannot request millions of offscreen edge samples.
                    low, high = 0., 1.
                    for axis in (0, 1):
                        if abs(delta[axis]) < 1e-15:
                            if not -1 <= projected[0,axis] <= size:
                                low, high = 1., 0.
                                break
                        else:
                            values = sorted(((-1-projected[0,axis])/delta[axis],
                                             (size-projected[0,axis])/delta[axis]))
                            low, high = max(low,values[0]), min(high,values[1])
                    if low > high:
                        continue
                    length = max(abs(delta[0]), abs(delta[1]))*(high-low)
                    t = np.linspace(low, high, max(2, int(math.ceil(length*2))+1))
                    points = projected[0] + t[:,None]*delta
                    xy = np.floor(points[:,:2]).astype(np.int64)
                    inside = (xy[:,0]>=0)&(xy[:,0]<size)&(xy[:,1]>=0)&(xy[:,1]<size)
                    xy, points = xy[inside], points[inside]
                    if not len(xy):
                        continue
                    # Collapse line coverage samples to one fragment per pixel.
                    _, first = np.unique(xy[:,1]*size+xy[:,0], return_index=True)
                    xy, points = xy[first], points[first]
                    x, y = xy[:,0], xy[:,1]
                    z = points[:,2].copy()
                    if abs(normal[2]) > 1e-9:
                        z += (-normal[0]/normal[2]/scale)*(x+.5-points[:,0])
                        z += (normal[1]/normal[2]/scale)*(y+.5-points[:,1])
                    bias = max(1e-9, self.extent*1e-8)
                    occluded = z < depth[y,x]-bias
                    wanted = occluded if hidden else ~occluded
                    wanted &= z >= line_depth[y,x]-bias
                    if not wanted.any():
                        continue
                    x,y,z = x[wanted],y[wanted],z[wanted]
                    old = output[y,x].astype(float)/255
                    oa = old[:,3]
                    a = alpha + oa*(1-alpha)
                    premult = np.asarray(rgb)/255*alpha + old[:,:3]*oa[:,None]*(1-alpha)
                    colors = np.column_stack((premult/np.maximum(a[:,None],1e-12), a))
                    output[y,x] = np.rint(np.clip(colors,0,1)*255).astype(np.uint8)
                    line_depth[y,x] = z
        return Image.fromarray(output, 'RGBA')

    def render(self, view, size=192, mode='texture', xray=False, normals=False, opacity=.35):
        if view not in VIEWS:
            raise ValueError('Perspectiva desconocida: '+str(view))
        if mode not in MODES:
            raise ValueError('Modo de visualización desconocido: '+str(mode))
        if type(xray) is not bool or type(normals) is not bool:
            raise ValueError('Rayos X y Normales deben ser booleanos.')
        if isinstance(size, bool) or not isinstance(size,(int,np.integer)) or not 32 <= size <= 2048:
            raise ValueError('La resolución debe ser un entero entre 32 y 2048 píxeles.')
        if isinstance(opacity, bool) or not isinstance(opacity,(int,float)) or not math.isfinite(opacity) or not .05 <= opacity <= .95:
            raise ValueError('La opacidad debe estar entre 0,05 y 0,95.')
        checkpoint()
        if mode == 'wireframe':
            image = Image.new('RGBA',(size,size))
        else:
            prepared, textures, alpha = self._prepared(view,mode,xray,normals,opacity)
            image = render_view(self.ir,view,size,self.bounds,_prepared=prepared,_textures=textures,_alpha_flags=alpha)
        if mode == 'wireframe' or xray:
            image = self._edges(image,view,size,xray,normals,opacity)
        return image


def render_profile_view(ir, view, size=192, mode='texture', xray=False,
                        normals=False, opacity=.35, bounds=None):
    """Render a single configured image; use ProfileRenderer for repeated views."""
    return ProfileRenderer(ir,bounds=bounds).render(view,size=size,mode=mode,xray=xray,
                                                 normals=normals,opacity=opacity)
