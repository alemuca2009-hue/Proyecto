"""Compatibility import; edit conversion_engine/control.py instead."""
import sys
from conversion_engine import control as _implementation
sys.modules[__name__] = _implementation
