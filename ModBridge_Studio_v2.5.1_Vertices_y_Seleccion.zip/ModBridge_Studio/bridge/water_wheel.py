"""Compatibility import; edit conversion_engine/water_wheel.py instead."""
import sys
from conversion_engine import water_wheel as _implementation
sys.modules[__name__] = _implementation
