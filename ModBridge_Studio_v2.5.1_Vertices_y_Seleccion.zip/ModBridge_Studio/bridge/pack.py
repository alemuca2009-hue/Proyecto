"""Compatibility import; edit conversion_engine/pack.py instead."""
import sys
from conversion_engine import pack as _implementation
sys.modules[__name__] = _implementation
