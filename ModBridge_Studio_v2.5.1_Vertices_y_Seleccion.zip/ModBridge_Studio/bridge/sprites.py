"""Compatibility import; edit conversion_engine/sprites.py instead."""
import sys
from conversion_engine import sprites as _implementation
sys.modules[__name__] = _implementation
