"""Separate disposable render jobs; conversion results and source assets stay intact."""
from __future__ import annotations

import copy
import os
from pathlib import Path
import secrets
import subprocess
import sys
import threading
import time

from .pack import write_json
from .pipeline import read_json


class RenderJobs:
    def __init__(self, studio, program_root):
        self.studio = studio
        self.program_root = Path(program_root)
        self.worker = None
        self.run = None
        self.result = None
        self.cancelled = False
        self.job = {'state': 'idle', 'progress': 0, 'total': 0,
                    'current_model': '', 'current_profile': '', 'message': 'Configura los renders.'}

    @property
    def active(self):
        return self.worker is not None

    def available_models(self):
        studio = self.studio
        if not studio.project or not studio.java:
            raise ValueError('Primero carga el mod Java y selecciona sus modelos.')
        available = {}
        master = studio.project.get('name') or Path(studio.java).name
        for model in studio.project.get('models', []):
            mid = model['id']
            descriptor = {'id': mid, 'name': mid.rsplit('/', 1)[-1], 'master': master}
            ready = studio.ready.get(mid)
            if ready:
                md = (Path(ready['run']) / 'models' / ready['slug']).resolve()
                if md.is_relative_to(studio.workspace) and (md / 'ir_original.json').is_file():
                    descriptor['modeldir'] = str(md)
            available[mid] = descriptor
        return available

    def plan(self, config):
        from .render_export import plan_render_export
        with self.studio.lock:
            available = self.available_models()
            plan = plan_render_export(config, available)
        # Detailed jobs can be numerous; the browser only needs the reviewed
        # summary, profile definitions and counts, never local filesystem paths.
        return copy.deepcopy(plan['summary'])

    def start(self, config):
        from .render_export import plan_render_export
        studio = self.studio
        with studio.lock:
            if self.active or studio.worker is not None or studio.job.get('state') in {'running', 'stopping'}:
                raise ValueError('Espera a que termine la tarea en curso antes de generar renders.')
            available = self.available_models()
            plan = plan_render_export(config, available)
            # Validation precedes any mutation: an invalid selection must not
            # discard the last completed render ZIP or the conversion results.
            selected = {entry['id'] for entry in config['models']}
            selected_available = {mid: available[mid] for mid in selected}
            run = studio.workspace / 'render_jobs' / ('renders_' + time.strftime('%Y%m%d_%H%M%S') + '_' + secrets.token_hex(4))
            run.mkdir(parents=True)
            trusted_config = {'run': str(run), 'java': studio.java,
                              'dependencies': list(studio.dependencies),
                              'available_models': selected_available, 'selection': copy.deepcopy(config)}
            write_json(run / 'config.json', trusted_config)
            env = os.environ.copy()
            for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
                env[key] = '1'
            with (run / 'worker.log').open('wb') as log:
                process = subprocess.Popen([sys.executable, '-u', str(self.program_root / 'render_worker.py'), str(run / 'config.json')],
                    cwd=str(self.program_root), env=env, stdout=log, stderr=subprocess.STDOUT,
                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            self.run, self.worker, self.result, self.cancelled = run, process, None, False
            total = plan['summary'].get('total_images', plan['summary'].get('image_count', 0))
            self.job = {'state': 'running', 'progress': 0, 'total': total,
                        'current_model': '', 'current_profile': '', 'message': 'Preparando la exportación configurada.'}

        def watch():
            while process.poll() is None:
                with studio.lock:
                    if self.worker is process and not self.cancelled:
                        self._refresh()
                try:
                    process.wait(timeout=.1)
                except subprocess.TimeoutExpired:
                    pass
            with studio.lock:
                if self.worker is not process:
                    return
                if self.cancelled:
                    self.job.update(state='cancelled', message='Generación detenida. Los modelos originales se conservan.')
                    self.result = None
                else:
                    self._refresh()
                    completion = read_json(run / 'completion.json', {})
                    result = completion.get('result') or {}
                    archive = Path(result.get('archive', ''))
                    if completion.get('ok') and archive.is_file() and archive.resolve().is_relative_to(run):
                        self.result = result
                        self.job.update(state='done', message='ZIP de renders listo.' if not result.get('failed') else 'ZIP listo con incidencias; consulta el informe de exportación.')
                    else:
                        self.result = None
                        self.job.update(state='error', message=completion.get('error') or 'No se completó el archivo ZIP. Consulta worker.log.')
                self.worker = None
        threading.Thread(target=watch, daemon=True).start()

    def _refresh(self):
        if self.run:
            data = read_json(self.run / 'progress.json')
            if isinstance(data, dict):
                self.job.update({key: data[key] for key in ('state', 'progress', 'total', 'current_model', 'current_profile', 'message') if key in data})

    def status(self):
        with self.studio.lock:
            result = None
            if self.result:
                result = {key: self.result[key] for key in ('generated', 'failed', 'errors', 'duplicates_skipped', 'total_images', 'summary') if key in self.result}
                result['download_url'] = '/download/renders.zip'
            return {**self.job, 'result': result}

    def download(self):
        with self.studio.lock:
            if self.active or self.job['state'] != 'done' or not self.result:
                raise ValueError('Todavía no hay un ZIP de renders completo para descargar.')
            path = Path(self.result['archive']).resolve()
            if not path.is_relative_to(self.run) or not path.is_file():
                raise ValueError('El ZIP de renders ya no está disponible.')
            return path

    def cancel(self):
        with self.studio.lock:
            process = self.worker
            if process is None:
                return
            self.cancelled = True
            self.result = None
            self.job.update(state='stopping', message='Deteniendo la generación de renders…')
        try:
            process.terminate()
            try:
                process.wait(timeout=.5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=.5)
        except (ProcessLookupError, subprocess.TimeoutExpired):
            pass

    def reset(self):
        """Forget the active project's render link; preserve completed files."""
        if self.active:
            raise ValueError('Espera a que termine la generación de renders.')
        self.result = None
        self.job = {'state': 'idle', 'progress': 0, 'total': 0,
                    'current_model': '', 'current_profile': '', 'message': 'Configura los renders.'}
