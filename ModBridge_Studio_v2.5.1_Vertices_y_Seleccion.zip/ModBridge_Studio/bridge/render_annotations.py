"""Pixel lettering for exported profile PNGs; never changes model geometry."""
import math

from PIL import Image, ImageDraw

from .control import checkpoint

VERTEX_COUNT_METHOD = 'unique_xyz_exact_full_ir'

# Small, bundled 5x7 bitmap alphabet: no system fonts or antialiasing required.
_GLYPHS = {
    'V': ('10001','10001','10001','10001','10001','01010','00100'),
    'E': ('11111','10000','10000','11110','10000','10000','11111'),
    'R': ('11110','10001','10001','11110','10100','10010','10001'),
    'T': ('11111','00100','00100','00100','00100','00100','00100'),
    'I': ('11111','00100','00100','00100','00100','00100','11111'),
    'C': ('01111','10000','10000','10000','10000','10000','01111'),
    'S': ('01111','10000','10000','01110','00001','00001','11110'),
    '0': ('01110','10001','10011','10101','11001','10001','01110'),
    '1': ('00100','01100','00100','00100','00100','00100','01110'),
    '2': ('01110','10001','00001','00010','00100','01000','11111'),
    '3': ('11110','00001','00001','01110','00001','00001','11110'),
    '4': ('00010','00110','01010','10010','11111','00010','00010'),
    '5': ('11111','10000','10000','11110','00001','00001','11110'),
    '6': ('01110','10000','10000','11110','10001','10001','01110'),
    '7': ('11111','00001','00010','00100','01000','01000','01000'),
    '8': ('01110','10001','10001','01110','10001','10001','01110'),
    '9': ('01110','10001','10001','01111','00001','00001','01110'),
    ':': ('00000','00100','00100','00000','00100','00100','00000'),
    ' ': ('00000',)*7,
}


def count_vertices(ir):
    """Count distinct full-IR XYZ positions, without camera culling or rounding.

    Shared face corners count once. Coincident positions count once even when
    UVs, normals or materials differ. Nearby but different points stay distinct.
    """
    positions = set()
    for face in ir['faces']:
        checkpoint()
        for vertex in face.get('vertices', []):
            if len(vertex) != 3 or any(not isinstance(v, (int, float)) or not math.isfinite(v) for v in vertex):
                raise ValueError('No se pueden contar vértices con coordenadas inválidas.')
            positions.add(tuple(vertex))
    return len(positions)


def annotate_vertex_count(image, count):
    """Draw a top-right badge in place, keeping resolution and framing intact."""
    if isinstance(count, bool) or not isinstance(count, int) or count < 0:
        raise ValueError('El conteo de vértices debe ser un entero no negativo.')
    width, height = image.size
    scale = max(1, min(3, min(width, height)//160))
    margin = max(2, min(width, height)//64)
    padding = 2*scale
    text = f'VÉRTICES: {count}'
    text_width = lambda line: (6*len(line)-1)*scale
    lines = [text]
    if text_width(text)+2*padding+2*margin > width:
        lines = ['VÉRTICES', str(count)]
    badge_width = max(map(text_width, lines))+2*padding
    badge_height = (9*len(lines)+2*(len(lines)-1))*scale+2*padding
    if badge_width+2*margin > width or badge_height+2*margin > height:
        raise ValueError('La resolución no permite mostrar el conteo completo.')
    left, top = width-margin-badge_width, margin
    bounds = [left, top, width-margin, top+badge_height]  # Exclusive right/bottom.
    with Image.new('RGBA', image.size) as overlay:
        draw = ImageDraw.Draw(overlay)
        draw.rectangle((left, top, bounds[2]-1, bounds[3]-1), fill=(12, 18, 22, 220))
        for row, line in enumerate(lines):
            for column, char in enumerate(line):
                rows = _GLYPHS['E' if char == 'É' else char]
                rows = (('00010', '00100') if char == 'É' else ('00000', '00000'))+rows
                x0 = left+padding+column*6*scale
                y0 = top+padding+row*11*scale
                for y, bits in enumerate(rows):
                    for x, bit in enumerate(bits):
                        if bit == '1':
                            x1, y1 = x0+x*scale, y0+y*scale
                            draw.rectangle((x1, y1, x1+scale-1, y1+scale-1), fill=(255,255,255,255))
        image.alpha_composite(overlay)
    return {'text': text, 'bounds': bounds, 'style': 'pixel_5x7', 'position': 'top_right'}
