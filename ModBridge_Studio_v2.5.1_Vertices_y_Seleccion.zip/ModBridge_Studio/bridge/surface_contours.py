"""Compatibility import; edit conversion_engine/surface_contours.py instead."""
import sys
from conversion_engine import surface_contours as _implementation
sys.modules[__name__] = _implementation
