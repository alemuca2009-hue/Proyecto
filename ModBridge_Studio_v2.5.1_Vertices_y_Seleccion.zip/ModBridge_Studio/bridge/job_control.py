"""Portable cooperative pause; no OS-specific process suspension."""
import json
import time
from pathlib import Path
from .pack import write_json


def pause_callback(run):
    run = Path(run)
    last_check = 0.0

    def requested():
        try:
            return json.loads((run/'control.json').read_text(encoding='utf-8')).get('paused') is True
        except (OSError, ValueError):
            return False

    def check():
        nonlocal last_check
        now = time.monotonic()
        if now-last_check < .05:
            return
        last_check = now
        if not requested():
            return
        write_json(run/'control_status.json', {'state':'paused'})
        while requested():
            time.sleep(.05)
        write_json(run/'control_status.json', {'state':'running'})
        last_check = time.monotonic()
    return check
