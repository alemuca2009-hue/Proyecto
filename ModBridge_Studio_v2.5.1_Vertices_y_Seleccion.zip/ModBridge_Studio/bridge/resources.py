"""Compatibility import; edit conversion_engine/resources.py instead."""
import sys
from conversion_engine import resources as _implementation
sys.modules[__name__] = _implementation
