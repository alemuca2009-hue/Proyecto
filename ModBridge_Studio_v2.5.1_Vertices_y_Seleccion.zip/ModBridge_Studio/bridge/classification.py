"""Evidence-based distinction between model definitions and renderable instances.

This module does not make an unsuccessful conversion successful. Abstract parent
resources are classified separately only when concrete inheritors provide the
missing geometry or texture bindings. Unknown/unbound resources stay pending.
"""
from __future__ import annotations
from collections import defaultdict
import hashlib
from .resources import asset_path, normalize_id


def _texture_binding(reference, mapping):
    seen=set()
    while isinstance(reference,str) and reference.startswith('#'):
        name=reference[1:]
        if name in seen:return None,'cycle:'+name
        seen.add(name)
        if name not in mapping:return None,name
        reference=mapping[name]
    if not isinstance(reference,str):return None,'invalid'
    try:return normalize_id(reference),None
    except ValueError:return None,'invalid'


def _missing_bindings(model):
    mapping=model.get('textures',{})
    missing=set()
    for element in model.get('elements',[]):
        if not isinstance(element,dict):continue
        for face in element.get('faces',{}).values():
            if isinstance(face,dict):
                _,problem=_texture_binding(face.get('texture'),mapping)
                if problem:missing.add(problem)
    if model.get('_generated'):
        for key,value in mapping.items():
            if key.startswith('layer'):
                _,problem=_texture_binding(value,mapping)
                if problem:missing.add(problem)
    return sorted(missing)


def _contains_surface(model):
    if any(e.get('faces') for e in model.get('elements',[]) if isinstance(e,dict)):
        return True
    if model.get('loader') in {'forge:obj','neoforge:obj'} and model.get('model'):
        return True
    if model.get('loader') in {'forge:composite','neoforge:composite'} and model.get('children'):
        return True
    if model.get('_generated') and model.get('_generated')!='minecraft:builtin/entity':
        return any(k.startswith('layer') for k in model.get('textures',{}))
    return False


def model_catalogue(pack):
    """Cache primary-model parent relationships; additional packs are resolution only."""
    cached=getattr(pack,'_classification_catalogue',None)
    if cached is not None:return cached
    records={};children=defaultdict(set);model_references=defaultdict(set)
    def visit(value,owner):
        if isinstance(value,dict):
            # Override model refs are use-sites, not inheritance.
            if isinstance(value.get('model'),str) and not value['model'].endswith('.obj'):
                try:model_references[normalize_id(value['model'])].add(owner)
                except ValueError:pass
            for k,v in value.items():
                if k!='parent':visit(v,owner)
        elif isinstance(value,list):
            for x in value:visit(x,owner)
    for mid in pack.models():
        try:
            raw=pack.read_json(asset_path(mid))
            if not isinstance(raw,dict):continue
            records[mid]={'parent':raw.get('parent')}
            if raw.get('elements')==[]:records[mid]['elements']=[]
            if isinstance(raw.get('parent'),str):children[normalize_id(raw['parent'])].add(mid)
            visit(raw,mid)
        except (ValueError,OSError,KeyError):continue
    result={'records':records,'children':dict(children),'references':dict(model_references),'resolved':{}}
    pack._classification_catalogue=result
    return result


def _resolved(pack,catalogue,mid):
    cache=catalogue['resolved']
    if mid not in cache:
        from .geometry import resolve_model
        try:cache[mid]=(resolve_model(pack,mid),None)
        except (ValueError,OSError,KeyError,TypeError) as exc:cache[mid]=(None,str(exc))
        if len(cache)>32:cache.pop(next(iter(cache)))
    return cache[mid]


def _parent_chain(pack, model_id):
    """Trace actual resource bytes, including vanilla dependencies, with cycle guard."""
    chain=[];current=model_id
    for _ in range(64):
        if current in chain:break
        chain.append(current)
        path=asset_path(current)
        if not pack.exists(path):break
        try:
            data=pack.read_json(path)
            parent=data.get('parent') if isinstance(data,dict) else None
            if not isinstance(parent,str):break
            current=normalize_id(parent)
        except (ValueError,OSError,TypeError):break
    return chain


def classify_unconverted(pack, model_id, resolved=None, warnings=None):
    """Classify evidence without deleting the failed resource from the inventory.

    `not_renderable_asset` is true only for demonstrated abstract parents or an
    explicitly empty, unreferenced resource. `coverage_eligible` remains true
    for missing dependencies, unknown texture bindings and runtime renderers.
    """
    mid=normalize_id(model_id);cat=model_catalogue(pack)
    try:raw=pack.read_json(asset_path(mid))
    except (ValueError,OSError):raw={}
    direct=sorted(cat['children'].get(mid,()))
    descendants=set();todo=list(direct)
    while todo:
        child=todo.pop()
        if child==mid or child in descendants:continue
        descendants.add(child);todo.extend(cat['children'].get(child,()))
    blockstates=pack.blockstates_for(mid) if hasattr(pack,'blockstates_for') else []
    refs=sorted(cat['references'].get(mid,()))
    errors=[]
    if resolved is None:
        resolved,error=_resolved(pack,cat,mid)
        if error:errors.append(error)
    messages=list(warnings or [])+errors
    model=resolved if isinstance(resolved,dict) else raw
    chain=_parent_chain(pack,mid)
    invisible_parent=None
    air_path=asset_path('minecraft:block/air')
    if 'minecraft:block/air' in chain and pack.exists(air_path):
        air=pack.read_json(air_path)
        if isinstance(air,dict) and not air.get('loader') and not air.get('elements') and not air.get('parent'):
            invisible_parent={'id':'minecraft:block/air','path':air_path,'sha256':hashlib.sha256(pack.read_bytes(air_path)).hexdigest()}
    missing=_missing_bindings(model)
    concrete=[]
    for child in sorted(descendants):
        cm,error=_resolved(pack,cat,child)
        if cm and _contains_surface(cm) and not _missing_bindings(cm):concrete.append(child)
    evidence={'parent':raw.get('parent'),'parent_chain':chain,'invisible_parent':invisible_parent,'direct_children':direct,'descendant_models':sorted(descendants),
        'concrete_descendants':concrete,'blockstate_references':blockstates,'model_references':refs,
        'unresolved_texture_bindings':missing,'has_explicit_empty_elements':raw.get('elements')==[]}
    result={'kind':'unresolved_resource','label':'Recurso pendiente','not_renderable_asset':False,
        'coverage_eligible':True,'conversion_success':False,'evidence':evidence}
    generated=model.get('_generated') or model.get('parent')
    loader=model.get('loader')
    has_surface=_contains_surface(model)
    if any('Falta parent' in str(w) or 'Textura ausente' in str(w) for w in messages):
        result.update(kind='missing_dependency',label='Dependencia ausente',
            reason='Faltan recursos externos necesarios; permanece pendiente de conversión.')
    elif invisible_parent and not has_surface and not loader and not model.get('_generated'):
        result.update(kind='intentionally_empty',label='Modelo original intencionalmente invisible',
            not_renderable_asset=True,coverage_eligible=False,
            reason='La cadena de padres procede del recurso minecraft:block/air vacío comprobado. No existe una superficie original que deba inventarse; se conserva su invisibilidad y sus referencias de uso.')
    elif generated=='minecraft:builtin/entity' or loader not in {None,'neoforge:obj','forge:obj','neoforge:composite','forge:composite'}:
        result.update(kind='runtime_renderer',label='Renderizador personalizado',
            reason='La geometría depende de un renderer o loader no resuelto.')
    elif (missing or not has_surface) and concrete and not blockstates and not refs:
        result.update(kind='abstract_template',label='Plantilla usada por modelos concretos',
            not_renderable_asset=True,coverage_eligible=False,
            reason='Este padre aporta parámetros, texturas o transformaciones a hijos concretos. Sus instancias se convierten con sus propios identificadores; el padre sin enlaces no representa otro objeto terminado.')
    elif not has_surface and (blockstates or refs):
        result.update(kind='runtime_renderer',label='Recurso sin superficie estática, usado en juego',
            reason='El JSON no define superficies pero tiene referencias de uso. Se necesita contexto de estado, fluido o renderizador; no se considera una conversión lograda.')
    elif missing:
        result.update(kind='missing_texture_binding',label='Plantilla sin instancia demostrada',
            reason='Faltan asignaciones de textura y no se ha demostrado una instancia concreta. Se conserva como pendiente; no se inventa su textura.')
    elif raw.get('elements')==[] and not direct and not blockstates and not refs and not loader:
        result.update(kind='empty_resource',label='Recurso explícitamente vacío',
            not_renderable_asset=True,coverage_eligible=False,
            reason='El archivo declara elements vacío y no tiene referencias de uso conocidas. Se conserva vacío, sin fabricar geometría.')
    elif not has_surface:
        result.update(kind='unresolved_resource',label='Descriptor sin geometría resoluble',
            reason='No hay suficiente evidencia para tratar este descriptor como un modelo terminado ni para excluirlo del conteo pendiente.')
    else:
        result.update(reason='Contiene superficies; el fallo debe resolverse por el adaptador o los recursos correspondientes.')
    return result
