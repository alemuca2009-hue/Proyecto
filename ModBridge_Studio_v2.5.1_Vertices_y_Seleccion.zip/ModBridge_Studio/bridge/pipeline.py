from __future__ import annotations
import csv, hashlib, html, json, shutil, time, zipfile, tempfile
from collections import Counter
from pathlib import Path
from PIL import Image, ImageDraw
from .control import cancellation, checkpoint, reporting, ConversionCancelled
from conversion_engine import convert_in_pack, load_settings, model_slug
from .resources import ResourcePack
from .rendering import compare_views, compare_geometry
from .reference import ReferenceAddon
from .pack import write_json
from .editable import export_editable_obj
from .classification import classify_unconverted
from .create_context import create_model_context
from .model_profile import finalize_model_profile
from .resources import asset_path
from . import __version__
from .catalog import compact_report, is_extended3d
from .verification import final_status

VIEWS=('superior','frontal','inferior','trasera','izquierda','derecha')

def read_json(path,default=None):
    try:return json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError,ValueError):return default

def relative_ir(ir, ir_file, export_root, modeldir, slug):
    ir=dict(ir or {}); textures={}
    for key,value in ir.get('textures',{}).items():
        p=Path(value)
        if p.name=='atlas.png': dest=export_root/'modelos_traducidos'/slug/'atlas.png'
        else:
            try: rel=p.relative_to(modeldir/'originals'); dest=export_root/'modelos_originales'/rel
            except ValueError:
                dest=export_root/'intermedio'/slug/'texturas_auxiliares'/p.name
                if p.is_file():dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
        import os
        textures[key]=Path(os.path.relpath(dest,ir_file.parent)).as_posix()
    ir['textures']=textures
    return ir

def diagnostic_views(modeldir,size,message):
    for view in VIEWS:
        directory=modeldir/'vistas'/view;directory.mkdir(parents=True,exist_ok=True)
        for side in ['original','traducido','diferencia']:
            path=directory/(side+'.png')
            if path.exists():continue
            im=Image.new('RGBA',(size,size),(24,31,41,255));d=ImageDraw.Draw(im)
            d.text((8,8),view,fill=(203,215,224))
            label='Sin geometria\ntraducible' if side=='traducido' else 'Sin vista\ndisponible'
            d.multiline_text((8,size//2-20),label,fill=(245,188,108),spacing=5)
            im.save(path)


def export_result(run, reports, inventory, reference=None, planned_total=None, started=None, export_name='exportacion'):
    # Always build from an empty directory. A previous export must not leak
    # old packs/scripts or models outside the current selection into the ZIP.
    run=Path(run)
    if not export_name.startswith('exportacion') or Path(export_name).name!=export_name:
        raise ValueError('Nombre de carpeta de exportación inválido.')
    destination=run/export_name
    if destination.is_symlink():raise ValueError('La salida de exportación no puede ser un enlace.')
    root=Path(tempfile.mkdtemp(prefix='exportacion_tmp_',dir=run))
    try:
        result=_export_model_files(run,root,reports,inventory,reference,planned_total,started)
        if destination.exists():shutil.rmtree(destination)
        root.replace(destination)
        result['export_dir']=str(destination)
        return result
    finally:
        if root.exists():shutil.rmtree(root)


def _export_model_files(run, root, reports, inventory, reference, planned_total, started):
    for d in ['modelos_originales','modelos_traducidos','comparaciones','intermedio','reportes/modelos']:
        (root/d).mkdir(parents=True,exist_ok=True)
    exported=[]
    for report in reports:
        checkpoint()
        report=dict(report)
        report['status']=final_status(report)
        report.pop('bedrock_integration',None)
        slug=report['slug']; modeldir=run/'models'/slug
        if 'model_profile' not in report:
            report['model_profile']=finalize_model_profile(report,read_json(modeldir/'ir_original.json',{}),read_json(modeldir/'ir_bedrock.json',{}),modeldir)
        report['extended3d']=is_extended3d(report)
        td=root/'modelos_traducidos'/slug; td.mkdir(parents=True,exist_ok=True)
        if (modeldir/'originals').exists():shutil.copytree(modeldir/'originals',root/'modelos_originales',dirs_exist_ok=True)
        if (modeldir/'original.json').exists():
            orig=root/'modelos_originales'/'seleccionados'/(slug+'.json');orig.parent.mkdir(exist_ok=True)
            shutil.copy2(modeldir/'original.json',orig)
        for name in ['model.geo.json','atlas.png','atlas_map.json','resolved.json','source_mesh_atlas.png','atlas_original_map.json','surface_report.json']:
            if (modeldir/name).exists():
                output_name='NO_COMPATIBLE_poly_mesh.geo.json' if name=='model.geo.json' and report.get('target_kind')=='experimental_poly_mesh' else name
                shutil.copy2(modeldir/name,td/output_name)
        if report.get('target_kind')=='experimental_poly_mesh':
            ir=read_json(modeldir/'ir_bedrock.json')
            if ir and (modeldir/'atlas.png').exists():export_editable_obj(ir,modeldir/'atlas.png',td)
        if (modeldir/'experimental.poly_mesh.json').exists():
            diagnostic=root/'intermedio'/slug/'NO_COMPATIBLE_poly_mesh.geo.json'
            diagnostic.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(modeldir/'experimental.poly_mesh.json',diagnostic)
        if report.get('target_kind') in ('surface_approximation','surface_reconstructed') and (modeldir/'ir_source_mesh.json').exists():
            editdir=td/'malla_original_editable';editdir.mkdir(exist_ok=True)
            shutil.copy2(modeldir/'source_mesh_atlas.png',editdir/'atlas.png')
            export_editable_obj(read_json(modeldir/'ir_source_mesh.json'),editdir/'atlas.png',editdir)
        # Include preserved OBJ or editable alternatives emitted by converter.
        for file in modeldir.glob('*.obj'):shutil.copy2(file,td/file.name)
        for name in ['ir_original.json','ir_bedrock.json','ir_source_mesh.json']:
            ir=read_json(modeldir/name)
            if ir is not None:
                target=root/'intermedio'/slug/name
                write_json(target,relative_ir(ir,target,root,modeldir,slug))
        if (modeldir/'vistas').exists():
            shutil.copytree(modeldir/'vistas',root/'comparaciones'/slug,dirs_exist_ok=True)
            (root/'comparaciones'/slug/'LEER_ESTADO.txt').write_text(report['id']+'\nEstado: '+report['status']+'\n'+('La imagen traducido.png muestra una malla diagnóstica NO compatible con Bedrock.\n' if report.get('target_kind')=='experimental_poly_mesh' else '')+'\n'.join(map(str,report.get('warnings',[]))),encoding='utf-8')
        r=dict(report)
        r['paths']={'geometry':'modelos_traducidos/'+slug+('/NO_COMPATIBLE_poly_mesh.geo.json' if report.get('target_kind')=='experimental_poly_mesh' else '/model.geo.json'),
            'atlas':'modelos_traducidos/'+slug+'/atlas.png','views':'comparaciones/'+slug,
            'original_ir':'intermedio/'+slug+'/ir_original.json','target_ir':'intermedio/'+slug+'/ir_bedrock.json'}
        for key in ['geometry','atlas','original_ir','target_ir']:
            if not (root/r['paths'][key]).is_file():r['paths'].pop(key,None)
        if report.get('target_kind')=='experimental_poly_mesh':r['paths']['editable_obj']='modelos_traducidos/'+slug+'/alternativa_editable.obj'
        write_json(root/'reportes'/'modelos'/(slug+'.json'),r)
        exported.append(r)
    summary={'version':__version__,'native_geometry_models':sum(r.get('status') in ('verified_static','review') and r.get('target_kind')!='experimental_poly_mesh' for r in exported),'non_renderable_definitions':sum(r.get('status')=='no_renderable' for r in exported),'surface_approximations':sum(r.get('target_kind')=='surface_approximation' for r in exported),'total':len(exported),'planned_total':planned_total or len(exported),'cancelled':planned_total is not None and len(exported)!=planned_total,'elapsed_seconds':round(time.monotonic()-started,2) if started else None,'statuses':dict(Counter(r.get('status','error') for r in exported)),
        'runtime_tested':False,'scope':'Modelos estáticos. No convierte código Java, física, lógica, CTM ni animaciones de renderizadores.',
        'inventory':inventory}
    summary['export_scope']='models_only'
    summary['creates_game_content']=False
    write_json(root/'reportes'/'resumen.json',summary)
    if reference:write_json(root/'reportes'/'referencia_addon.json',reference.to_dict())
    with (root/'reportes'/'resumen.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['modelo','estado','tipo_destino','advertencias','reporte'])
        for r in exported:w.writerow([r['id'],r.get('status'),r.get('target_kind'), ' | '.join(map(str,r.get('warnings',[]))), 'modelos/'+r['slug']+'.json'])
    rows=[]
    for r in exported:
        slug=r['slug'];name=html.escape(r['id']);status=html.escape(r['status'])
        status={'verified_static':'Verificado estático','review':'Requiere revisión','unsupported':'No convertido','no_renderable':'Plantilla sin instancia','error':'Error'}.get(r['status'],status)
        warnings='<br>'.join(html.escape(str(x)) for x in r.get('warnings',[]))
        views=''.join('<section><h3>'+v+'</h3><div class="pair"><figure><img loading="lazy" src="comparaciones/'+slug+'/'+v+'/original.png"><figcaption>Original</figcaption></figure><figure><img loading="lazy" src="comparaciones/'+slug+'/'+v+'/traducido.png"><figcaption>Representación destino · consultar estado</figcaption></figure><figure><img loading="lazy" src="comparaciones/'+slug+'/'+v+'/diferencia.png"><figcaption>Diferencia</figcaption></figure></div></section>' for v in VIEWS)
        rows.append('<details><summary>'+name+' <span>'+status+'</span></summary><p>'+warnings+'</p><a href="reportes/modelos/'+slug+'.json">Reporte matemático y limitaciones</a>'+views+'</details>')
    page='''<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>ModBridge · Comparación</title><style>body{background:#111820;color:#e8eef3;font:15px system-ui;margin:0 auto;padding:40px;max-width:1150px}h1{font-size:36px}p{color:#adbcc8;line-height:1.6}details{background:#1a242f;border:1px solid #344452;margin:12px 0;border-radius:12px;padding:18px}summary{cursor:pointer;font-weight:600}span{color:#bbef88;margin-left:14px}.pair{display:flex;gap:12px;flex-wrap:wrap}figure{margin:0;background:#202c39;padding:10px;border-radius:8px}img{max-width:220px;image-rendering:pixelated}figcaption{text-align:center}a{color:#92deed}h3{text-transform:capitalize}</style><h1>Modelos bajo la lupa</h1><p>Comparación de seis cámaras ortográficas idénticas. La validación estática no es una prueba dentro de Minecraft. Los diagnósticos vacíos no representan una conversión exitosa. Las caras se observan por ambos lados y sin iluminación del juego, con fines de inspección.</p>'''+''.join(rows)+'</html>'
    (root/'ABRIR_COMPARACION.html').write_text(page,encoding='utf-8')
    (root/'LEEME.txt').write_text('ModBridge Studio · Resultado\n\nmodelos_originales: recursos fuente conservados.\nmodelos_traducidos: geometry JSON + atlas PNG por modelo.\ncomparaciones: seis lados, cada uno con original, traducido y diferencia.\nintermedio: superficies, normales, UV y texturas para inspección.\nreportes: estado y limitaciones por modelo; CSV y JSON resumen.\n\nAbrir ABRIR_COMPARACION.html en el navegador. La etiqueta verified_static corresponde a la validación original o al paso automático desde revisión por geometría coincidente y píxeles conservados; los avisos y diferencias visuales se mantienen en el reporte. No certifica funcionamiento en Minecraft. Las texturas faltantes no se inventan: cargar el JAR de cliente vanilla/dependencia correspondiente y repetir.\n',encoding='utf-8')
    archive=run/'resultado.zip'; temporary=run/'resultado.zip.part'
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
        for file in sorted(root.rglob('*')):
            checkpoint()
            if file.is_file():
                with file.open('rb') as src, z.open(file.relative_to(root).as_posix(),'w',force_zip64=True) as dst:
                    while chunk:=src.read(1024*1024):
                        checkpoint();dst.write(chunk)
    checkpoint();temporary.replace(archive)
    return {'summary':summary,'reports':exported,'download_url':'/download/result.zip','archive':str(archive),'export_dir':str(root)}


def run_conversion(java_path, run_dir, models=None, pattern='', dependencies=None, reference_path=None, size=192, progress=None, cancel=None, mesh_mode='surface', make_export=True, on_model=None, retained_reports=None):
    with cancellation(cancel), ResourcePack(java_path,extra_paths=dependencies or []) as pack:
        checkpoint()
        return _run_conversion(pack, run_dir, models, pattern, reference_path, size, progress, mesh_mode, make_export, on_model, retained_reports)

def _run_conversion(pack, run_dir, models, pattern, reference_path, size, progress, mesh_mode, make_export, on_model, retained_reports=None):
    if mesh_mode not in ('surface','exact'):raise ValueError('mesh_mode debe ser surface o exact')
    run=Path(run_dir).resolve()
    retained_reports=list(retained_reports or [])
    retained_ids={r['id'] for r in retained_reports}
    if len(retained_ids)!=len(retained_reports) or retained_ids.intersection(models or []):
        raise ValueError('El reinicio no puede reutilizar los modelos seleccionados.')
    existing={p.name for p in (run/'models').iterdir()} if (run/'models').exists() else set()
    if existing and existing!={model_slug(mid) for mid in retained_ids}:
        raise ValueError('La carpeta de salida ya contiene un lote. Elegir otra carpeta para no mezclar resultados anteriores.')
    (run/'models').mkdir(parents=True,exist_ok=True)
    available=set(pack.models())
    ids=[x for x in (models or sorted(available)) if pattern.lower() in x.lower()]
    if any(x not in available for x in ids):raise ValueError('La selección incluye un modelo inexistente.')
    if not ids:raise ValueError('No hay modelos que coincidan con la selección.')
    if len(ids)>20000:raise ValueError('Máximo 20.000 modelos por lote.')
    size=max(64,min(512,int(size)))
    reference=ReferenceAddon(reference_path) if reference_path else None
    conversion_settings=load_settings()
    reports=list(retained_reports); started=time.monotonic()
    for i,mid in enumerate(ids):
        checkpoint()
        if progress:progress({'state':'running','progress':i,'total':len(ids),'current':mid,'message':'Convirtiendo y comparando las seis vistas'})
        slug=model_slug(mid);md=run/'models'/slug;md.mkdir(parents=True,exist_ok=True)
        try:
            def activity(message):
                if progress:progress({'state':'running','progress':i,'total':len(ids),'current':mid,'message':message+' · '+mid})
            with reporting(activity):
                converted=convert_in_pack(pack,mid,md,mesh_mode=mesh_mode,settings=conversion_settings)
            report,original,target=converted.report,converted.original_ir,converted.target_ir
            checkpoint()
            if progress:progress({'state':'running','progress':i,'total':len(ids),'current':mid,'message':'Comparando seis lados · '+mid})
            checkpoint()
            if original.get('faces'):
                report['metrics']['six_views']=compare_views(original,target,md/'vistas',size=size)
                report['metrics']['geometry_independent']=report['metrics']['six_views']['geometry']
            else:
                diagnostic_views(md,size,'Sin geometría original evaluable')
                report['warnings'].append('No se obtuvo una superficie original evaluable; las imágenes muestran un diagnóstico.')
                if report.get('status')=='verified_static':report['status']='unsupported'
            if not target.get('faces'):
                # Empty target must never look like a successful translation.
                for view in VIEWS:
                    path=md/'vistas'/view/'traducido.png'
                    if path.exists():path.unlink()
                diagnostic_views(md,size,'Sin geometría traducida')
                if report.get('status')=='verified_static':report['status']='unsupported'
            if reference:
                matches=[]
                for path in sorted((md/'originals').rglob('*.png')):
                    found=reference.compare_texture(path.read_bytes())
                    if found:matches.append({'source':path.relative_to(md/'originals').as_posix(),'identical_rgba':found})
                report['reference']={'candidates':reference.candidates(mid),'identical_textures':matches,
                    'note':'Solo candidatos de nombre y coincidencias RGBA; no se fuerza un emparejamiento de geometrías.'}
                if 'water_wheel' in mid:
                    selected_block='create:large_water_wheel' if 'large_water_wheel' in mid else 'create:water_wheel'
                    report['reference']['water_wheel_profile']=[w for w in reference.water_wheels['wheels'] if w['block_id']==selected_block]
            if report.get('status')=='unsupported':
                classification=classify_unconverted(pack,mid,warnings=report.get('warnings'))
                report['classification']=classification
                if classification.get('not_renderable_asset'):
                    report['status']='no_renderable'
                    report['warnings'].append('Definición de plantilla sin instancia autónoma; consultar hijos concretos en classification.evidence. No se cuenta como conversión lograda.')
            context=create_model_context(pack,mid)
            if context:report['source_context']=context
            provenance=pack._virtual_provenance.get(asset_path(mid))
            if provenance and provenance.get('kind')=='explicit_static_assembly':
                report['assembly']=provenance
                report['warnings'].append(provenance['reason'])
            report['runtime_tested']=False
            independent=report['metrics'].get('geometry_independent',{})
            if report.get('status')=='verified_static' and independent.get('surface_geometry_equal') is not True:
                report['status']='review';report['warnings'].append('La comprobación independiente de superficies no pasó.')
            if report.get('status')=='verified_static' and independent.get('uv_mapping_check_passed') is False:
                report['status']='review';report['warnings'].append('La comprobación independiente de UV/material no pasó.')
            # Raster output is diagnostic; the final 2.4.3 rule below can
            # promote review models whose geometry and texture cards pass.
            visual=report['metrics'].get('six_views',{})
            if report.get('status')=='verified_static' and visual.get('all_views_pixel_identical') is not True:
                report['status']='review';report['warnings'].append('Las vistas rasterizadas difieren; consulta la comparación visual.')
        except ConversionCancelled:raise
        except Exception as e:
            report={'id':mid,'slug':slug,'status':'error','warnings':[type(e).__name__+': '+str(e)],'metrics':{},'runtime_tested':False}
            diagnostic_views(md,size,str(e))
        checkpoint()
        report['extended3d']=is_extended3d(report)
        report['status']=final_status(report)
        write_json(md/'report.json',report);reports.append(report)
        ready=compact_report(report)
        write_json(md/'ready.json',ready)
        if on_model:on_model(ready)
        if progress:progress({'state':'running','progress':i+1,'total':len(ids),'current':mid,'message':'Modelo listo para inspeccionar · '+mid})
    checkpoint()
    if not make_export:
        result={'reports':reports,'summary':{'total':len(reports),'planned_total':len(ids),'preview_only':True}}
        write_json(run/'result.json',result)
        return result
    if progress:progress({'state':'running','progress':len(reports),'total':len(ids),'current':'','message':'Organizando modelos, reportes y ZIP'})
    result=export_result(run,reports,pack.inventory(),reference,planned_total=len(ids)+len(retained_reports),started=started)
    result['summary']['elapsed_seconds']=round(time.monotonic()-started,2)
    result['summary']['cancelled']=len(reports)!=len(ids)+len(retained_reports)
    write_json(run/'result.json',result)
    if hasattr(pack,'close'):pack.close()
    return result
