"""Render selected model/profile combinations in an isolated process."""
from __future__ import annotations

import json
from pathlib import Path
import sys
import traceback

from conversion_engine import convert_in_pack, load_settings, engine_metadata
from bridge.pack import write_json
from bridge.pipeline import model_slug, read_json
from bridge.render_export import export_renders
from bridge.resources import ResourcePack
from bridge.verification import final_status


def main(config_path):
    config = json.loads(Path(config_path).read_text(encoding='utf-8'))
    run = Path(config['run'])
    pack = None

    def progress(value):
        write_json(run / 'progress.json', value)

    def prepare_model(mid, descriptor):
        nonlocal pack
        if descriptor.get('modeldir'):
            cached = read_json(Path(descriptor['modeldir'])/'report.json', {})
            if cached.get('conversion_engine', {}).get('signature') == expected_engine['signature']:
                return descriptor
        if pack is None:
            pack = ResourcePack(config['java'], extra_paths=config.get('dependencies', []))
        md = run / 'prepared_models' / model_slug(mid)
        md.mkdir(parents=True, exist_ok=True)
        converted = convert_in_pack(pack, mid, md, mesh_mode=mode, settings=settings)
        report = converted.report
        report['id'] = mid
        report['status'] = final_status(report)
        write_json(md / 'report.json', report)
        return {**descriptor, 'modeldir': str(md), 'target_kind': report.get('target_kind')}

    try:
        settings = load_settings()
        mode = config['selection'].get('mesh_mode', 'surface')
        expected_engine = engine_metadata(settings, mode)
        result = export_renders(config['selection'], config['available_models'], run / 'output',
                                progress=progress, prepare_model=prepare_model)
        write_json(run / 'completion.json', {'ok': True, 'result': result})
        return 0
    except Exception as error:
        traceback.print_exc()
        write_json(run / 'completion.json', {'ok': False, 'error': str(error)})
        return 1
    finally:
        if pack is not None:
            pack.close()


if __name__ == '__main__':
    sys.exit(main(sys.argv[1]))
