'use strict';

// Pure library operations, shared by the browser and dependency-free Node tests.
((root) => {
  const GROUPS = Object.freeze({verified_static: 'verified', review: 'review',
    unsupported: 'failed', error: 'failed', no_renderable: 'template'});
  const collator = new Intl.Collator('es', {sensitivity: 'base'});

  function reportList(value) {
    if (Array.isArray(value)) return value;
    return Object.entries(value || {}).map(([id, report]) => ({id, ...report}));
  }
  function mergeReports(...sources) {
    const merged = new Map();
    for (const source of sources) {
      for (const report of reportList(source)) {
        if (typeof report?.id === 'string') merged.set(report.id, report);
      }
    }
    return [...merged.values()];
  }
  function resultGroup(report) {
    const reconstructed = report?.requires_surface_review === true || report?.target_kind === 'surface_reconstructed'
      || (report?.target_kind === 'surface_approximation' && report?.metrics?.surface?.exact_geometry === true);
    const status = reconstructed ? 'review' : report?.status;
    return Object.hasOwn(GROUPS, status) ? GROUPS[status] : null;
  }
  function matchesAnalysis(report, category, selected) {
    if (!Array.isArray(selected) || !selected.length) return true;
    const tags = report ? report.analysis?.[category] || [] : ['unreviewed'];
    return selected.some((value) => tags.includes(value));
  }
  function hasResults(reports) { return reportList(reports).some((report) => resultGroup(report) !== null); }
  function visibleModels(models, reports, options = {}) {
    const byId = new Map(reportList(reports).map((report) => [report.id, report]));
    const query = (options.query || '').trim().toLowerCase();
    const visible = models.filter((model) => {
      if (!model.id.toLowerCase().includes(query)) return false;
      const report = byId.get(model.id);
      if (options.group && resultGroup(report) !== options.group) return false;
      if (options.extendedOnly && report?.extended3d !== true) return false;
      return matchesAnalysis(report, 'geometry', options.geometryStates)
        && matchesAnalysis(report, 'textures', options.textureStates);
    });
    if (options.sortAZ) {
      visible.sort((a, b) => collator.compare(a.id.split('/').pop(), b.id.split('/').pop())
        || collator.compare(a.id, b.id) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
    }
    return visible;
  }
  function conversionIds(models, reports, options, selected) {
    // Preserve explicit selections, including selected rows hidden by filters.
    const valid = new Set(models.map((model) => model.id));
    const ids = [...selected].filter((id) => valid.has(id));
    return ids.length ? ids : visibleModels(models, reports, options).map((model) => model.id);
  }
  function reportSignature(reports) {
    return JSON.stringify(reportList(reports).map((report) => [report.id, report.status, report.extended3d === true,
      report.requires_surface_review === true, report.analysis?.geometry || [], report.analysis?.textures || []]));
  }
  const api = {matchesAnalysis, resultGroup, hasResults, mergeReports, visibleModels, conversionIds, reportSignature};
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.ModBridgeLibrary = api;
})(typeof globalThis === 'undefined' ? this : globalThis);
