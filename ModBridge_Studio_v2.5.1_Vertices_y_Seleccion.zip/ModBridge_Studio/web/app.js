'use strict';

(() => {
  const $ = (id) => document.getElementById(id);
  const SIDE_NAMES = {frontal: 'Frontal', trasera: 'Trasera', izquierda: 'Izquierda', derecha: 'Derecha', superior: 'Superior', inferior: 'Inferior'};
  const STATUS_NAMES = {verified_static: 'Verificado estático', review: 'Requiere revisión', unsupported: 'No convertido', no_renderable: 'Plantilla', error: 'Error', pending: 'Pendiente'};
  const library = window.ModBridgeLibrary;
  const libraryOptions = {group: '', extendedOnly: false, sortAZ: false, geometryStates: [], textureStates: []};
  const state = {project: null, result: null, ready: [], canExportPartial: false, page: 0, abort: null, job: {}, models: [], selected: new Set(), activeId: null, model: null, filter: '', side: 'frontal', panel: 'views', uploading: false, cancelling: false, modelRequest: 0, connected: true, resultSignature: '', camera: {yaw: -.62, pitch: .34, zoom: 1}};
  let pollBusy = false;
  let renderDialog = null;
  const VIEW_MODES = {wireframe: 'Alambre', solid: 'Sólido', texture: 'Texturas'};
  const viewOptions = {mode: 'texture', xray: false, normals: false, opacity: .35};
  try {
    const saved = JSON.parse(localStorage.getItem('modbridge.viewer') || 'null');
    if (saved && typeof saved === 'object') {
      if (Object.hasOwn(VIEW_MODES, saved.mode)) viewOptions.mode = saved.mode;
      viewOptions.xray = saved.xray === true; viewOptions.normals = saved.normals === true;
      if (Number.isFinite(saved.opacity)) viewOptions.opacity = Math.max(.05, Math.min(.95, Math.round(saved.opacity * 20) / 20));
    } else if (localStorage.getItem('modbridge.showTextures') === 'false') viewOptions.mode = 'solid';
  } catch (_) {}
  const viewers = new Map();


  function node(tag, className, content) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (content !== undefined) element.textContent = content;
    return element;
  }
  function icon(name, className = '') {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    if (className) svg.setAttribute('class', className);
    svg.setAttribute('aria-hidden', 'true');
    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', '#i-' + name);
    svg.append(use);
    return svg;
  }
  function toast(message, error = false) {
    const box = node('div', 'toast' + (error ? ' error' : ''));
    box.append(icon(error ? 'warning' : 'check'), node('span', '', message));
    const close = node('button'); close.setAttribute('aria-label', 'Cerrar aviso'); close.append(icon('close')); close.onclick = () => box.remove(); box.append(close);
    $('toast-stack').append(box);
    setTimeout(() => box.remove(), error ? 14000 : 6500);
  }
  async function request(url, options = {}) {
    const headers = {...(options.headers || {})};
    if ((options.method || 'GET').toUpperCase() !== 'GET') headers['X-Bridge-Token'] = window.bridgeToken || '';
    const response = await fetch(url, {cache: 'no-store', ...options, headers});
    let data;
    try { data = await response.json(); } catch (_) { throw new Error(response.ok ? 'El servidor devolvió una respuesta no válida.' : `No se pudo completar la operación (${response.status}).`); }
    if (!response.ok || data.ok === false) throw new Error(data.error || data.message || `Error ${response.status}`);
    return data;
  }
  function numeric(value) { return typeof value === 'number' && Number.isFinite(value); }
  function pretty(value) {
    if (value === null || value === undefined) return '—';
    if (typeof value === 'boolean') return value ? 'Sí' : 'No';
    if (numeric(value)) return Number.isInteger(value) ? value.toLocaleString('es') : (Math.abs(value) > 0 && Math.abs(value) < .00001 ? value.toExponential(3) : value.toLocaleString('es', {maximumFractionDigits: 6}));
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
  }
  function localURL(path) {
    if (!path || typeof path !== 'string') return null;
    try { const u = new URL(path, location.origin); return u.origin === location.origin && ['http:', 'https:'].includes(u.protocol) ? u.href : null; } catch (_) { return null; }
  }
  function allReports() {
    const reports = state.ready;
    return Array.isArray(reports) ? reports : Object.entries(reports).map(([id, value]) => ({id, ...value}));
  }
  function modelReport(id) { return allReports().find((report) => report.id === id); }
  function currentLibraryOptions() { return {...libraryOptions, query: state.filter}; }
  function resetResultFilters(clearAnalysis = false) {
    libraryOptions.group = ''; libraryOptions.extendedOnly = false;
    if (clearAnalysis) { libraryOptions.geometryStates = []; libraryOptions.textureStates = []; }
  }
  async function loadAnalysisFilters() {
    try {
      const data = await request('/api/analysis-filters');
      const filters = data.filters || data.analysis_filters || data;
      for (const [category, key] of [['geometry', 'geometryStates'], ['textures', 'textureStates']]) {
        const fragment = document.createDocumentFragment();
        for (const option of filters[category] || []) {
          const label = node('label', 'check-label');
          const input = node('input'); input.type = 'checkbox'; input.value = option.id || option.value; input.dataset.analysisCategory = key;
          input.checked = libraryOptions[key].includes(input.value);
          input.addEventListener('change', () => {
            libraryOptions[key] = [...document.querySelectorAll(`input[data-analysis-category="${key}"]:checked`)].map((check) => check.value);
            state.page = 0; renderLibrary();
          });
          label.append(input, node('span', '', option.label)); fragment.append(label);
        }
        $('advanced-' + category).replaceChildren(fragment);
      }
      $('advanced-filter-status').textContent = 'Sin casillas marcadas se muestran todos los estados.';
    } catch (error) { $('advanced-filter-status').textContent = `No se pudieron cargar los filtros: ${error.message}`; }
  }
  function visibleModels() {
    return library.visibleModels(state.models, allReports(), currentLibraryOptions());
  }
  function updateLibraryFilters() {
    const available = library.hasResults(allReports());
    if (!available) resetResultFilters();
    document.querySelectorAll('[data-result-group]').forEach((button) => {
      button.disabled = !available;
      button.setAttribute('aria-pressed', String(button.dataset.resultGroup === libraryOptions.group));
    });
    $('clear-color-filter').disabled = !libraryOptions.group;
    $('extended3d-filter').disabled = !available;
    $('extended3d-filter').checked = libraryOptions.extendedOnly;
    $('sort-models-az').checked = libraryOptions.sortAZ;
    document.querySelectorAll('[data-analysis-category]').forEach((input) => { input.checked = libraryOptions[input.dataset.analysisCategory].includes(input.value); });
    $('clear-advanced-filters').disabled = !libraryOptions.geometryStates.length && !libraryOptions.textureStates.length;
    $('library-filter-help').textContent = available
      ? 'Un color a la vez · combina con búsqueda y tamaño.'
      : 'Convierte un modelo para filtrar por resultado y tamaño.';
  }
  function renderLibrary() {
    updateLibraryFilters();
    const visible = visibleModels();
    const list = $('model-list');
    const scroll = list.scrollTop;
    $('model-count').textContent = pretty(visible.length);
    $('model-count').title = `${pretty(state.models.length)} modelos en la biblioteca`;
    $('library-result-count').textContent = `${pretty(visible.length)} de ${pretty(state.models.length)} modelos`;
    const visibleIds = new Set(visible.map((model) => model.id));
    const hiddenSelected = [...state.selected].filter((id) => !visibleIds.has(id)).length;
    $('selected-count').textContent = `${state.selected.size.toLocaleString('es')} seleccionados${hiddenSelected ? ` · ${hiddenSelected.toLocaleString('es')} ocultos` : ''}`;
    $('select-all').checked = !!visible.length && visible.every((m) => state.selected.has(m.id));
    $('select-all').indeterminate = visible.some((m) => state.selected.has(m.id)) && !$('select-all').checked;
    $('select-all').disabled = !visible.length || isRunning();
    const reports = new Map(allReports().map((r) => [r.id, r]));
    const fragment = document.createDocumentFragment();
    if (!visible.length) {
      const empty = node('div', 'library-empty'); empty.append(icon(state.models.length ? 'search' : 'cube'), node('strong', '', state.models.length ? 'No hay coincidencias' : 'Tu biblioteca comienza aquí'), node('p', '', state.models.length ? 'Ajusta la búsqueda o desactiva los filtros de resultado y tamaño.' : 'Carga un mod Java para explorar sus modelos y elegir qué convertir.')); fragment.append(empty);
    }
    const pages = Math.max(1, Math.ceil(visible.length / 100));
    state.page = Math.min(state.page, pages - 1);
    $('page-info').textContent = `${state.page + 1} / ${pages} · ${visible.length.toLocaleString('es')} modelos`;
    $('page-prev').disabled = state.page === 0; $('page-next').disabled = state.page >= pages - 1;
    for (const model of visible.slice(state.page * 100, (state.page + 1) * 100)) {
      const status = reports.get(model.id)?.status || model.status || 'pending';
      const row = node('div', 'model-row' + (model.id === state.activeId ? ' active' : ''));
      const check = node('input'); check.type = 'checkbox'; check.checked = state.selected.has(model.id); check.dataset.id = model.id; check.setAttribute('aria-label', `Seleccionar ${model.id}`); check.disabled = isRunning();
      const button = node('button', 'model-open'); button.type = 'button'; button.dataset.id = model.id; button.title = model.id; button.setAttribute('aria-pressed', String(model.id === state.activeId));
      const split = model.id.split('/'); const name = split.pop();
      const copy = node('span', 'model-copy'); copy.append(node('span', 'model-name', name), node('span', 'model-path', split.join('/') || model.id.split(':')[0]));
      const dot = node('span', 'model-state ' + status); dot.title = STATUS_NAMES[status] || status;
      button.append(icon('cube', 'model-icon'), copy, dot); row.append(check, button); fragment.append(row);
    }
    list.replaceChildren(fragment); list.scrollTop = scroll;
    updateActions();
  }
  function isRunning() { return state.uploading || state.convertBusy || state.renderBusy || ['running', 'pausing', 'paused', 'stopping'].includes(state.job?.state); }
  function updateActions() {
    const running = isRunning();
    $('convert-button').disabled = running || !state.models.length || (!state.selected.size && !visibleModels().length);
    const count = state.selected.size || visibleModels().length;
    $('convert-button').querySelector('span').textContent = running && state.job.state === 'running' ? 'Convirtiendo…' : count ? `Convertir ${count.toLocaleString('es')} ${count === 1 ? 'modelo' : 'modelos'}` : 'Convertir modelos';
    const paused = ['paused','pausing'].includes(state.job?.state);
    $('pause-button').disabled = !!(state.uploading || state.renderBusy || !['running','pausing','paused'].includes(state.job?.state) || state.pauseBusy);
    $('pause-button').classList.toggle('button-continue', paused);
    $('pause-button').setAttribute('aria-pressed', String(paused));
    $('pause-label').textContent = paused ? 'Continuar' : 'Pausar';
    const selectedCount = state.models.filter(m => state.selected.has(m.id)).length;
    $('convert-selected-button').disabled = !!running || !selectedCount;
    $('convert-selected-button').title = selectedCount ? `Convertir únicamente ${selectedCount} modelos seleccionados` : 'Ocupas seleccionar modelos';
    const restartHint = !selectedCount ? 'Ocupas seleccionar modelos' : running ? 'Detén o termina la tarea antes de reiniciar los modelos seleccionados' : `Volver a procesar ${selectedCount} modelos seleccionados; conservar los demás resultados`;
    $('restart-button').disabled = running || !selectedCount;
    $('restart-control').title = restartHint;
    $('restart-help').textContent = restartHint;
    $('render-size').disabled = running;
    $('mesh-mode').disabled = running;
    $('open-render-dialog').disabled = !state.renderBusy && (state.uploading || ['running', 'pausing', 'paused', 'stopping'].includes(state.job?.state));
    $('cancel-button').hidden = !['running', 'pausing', 'paused', 'stopping'].includes(state.job?.state);
    $('cancel-button').disabled = state.cancelling || state.job.state === 'stopping';
    $('preview-button').disabled = running || !state.activeId;
    $('export-partial').hidden = !state.canExportPartial || (!!state.result?.download_url && !state.resultIsPrevious);
    $('export-partial').disabled = running;
    document.querySelectorAll('.source-card').forEach((card) => { card.disabled = running; });
    const download = localURL(state.result?.download_url || state.job?.result_url);
    const conversionRunning = state.uploading || ['running', 'pausing', 'paused', 'stopping'].includes(state.job?.state);
    $('download-button').classList.toggle('disabled', !download || conversionRunning);
    $('download-button').setAttribute('aria-disabled', String(!download || conversionRunning));
    if (download) $('download-button').href = download; else $('download-button').removeAttribute('href');
    if (download) $('download-button').setAttribute('download', 'ModBridge_resultados.zip');
    $('download-button').title = state.resultIsPrevious ? 'ZIP de la conversión anterior. El reinicio todavía no ha generado un resultado nuevo.' : 'Descargar el resultado disponible';
    $('download-button').querySelector('span').textContent = state.resultIsPrevious ? 'Descargar ZIP anterior' : 'Descargar ZIP';
  }
  function renderProject() {
    const p = state.project;
    if (p) {
      $('java-filename').textContent = p.name || 'Mod Java cargado';
      const inv = p.inventory || {};
      const textures = inv.textures ?? inv.texture_count;
      $('java-detail').textContent = `${state.models.length.toLocaleString('es')} modelos${numeric(textures) ? ` · ${textures.toLocaleString('es')} texturas` : ''}`;
      $('upload-java').classList.add('loaded');
      const ref = p.reference || p.reference_name;
      if (ref) {
        $('reference-filename').textContent = typeof ref === 'string' ? ref : ref.name || 'Referencia cargada';
        $('reference-detail').textContent = 'Port de referencia disponible para el análisis';
        $('upload-reference').classList.add('loaded');
      }
      const dependencies = p.dependencies || p.extra_paths;
      if (Array.isArray(dependencies) && dependencies.length) {
        $('dependency-filename').textContent = `${dependencies.length} ${dependencies.length === 1 ? 'paquete adicional' : 'paquetes adicionales'}`;
        $('dependency-detail').textContent = 'Prioridad sobre vanilla ' + (inv.bundled_vanilla_version || 'incluido');
        $('upload-dependency').classList.add('loaded');
      } else {
        const version = inv.bundled_vanilla_version;
        $('dependency-filename').textContent = version ? `Vanilla ${version} incluido` : 'Añade recursos adicionales';
        $('dependency-detail').textContent = version ? 'Recursos oficiales · se resuelven automáticamente' : 'Cliente Minecraft o recursos .jar/.zip';
        $('upload-dependency').classList.toggle('loaded', !!version);
      }
    }
  }
  function renderJob() {
    const job = state.job || {};
    const running = ['running', 'pausing', 'paused', 'stopping'].includes(job.state);
    $('job-indicator').className = 'job-indicator ' + (job.state || '');
    $('job-title').textContent = state.uploading ? 'Leyendo recursos…' : job.state === 'paused' ? 'Conversión en pausa' : job.state === 'pausing' ? 'Pausando…' : job.state === 'stopping' ? 'Deteniendo…' : job.state === 'cancelled' ? 'Detenido · modelos terminados conservados' : running ? (job.operation === 'preview' ? 'Preparando vista del modelo' : 'Traduciendo y comprobando') : job.state === 'done' ? (job.operation === 'preview' ? 'Vistas del modelo listas' : state.result?.summary?.cancelled ? 'Lote detenido · resultados parciales' : 'Conversión terminada') : job.state === 'error' ? 'La conversión necesita atención' : state.models.length ? 'Proyecto listo para convertir' : 'Listo para comenzar';
    const progress = Number(job.progress || 0), total = Number(job.total || 0);
    $('job-counter').textContent = total ? `${progress.toLocaleString('es')} / ${total.toLocaleString('es')}` : '';
    $('job-message').textContent = state.uploading ? 'El archivo se procesa localmente.' : job.message || job.current || (state.models.length ? 'Selecciona modelos o convierte todos los resultados de la búsqueda.' : 'Carga el original para preparar tu proyecto.');
    $('job-message').title = $('job-message').textContent;
    $('progress-track').hidden = !running && job.state !== 'done';
    $('progress-fill').style.width = (total ? Math.min(100, 100 * progress / total) : 0) + '%';
    updateActions();
  }
  async function poll() {
    if (pollBusy) return;
    pollBusy = true;
    try {
      const data = await request('/api/status?compact=1');
      if (data.project) {
        if (!state.project || data.project.revision !== state.project.revision) data.project = await request('/api/inventory');
        else data.project.models = state.project.models;
      }
      const previousJob = state.job?.state;
      const oldProject = state.project?.name;
      const oldRevision = state.project?.revision;
      const oldModels = state.models.length;
      state.project = data.project || null; state.job = data.job || {}; state.result = data.result || null; state.resultIsPrevious = !!data.result_is_previous; state.ready = library.mergeReports(data.result?.reports, data.ready_models); state.canExportPartial = !!data.can_export_partial;
      const models = state.project?.models || [];
      state.models = models.map((m) => typeof m === 'string' ? {id: m} : m).filter((m) => typeof m.id === 'string');
      const changed = oldRevision !== undefined && oldRevision !== state.project?.revision;
      if (oldProject && (changed || oldProject !== state.project?.name)) {
        resetResultFilters(true); state.page = 0;
        if (oldProject !== state.project?.name) state.selected.clear();
        const validIds = new Set(state.models.map((m) => m.id));
        state.selected = new Set([...state.selected].filter((id) => validIds.has(id)));
        if (!validIds.has(state.activeId)) state.activeId = null;
        state.modelRequest += 1; state.model = null; state.resultSignature = ''; clearInspector();
        if (state.activeId) selectModel(state.activeId, false);
      }
      if (changed || state.models.length !== oldModels || oldProject !== state.project?.name) renderLibrary();
      const signature = `${library.reportSignature(allReports())}:${state.job.state}:${state.result?.download_url || ''}`;
      if (signature !== state.resultSignature) {
        state.resultSignature = signature; renderLibrary();
        if (state.activeId && !state.model && modelReport(state.activeId)) selectModel(state.activeId, false);
        else if (!state.activeId && allReports().length) selectModel(allReports()[0].id);
      }
      renderProject(); renderJob();
      if (['running','pausing','paused','stopping'].includes(previousJob) && state.job.state === 'done') {
        state.cancelling = false;
        toast(state.job.operation === 'preview' ? 'Modelo listo: revisa sus seis lados o gira su geometría.' : 'Exportación terminada. Puedes descargar el ZIP.');
        if (state.activeId) await selectModel(state.activeId, false); else if (allReports().length) await selectModel(allReports()[0].id);
      }
      if (['running','pausing','paused','stopping'].includes(previousJob) && state.job.state === 'cancelled') { state.cancelling = false; toast('Proceso detenido. Las vistas terminadas siguen disponibles.'); }
      if (previousJob === 'running' && state.job.state === 'error') toast(state.job.message || 'La conversión no pudo completarse. Consulta el reporte.', true);
      if (!state.connected) { state.connected = true; toast('Conexión con el programa restablecida.'); }
    } catch (error) {
      if (state.connected) {
        state.connected = false;
        $('job-title').textContent = 'Sin conexión con el programa';
        $('job-message').textContent = 'Mantén abierta la ventana de ModBridge en tu equipo.';
        $('job-indicator').className = 'job-indicator error';
        $('convert-button').disabled = true;
      }
    } finally { pollBusy = false; }
  }
  async function upload(kind, file) {
    if (!file || isRunning()) return;
    const allowed = kind === 'reference' ? /\.(mcaddon|mcpack|zip)$/i : /\.(jar|zip)$/i;
    if (!allowed.test(file.name)) { toast(kind === 'reference' ? 'Selecciona un archivo .mcaddon, .mcpack o .zip.' : 'Selecciona un archivo .jar o .zip.', true); return; }
    state.uploading = true; renderJob();
    try {
      const result = await request(`/api/upload?kind=${encodeURIComponent(kind)}&name=${encodeURIComponent(file.name)}`, {method: 'POST', headers: {'Content-Type': 'application/octet-stream', 'X-Filename': file.name.normalize('NFKD').replace(/[^\x20-\x7E]/g, '_')}, body: file});
      if (kind === 'java') { state.selected.clear(); state.activeId = null; state.model = null; clearInspector(); }
      if (kind === 'reference') { $('reference-filename').textContent = file.name; $('reference-detail').textContent = 'Referencia cargada · información incluida en el proyecto'; $('upload-reference').classList.add('loaded'); }
      if (kind === 'dependency') { $('dependency-filename').textContent = file.name; $('dependency-detail').textContent = 'Recursos adicionales cargados'; $('upload-dependency').classList.add('loaded'); }
      toast(result.message || `${file.name} cargado correctamente.`);
    } catch (error) { toast(error.message, true); }
    finally { state.uploading = false; await poll(); renderJob(); }
  }
  async function convert(selectedOnly = false) {
    if (isRunning() || !state.models.length) return;
    const ids = selectedOnly ? state.models.filter(m => state.selected.has(m.id)).map(m => m.id) : library.conversionIds(state.models, allReports(), currentLibraryOptions(), state.selected);
    if (selectedOnly && !ids.length) { toast('Ocupas seleccionar modelos'); return; }
    if (!ids.length) return;
    state.convertBusy = true; updateActions();
    try {
      const payload = {models: ids, filter: '', render_size: Number($('render-size').value), mesh_mode: $('mesh-mode').value, include_reference: true};
      await request(selectedOnly ? '/api/convert-selected' : '/api/convert', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload)});
      state.model = null; state.ready = []; state.result = null; state.resultIsPrevious = false; state.resultSignature = ''; resetResultFilters(); clearInspector();
      state.job = {state: 'running', total: ids.length, progress: 0, message: 'Preparando la conversión…'};
      renderJob(); renderLibrary(); await poll();
    } catch (error) { toast(error.message, true); }
    finally { state.convertBusy = false; updateActions(); }
  }
  function clearInspector() {
    $('model-namespace').textContent = 'INSPECTOR DE FIDELIDAD';
    $('active-model-title').textContent = 'Un original. Dos representaciones.';
    $('active-model-status').textContent = 'Sin modelo'; $('active-model-status').className = 'status-pill muted';
    $('diagnostic-warning').hidden = true; $('preview-detail').textContent = '';
    $('compare-empty').hidden = false; $('paired-view').hidden = true; $('overlay-view').hidden = true; $('difference-details').hidden = true;
    $('empty-title').textContent = 'La fidelidad se comprueba.';
    $('empty-copy').textContent = 'Selecciona un modelo y pulsa «Ver este modelo». Las seis vistas usan la misma cámara, escala e iluminación.';
    $('metric-geometry').textContent = 'Sin comparar'; $('metric-geometry').className = '';
    $('metric-textures').textContent = 'Sin comparar'; $('metric-textures').className = '';
    $('metric-views').replaceChildren(document.createTextNode('— '), node('small', '', '/ 6'));
    $('source-face-count').textContent = '— caras'; $('target-face-count').textContent = '— caras';
    $('report-content').replaceChildren(reportEmpty('El reporte aparecerá al convertir este modelo.'));
    drawCanvases();
  }
  function reportEmpty(copy) {
    const empty = node('div', 'report-empty'); empty.append(icon('file'), node('h3', '', 'Una conversión que se puede revisar.'), node('p', '', copy)); return empty;
  }
  async function selectModel(id, rerender = true) {
    state.abort?.abort(); state.abort = new AbortController();
    state.activeId = id; state.model = null;
    const thisRequest = ++state.modelRequest;
    clearInspector();
    $('model-namespace').textContent = id.slice(0, id.lastIndexOf('/') + 1) || id.split(':')[0];
    $('active-model-title').textContent = id.split('/').pop();
    $('active-model-title').title = id;
    const report = modelReport(id);
    const status = report?.status || 'pending';
    $('active-model-status').textContent = STATUS_NAMES[status] || status;
    $('active-model-status').className = 'status-pill ' + (status === 'pending' ? 'muted' : status);
    if (rerender) renderLibrary();
    if (!report) {
      $('empty-title').textContent = 'Este modelo está listo para analizarse.';
      $('empty-copy').textContent = isRunning() ? 'Las vistas aparecerán en cuanto termine este modelo. Puedes revisar otros modelos ya listos.' : 'Pulsa «Ver este modelo» para preparar sus seis lados y su geometría sin convertir todo el lote.';
      return;
    }
    $('empty-title').textContent = 'Cargando la comparación…';
    try {
      const data = await request(`/api/model?id=${encodeURIComponent(id)}`, {signal: state.abort.signal});
      if (thisRequest !== state.modelRequest) return;
      state.model = data; state.model.report = data.report || report;
      renderInspector();
      if (state.panel === 'geometry') await loadGeometry();
    } catch (error) {
      if (thisRequest !== state.modelRequest) return;
      state.model = {report}; renderReport(report);
      $('empty-title').textContent = 'No fue posible abrir la vista.';
      $('empty-copy').textContent = error.message;
      toast(error.message, true);
    }
  }
  function renderInspector() {
    const model = state.model;
    if (!model) return;
    const report = model.report || {};
    $('active-model-status').textContent = STATUS_NAMES[report.status] || report.status || 'Pendiente';
    $('active-model-status').className = 'status-pill ' + (report.status || 'muted');
    const experimental = report.target_kind === 'experimental_poly_mesh';
    const approximation = report.target_kind === 'surface_approximation';
    const reconstructed = report.target_kind === 'surface_reconstructed';
    const surface = approximation || reconstructed;
    $('diagnostic-warning').hidden = !experimental && !surface;
    const exactSurface = reconstructed || report.metrics?.surface?.exact_geometry === true;
    $('diagnostic-warning').textContent = experimental ? 'NO compatible con Bedrock: esta representación es una visualización diagnóstica de una malla experimental. Debe adaptarse antes de usarse en el juego.' : surface ? exactSurface
      ? 'SUPERFICIES RECONSTRUIDAS: la planificación conserva los polígonos como rectángulos. Consulta la comprobación independiente de superficie, UV y texturas en el reporte.'
      : 'APROXIMACIÓN: las caras no rectangulares se representan mediante franjas interiores. Consulta la pérdida de área, el error de contorno y la conservación de UV y texturas en el reporte.' : '';
    const targetLabel = experimental ? 'Malla experimental · diagnóstico' : surface ? exactSurface ? 'Superficies · reconstruidas' : 'Superficies · aproximación' : 'Traducido Bedrock';
    $('target-view-label').textContent = targetLabel;
    $('target-canvas-label').textContent = targetLabel;
    renderViews(); renderReport(report); renderMetrics(report);
    $('source-face-count').textContent = model.original_ir ? `${model.original_ir.face_count.toLocaleString('es')} caras` : 'Cargar al abrir 3D';
    $('target-face-count').textContent = model.bedrock_ir ? `${model.bedrock_ir.face_count.toLocaleString('es')} caras` : 'Cargar al abrir 3D';
    drawCanvases();
  }
  function setImage(id, path, alt) {
    const img = $(id); const url = localURL(path);
    img.alt = alt;
    img.onload = () => { img.style.visibility = 'visible'; const failed = img.parentElement.querySelector('.image-failed'); if (failed) failed.hidden = true; };
    img.onerror = () => { img.style.visibility = 'hidden'; const failed = img.parentElement.querySelector('.image-failed'); if (failed) failed.hidden = false; };
    if (url) { img.style.visibility = 'visible'; if (img.src !== url) img.src = url; }
    else { img.removeAttribute('src'); img.style.visibility = 'hidden'; }
  }
  function renderViews() {
    const model = state.model;
    const base = model?.views_base;
    const hasViews = !!base;
    $('compare-empty').hidden = hasViews;
    $('paired-view').hidden = !hasViews || $('overlay-toggle').checked;
    $('overlay-view').hidden = !hasViews || !$('overlay-toggle').checked;
    $('difference-details').hidden = !hasViews;
    if (!hasViews) {
      $('empty-title').textContent = model?.report?.status === 'unsupported' ? 'La conversión requiere revisión.' : 'No hay vistas comparativas disponibles.';
      $('empty-copy').textContent = 'Consulta el reporte para conocer las limitaciones, los recursos faltantes y los archivos originales conservados.';
      return;
    }
    const side = state.side, label = SIDE_NAMES[side];
    const url = (kind) => `${base.replace(/\/$/, '')}/${side}/${kind}.png`;
    setImage('original-view', url('original'), `Vista ${label.toLowerCase()} del modelo Java original`);
    setImage('bedrock-view', url('traducido'), `Vista ${label.toLowerCase()} de la geometría Bedrock traducida`);
    setImage('overlay-source', url('original'), `Original: ${label.toLowerCase()}`);
    setImage('overlay-target', url('traducido'), `Traducido: ${label.toLowerCase()}`);
    setImage('difference-view', url('diferencia'), `Diferencias de la vista ${label.toLowerCase()}`);
  }
  function findValue(object, keys) {
    for (const key of keys) if (object && Object.hasOwn(object, key)) return object[key];
    return undefined;
  }
  function renderMetrics(report) {
    const metrics = report.metrics || {};
    const geom = metrics.geometry_independent || metrics.geometry || metrics;
    const match = findValue(geom, ['surface_geometry_equal', 'equivalent', 'geometry_equal', 'geometry_match', 'geometry_exact', 'same_geometry']);
    const error = findValue(metrics, ['max_vertex_error_pixels']) ?? findValue(geom, ['max_vertex_error', 'max_vertex_error_px', 'max_position_error', 'vertex_max_error', 'vertex_error_max']);
    const geometryText = match === true ? 'Coincidente' : match === false ? 'Diferencias detectadas' : numeric(error) ? `Error: ${pretty(error)} px` : report.status === 'verified_static' ? 'Verificada' : 'Consultar reporte';
    $('metric-geometry').textContent = geometryText;
    $('metric-geometry').className = match === true ? 'good' : match === false ? 'warning' : '';
    const tessellation = geom.tessellation_equal ?? geom.tessellation_geometry_equal;
    $('metric-geometry').title = tessellation === false && match === true
      ? 'Misma superficie comprobada; la división en caras es diferente.'
      : 'Comprobación independiente de la superficie exportada; no certifica su carga en Minecraft.';
    const texture = metrics.textures || metrics;
    const texMatch = findValue(texture, ['rgba_texels_preserved', 'texels_equal', 'textures_equal', 'texture_pixels_equal', 'texture_match', 'pixel_exact', 'texture_exact']);
    const missingTextures = (metrics.six_views?.missing_textures?.original || []).length > 0 || (metrics.six_views?.missing_textures?.translated || []).length > 0;
    const uvMismatch = geom.uv_mapping_check_passed === false;
    const uvProofSkipped = uvMismatch && geom.uv_mapping_check_performed === false;
    $('metric-textures').textContent = missingTextures ? 'Faltan texturas' : uvProofSkipped ? 'UV sin verificar' : uvMismatch ? 'Diferencias UV/material' : texMatch === true ? 'Píxeles conservados' : texMatch === false ? 'Revisar diferencias' : report.status === 'verified_static' ? 'Verificadas' : 'Consultar reporte';
    $('metric-textures').className = missingTextures || uvMismatch ? 'warning' : texMatch === true ? 'good' : texMatch === false ? 'warning' : '';
    const uvMatch = geom.uv_mapping_check_passed ?? metrics.uv_mapping_preserved ?? metrics.surface?.uv_mapping_preserved;
    $('metric-textures').title = uvProofSkipped ? 'La comprobación UV/material no se realizó porque las superficies difieren. No se ha medido una distorsión UV.'
      : uvMatch === true ? 'Asignación UV conservada según el reporte de conversión; los píxeles se evalúan por separado.'
      : uvMatch === false ? 'La asignación UV contiene aproximaciones; consulta el reporte aunque los PNG originales estén conservados.'
      : 'La conservación de píxeles se evalúa por separado de la asignación UV.';
    const visual = metrics.six_views || report.visual || metrics.visual || report.render_metrics || metrics.views;
    let views = 0, identical = 0;
    if (visual) {
      const viewData = visual.views || visual;
      const measurements = Array.isArray(viewData) ? viewData
        : Object.keys(SIDE_NAMES).filter((side) => Object.hasOwn(viewData, side)).map((side) => viewData[side]);
      views = measurements.length;
      identical = measurements.filter((view) => view?.pixel_identical === true).length;
    }
    $('metric-views').replaceChildren(document.createTextNode(`${views} `), node('small', '', '/ 6 comparadas'));
    $('metric-views').title = `${identical} de ${views} vistas con píxeles idénticos${numeric(visual?.size) ? ` a ${visual.size} × ${visual.size} px` : ''}. Comparadas no significa aprobadas.`;
  }
  function tableRow(table, name, value) {
    const row = node('tr'); row.append(node('th', '', name), node('td', '', pretty(value))); table.append(row);
  }
  function section(title, iconName = 'file') {
    const s = node('section', 'report-section'); const h = node('h3'); h.append(icon(iconName), document.createTextNode(title)); s.append(h); return s;
  }
  function renderReport(report) {
    const fragment = document.createDocumentFragment();
    const status = section('Alcance de la validación', 'check');
    const statusText = report.status === 'no_renderable'
      ? 'Plantilla parametrizada: este archivo aporta propiedades a sus modelos hijos. No es un modelo independiente fallido. Sus instancias concretas se procesan por separado y se enumeran en el reporte.'
      : ['surface_approximation', 'surface_reconstructed'].includes(report.target_kind)
      ? report.target_kind === 'surface_reconstructed' || report.metrics?.surface?.exact_geometry === true
        ? 'Reconstrucción en rectángulos de geometría Bedrock. Una división distinta en caras puede conservar la misma superficie. La comprobación independiente, las UV y los píxeles se informan por separado; no se certifica ejecución en el juego.'
        : 'Conversión con rectángulos exactos cuando son representables y franjas interiores para otros polígonos. Las caras aproximadas o pendientes y sus errores se detallan en el reporte. Las UV y los texels se evalúan por separado.'
      : report.target_kind === 'experimental_poly_mesh'
      ? 'NO compatible con Minecraft Bedrock. La malla se conserva para diagnóstico y edición; las vistas de esta representación experimental no demuestran que el juego pueda cargarla.'
      : report.status === 'verified_static'
      ? 'El recurso estático superó las comprobaciones implementadas. Este estado no acredita el comportamiento del mod, sus animaciones, ni su apariencia dentro del motor de Bedrock.'
      : 'Esta conversión contiene aspectos que requieren revisión. El reporte conserva los límites encontrados para que puedan corregirse sin confundir una vista similar con una equivalencia completa.';
    status.append(node('div', 'report-notice' + (report.status === 'verified_static' ? '' : ' warning'), statusText)); fragment.append(status);
    const warnings = report.warnings || report.limitations || [];
    if (warnings.length) {
      const warn = section('Hallazgos y limitaciones', 'warning'); const list = node('ul', 'report-list');
      for (const warning of warnings) list.append(node('li', '', typeof warning === 'string' ? warning : warning.message || pretty(warning)));
      warn.append(list); fragment.append(warn);
    }
    for (const [key, label] of [['preserved', 'Propiedades conservadas'], ['modified', 'Propiedades modificadas']]) {
      if (!report[key]) continue;
      const sec = section(label, key === 'preserved' ? 'check' : 'sliders');
      if (Array.isArray(report[key])) { const ul = node('ul', 'report-list'); report[key].forEach((entry) => ul.append(node('li', '', pretty(entry)))); sec.append(ul); }
      else sec.append(node('p', 'report-notice', pretty(report[key])));
      fragment.append(sec);
    }
    const data = section('Datos del modelo', 'cube'); const table = node('table', 'data-table');
    tableRow(table, 'Identificador', report.id || state.activeId);
    tableRow(table, 'Estado', STATUS_NAMES[report.status] || report.status);
    if (report.target_kind) tableRow(table, 'Destino', report.target_kind);
    if (state.model?.original_ir?.bounds) tableRow(table, 'Límites originales [mín., máx.]', state.model.original_ir.bounds);
    if (state.model?.bedrock_ir?.bounds) tableRow(table, 'Límites traducidos [mín., máx.]', state.model.bedrock_ir.bounds);
    if (state.model?.original_ir?.faces) tableRow(table, 'Caras originales', state.model.original_ir.faces.length);
    if (state.model?.bedrock_ir?.faces) tableRow(table, 'Caras traducidas', state.model.bedrock_ir.faces.length);
    tableRow(table, 'Validación dentro del juego', 'Pendiente: debe comprobarse en Minecraft Bedrock');
    data.append(table); fragment.append(data);
    if (report.classification) {
      const sec = section('Clasificación del recurso', 'file');
      sec.append(node('pre', 'report-json', JSON.stringify(report.classification, null, 2))); fragment.append(sec);
    }
    if (report.source_context) {
      const sec = section('Referencias del recurso original', 'link');
      sec.append(node('p', 'report-notice warning', report.source_context.reason));
      for (const related of report.source_context.related_models || []) {
        const button = node('button', 'button button-quiet', 'Ver modelo relacionado: ' + related.id);
        button.onclick = () => selectModel(related.id);
        sec.append(button);
      }
      fragment.append(sec);
    }
    if (report.model_profile) {
      const info = report.model_profile;
      const sec = section('Geometría, escala y dimensiones', 'cube');
      const t = node('table', 'data-table');
      const uses = {entity_geometry:'Geometría de entidad', block_or_entity_geometry:'Geometría de bloque o entidad', diagnostic_only:'Diagnóstico: consultar avisos'};
      tableRow(t, 'Modelo 3D extendido', report.extended3d === true);
      tableRow(t, 'Uso del archivo geométrico', uses[info.geometry_usage] || info.geometry_usage);
      tableRow(t, 'Tamaño original en bloques', info.source?.dimensions_blocks);
      tableRow(t, 'Envolvente del modelo exportado en bloques', info.target?.dimensions_blocks);
      tableRow(t, 'Dentro del perfil geométrico de bloque', info.target?.block_compatible ? 'Sí' : 'No');
      tableRow(t, 'Escala global', '1.0 · sin reducir');
      sec.append(t);
      for (const note of info.notes || []) sec.append(node('p', 'report-notice', note));
      if (report.assembly) sec.append(node('p', 'report-notice', report.assembly.reason));
      fragment.append(sec);
    }
    const metrics = report.metrics;
    const geometry = metrics?.geometry_independent || metrics?.geometry;
    const surface = metrics?.surface;
    if (geometry || surface) {
      const sec = section('Superficie, caras y textura', 'cube');
      const t = node('table', 'data-table');
      const resultText = (value) => value === true ? 'Sí' : value === false ? 'No' : 'No comprobado';
      tableRow(t, 'Misma superficie geométrica', resultText(geometry?.surface_geometry_equal));
      tableRow(t, 'Misma división en caras', resultText(geometry?.tessellation_equal ?? geometry?.tessellation_geometry_equal));
      if (numeric(geometry?.unmatched_boundary_length_model_units)) tableRow(t, 'Longitud de bordes no coincidentes (unidades de modelo)', geometry.unmatched_boundary_length_model_units);
      const texels = findValue(metrics?.textures || metrics, ['rgba_texels_preserved', 'texels_equal', 'textures_equal', 'texture_pixels_equal', 'texture_match', 'pixel_exact', 'texture_exact']);
      tableRow(t, 'Texels RGBA originales conservados en destino', resultText(texels));
      tableRow(t, 'UV/material coincidentes (comprobación independiente)', geometry?.uv_mapping_check_performed === false ? 'No comprobado: las superficies difieren' : resultText(geometry?.uv_mapping_check_passed));
      tableRow(t, 'UV originales reutilizadas por el conversor', resultText(metrics?.uv_mapping_preserved ?? surface?.uv_mapping_preserved));
      if (surface?.texture_transfer) {
        tableRow(t, 'Rectángulos con UV originales', surface.texture_transfer.direct_uv_rectangles);
        tableRow(t, 'Rectángulos con textura remuestreada', surface.texture_transfer.sampled_rectangles);
      }
      if (surface?.contour_refinement) {
        const contour = surface.contour_refinement;
        if (numeric(contour.exact_polygon_count)) tableRow(t, 'Polígonos exactos', contour.exact_polygon_count);
        if (numeric(contour.approximate_polygon_count)) tableRow(t, 'Polígonos aproximados', contour.approximate_polygon_count);
        if (numeric(contour.pending_polygon_count)) tableRow(t, 'Polígonos pendientes', contour.pending_polygon_count);
        if (numeric(contour.budget_limited_polygon_count)) tableRow(t, 'Polígonos limitados por el presupuesto', contour.budget_limited_polygon_count);
        if (numeric(contour.area_coverage_ratio)) tableRow(t, 'Área conservada (%)', (100 * contour.area_coverage_ratio).toFixed(4));
        if (numeric(contour.omitted_planar_area)) tableRow(t, 'Área omitida (unidades de modelo²)', contour.omitted_planar_area);
        if (numeric(contour.outside_source_area)) tableRow(t, 'Área fuera del contorno original (unidades de modelo²)', contour.outside_source_area);
        if (numeric(contour.max_sampled_boundary_distance_model_units)) tableRow(t, 'Distancia máxima muestreada del borde (64 muestras por arista; unidades de modelo)', contour.max_sampled_boundary_distance_model_units);
        if (numeric(contour.masked_fallback_polygon_count)) tableRow(t, 'Caras con rectángulo envolvente y máscara', contour.masked_fallback_polygon_count);
      }
      sec.append(t);
      sec.append(node('p', 'report-notice', 'La coincidencia de superficie no exige el mismo número de caras. Conservar los PNG fuente no demuestra que las UV o el atlas de destino sean idénticos.'));
      fragment.append(sec);
    }
    if (metrics && Object.keys(metrics).length) {
      const sec = section('Mediciones de la conversión', 'sliders'); const t = node('table', 'data-table');
      for (const [key, value] of Object.entries(metrics)) {
        if (['six_views', 'geometry_independent', 'surface', 'textures', 'source_mesh_diagnostic'].includes(key)) continue;
        // Per-face plans and atlas maps can contain megabytes. Keep the normal
        // inspector bounded; the complete evidence remains in exports and in
        // the JSON panel, which is populated only when explicitly opened.
        const summary = value && typeof value === 'object'
          ? `${Array.isArray(value) ? `${value.length} entradas` : `${Object.keys(value).length} campos`} · consultar reporte JSON`
          : value;
        tableRow(t, key.replace(/_/g, ' '), summary);
      }
      sec.append(t);
      if (metrics.surface || metrics.textures?.transfer) sec.append(node('p', 'report-notice', 'El detalle por cara y el mapa de texturas se conservan en surface_report.json y atlas_map.json del ZIP.'));
      fragment.append(sec);
    }
    if (metrics?.six_views?.views) {
      const sec = section('Comprobación de las seis vistas', 'grid'); const t = node('table', 'data-table');
      const compared = Object.values(metrics.six_views.views);
      const identical = compared.filter((view) => view.pixel_identical === true).length;
      sec.append(node('p', 'report-notice', `${compared.length} vistas comparadas; ${identical} con píxeles idénticos${numeric(metrics.six_views.size) ? ` a ${metrics.six_views.size} × ${metrics.six_views.size} px` : ''}. Este resultado no acredita igualdad a cualquier resolución ni validación en el juego.`));
      for (const [side, measurement] of Object.entries(metrics.six_views.views)) {
        tableRow(t, SIDE_NAMES[side] || side, `${pretty(measurement.mismatch_pixels)} píxeles distintos · error RGBA ${pretty(measurement.rgba_mae)}`);
      }
      sec.append(t); fragment.append(sec);
    }
    if (report.reference) {
      const ref = report.reference;
      const sec = section('Comparación con el port de referencia', 'layers');
      sec.append(node('p', 'report-notice warning', ref.note || 'Las coincidencias de nombre son candidatos para revisión humana y no confirman equivalencia geométrica.'));
      for (const wheel of ref.water_wheel_profile || []) {
        const table = node('table', 'data-table');
        tableRow(table, 'Uso geométrico en la referencia', 'Modelo de entidad: admite la rueda a escala completa');
        tableRow(table, 'Bloque', wheel.block_id);
        tableRow(table, 'Entidad', wheel.entity_id);
        tableRow(table, 'Dimensiones de la entidad (bloques)', wheel.geometries?.entity?.profile?.dimensions_blocks);
        tableRow(table, 'Variantes de madera / texturas distintas', `${wheel.wood_variants.length} / ${wheel.unique_variant_textures}`);
        tableRow(table, 'Geometría fuente de referencia', wheel.geometries?.entity?.path);
        sec.append(table);
      }
      const candidates = ref.candidates || [];
      const textureMatches = ref.identical_textures || [];
      const summary = node('table', 'data-table');
      tableRow(summary, 'Candidatos por nombre', candidates.length);
      tableRow(summary, 'Texturas originales con coincidencia RGBA', textureMatches.length);
      sec.append(summary);
      if (candidates.length) {
        const table = node('table', 'data-table');
        candidates.forEach((candidate) => tableRow(table, candidate.identifier || candidate.path || 'Candidato', `${candidate.path || ''}${numeric(candidate.cubes) ? ` · ${candidate.cubes} cubos` : ''}${numeric(candidate.bones) ? ` · ${candidate.bones} huesos` : ''}`));
        sec.append(table);
      }
      if (textureMatches.length) {
        const details = node('details', 'report-raw');
        details.append(node('summary', '', 'Ver texturas coincidentes'));
        const table = node('table', 'data-table');
        textureMatches.forEach((entry) => tableRow(table, entry.source || 'Textura original', Array.isArray(entry.identical_rgba) ? entry.identical_rgba.map(pretty).join(' · ') : entry.identical_rgba));
        details.append(table); sec.append(details);
      }
      fragment.append(sec);
    }
    if (report.visual || report.render_metrics) {
      const sec = section('Comparación visual', 'grid'); sec.append(node('pre', 'report-json', JSON.stringify(report.visual || report.render_metrics, null, 2))); fragment.append(sec);
    }
    const raw = node('details', 'report-raw');
    raw.append(node('summary', '', 'Abrir reporte JSON completo'));
    let rawLoaded = false;
    raw.addEventListener('toggle', () => {
      if (!raw.open || rawLoaded) return;
      raw.append(node('pre', 'report-json', JSON.stringify(report, null, 2)));
      rawLoaded = true;
    });
    fragment.append(raw);
    $('report-content').replaceChildren(fragment);
  }
  function switchPanel(panel) {
    state.panel = panel;
    document.querySelectorAll('.inspector-tab').forEach((button) => { const active = button.dataset.panel === panel; button.classList.toggle('active', active); button.setAttribute('aria-selected', String(active)); });
    for (const name of ['views', 'geometry', 'report']) $('panel-' + name).hidden = name !== panel;
    if (panel === 'geometry') { loadGeometry(); requestAnimationFrame(drawCanvases); }
  }

  // Load bounded geometry and UVs on demand; the six-view audit stays independent.
  async function loadGeometry() {
    if (!state.model || state.model.original_ir || state.model.geometryLoading) return;
    const current = state.model, id = state.activeId;
    current.geometryLoading = true; current.geometryError = '';
    $('preview-detail').textContent = 'Cargando geometría para inspección…';
    try {
      const data = await request(`/api/model?id=${encodeURIComponent(id)}&geometry=1`, {signal: state.abort?.signal});
      if (state.model !== current) return;
      Object.assign(current, data);
      renderInspector();
    } catch (error) {
      if (state.model === current && error.name !== 'AbortError') {
        current.geometryError = error.message;
        $('preview-detail').textContent = 'No fue posible cargar el visor: ' + error.message + '. Vuelve a abrir la pestaña para reintentar.';
        toast(error.message, true);
      }
    } finally { current.geometryLoading = false; if (state.model === current && !current.geometryError) scheduleDraw(); }
  }
  function sharedBounds() {
    return state.model?.preview_bounds || {center:[0,8,0],span:20,min:[-8,0,-8],max:[8,16,8]};
  }
  let drawPending = false;
  function scheduleDraw() {
    if (drawPending) return;
    drawPending = true; requestAnimationFrame(() => { drawPending = false; drawCanvases(); });
  }
  function previewCompleteness(model) {
    const sampled = [['Original', model?.original_ir], ['Traducido', model?.bedrock_ir]]
      .filter(([, ir]) => ir?.preview_simplified);
    if (!sampled.length) return 'Geometría completa';
    const limits = sampled.map(([label, ir]) => {
      const limit = Number.isInteger(ir.preview_face_limit) && ir.preview_face_limit > 0 ? ir.preview_face_limit : 12000;
      return `${label}: máximo ${limit.toLocaleString('es')} caras`;
    });
    return `Vista aligerada (${limits.join('; ')}). La validación y el ZIP usan la geometría completa.`;
  }
  function drawCanvases() {
    // Release GPU resources immediately when selection/project changes, even
    // when another tab is active. Late image loads cannot paint a previous model.
    if (!state.model) for (const viewer of viewers.values()) viewer.setScene(null);
    if (state.panel !== 'geometry') return;
    const bounds = sharedBounds();
    for (const [id, side] of [['original-canvas', 'original_ir'], ['bedrock-canvas', 'bedrock_ir']]) {
      if (!viewers.has(id)) viewers.set(id, new window.ModBridgeViewer($(id), scheduleDraw));
      const viewer = viewers.get(id);
      viewer.setScene(state.model?.[side] || null);
      viewer.render(state.camera, bounds, viewOptions);
    }
    const statuses = [...viewers.values()].map((viewer) => viewer.status());
    const error = statuses.find((status) => status.error)?.error;
    if (error) { $('preview-detail').textContent = error; return; }
    if (!state.model?.original_ir) {
      if (!state.model?.geometryError) $('preview-detail').textContent = state.model?.geometryLoading ? 'Cargando geometría para inspección…' : 'Selecciona un modelo y pulsa «Ver este modelo» para abrirlo aquí.';
      return;
    }
    let detail = previewCompleteness(state.model);
    const loading = statuses.reduce((n, status) => n + status.loading, 0);
    const failed = statuses.reduce((n, status) => n + status.failed + status.withoutUV, 0);
    detail += ' · ' + VIEW_MODES[viewOptions.mode];
    if (viewOptions.normals) detail += ' · Orientación de caras activada.';
    else if (viewOptions.mode === 'texture') detail += loading ? ' · Cargando texturas…' : failed ? ' · Algunas texturas o UV no están disponibles: esas caras se muestran en gris. Consulta «Seis vistas» y el reporte.' : ' · Texturas visibles.';
    if (viewOptions.xray) detail += ' · Rayos X ' + Math.round(viewOptions.opacity * 100) + '%.';
    $('preview-detail').textContent = detail;
  }
  function bindCanvas(canvas) {
    let drag = null;
    canvas.addEventListener('pointerdown', (event) => { if (event.button !== 0) return; canvas.focus({preventScroll: true}); drag = {x: event.clientX, y: event.clientY}; canvas.setPointerCapture(event.pointerId); });
    canvas.addEventListener('pointermove', (event) => {
      if (!drag) return;
      state.camera.yaw += (event.clientX - drag.x) * .012;
      state.camera.pitch = Math.max(-1.54, Math.min(1.54, state.camera.pitch + (event.clientY - drag.y) * .012));
      drag = {x: event.clientX, y: event.clientY}; scheduleDraw();
    });
    const endDrag = () => { drag = null; }; canvas.addEventListener('pointerup', endDrag); canvas.addEventListener('pointercancel', endDrag); canvas.addEventListener('lostpointercapture', endDrag);
    canvas.addEventListener('wheel', (event) => { event.preventDefault(); state.camera.zoom = Math.max(.25, Math.min(6, state.camera.zoom * Math.exp(-event.deltaY * .001))); scheduleDraw(); }, {passive: false});
    canvas.addEventListener('keydown', (event) => {
      if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', '+', '-', '='].includes(event.key)) return;
      event.preventDefault();
      if (event.key === 'ArrowLeft') state.camera.yaw -= .12;
      if (event.key === 'ArrowRight') state.camera.yaw += .12;
      if (event.key === 'ArrowUp') state.camera.pitch = Math.max(-1.54, state.camera.pitch - .12);
      if (event.key === 'ArrowDown') state.camera.pitch = Math.min(1.54, state.camera.pitch + .12);
      if (event.key === '+' || event.key === '=') state.camera.zoom = Math.min(6, state.camera.zoom * 1.1);
      if (event.key === '-') state.camera.zoom = Math.max(.25, state.camera.zoom / 1.1);
      drawCanvases();
    });
  }

  for (const kind of ['java', 'reference', 'dependency']) {
    const card = $('upload-' + kind), input = $('file-' + kind);
    card.addEventListener('click', () => input.click());
    input.addEventListener('change', () => { if (input.files[0]) upload(kind, input.files[0]); input.value = ''; });
    card.addEventListener('dragover', (event) => { event.preventDefault(); if (!isRunning()) card.classList.add('dragover'); });
    card.addEventListener('dragleave', () => card.classList.remove('dragover'));
    card.addEventListener('drop', (event) => { event.preventDefault(); card.classList.remove('dragover'); if (event.dataTransfer.files[0]) upload(kind, event.dataTransfer.files[0]); });
  }
  window.addEventListener('dragover', (event) => event.preventDefault());
  window.addEventListener('drop', (event) => event.preventDefault());
  $('model-search').addEventListener('input', (event) => { state.filter = event.target.value.trim(); state.page = 0; renderLibrary(); });
  document.querySelectorAll('[data-result-group]').forEach((button) => button.addEventListener('click', () => {
    libraryOptions.group = libraryOptions.group === button.dataset.resultGroup ? '' : button.dataset.resultGroup;
    state.page = 0; renderLibrary();
  }));
  $('clear-color-filter').addEventListener('click', () => { libraryOptions.group = ''; state.page = 0; renderLibrary(); });
  $('extended3d-filter').addEventListener('change', (event) => { libraryOptions.extendedOnly = event.target.checked; state.page = 0; renderLibrary(); });
  $('sort-models-az').addEventListener('change', (event) => { libraryOptions.sortAZ = event.target.checked; state.page = 0; renderLibrary(); });
  $('clear-advanced-filters').addEventListener('click', () => { libraryOptions.geometryStates = []; libraryOptions.textureStates = []; state.page = 0; renderLibrary(); });
  $('open-render-dialog').addEventListener('click', () => renderDialog.open());
  $('select-all').addEventListener('change', (event) => { for (const m of visibleModels()) event.target.checked ? state.selected.add(m.id) : state.selected.delete(m.id); renderLibrary(); });
  $('model-list').addEventListener('change', (event) => { if (event.target.matches('input[data-id]')) { event.target.checked ? state.selected.add(event.target.dataset.id) : state.selected.delete(event.target.dataset.id); renderLibrary(); } });
  $('model-list').addEventListener('click', (event) => { const button = event.target.closest('.model-open'); if (button) selectModel(button.dataset.id); });
  document.querySelectorAll('.side-tab').forEach((button) => button.addEventListener('click', () => { state.side = button.dataset.side; document.querySelectorAll('.side-tab').forEach((b) => { const active = b === button; b.classList.toggle('active', active); b.setAttribute('aria-selected', String(active)); }); renderViews(); }));
  document.querySelectorAll('.inspector-tab').forEach((button) => button.addEventListener('click', () => switchPanel(button.dataset.panel)));
  $('overlay-toggle').addEventListener('change', renderViews);
  $('overlay-range').addEventListener('input', (event) => { const value = event.target.value; $('overlay-original').style.clipPath = `inset(0 ${100 - value}% 0 0)`; $('overlay-divider').style.left = value + '%'; });
  $('convert-button').addEventListener('click', () => convert());
  $('convert-selected-button').addEventListener('click', () => convert(true));
  $('pause-button').addEventListener('click', async () => {
    if (state.pauseBusy) return;
    state.pauseBusy = true; updateActions();
    try {
      const resume = ['paused','pausing'].includes(state.job.state);
      await request(resume ? '/api/resume' : '/api/pause', {method:'POST', headers:{'Content-Type':'application/json'}, body:'{}'});
      await poll();
    } catch (error) { toast(error.message, true); }
    finally { state.pauseBusy = false; updateActions(); }
  });
  $('restart-button').addEventListener('click', async () => {
    const ids = state.models.filter(m => state.selected.has(m.id)).map(m => m.id);
    if (!ids.length) { toast('Ocupas seleccionar modelos', true); return; }
    if (isRunning()) return;
    $('restart-button').disabled = true;
    try {
      await request('/api/restart', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({models:ids, render_size:Number($('render-size').value), mesh_mode:$('mesh-mode').value, include_reference:true})});
      if (ids.includes(state.activeId)) { state.model = null; clearInspector(); }
      state.job = {state:'running',operation:'restart',total:ids.length,progress:0,message:'Reiniciando únicamente los modelos seleccionados…'};
      state.resultSignature=''; renderJob(); renderLibrary(); await poll();
    } catch (error) { toast(error.message,true); updateActions(); }
  });

  $('cancel-button').addEventListener('click', async () => {
    if (state.cancelling) return;
    state.cancelling = true; updateActions();
    try { await request('/api/cancel', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: '{}'}); toast('Detención solicitada. Se conservarán las vistas terminadas.'); await poll(); }
    catch (error) { state.cancelling = false; toast(error.message, true); updateActions(); }
  });
  $('page-prev').addEventListener('click', () => { state.page = Math.max(0, state.page - 1); renderLibrary(); });
  $('page-next').addEventListener('click', () => { state.page++; renderLibrary(); });
  $('preview-button').addEventListener('click', async () => {
    if (isRunning() || !state.activeId) return;
    if (modelReport(state.activeId)) { await selectModel(state.activeId); switchPanel('views'); return; }
    try {
      await request('/api/preview', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({models:[state.activeId], render_size:Number($('render-size').value), mesh_mode:$('mesh-mode').value})});
      state.job = {state:'running', operation:'preview', message:'Generando las vistas de este modelo…'};
      renderJob(); await poll();
    } catch (error) { toast(error.message, true); }
  });
  $('export-partial').addEventListener('click', async () => {
    try {
      await request('/api/export-completed', {method:'POST', headers:{'Content-Type':'application/json'}, body:'{}'});
      state.job = {state:'running', operation:'export', message:'Preparando ZIP de los modelos terminados…'};
      renderJob(); await poll();
    } catch (error) { toast(error.message, true); }
  });
  $('help-button').addEventListener('click', () => $('help-dialog').showModal());
  $('close-help').addEventListener('click', () => $('help-dialog').close());
  $('help-done').addEventListener('click', () => $('help-dialog').close());
  $('help-dialog').addEventListener('click', (event) => { if (event.target === $('help-dialog')) { const rect = $('help-dialog').getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) $('help-dialog').close(); } });
  function updateViewControls(persist = false) {
    document.querySelectorAll('[data-view-mode]').forEach((button) => {
      const active = button.dataset.viewMode === viewOptions.mode;
      button.setAttribute('aria-checked', String(active)); button.tabIndex = active ? 0 : -1;
    });
    $('xray-toggle').setAttribute('aria-checked', String(viewOptions.xray));
    $('xray-toggle').title = 'Rayos X: ' + (viewOptions.xray ? 'activado' : 'desactivado') + ' · ver a través del modelo';
    $('normals-toggle').checked = viewOptions.normals;
    $('normals-state').textContent = viewOptions.normals ? 'ON' : 'OFF';
    $('normals-legend').hidden = !viewOptions.normals;
    $('xray-opacity-control').hidden = !viewOptions.xray;
    $('xray-opacity-label').textContent = viewOptions.mode === 'wireframe' ? 'Aristas ocultas' : 'Opacidad';
    $('xray-opacity').value = Math.round(viewOptions.opacity * 100);
    $('xray-opacity-value').textContent = Math.round(viewOptions.opacity * 100) + '%';
    if (persist) {
      try { localStorage.setItem('modbridge.viewer', JSON.stringify(viewOptions)); } catch (_) {}
    }
  }
  function setViewMode(mode) { viewOptions.mode = mode; updateViewControls(true); scheduleDraw(); }
  document.querySelectorAll('[data-view-mode]').forEach((button) => {
    button.addEventListener('click', () => setViewMode(button.dataset.viewMode));
    button.addEventListener('keydown', (event) => {
      const keys = ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End'];
      if (!keys.includes(event.key)) return;
      event.preventDefault();
      const modes = Object.keys(VIEW_MODES), index = modes.indexOf(viewOptions.mode);
      const next = event.key === 'Home' ? 0 : event.key === 'End' ? modes.length - 1 : (index + (['ArrowLeft', 'ArrowUp'].includes(event.key) ? -1 : 1) + modes.length) % modes.length;
      setViewMode(modes[next]); document.querySelector(`[data-view-mode="${modes[next]}"]`).focus();
    });
  });
  $('xray-toggle').addEventListener('click', () => { viewOptions.xray = !viewOptions.xray; updateViewControls(true); scheduleDraw(); });
  $('normals-toggle').addEventListener('change', (event) => { viewOptions.normals = event.target.checked; updateViewControls(true); scheduleDraw(); });
  $('xray-opacity').addEventListener('input', (event) => { viewOptions.opacity = Number(event.target.value) / 100; updateViewControls(true); scheduleDraw(); });
  updateViewControls();
  $('reset-camera').addEventListener('click', () => { state.camera = {yaw: -.62, pitch: .34, zoom: 1}; drawCanvases(); });
  bindCanvas($('original-canvas')); bindCanvas($('bedrock-canvas'));
  new ResizeObserver(scheduleDraw).observe($('panel-geometry'));
  window.addEventListener('resize', scheduleDraw);
  renderDialog = window.ModBridgeRenderDialog.create({
    request,
    getContext: () => ({
      revision: state.project?.revision,
      master: state.project?.name || 'Maestra',
      models: state.models.filter((model) => state.selected.has(model.id)),
      size: Number($('render-size').value), meshMode: $('mesh-mode').value
    }),
    onBusyChange: (busy) => { state.renderBusy = busy; renderLibrary(); },
    notify: toast
  });
  loadAnalysisFilters(); renderDialog.refreshStatus();
  poll(); setInterval(() => { if (!state.connected || ['running','pausing','paused','stopping'].includes(state.job.state)) poll(); }, 500);
})();
