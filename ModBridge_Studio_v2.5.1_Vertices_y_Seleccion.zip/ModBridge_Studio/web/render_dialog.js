'use strict';

// The configurator owns export selections only. Model data remains on the server.
window.ModBridgeRenderDialog = (() => {
  function create({request, getContext, onBusyChange = () => {}}) {
    const helpers = window.ModBridgeRenderConfig;
    const $ = (id) => document.getElementById(id);
    const dialog = $('render-dialog');
    let models = [], profiles = [], activeId = '', sequence = 0, contextKey = '';
    let busy = false, starting = false, pollBusy = false, timer = null, planTimer = null;
    let planRevision = 0, verifiedRevision = -1, serverError = '', lastSummary = null;
    let lastStatus = null, statusGeneration = 0;
    let masterIds = new Set(), masterUndo = null;
    const active = () => profiles.find((profile) => profile.id === activeId);
    const el = (tag, className, text) => {
      const result = document.createElement(tag);
      if (className) result.className = className;
      if (text !== undefined) result.textContent = text;
      return result;
    };
    const json = (body) => ({method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});
    const count = (value) => Number(value || 0).toLocaleString('es');
    const labelFor = (items, value) => items.find((item) => item.id === value)?.label || value;
    const variantsText = (profile) => helpers.parameterVariants(profile).map((variant) => variant.xray && variant.normals ? 'Rayos X + Normales' : variant.xray ? 'Rayos X' : variant.normals ? 'Normales' : 'Sin parámetros').join(' / ');
    const representationText = (value) => ({original: 'Original Java', translated: 'Traducido Bedrock', comparison: 'Comparación (Java + Bedrock)'}[value] || value);
    const profileText = (profile) => `${profile.views.map((v) => labelFor(helpers.VIEWS, v)).join(', ') || 'Sin perspectivas'} · ${profile.modes.map((v) => labelFor(helpers.MODES, v)).join(', ') || 'Sin modos'} · ${variantsText(profile)} · ${profile.size} px · ${representationText(profile.representation)}`;
    function configuration() {
      return {
        profiles: profiles.map((profile) => ({...profile, views: [...profile.views], modes: [...profile.modes]})),
        models: models.filter((model) => model.selected).map((model) => ({id: model.id, master: model.master, profile_ids: profiles.filter((profile) => model.profileIds.has(profile.id)).map((profile) => profile.id)})),
        mesh_mode: getContext().meshMode || 'surface'
      };
    }
    function masterSnapshot() {
      return {models: models.map((model) => ({...model, profileIds: undefined, profile_ids: [...model.profileIds]})),
        profiles: helpers.cloneJSON(profiles), activeId, masterIds: [...masterIds]};
    }
    function masterOptions() {
      return {scope: $('render-master-scope').value, assign: $('render-master-assign').checked,
        assignment_mode: $('render-master-assignment').value, profile_ids: profiles.filter((p) => masterIds.has(p.id)).map((p) => p.id),
        set_master: $('render-master-set-name').checked, master: $('render-master-name').value,
        copy_settings: $('render-master-copy-settings').checked, source_profile_id: activeId};
    }
    function renderMasterProfiles() {
      masterIds = new Set([...masterIds].filter((id) => profiles.some((p) => p.id === id)));
      const fragment = document.createDocumentFragment();
      for (const profile of profiles) {
        const label = el('label', 'check-label'); label.title = profileText(profile);
        const check = el('input'); check.type = 'checkbox'; check.checked = masterIds.has(profile.id); check.dataset.masterProfile = profile.id;
        check.addEventListener('change', () => { check.checked ? masterIds.add(profile.id) : masterIds.delete(profile.id); renderMasterPreview(); });
        label.append(check, el('span', '', profile.name)); fragment.append(label);
      }
      $('render-master-profiles').replaceChildren(fragment);
      renderMasterPreview();
    }
    function renderMasterPreview() {
      const options = masterOptions();
      $('render-master-name').disabled = !options.set_master;
      $('render-master-assignment').disabled = !options.assign;
      $('render-master-source').textContent = active() ? `Perfil activo que aporta los ajustes: ${active().name}. ${profileText(active())}` : '';
      const plan = helpers.masterUpdate(masterSnapshot(), options);
      const actions = [];
      if (options.assign) actions.push(`${{replace: 'reemplazar', add: 'añadir', remove: 'quitar'}[options.assignment_mode]} la asignación con ${count(options.profile_ids.length)} perfiles`);
      if (options.set_master) actions.push(`usar la maestra «${options.master.trim() || 'sin nombre'}»`);
      if (options.copy_settings) actions.push(`actualizar ${count(plan.settings_profile_count)} perfiles con los ajustes del perfil activo`);
      $('render-master-preview').textContent = `Al aplicar: ${count(plan.model_count)} de ${count(models.length)} modelos del configurador. ${actions.join('; ')}.${plan.cloned_profile_count ? ` Se crearán ${count(plan.cloned_profile_count)} copias de perfiles compartidos para conservar intactos los modelos fuera del alcance.` : ''} No cambia cuáles están marcados para exportar.`;
      $('render-master-errors').replaceChildren(...plan.errors.map((error) => el('li', '', error)));
      $('render-master-errors').hidden = !plan.errors.length;
      $('render-master-apply').disabled = !!plan.errors.length;
      $('render-master-undo').disabled = !masterUndo;
      return plan;
    }
    function installMasterSnapshot(snapshot) {
      models = snapshot.models.map((model) => { const copy = {...model, profileIds: new Set(model.profile_ids)}; delete copy.profile_ids; return copy; });
      profiles = snapshot.profiles; activeId = snapshot.activeId || activeId;
      masterIds = new Set(snapshot.masterIds || [...masterIds]);
    }
    function applyMaster() {
      const plan = renderMasterPreview();
      if (plan.errors.length) return;
      masterUndo = masterSnapshot();
      const mapping = new Map(plan.clones.map((item) => [item.source_id, item.id]));
      installMasterSnapshot({...plan, activeId, masterIds: [...masterIds].map((id) => mapping.get(id) || id)});
      renderModels(); renderProfiles(); renderEditor(); changed(true);
      $('render-master-feedback').textContent = `Control maestro aplicado a ${count(plan.model_count)} modelos. ${count(plan.settings_profile_count)} perfiles actualizados${plan.cloned_profile_count ? `; ${count(plan.cloned_profile_count)} copias para respetar el alcance` : ''}. Puedes deshacer esta aplicación antes de realizar otro cambio de configuración.`;
    }
    function setBusy(value) {
      const changed = busy !== value;
      busy = value;
      $('render-configuration').disabled = busy;
      $('render-cancel').hidden = !busy;
      $('render-cancel').disabled = starting || lastStatus?.state === 'stopping' || lastStatus?.state === 'cancelling';
      $('render-start').disabled = busy || verifiedRevision !== planRevision || !!lastSummary?.errors?.length || !lastSummary?.image_count;
      if (changed) onBusyChange(busy);
    }
    function renderModels() {
      const fragment = document.createDocumentFragment();
      if (!models.length) fragment.append(el('p', 'render-empty', 'No hay modelos seleccionados. Cierra el configurador y marca los modelos en la biblioteca.'));
      for (const model of models) {
        const row = el('div', 'render-model-row');
        const heading = el('div', 'render-model-heading');
        const label = el('label', 'check-label');
        const check = el('input'); check.type = 'checkbox'; check.checked = model.selected; check.dataset.modelId = model.id;
        const name = el('span', 'render-model-name', model.name); name.title = model.id;
        label.append(check, name); heading.append(label, el('small', '', model.id));
        check.addEventListener('change', () => { model.selected = check.checked; changed(); });
        const masterLabel = el('label', 'render-master-label', 'Maestra');
        const master = el('input'); master.type = 'text'; master.value = model.master; master.maxLength = 120; master.setAttribute('aria-label', `Maestra de ${model.name}`); master.dataset.masterFor = model.id;
        master.addEventListener('input', () => { model.master = master.value; changed(); }); masterLabel.append(master);
        const assignments = el('div', 'render-model-profiles'); assignments.setAttribute('role', 'group'); assignments.setAttribute('aria-label', `Perfiles de ${model.name}`);
        for (const profile of profiles) {
          const choice = el('label', 'check-label'); choice.title = profileText(profile);
          const input = el('input'); input.type = 'checkbox'; input.checked = model.profileIds.has(profile.id); input.dataset.modelProfile = 'true'; input.dataset.modelId = model.id; input.dataset.profileId = profile.id;
          input.addEventListener('change', () => { input.checked ? model.profileIds.add(profile.id) : model.profileIds.delete(profile.id); changed(); });
          const text = el('span', '', profile.name); text.dataset.profileLabel = profile.id; choice.append(input, text); assignments.append(choice);
        }
        const tools = el('div', 'render-tools');
        for (const [title, all] of [['Todos los perfiles', true], ['Ningún perfil', false]]) {
          const button = el('button', 'button button-small button-quiet', title); button.type = 'button'; button.setAttribute('aria-label', `${title}: ${model.name}`);
          button.addEventListener('click', () => { model.profileIds = new Set(all ? profiles.map((p) => p.id) : []); renderModels(); changed(); }); tools.append(button);
        }
        row.append(heading, masterLabel, assignments, tools); fragment.append(row);
      }
      $('render-models').replaceChildren(fragment);
      renderMasterPreview();
    }
    function renderProfiles() {
      const focusedProfile = $('render-profile-list').contains(document.activeElement) ? document.activeElement.dataset.profileId : null;
      const fragment = document.createDocumentFragment();
      for (const profile of profiles) {
        const button = el('button', 'render-profile-card'); button.type = 'button'; button.dataset.profileId = profile.id; button.setAttribute('aria-pressed', String(profile.id === activeId));
        button.append(el('strong', '', profile.name), el('span', '', profileText(profile)));
        button.addEventListener('click', () => { activeId = profile.id; renderProfiles(); renderEditor(); }); fragment.append(button);
      }
      $('render-profile-list').replaceChildren(fragment);
      if (focusedProfile) [...$('render-profile-list').children].find((button) => button.dataset.profileId === focusedProfile)?.focus();
      $('render-remove-profile').disabled = profiles.length < 2;
      $('render-add-profile').disabled = profiles.length >= 32;
      $('render-duplicate-profile').disabled = profiles.length >= 32;
      document.querySelectorAll('[data-profile-label]').forEach((node) => {
        const profile = profiles.find((p) => p.id === node.dataset.profileLabel);
        if (profile) { node.textContent = profile.name; node.parentElement.title = profileText(profile); }
      });
      renderMasterProfiles();
    }
    function renderEditor() {
      const profile = active();
      if (!profile) return;
      $('render-profile-name').value = profile.name;
      $('render-representation').value = profile.representation;
      $('render-resolution').value = profile.size;
      $('render-views').querySelectorAll('input').forEach((input) => { input.checked = profile.views.includes(input.value); });
      $('render-modes').querySelectorAll('input').forEach((input) => { input.checked = profile.modes.includes(input.value); });
      $('render-xray').checked = profile.xray;
      $('render-normals').checked = profile.normals;
      $('render-three-combinations').checked = profile.three_combinations;
      renderParameters();
    }
    function renderParameters() {
      const profile = active();
      if (!profile) return;
      $('render-xray').disabled = profile.three_combinations;
      $('render-normals').disabled = profile.three_combinations;
      $('render-opacity').disabled = !profile.xray && !profile.three_combinations;
      $('render-opacity').value = Math.round(profile.opacity * 100);
      $('render-opacity-value').textContent = `${Math.round(profile.opacity * 100)}%`;
      $('render-parameter-detail').textContent = profile.three_combinations
        ? 'Exactamente 3 variantes: solo Rayos X, solo Normales y ambos. No incluye la variante sin parámetros.'
        : `Una variante: ${variantsText(profile)}. Al marcar ambos, se aplican juntos en una imagen.`;
    }
    function renderSummary(summary) {
      lastSummary = summary;
      $('render-model-count').textContent = `${count(models.filter((model) => model.selected).length)} de ${count(models.length)}`;
      const tiles = [ ['model_count', 'Modelos'], ['profile_count', 'Perfiles'], ['view_count', 'Perspectivas'], ['mode_count', 'Modos'], ['combination_count', 'Combinaciones'], ['image_count', 'Imágenes'] ];
      if (summary.comparison_pair_count) tiles.splice(tiles.length - 1, 0, ['comparison_pair_count', 'Pares Java / Bedrock']);
      $('render-summary').classList.toggle('has-comparison', !!summary.comparison_pair_count);
      $('render-summary').replaceChildren(...tiles.map(([key, label]) => { const tile = el('div'); tile.dataset.summaryCount = key; tile.append(el('strong', '', count(summary[key])), el('span', '', label)); return tile; }));
      const details = document.createDocumentFragment();
      for (const model of models.filter((m) => m.selected)) {
        const assigned = (summary.assignments || []).filter((row) => row.model_id === model.id);
        const line = el('p'); line.append(el('strong', '', model.name + ': '));
        line.append(document.createTextNode(assigned.map((row) => `${profiles.find((p) => p.id === row.profile_id)?.name || row.profile_id} (${count(row.image_count)} imágenes${row.duplicate_count ? `, ${count(row.duplicate_count)} repetidas omitidas` : ''})`).join(' · ') || 'Sin perfiles asignados'));
        details.append(line);
      }
      $('render-summary-details').replaceChildren(details);
      $('render-comparison-note').hidden = !summary.comparison_pair_count;
      $('render-comparison-note').textContent = summary.comparison_pair_count
        ? `Comparación: ${count(summary.comparison_pair_count)} pares solicitados. Cada par usa la misma cámara, resolución y ajustes para Java y Bedrock. Sus archivos terminan en _java.png y _bedrock.png; si una imagen ya existe en otro perfil, el manifiesto enlaza ese archivo sin duplicarlo.`
        : '';
      $('render-duplicate-note').textContent = summary.duplicate_count
        ? `${count(summary.duplicate_count)} imágenes repetidas se omiten. La primera asignación de perfil conserva cada combinación idéntica; no se crean carpetas vacías.`
        : 'Las combinaciones idénticas entre perfiles se guardan una sola vez, en el primer perfil asignado. No se crean carpetas vacías.';
      renderErrors();
      $('render-start').disabled = busy || verifiedRevision !== planRevision || !!summary.errors?.length || !summary.image_count;
    }
    function renderErrors() {
      const errors = [...(lastSummary?.errors || [])];
      if (serverError) errors.push(serverError);
      $('render-validation').replaceChildren(...errors.map((error) => el('li', '', typeof error === 'string' ? error : error.message || JSON.stringify(error))));
      $('render-validation').hidden = !errors.length;
    }
    function changed(preserveMasterUndo = false) {
      if (!preserveMasterUndo) { masterUndo = null; $('render-master-feedback').textContent = ''; }
      renderMasterPreview();
      planRevision += 1; verifiedRevision = -1; serverError = '';
      clearTimeout(planTimer);
      renderSummary(helpers.planSummary(configuration()));
      $('render-plan-status').textContent = lastSummary.errors.length ? 'Completa la configuración' : 'Comprobando configuración…';
      // A previous export stays downloadable, but is explicitly labelled as such.
      if (!$('render-download').hidden) $('render-result').textContent = 'El ZIP disponible corresponde a la última exportación. Genera de nuevo para incluir estos cambios.';
      if (!lastSummary.errors.length) planTimer = setTimeout(() => validatePlan(planRevision), 300);
    }
    async function validatePlan(revision) {
      if (revision !== planRevision || lastSummary?.errors?.length) return false;
      try {
        const data = await request('/api/renders/plan', json(configuration()));
        if (revision !== planRevision) return false;
        const plan = data.plan || data;
        const summary = plan.summary || plan;
        if (!Number.isFinite(summary.image_count)) throw new Error('El servidor no devolvió la cantidad de imágenes del plan.');
        verifiedRevision = revision; serverError = '';
        renderSummary({...summary, errors: []});
        $('render-plan-status').textContent = 'Configuración comprobada';
        return true;
      } catch (error) {
        if (revision !== planRevision) return false;
        serverError = error.message; verifiedRevision = -1;
        $('render-plan-status').textContent = 'No se pudo comprobar'; renderErrors(); $('render-start').disabled = true;
        return false;
      }
    }
    function newProfile(duplicate = false) {
      if (profiles.length >= 32) return;
      const id = 'perfil_' + (++sequence);
      const profile = duplicate ? {...active(), views: [...active().views], modes: [...active().modes], id, name: active().name + ' copia'} : helpers.createProfile(id, `Perfil ${sequence}`, Number(getContext().size) || 192);
      profiles.push(profile); masterIds.add(id); activeId = id;
      for (const model of models) if (model.selected) model.profileIds.add(id);
      renderModels(); renderProfiles(); renderEditor(); changed();
    }
    function loadSelection() {
      const context = getContext();
      const key = `${context.revision || ''}:${context.master || ''}`;
      if (key !== contextKey) {
        profiles = []; models = []; sequence = 0; contextKey = key;
        clearResult();
      }
      const previous = new Map(models.map((model) => [model.id, model]));
      if (!profiles.length) { activeId = 'perfil_' + (++sequence); profiles.push(helpers.createProfile(activeId, `Perfil ${sequence}`, Number(context.size) || 192)); masterIds.add(activeId); }
      models = context.models.map((source) => {
        const old = previous.get(source.id);
        return {id: source.id, name: source.name || source.id.split('/').pop(), selected: old?.selected ?? true, master: old?.master || context.master || 'Maestra', profileIds: old?.profileIds || new Set([activeId])};
      });
      renderModels(); renderProfiles(); renderEditor(); changed();
    }
    function safeDownload(path) {
      if (typeof path !== 'string' || !path) return null;
      try { const url = new URL(path, location.origin); return url.origin === location.origin && ['http:', 'https:'].includes(url.protocol) ? url.href : null; } catch (_) { return null; }
    }
    function clearResult() {
      $('render-download').hidden = true; $('render-download').removeAttribute('href');
      $('render-result').textContent = ''; $('render-export-errors').hidden = true;
      $('render-progress-area').hidden = true; $('render-current').textContent = '';
    }
    function renderStatus(status) {
      lastStatus = status;
      const running = ['queued', 'preparing', 'running', 'stopping', 'cancelling'].includes(status.state);
      setBusy(running || starting);
      if (status.state === 'idle' || !status.state) { clearResult(); return; }
      $('render-progress-area').hidden = false;
      const total = Number(status.total) || 0, progress = Number(status.progress) || 0;
      $('render-progress').max = Math.max(total, 1); $('render-progress').value = Math.max(0, Math.min(progress, total || 1));
      $('render-progress-text').textContent = `${status.message || (running ? 'Generando imágenes…' : 'Proceso finalizado')}${total ? ` · ${count(progress)} / ${count(total)}` : ''}`;
      $('render-current').textContent = [status.current_model && `Modelo: ${status.current_model}`, status.current_profile && `Perfil: ${status.current_profile}`].filter(Boolean).join(' · ');
      if (running) return;
      const result = status.result || {};
      const url = safeDownload(result.download_url);
      $('render-download').hidden = !url;
      if (url) $('render-download').href = url; else $('render-download').removeAttribute('href');
      const errors = Array.isArray(result.errors) ? result.errors : [];
      $('render-export-errors').hidden = !errors.length;
      $('render-export-error-list').replaceChildren(...errors.map((error) => el('li', '', typeof error === 'string' ? error : [error.model_id || error.model, error.profile_id || error.profile, error.message || error.error].filter(Boolean).join(' · ') || JSON.stringify(error))));
      $('render-result').textContent = status.state === 'done' || status.state === 'completed'
        ? `Exportación terminada: ${count(result.generated ?? progress)} imágenes${errors.length ? `; ${count(errors.length)} incidencias (consulta el detalle)` : ''}.${url ? ' El ZIP está listo para descargar.' : ' No se generó un ZIP descargable.'}`
        : status.state === 'cancelled' ? `Generación detenida.${url ? ' Puedes descargar las imágenes terminadas.' : ''}`
        : status.state === 'error' || status.state === 'failed' ? `No se pudo completar la exportación: ${status.message || 'consulta las incidencias.'}` : status.message || '';
    }
    function scheduleStatus() { clearTimeout(timer); if (busy) timer = setTimeout(refreshStatus, 600); }
    async function refreshStatus() {
      if (pollBusy) return;
      pollBusy = true;
      const generation = statusGeneration;
      try { const data = await request('/api/renders/status'); if (generation === statusGeneration) renderStatus(data.job || data); }
      catch (error) { if (busy || dialog.open) $('render-progress-text').textContent = `No se pudo consultar el progreso: ${error.message}${busy ? ' Se volverá a intentar.' : ''}`; }
      finally { pollBusy = false; scheduleStatus(); }
    }
    async function start(event) {
      event.preventDefault();
      if (busy || starting) return;
      clearTimeout(planTimer);
      if (!$('render-form').reportValidity()) return;
      starting = true; setBusy(true);
      try {
        if (verifiedRevision !== planRevision && !await validatePlan(planRevision)) return;
        if (!lastSummary.image_count || lastSummary.errors?.length) return;
        statusGeneration += 1;
        const data = await request('/api/renders/start', json(configuration()));
        serverError = ''; renderErrors();
        $('render-export-errors').hidden = true; $('render-download').hidden = true; $('render-result').textContent = '';
        renderStatus(data.job || {...data, state: data.state || 'running'});
      } catch (error) { serverError = error.message; renderErrors(); }
      finally { starting = false; setBusy(['queued', 'preparing', 'running', 'stopping', 'cancelling'].includes(lastStatus?.state)); scheduleStatus(); }
    }
    for (const [id, values, property] of [['render-views', helpers.VIEWS, 'views'], ['render-modes', helpers.MODES, 'modes']]) {
      for (const choice of values) {
        const label = el('label', 'check-label'); const check = el('input'); check.type = 'checkbox'; check.value = choice.id;
        check.addEventListener('change', () => { const profile = active(); profile[property] = values.filter((value) => $(id).querySelector(`input[value="${value.id}"]`).checked).map((value) => value.id); renderProfiles(); changed(); });
        label.append(check, document.createTextNode(choice.label)); $(id).append(label);
      }
    }
    for (const id of ['render-master-scope', 'render-master-assignment', 'render-master-assign', 'render-master-set-name', 'render-master-copy-settings']) $(id).addEventListener('change', renderMasterPreview);
    $('render-master-name').addEventListener('input', renderMasterPreview);
    $('render-master-edit-source').addEventListener('click', () => { $('render-profile-name').scrollIntoView({block: 'center'}); $('render-profile-name').focus({preventScroll: true}); });
    $('render-master-return').addEventListener('click', () => { $('render-master-title').scrollIntoView({block: 'start'}); $('render-master-scope').focus(); });
    for (const [id, all] of [['render-master-profiles-all', true], ['render-master-profiles-none', false]]) $(id).addEventListener('click', () => { masterIds = new Set(all ? profiles.map((p) => p.id) : []); renderMasterProfiles(); });
    $('render-master-apply').addEventListener('click', applyMaster);
    $('render-master-undo').addEventListener('click', () => {
      if (!masterUndo) return;
      const snapshot = masterUndo; masterUndo = null;
      installMasterSnapshot(snapshot); renderModels(); renderProfiles(); renderEditor(); changed(true);
      $('render-master-feedback').textContent = 'Aplicación maestra deshecha. Se restauró la configuración anterior.';
    });
    $('render-form').addEventListener('submit', start);
    $('render-close').addEventListener('click', () => dialog.close());
    $('render-add-profile').addEventListener('click', () => newProfile());
    $('render-duplicate-profile').addEventListener('click', () => newProfile(true));
    $('render-remove-profile').addEventListener('click', () => {
      if (profiles.length < 2) return;
      profiles = profiles.filter((profile) => profile.id !== activeId);
      for (const model of models) model.profileIds.delete(activeId);
      activeId = profiles[0].id; renderModels(); renderProfiles(); renderEditor(); changed();
    });
    for (const [id, selected] of [['render-models-all', true], ['render-models-none', false]]) $(id).addEventListener('click', () => { models.forEach((model) => { model.selected = selected; }); renderModels(); changed(); });
    for (const [id, all] of [['render-views-all', true], ['render-views-none', false]]) $(id).addEventListener('click', () => { active().views = all ? helpers.VIEWS.map((view) => view.id) : []; renderEditor(); renderProfiles(); changed(); });
    for (const [id, assign] of [['render-assign-active', true], ['render-unassign-active', false]]) $(id).addEventListener('click', () => { models.filter((m) => m.selected).forEach((m) => assign ? m.profileIds.add(activeId) : m.profileIds.delete(activeId)); renderModels(); changed(); });
    for (const [id, property] of [['render-profile-name', 'name'], ['render-representation', 'representation'], ['render-resolution', 'size'], ['render-xray', 'xray'], ['render-normals', 'normals'], ['render-three-combinations', 'three_combinations'], ['render-opacity', 'opacity']]) {
      $(id).addEventListener(['render-profile-name', 'render-resolution', 'render-opacity'].includes(id) ? 'input' : 'change', () => {
        active()[property] = ['xray', 'normals', 'three_combinations'].includes(property) ? $(id).checked : property === 'size' ? Number($(id).value) : property === 'opacity' ? Number($(id).value) / 100 : $(id).value;
        renderParameters(); renderProfiles(); changed();
      });
    }
    $('render-cancel').addEventListener('click', async () => {
      $('render-cancel').disabled = true;
      try { await request('/api/renders/cancel', json({})); $('render-progress-text').textContent = 'Detención solicitada. Los modelos originales se conservan.'; await refreshStatus(); }
      catch (error) { $('render-progress-text').textContent = error.message; $('render-cancel').disabled = false; }
    });
    dialog.addEventListener('click', (event) => { if (event.target === dialog) { const rect = dialog.getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close(); } });
    return {
      open() {
        if (!busy || !profiles.length) loadSelection();
        if (!dialog.open) dialog.showModal();
        $('render-close').focus();
        refreshStatus();
      },
      refreshStatus,
      isBusy: () => busy
    };
  }
  return {create};
})();
