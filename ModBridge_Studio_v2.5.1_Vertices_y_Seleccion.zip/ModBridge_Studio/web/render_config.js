'use strict';

// Pure configuration helpers. The server validates the plan again before rendering.
((root) => {
  const VIEWS = Object.freeze([
    {id: 'superior', label: 'Arriba'}, {id: 'inferior', label: 'Abajo'},
    {id: 'izquierda', label: 'Izquierda'}, {id: 'derecha', label: 'Derecha'},
    {id: 'frontal', label: 'Enfrente'}, {id: 'trasera', label: 'Atrás'}
  ].map(Object.freeze));
  const MODES = Object.freeze([
    {id: 'wireframe', label: 'Alambre'}, {id: 'solid', label: 'Sólido'},
    {id: 'texture', label: 'Texturas'}
  ].map(Object.freeze));
  const viewIds = new Set(VIEWS.map((view) => view.id));
  const modeIds = new Set(MODES.map((mode) => mode.id));
  const MAX_PROFILES = 32;
  const MAX_CANDIDATE_IMAGES = 100000;

  function cloneJSON(value) { return JSON.parse(JSON.stringify(value)); }
  function createProfile(id, name, size = 192) {
    return {id, name, views: ['frontal'], modes: ['texture'], xray: false,
      normals: false, three_combinations: false, opacity: 0.35, size,
      representation: 'translated'};
  }
  function cloneProfile(profile, id, name) {
    const copy = cloneJSON(profile);
    if (id !== undefined) copy.id = id;
    if (name !== undefined) copy.name = name;
    return copy;
  }
  function parameterVariants(profile = {}) {
    if (profile.three_combinations === true) return [
      {xray: true, normals: false}, {xray: false, normals: true},
      {xray: true, normals: true}
    ];
    return [{xray: profile.xray === true, normals: profile.normals === true}];
  }
  function validId(id) { return typeof id === 'string' && id.trim().length > 0; }
  function unique(values) { return [...new Set(values)]; }
  function masterUpdate(input = {}, options = {}) {
    // Plan a batch edit on copies. A shared profile is cloned only when a
    // settings change would otherwise leak to a model outside the scope.
    const models = cloneJSON(input.models || []), profiles = cloneJSON(input.profiles || []);
    const errors = [], clones = [];
    const targets = models.filter((model) => options.scope === 'selected' ? model.selected !== false : true);
    const targetIds = new Set(targets.map((model) => model.id));
    const ids = unique(options.profile_ids || []);
    const byId = new Map(profiles.map((profile) => [profile.id, profile]));
    const result = {models, profiles, errors, clones, model_count: targets.length,
      changed_model_count: 0, settings_profile_count: 0, cloned_profile_count: 0};
    if (!['all', 'selected'].includes(options.scope)) errors.push('Elige el alcance del control maestro.');
    if (!targets.length) errors.push('No hay modelos dentro del alcance elegido.');
    if (!options.assign && !options.set_master && !options.copy_settings) errors.push('Activa al menos una acción del control maestro.');
    if (ids.some((id) => !byId.has(id))) errors.push('La selección maestra contiene perfiles que ya no existen.');
    if (options.assign && !['replace', 'add', 'remove'].includes(options.assignment_mode)) errors.push('Elige cómo aplicar los perfiles.');
    if (options.set_master && (typeof options.master !== 'string' || !options.master.trim() || options.master.trim().length > 120)) errors.push('Escribe una maestra de 1 a 120 caracteres.');
    const source = byId.get(options.source_profile_id);
    if (options.copy_settings) {
      if (!source) errors.push('Selecciona el perfil activo que aportará los ajustes.');
      else errors.push(...planSummary({profiles: [source], models: [{id: 'master_validation', profile_ids: [source.id]}]}).errors);
      if (!ids.length) errors.push('Elige los perfiles que recibirán los ajustes.');
    }
    if (errors.length) return result;
    const before = new Map(models.map((model) => [model.id, JSON.stringify(model)]));
    for (const model of targets) {
      const assigned = unique(model.profile_ids || []);
      if (options.assign) model.profile_ids = options.assignment_mode === 'replace' ? [...ids]
        : options.assignment_mode === 'add' ? unique([...assigned, ...ids])
        : assigned.filter((id) => !ids.includes(id));
      if (options.set_master) model.master = options.master.trim();
    }
    if (options.copy_settings) {
      const keys = ['views', 'modes', 'xray', 'normals', 'three_combinations', 'opacity', 'size', 'representation'];
      const sourceWithDefaults = {...createProfile(source.id, source.name), ...source};
      const settings = Object.fromEntries(keys.map((key) => [key, cloneJSON(sourceWithDefaults[key])]));
      for (const pid of ids) {
        const profile = byId.get(pid);
        const users = targets.filter((model) => (model.profile_ids || []).includes(pid));
        if (!users.length || keys.every((key) => JSON.stringify(profile[key]) === JSON.stringify(settings[key]))) continue;
        let destination = profile;
        if (models.some((model) => !targetIds.has(model.id) && (model.profile_ids || []).includes(pid))) {
          if (profiles.length >= MAX_PROFILES) {
            errors.push(`La edición necesita copiar un perfil compartido y superaría el límite de ${MAX_PROFILES}. Usa Todos los modelos o elimina un perfil sin uso.`);
            return {...result, models: cloneJSON(input.models || []), profiles: cloneJSON(input.profiles || [])};
          }
          const prefix = pid.slice(0, 60);
          let suffix = 1, cloneId = `${prefix}_maestro_${suffix}`;
          while (byId.has(cloneId)) cloneId = `${prefix}_maestro_${++suffix}`;
          destination = cloneProfile(profile, cloneId, `${profile.name.slice(0, 100)} · maestro`);
          profiles.push(destination); byId.set(cloneId, destination);
          clones.push({source_id: pid, id: cloneId});
          for (const model of users) model.profile_ids = model.profile_ids.map((id) => id === pid ? cloneId : id);
        }
        Object.assign(destination, cloneJSON(settings));
        result.settings_profile_count++;
      }
    }
    result.changed_model_count = models.filter((model) => JSON.stringify(model) !== before.get(model.id)).length;
    result.cloned_profile_count = clones.length;
    return result;
  }
  function planSummary(config = {}) {
    const errors = [];
    const assignments = [];
    const summary = {model_count: 0, profile_count: 0, view_count: 0, mode_count: 0,
      combination_count: 0, image_count: 0, duplicate_count: 0, comparison_pair_count: 0,
      requested_image_count: 0, assignments, errors};
    const profiles = new Map(), usedProfiles = new Set(), views = new Set();
    const modes = new Set(), combinations = new Set(), modelIds = new Set();
    if (!config || typeof config !== 'object' || Array.isArray(config)) {
      errors.push('La configuración de renders no es válida.');
      config = {};
    }
    if (!Array.isArray(config.profiles)) errors.push('La lista de perfiles no es válida.');
    if (Array.isArray(config.profiles) && config.profiles.length > MAX_PROFILES)
      errors.push(`La exportación admite hasta ${MAX_PROFILES} perfiles. Divide la configuración en varios lotes.`);
    for (const profile of Array.isArray(config.profiles) ? config.profiles : []) {
      if (!profile || typeof profile !== 'object' || !validId(profile.id)) {
        errors.push('Todos los perfiles deben tener un identificador.');
        continue;
      }
      if (profiles.has(profile.id)) {
        errors.push(`El identificador de perfil «${profile.id}» está repetido.`);
        continue;
      }
      profiles.set(profile.id, profile);
    }
    if (!Array.isArray(config.models)) errors.push('La lista de modelos no es válida.');
    const models = Array.isArray(config.models) ? config.models : [];
    if (!models.length) errors.push('Selecciona al menos un modelo.');

    // Normalize only assigned profiles: an unused profile can remain a draft.
    const normalized = new Map();
    function normalize(profile) {
      if (normalized.has(profile.id)) return normalized.get(profile.id);
      const before = errors.length;
      const label = String(profile.name || profile.id);
      const pv = Array.isArray(profile.views) ? unique(profile.views) : [];
      const pm = Array.isArray(profile.modes) ? unique(profile.modes) : [];
      if (!pv.length) errors.push(`El perfil «${label}» necesita al menos una perspectiva.`);
      if (pv.some((view) => !viewIds.has(view))) errors.push(`El perfil «${label}» contiene una perspectiva no válida.`);
      if (!pm.length) errors.push(`El perfil «${label}» necesita al menos un modo de visualización.`);
      if (pm.some((mode) => !modeIds.has(mode))) errors.push(`El perfil «${label}» contiene un modo de visualización no válido.`);
      for (const flag of ['xray', 'normals', 'three_combinations']) {
        if (profile[flag] !== undefined && typeof profile[flag] !== 'boolean')
          errors.push(`El parámetro ${flag} del perfil «${label}» debe estar activado o desactivado.`);
      }
      const size = profile.size === undefined ? 192 : profile.size;
      if (!Number.isInteger(size) || size < 64 || size > 512)
        errors.push(`La resolución del perfil «${label}» debe ser un entero entre 64 y 512.`);
      const opacity = profile.opacity === undefined ? 0.35 : profile.opacity;
      if (typeof opacity !== 'number' || !Number.isFinite(opacity) || opacity < 0.05 || opacity > 0.95)
        errors.push(`La opacidad del perfil «${label}» debe estar entre 0.05 y 0.95.`);
      const representation = profile.representation === undefined ? 'translated' : profile.representation;
      if (!['translated', 'original', 'comparison'].includes(representation))
        errors.push(`La representación del perfil «${label}» no es válida.`);
      const result = errors.length === before ? {views: pv, modes: pm, size, opacity,
        representation, parameters: parameterVariants(profile)} : null;
      normalized.set(profile.id, result);
      return result;
    }

    modelLoop: for (const model of models) {
      if (!model || typeof model !== 'object' || !validId(model.id)) {
        errors.push('Todos los modelos seleccionados deben tener un identificador.');
        continue;
      }
      if (modelIds.has(model.id)) {
        errors.push(`El modelo «${model.id}» está seleccionado más de una vez.`);
        continue;
      }
      modelIds.add(model.id);
      summary.model_count++;
      const ids = Array.isArray(model.profile_ids) ? unique(model.profile_ids) : [];
      if (!ids.length) errors.push(`Selecciona al menos un perfil para «${model.id}».`);
      const seen = new Set();
      for (const profileId of ids) {
        const profile = profiles.get(profileId);
        if (!profile) {
          errors.push(`El modelo «${model.id}» utiliza un perfil inexistente: ${String(profileId)}.`);
          continue;
        }
        usedProfiles.add(profileId);
        const p = normalize(profile);
        if (!p) continue;
        const representations = p.representation === 'comparison' ? ['original', 'translated'] : [p.representation];
        const pairCount = p.views.length * p.modes.length * p.parameters.length;
        const requested = pairCount * representations.length;
        if (summary.requested_image_count + requested > MAX_CANDIDATE_IMAGES) {
          errors.push(`La exportación supera ${MAX_CANDIDATE_IMAGES} combinaciones. Divide los modelos o perfiles en varios lotes.`);
          break modelLoop;
        }
        const row = {model_id: model.id, profile_id: profileId, image_count: 0,
          duplicate_count: 0, requested_image_count: 0};
        assignments.push(row);
        if (p.representation === 'comparison') summary.comparison_pair_count += pairCount;
        for (const view of p.views) views.add(view);
        for (const mode of p.modes) modes.add(mode);
        for (const pair of p.parameters) combinations.add(`${pair.xray}:${pair.normals}`);
        for (const view of p.views) for (const mode of p.modes) for (const pair of p.parameters) for (const representation of representations) {
          row.requested_image_count++;
          const key = JSON.stringify([representation, p.size, view, mode,
            pair.xray, pair.normals, pair.xray ? p.opacity : null]);
          if (seen.has(key)) row.duplicate_count++;
          else { seen.add(key); row.image_count++; }
        }
        summary.image_count += row.image_count;
        summary.duplicate_count += row.duplicate_count;
        summary.requested_image_count += row.requested_image_count;
      }
    }
    summary.profile_count = usedProfiles.size;
    summary.view_count = views.size;
    summary.mode_count = modes.size;
    summary.combination_count = combinations.size;
    summary.images = summary.image_count;
    summary.duplicates = summary.duplicate_count;
    summary.rows = assignments;
    return summary;
  }
  const api = {VIEWS, MODES, MAX_PROFILES, MAX_CANDIDATE_IMAGES,
    createProfile, cloneProfile, cloneJSON, parameterVariants, planSummary, masterUpdate};
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.ModBridgeRenderConfig = api;
})(typeof globalThis === 'undefined' ? this : globalThis);
