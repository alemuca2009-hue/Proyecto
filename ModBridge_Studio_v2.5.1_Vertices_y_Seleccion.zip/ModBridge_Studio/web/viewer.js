'use strict';

// Local WebGL renderer. No CDN, model rewriting, or texture resampling.
(() => {
  const VERTEX = `
    attribute vec3 a_position;
    attribute vec2 a_uv;
    attribute float a_shade;
    uniform vec3 u_center;
    uniform vec4 u_rotation;
    uniform vec3 u_scale;
    varying vec2 v_uv;
    varying float v_shade;
    void main() {
      vec3 p = a_position - u_center;
      float x = p.x * u_rotation.x + p.z * u_rotation.y;
      float z = -p.x * u_rotation.y + p.z * u_rotation.x;
      float y = p.y * u_rotation.z - z * u_rotation.w;
      z = p.y * u_rotation.w + z * u_rotation.z;
      gl_Position = vec4(x * u_scale.x, y * u_scale.y, -z * u_scale.z, 1.0);
      v_uv = a_uv;
      v_shade = a_shade;
    }`;
  const FRAGMENT = `
    precision highp float;
    uniform sampler2D u_texture;
    uniform vec2 u_textureSize;
    uniform bool u_textured;
    uniform bool u_translucentPass;
    uniform bool u_orientation;
    uniform float u_opacity;
    uniform vec4 u_color;
    varying vec2 v_uv;
    varying float v_shade;
    void main() {
      vec4 color = u_textured ? texture2D(u_texture, v_uv / u_textureSize)
                             : vec4(u_color.rgb * v_shade, u_color.a);
      if (u_orientation) {
        // Front/back classification follows the IR's original vertex winding.
        // Do not reverse normals to make a broken model appear correct.
        color = vec4(gl_FrontFacing ? vec3(0.16, 0.40, 1.0)
                                   : vec3(1.0, 0.20, 0.24), 1.0);
      }
      color.a *= u_opacity;
      if (color.a < 0.001) discard;
      if (u_translucentPass) {
        if (color.a >= 0.999) discard;
      } else if (color.a < 0.999) discard;
      gl_FragColor = color;
    }`;

  class ModelViewer {
    constructor(canvas, changed = () => {}) {
      this.canvas = canvas;
      this.changed = changed;
      this.scene = null;
      this.faces = [];
      this.textures = new Map();
      this.error = '';
      this.lost = false;
      this.generation = 0;
      this.overlay = document.createElement('canvas');
      this.overlay.className = 'viewer-overlay';
      this.overlay.setAttribute('aria-hidden', 'true');
      canvas.parentElement.append(this.overlay);
      this.init();
      canvas.addEventListener('webglcontextlost', (event) => {
        event.preventDefault(); this.lost = true;
        this.error = 'Se interrumpió el contexto 3D. Esperando su recuperación…';
        this.changed();
      });
      canvas.addEventListener('webglcontextrestored', () => {
        const scene = this.scene;
        this.releaseScene(); this.scene = null; this.lost = false;
        this.init(); this.setScene(scene); this.changed();
      });
    }
    init() {
      try {
        const gl = this.gl = this.canvas.getContext('webgl', {alpha: false, antialias: true});
        if (!gl) throw new Error('WebGL no está disponible. Activa la aceleración gráfica del navegador o utiliza «Seis vistas».');
        const compile = (type, source) => {
          const shader = gl.createShader(type);
          gl.shaderSource(shader, source); gl.compileShader(shader);
          if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
            const message = gl.getShaderInfoLog(shader); gl.deleteShader(shader); throw new Error(message);
          }
          return shader;
        };
        const vertex = compile(gl.VERTEX_SHADER, VERTEX);
        const fragmentSource = gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER, gl.HIGH_FLOAT).precision
          ? FRAGMENT : FRAGMENT.replace('precision highp float', 'precision mediump float');
        const fragment = compile(gl.FRAGMENT_SHADER, fragmentSource);
        const program = this.program = gl.createProgram();
        gl.attachShader(program, vertex); gl.attachShader(program, fragment); gl.linkProgram(program);
        gl.deleteShader(vertex); gl.deleteShader(fragment);
        if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program));
        this.attributes = ['a_position', 'a_uv', 'a_shade'].map((name) => gl.getAttribLocation(program, name));
        this.uniforms = Object.fromEntries(['u_center', 'u_rotation', 'u_scale', 'u_texture', 'u_textureSize', 'u_textured', 'u_translucentPass', 'u_orientation', 'u_opacity', 'u_color'].map((name) => [name, gl.getUniformLocation(program, name)]));
        this.white = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, this.white);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([255, 255, 255, 255]));
        this.textureParameters();
        this.grid = gl.createBuffer();
        gl.disable(gl.CULL_FACE); // Both sides are inspectable, including flat Bedrock surfaces.
        gl.frontFace(gl.CCW);
        gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL);
        this.error = '';
      } catch (error) { this.error = error.message; }
    }
    textureParameters() {
      const gl = this.gl;
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    }
    releaseScene() {
      this.generation++;
      for (const texture of this.textures.values()) {
        if (texture.image) { texture.image.onload = texture.image.onerror = null; texture.image.removeAttribute('src'); }
        if (texture.handle) this.gl?.deleteTexture(texture.handle);
      }
      this.textures.clear();
      if (this.buffer) this.gl?.deleteBuffer(this.buffer);
      if (this.edgeBuffer) this.gl?.deleteBuffer(this.edgeBuffer);
      this.buffer = this.edgeBuffer = null; this.faces = [];
    }
    setScene(scene) {
      if (this.scene === scene) return;
      this.releaseScene(); this.scene = scene;
      if (!scene || this.error || this.lost) return;
      const data = [], edges = [];
      for (const face of scene.faces || []) {
        const vertices = face.vertices || [];
        if (vertices.length < 3 || !vertices.every((v) => v.length === 3 && v.every(Number.isFinite))) continue;
        const uv = face.uv || [];
        const hasUV = uv.length === vertices.length && uv.every((v) => v.length === 2 && v.every(Number.isFinite));
        const u = vertices[1].map((v, i) => v - vertices[0][i]);
        const v = vertices[2].map((x, i) => x - vertices[0][i]);
        const normal = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
        const shade = .58 + .42 * Math.abs((normal[0] * -.35 + normal[1] * .8 + normal[2] * -.48) / (Math.hypot(...normal) || 1));
        const first = data.length / 6;
        // The conversion IR contains convex quads and pre-triangulated OBJ faces.
        for (let i = 1; i < vertices.length - 1; i++) {
          for (const j of [0, i, i + 1]) data.push(...vertices[j], ...(hasUV ? uv[j] : [0, 0]), shade);
        }
        const edgeFirst = edges.length / 6;
        // Perimeter edges only: fan triangulation must not add diagonal lines.
        const wireEdges = Array.isArray(face.wire_edges) ? face.wire_edges
          : vertices.map((p, i) => [p, vertices[(i + 1) % vertices.length]]);
        for (const segment of wireEdges) {
          if (segment.length !== 2 || !segment.every(p => p.length === 3 && p.every(Number.isFinite))) continue;
          edges.push(...segment[0], 0, 0, 1, ...segment[1], 0, 0, 1);
        }
        this.faces.push({first, count: data.length / 6 - first, key: hasUV ? face.texture : null,
          edgeFirst, edgeCount: edges.length / 6 - edgeFirst, normal,
          center: [0, 1, 2].map((axis) => vertices.reduce((sum, p) => sum + p[axis], 0) / vertices.length)});
      }
      const gl = this.gl;
      this.buffer = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(data), gl.STATIC_DRAW);
      this.edgeBuffer = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.edgeBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(edges), gl.STATIC_DRAW);
    }
    loadTextures() {
      if (!this.scene || this.error || this.lost) return;
      const generation = this.generation;
      for (const key of new Set(this.faces.map((face) => face.key).filter((key) => key != null))) {
        if (this.textures.has(key)) continue;
        const record = {state: 'loading', image: null, handle: null};
        this.textures.set(key, record);
        let url;
        try {
          url = new URL(this.scene.textures?.[key] || '', location.origin);
          if (!this.scene.textures?.[key] || url.origin !== location.origin || !['http:', 'https:'].includes(url.protocol)) throw new Error('Textura no disponible');
        } catch (_) { record.state = 'error'; continue; }
        const image = record.image = new Image();
        image.onload = () => {
          if (generation !== this.generation || this.lost) return;
          const gl = this.gl;
          const max = gl.getParameter(gl.MAX_TEXTURE_SIZE);
          if (image.naturalWidth > max || image.naturalHeight > max) {
            record.state = 'error'; record.reason = `Textura mayor que el límite gráfico (${max} px)`;
          } else {
            try {
              record.handle = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, record.handle);
              gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false); // IR UVs use a top-left pixel origin.
              gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
              gl.pixelStorei(gl.UNPACK_COLORSPACE_CONVERSION_WEBGL, gl.NONE);
              gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
              this.textureParameters();
              record.width = image.naturalWidth; record.height = image.naturalHeight; record.state = 'ready';
            } catch (_) { record.state = 'error'; }
          }
          image.onload = image.onerror = null; record.image = null; this.changed();
        };
        image.onerror = () => {
          if (generation !== this.generation) return;
          record.state = 'error'; record.image = null; this.changed();
        };
        image.src = url.href;
      }
    }
    status() {
      const textures = [...this.textures.values()];
      return {error: this.error, loading: textures.filter((t) => t.state === 'loading').length,
        failed: textures.filter((t) => t.state === 'error').length,
        withoutUV: this.faces.filter((f) => f.key == null).length};
    }
    bind(buffer) {
      const gl = this.gl;
      gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      for (let i = 0; i < 3; i++) {
        gl.enableVertexAttribArray(this.attributes[i]);
        gl.vertexAttribPointer(this.attributes[i], [3, 2, 1][i], gl.FLOAT, false, 24, [0, 12, 20][i]);
      }
    }
    render(camera, bounds, options = {}) {
      // Keep the boolean API usable for older renderer integrations/tests.
      if (typeof options === 'boolean') options = {mode: options ? 'texture' : 'solid'};
      const mode = ['wireframe', 'solid', 'texture'].includes(options.mode) ? options.mode : 'texture';
      const normals = options.normals === true, xray = options.xray === true;
      const opacity = Number.isFinite(options.opacity) ? Math.max(.05, Math.min(.95, options.opacity)) : .35;
      const textured = mode === 'texture' && !normals;
      const rect = this.canvas.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const ratio = Math.min(window.devicePixelRatio || 1, 2);
      const width = Math.round(rect.width * ratio), height = Math.round(rect.height * ratio);
      if (this.canvas.width !== width || this.canvas.height !== height) { this.canvas.width = width; this.canvas.height = height; }
      this.drawOverlay(rect, ratio, camera);
      if (this.error || this.lost) return;
      if (textured) this.loadTextures();
      const gl = this.gl, u = this.uniforms;
      const cy = Math.cos(camera.yaw), sy = Math.sin(camera.yaw), cp = Math.cos(camera.pitch), sp = Math.sin(camera.pitch);
      const scale = Math.min(width, height) / bounds.span * .84 * camera.zoom;
      gl.viewport(0, 0, width, height); gl.depthMask(true); gl.disable(gl.BLEND);
      gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.colorMask(true, true, true, true);
      gl.clearColor(.075, .11, .09, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.useProgram(this.program);
      gl.uniform3fv(u.u_center, bounds.center); gl.uniform4f(u.u_rotation, cy, sy, cp, sp);
      gl.uniform3f(u.u_scale, 2 * scale / width, 2 * scale / height, 1 / (bounds.span * 4));
      gl.uniform1i(u.u_texture, 0); gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.white); gl.uniform2f(u.u_textureSize, 1, 1);
      gl.uniform1i(u.u_textured, 0); gl.uniform1i(u.u_translucentPass, 0);
      gl.uniform1i(u.u_orientation, 0); gl.uniform1f(u.u_opacity, 1);
      if (mode === 'wireframe' && !xray) this.depthPrepass();
      const grid = [], size = Math.max(16, Math.ceil(bounds.span / 16) * 16), y = bounds.min[1] - .2;
      for (let n = -4; n <= 4; n++) {
        const offset = size * n / 4, x = bounds.center[0], z = bounds.center[2];
        for (const point of [[x + offset, y, z - size], [x + offset, y, z + size], [x - size, y, z + offset], [x + size, y, z + offset]]) grid.push(...point, 0, 0, 1);
      }
      this.bind(this.grid); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(grid), gl.DYNAMIC_DRAW);
      gl.uniform4f(u.u_color, .18, .24, .20, 1); gl.drawArrays(gl.LINES, 0, grid.length / 6);
      if (!this.buffer) return;
      if (mode === 'wireframe') {
        if (xray) this.depthPrepass(true);
        this.drawEdges(camera, normals, xray, opacity);
        return;
      }
      this.bind(this.buffer); gl.uniform4f(u.u_color, .69, .74, .70, 1);
      gl.uniform1i(u.u_orientation, normals);
      const draw = (face, texture) => {
        gl.uniform1i(u.u_textured, !!texture);
        gl.bindTexture(gl.TEXTURE_2D, texture?.handle || this.white);
        gl.uniform2f(u.u_textureSize, texture?.width || 1, texture?.height || 1);
        gl.drawArrays(gl.TRIANGLES, face.first, face.count);
      };
      const transparent = [];
      if (xray) {
        gl.disable(gl.DEPTH_TEST); gl.depthMask(false);
        gl.enable(gl.BLEND); gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
        gl.uniform1f(u.u_opacity, opacity); gl.uniform1i(u.u_translucentPass, 1);
      }
      for (const face of this.faces) {
        const record = textured ? this.textures.get(face.key) : null;
        const texture = record?.state === 'ready' ? record : null;
        // Opaque texels and geometry write real per-pixel depth, independent of face order.
        if (!xray) draw(face, texture);
        if (texture || xray) {
          const p = face.center.map((v, i) => v - bounds.center[i]);
          transparent.push({face, texture, depth: p[1] * sp + (-p[0] * sy + p[2] * cy) * cp});
        }
      }
      // Keep cutout holes empty; blend translucent texels far-to-near without
      // blocking later transparent layers. Opaque depth remains active.
      gl.enable(gl.BLEND); gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
      gl.depthMask(false); gl.uniform1i(u.u_translucentPass, 1);
      transparent.sort((a, b) => a.depth - b.depth);
      for (const entry of transparent) draw(entry.face, entry.texture);
      gl.depthMask(true); gl.disable(gl.BLEND); gl.enable(gl.DEPTH_TEST);
      if (xray) {
        this.depthPrepass(true);
        this.drawEdges(camera, normals, true, opacity);
      }
    }
    depthPrepass(clear = false) {
      if (!this.buffer) return;
      const gl = this.gl, u = this.uniforms;
      gl.depthMask(true); gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL);
      if (clear) gl.clear(gl.DEPTH_BUFFER_BIT);
      gl.colorMask(false, false, false, false); gl.disable(gl.BLEND);
      gl.uniform1i(u.u_textured, 0); gl.uniform1i(u.u_orientation, 0);
      gl.uniform1i(u.u_translucentPass, 0); gl.uniform1f(u.u_opacity, 1);
      gl.uniform4f(u.u_color, 1, 1, 1, 1);
      this.bind(this.buffer);
      // A small polygon offset keeps real perimeter lines from z-fighting
      // against the surface used to hide edges on the back of the model.
      gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(1, 1);
      for (const face of this.faces) gl.drawArrays(gl.TRIANGLES, face.first, face.count);
      gl.disable(gl.POLYGON_OFFSET_FILL); gl.colorMask(true, true, true, true);
    }
    drawEdges(camera, normals, xray, opacity) {
      const gl = this.gl, u = this.uniforms;
      this.bind(this.edgeBuffer);
      gl.uniform1i(u.u_textured, 0); gl.uniform1i(u.u_orientation, 0); gl.uniform1f(u.u_opacity, 1);
      gl.bindTexture(gl.TEXTURE_2D, this.white); gl.depthMask(false);
      gl.enable(gl.BLEND); gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
      const sy = Math.sin(camera.yaw), cy = Math.cos(camera.yaw), sp = Math.sin(camera.pitch), cp = Math.cos(camera.pitch);
      const faces = this.faces.map((face) => ({face, facing: face.normal[1] * sp + (-face.normal[0] * sy + face.normal[2] * cy) * cp}));
      // Draw outward-facing edges last at shared boundaries. Lines do not
      // have gl_FrontFacing, so use each polygon's actual transformed normal.
      faces.sort((a, b) => a.facing - b.facing);
      const pass = (hidden) => {
        gl.depthFunc(hidden ? gl.GREATER : gl.LEQUAL);
        gl.uniform1i(u.u_translucentPass, hidden);
        for (const {face, facing} of faces) {
          const rgb = normals ? (facing >= 0 ? [.16, .40, 1] : [1, .20, .24]) : [.69, .84, .56];
          gl.uniform4f(u.u_color, ...rgb, hidden ? opacity : 1);
          gl.drawArrays(gl.LINES, face.edgeFirst, face.edgeCount);
        }
      };
      if (xray) pass(true);
      pass(false);
      gl.depthFunc(gl.LEQUAL); gl.depthMask(true); gl.disable(gl.BLEND);
    }
    drawOverlay(rect, ratio, camera) {
      const overlay = this.overlay;
      overlay.width = Math.round(rect.width * ratio); overlay.height = Math.round(rect.height * ratio);
      overlay.style.height = rect.height + 'px';
      const ctx = overlay.getContext('2d'); ctx.scale(ratio, ratio);
      if (this.error || !this.faces.length) {
        ctx.fillStyle = '#9ba8a3'; ctx.font = '12px system-ui'; ctx.textAlign = 'center';
        ctx.fillText(this.error ? 'Visor 3D no disponible · revisa el aviso inferior' : 'Sin geometría disponible', rect.width / 2, rect.height / 2);
      }
      const cy = Math.cos(camera.yaw), sy = Math.sin(camera.yaw), cp = Math.cos(camera.pitch), sp = Math.sin(camera.pitch);
      const origin = [30, rect.height - 30];
      for (const [axis, vector, color] of [['X', [1, 0, 0], '#cf8c82'], ['Y', [0, 1, 0], '#b0d27f'], ['Z', [0, 0, 1], '#7faecb']]) {
        const x = vector[0] * cy + vector[2] * sy, z = -vector[0] * sy + vector[2] * cy;
        const y = vector[1] * cp - z * sp;
        ctx.strokeStyle = ctx.fillStyle = color; ctx.lineWidth = 1.3;
        ctx.beginPath(); ctx.moveTo(...origin); ctx.lineTo(origin[0] + x * 18, origin[1] - y * 18); ctx.stroke();
        ctx.font = '9px monospace'; ctx.textAlign = 'center'; ctx.fillText(axis, origin[0] + x * 25, origin[1] - y * 25 + 3);
      }
    }
  }
  window.ModBridgeViewer = ModelViewer;
})();
