"""One disposable process per job: no worker pool, no geometry transferred over IPC."""
from __future__ import annotations
import json, sys, traceback
from pathlib import Path
from bridge.pipeline import run_conversion, export_result, read_json
from bridge.pack import write_json
from bridge.resources import ResourcePack
from bridge.reference import ReferenceAddon
from bridge.preview import build_preview
from bridge.catalog import compact_report
from bridge.control import pausing, checkpoint
from bridge.job_control import pause_callback
from bridge.run_history import retain_models


def run_job(config_path):
    config=json.loads(Path(config_path).read_text(encoding='utf-8'))
    run=Path(config['run']); operation=config['operation']
    def progress(value):
        checkpoint()
        write_json(run/'progress.json',value)
    def ready(value):
        build_preview(run/'models'/value['slug'])
        with (run/'ready.ndjson').open('a',encoding='utf-8') as stream:
            stream.write(json.dumps(value,ensure_ascii=False)+'\n')
    try:
        if operation=='export':
            source=Path(config['source_run'])
            reports=[read_json(marker.parent/'report.json') for marker in sorted((source/'models').glob('*/ready.json'))]
            reports=[r for r in reports if r]
            if not reports:raise ValueError('Todavía no hay modelos terminados para exportar.')
            progress({'state':'running','progress':len(reports),'total':config.get('planned_total',len(reports)), 'message':'Exportando únicamente modelos terminados'})
            with ResourcePack(config['java'], extra_paths=config['dependencies']) as pack:inventory=pack.inventory()
            reference=ReferenceAddon(config['reference']) if config.get('reference') else None
            result=export_result(source,reports,inventory,reference,planned_total=config.get('planned_total'),export_name='exportacion_parcial')
        else:
            retained=retain_models(config.get('retained_models',{}),run,ready=ready)
            result=run_conversion(config['java'],run, models=config.get('models'), pattern=config.get('filter',''),
                dependencies=config['dependencies'],reference_path=config.get('reference'),size=config['render_size'],
                mesh_mode=config['mesh_mode'],progress=progress,on_model=ready,make_export=operation!='preview',retained_reports=retained)
        # The UI gets only the tiny catalogue; detailed reports and IR remain on disk.
        result['reports']=[compact_report(r) for r in result['reports']]
        write_json(run/'completion.json',{'ok':True,'result':result})
    except Exception as error:
        traceback.print_exc()
        write_json(run/'completion.json',{'ok':False,'error':str(error)})
        return 1
    return 0

def main(config_path):
    config=json.loads(Path(config_path).read_text(encoding='utf-8'))
    with pausing(pause_callback(config['run'])):
        return run_job(config_path)

if __name__=='__main__':sys.exit(main(sys.argv[1]))
