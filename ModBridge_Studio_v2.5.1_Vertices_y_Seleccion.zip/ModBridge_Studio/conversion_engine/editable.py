"""Lossless polygon editing alternative for meshes Bedrock cannot load."""
from pathlib import Path
from PIL import Image


def export_editable_obj(ir, atlas_path, destination):
    """Export decoded canonical mesh to OBJ (1 world unit=1 block), no voxelization."""
    dest=Path(destination);dest.mkdir(parents=True,exist_ok=True)
    with Image.open(atlas_path) as image:width,height=image.size
    obj=['# ModBridge editable diagnostic mesh. NOT a Bedrock geometry.',
         '# Coordinates divided by 16: one OBJ unit = one Minecraft block.',
         'mtllib alternativa_editable.mtl','o modelo','usemtl atlas']
    index=1
    for face in ir.get('faces',[]):
        vertices=face['vertices'];uvs=face['uv']
        normals=face.get('vertex_normals') or [face.get('normal',[0,1,0])]*len(vertices)
        for vertex in vertices:obj.append('v '+' '.join(format(float(v)/16,'.12g') for v in vertex))
        for u,v in uvs:obj.append(f'vt {u/width:.12g} {1-v/height:.12g}')
        for normal in normals:obj.append('vn '+' '.join(format(float(v),'.12g') for v in normal))
        obj.append('f '+' '.join(f'{i}/{i}/{i}' for i in range(index,index+len(vertices))))
        index+=len(vertices)
    (dest/'alternativa_editable.obj').write_text('\n'.join(obj)+'\n',encoding='utf-8')
    (dest/'alternativa_editable.mtl').write_text('newmtl atlas\nKd 1 1 1\nKa 1 1 1\nd 1\nmap_Kd atlas.png\n',encoding='utf-8')
    (dest/'NO_COMPATIBLE.txt').write_text(
        'La geometría poly_mesh es diagnóstica: NO debe incluirse en un pack Bedrock de producción.\n'
        'alternativa_editable.obj + .mtl + atlas.png conservan superficies y UV para reconstrucción manual en un editor 3D.\n'
        'No se voxeliza ni se aproxima la forma automáticamente. Se conserva también el OBJ/MTL fuente bajo modelos_originales.\n'
        'La apariencia de transparencias/materiales del OBJ depende del importador del editor.\n',encoding='utf-8')
