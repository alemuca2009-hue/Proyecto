"""Join existing coplanar surfaces without changing their union or UV triangles.

The boundary is built by cancelling opposite source edges, never by a convex
hull. Inner cycles remain holes. Duplicate coincident layers are kept separate.
"""
from __future__ import annotations

from collections import defaultdict
import numpy as np
from .control import checkpoint
from .triangulation import _triangulate


def _key(point):
    return tuple(round(float(value), 8) for value in point)


def _prepared(face):
    vertices = np.asarray(face.get('vertices', []), dtype=float)
    uv = np.asarray(face.get('uv', []), dtype=float)
    if (vertices.ndim != 2 or vertices.shape[1:] != (3,) or len(vertices) < 3
            or uv.shape != (len(vertices), 2) or not np.isfinite(vertices).all()
            or not np.isfinite(uv).all()):
        return None
    triangles = _triangulate(vertices)
    if not triangles:
        return None
    areas = [np.cross(vertices[b]-vertices[a], vertices[c]-vertices[a]) for a,b,c in triangles]
    normal = max(areas, key=lambda value: np.linalg.norm(value))
    length = np.linalg.norm(normal)
    if length < 1e-12:
        return None
    normal = normal / length
    scale = max(1., float(np.linalg.norm(np.ptp(vertices, axis=0))))
    if np.max(np.abs((vertices-vertices[0]) @ normal)) > 1e-8*scale:
        return None
    area = sum(float(np.dot(value, normal))/2 for value in areas)
    if area <= 1e-12:
        return None
    keys = list(map(_key, vertices))
    if len(set(keys)) != len(keys):
        return None
    return {'vertices': vertices, 'uv': uv, 'triangles': triangles,
            'normal': normal, 'area': area, 'keys': keys, 'scale': scale}


def _compatible(a, b, pa, pb):
    if any(a.get(key) != b.get(key) for key in ('texture','material','tintindex','cullface','shade')):
        return False
    if float(pa['normal'] @ pb['normal']) < 1-1e-10:
        return False
    tolerance = 1e-8*max(pa['scale'], pb['scale'])
    return np.max(np.abs((pb['vertices']-pa['vertices'][0]) @ pa['normal'])) <= tolerance


def _region(indices, faces, prepared):
    positions, uv_values, edges = {}, {}, defaultdict(list)
    triangles, vertices, uv, source_indices = [], [], [], []
    for index in indices:
        face, part = faces[index], prepared[index]
        offset = len(vertices)
        vertices.extend(part['vertices'].tolist()); uv.extend(part['uv'].tolist())
        triangles.extend(tuple(offset + v for v in triangle) for triangle in part['triangles'])
        source_indices.extend(face['source_indices'])
        for i, key in enumerate(part['keys']):
            if key in positions and np.linalg.norm(positions[key]-part['vertices'][i]) > 1e-8:
                return None
            positions[key] = part['vertices'][i]
            uv_values.setdefault(key, part['uv'][i])
        for a,b in zip(part['keys'], part['keys'][1:]+part['keys'][:1]):
            edges[tuple(sorted((a,b)))].append((a,b))
    boundary = []
    for occurrences in edges.values():
        if len(occurrences) == 1:
            boundary.append(occurrences[0])
        elif len(occurrences) != 2 or occurrences[0] != occurrences[1][::-1]:
            return None  # Non-manifold or overlapping surfaces stay independent.
    following = dict(boundary)
    if len(following) != len(boundary) or len(set(following.values())) != len(boundary):
        return None
    unused = set(following); rings = []
    while unused:
        first = min(unused); order = [first]; unused.remove(first)
        current = following[first]
        while current != first:
            if current not in unused:
                return None
            unused.remove(current); order.append(current); current = following[current]
        if len(order) < 3:
            return None
        ring = np.asarray([positions[key] for key in order])
        # Collinear tessellation vertices are not silhouette corners. They are
        # still retained in the independent interpolation triangles above.
        while len(ring) > 3:
            ab=ring-np.roll(ring,1,axis=0);bc=np.roll(ring,-1,axis=0)-ring
            straight=(np.linalg.norm(np.cross(ab,bc),axis=1) <=
                      1e-10*np.maximum(1.,np.linalg.norm(ab,axis=1)*np.linalg.norm(bc,axis=1)))
            straight &= np.sum(ab*bc,axis=1)>=0
            if not straight.any():break
            if np.count_nonzero(~straight)<3:return None
            ring=ring[~straight]
        rings.append(ring)
    normal = prepared[indices[0]]['normal']
    boundary_area = sum(float(np.sum(np.cross(ring,np.roll(ring,-1,axis=0)),axis=0) @ normal)/2 for ring in rings)
    source_area = sum(prepared[index]['area'] for index in indices)
    if abs(boundary_area-source_area) > max(1e-8,source_area*1e-9):
        return None
    rings.sort(key=lambda ring:-abs(float(np.sum(np.cross(ring,np.roll(ring,-1,axis=0)),axis=0) @ normal)))
    return {**faces[indices[0]], 'vertices': vertices, 'uv': uv,
            'source_triangles': triangles, 'boundary_contours': [ring.tolist() for ring in rings],
            'source_indices': sorted(source_indices), 'normal': normal.tolist(),
            'coplanar_region': True, 'preserves_source_uv_triangles': True,
            'source_planar_area': source_area}


def _merge_regions(faces, can_merge=None):
    """Join compatible edge-connected faces, preserving holes and multiplicity.

    ``can_merge(parts, region)`` may reject a union to preserve native UV tiles.
    Face and vertex dictionaries supplied by the caller are never mutated.
    """
    prepared=[]
    for face in faces:
        checkpoint();prepared.append(_prepared(face))
    edges = defaultdict(list); layers = {}; fingerprints = defaultdict(int)
    for index,(face,part) in enumerate(zip(faces,prepared)):
        checkpoint()
        if part is None:
            continue
        signature = (str(face.get('texture')), tuple(sorted(part['keys'])),
                     tuple(np.round(part['normal'],8)), tuple(map(tuple,np.round(part['uv'],8))))
        layers[index] = fingerprints[signature]; fingerprints[signature] += 1
        for position,(a,b) in enumerate(zip(part['keys'],part['keys'][1:]+part['keys'][:1])):
            edges[tuple(sorted((a,b)))].append((index,position,a,b))
    adjacency = defaultdict(set)
    for occurrences in edges.values():
        checkpoint()
        by_layer=defaultdict(list)
        for occurrence in occurrences:by_layer[layers[occurrence[0]]].append(occurrence)
        for layer in by_layer.values():
            if len(layer)!=2:continue  # Ambiguous edge; never search O(k²) pairs.
            (a,ap,ak,al),(b,bp,bk,bl)=layer
            if a == b or (ak,al) != (bl,bk):continue
            pa,pb = prepared[a],prepared[b]
            if not _compatible(faces[a],faces[b],pa,pb):continue
            # Texture/material changes are rejected above. UV discontinuity
            # remains in the original triangles, subject to the native-UV guard.
            adjacency[a].add(b); adjacency[b].add(a)
    seen=set(); replacements={}; removed=set(); groups=[]; rejected=0
    for first in range(len(faces)):
        if first in seen:
            continue
        pending=[first]; component=[]; seen.add(first)
        while pending:
            current=pending.pop();component.append(current)
            for neighbour in sorted(adjacency[current]):
                if neighbour not in seen:seen.add(neighbour);pending.append(neighbour)
        component.sort()
        if len(component)<2 or sum(len(faces[i]['source_indices']) for i in component)<2:
            continue
        region = _region(component,faces,prepared)
        if region is None or (can_merge and not can_merge([faces[i] for i in component],region)):
            rejected += 1; continue
        replacements[first]=region;removed.update(component[1:]);groups.append(region)
    output=[replacements.get(i,face) for i,face in enumerate(faces) if i not in removed]
    return output, {'method':'source_edge_cancellation_with_original_uv_triangles',
                    'input_patch_count':len(faces),'output_patch_count':len(output),
                    'merged_region_count':len(groups),
                    'merged_source_faces':[region['source_indices'] for region in groups],
                    'hole_count':sum(max(0,len(region['boundary_contours'])-1) for region in groups),
                    'rejected_region_count':rejected,
                    'preserves_source_uv_triangles':True,'preserves_surface_multiplicity':True,
                    'fills_holes':False}


def _rectangle(region):
    rings=region['boundary_contours']
    if len(rings)!=1 or len(rings[0])!=4:return None
    ring=np.asarray(rings[0],float);edges=np.roll(ring,-1,axis=0)-ring
    lengths=np.linalg.norm(edges,axis=1)
    if min(lengths)<1e-9:return None
    if any(abs(float(edges[i]@edges[(i+1)%4]))>1e-9*lengths[i]*lengths[(i+1)%4] for i in range(4)):return None
    if np.linalg.norm(ring[0]+ring[2]-ring[1]-ring[3])>1e-8:return None
    normal=np.asarray(region['normal']);u=edges[0]/lengths[0];v=np.cross(normal,u)
    points=np.asarray(region['vertices']);uv=np.asarray(region['uv'])
    local=np.column_stack(((points-ring[0])@u,(points-ring[0])@v,np.ones(len(points))))
    fit=np.linalg.lstsq(local,uv,rcond=None)[0]
    if np.max(np.abs(local@fit-uv))>1e-6:return None
    # Copy UV values from actual corners, not fitted/rounded replacements.
    corner_uv=[uv[int(np.argmin(np.linalg.norm(points-corner,axis=1)))].tolist() for corner in ring]
    output={k:value for k,value in region.items() if k not in {'source_triangles','boundary_contours','vertex_normals','coplanar_region'}}
    output.update(vertices=ring.tolist(),uv=corner_uv,recovered_rectangle=True)
    return output


def recover_rectangles(faces):
    from .surface_proof import _oriented_surface_comparison
    prepared=[dict(face,source_indices=[i]) for i,face in enumerate(faces)]
    def accept(parts,region):
        rectangle=_rectangle(region)
        return rectangle is not None and _oriented_surface_comparison(parts,[rectangle],1e-5)['equal']
    regions,report=_merge_regions(prepared,can_merge=accept)
    output=[_rectangle(face) if face.get('coplanar_region') else face for face in regions]
    report['method']='only_proven_rectangles_with_continuous_affine_uv'
    report.pop('preserves_source_uv_triangles',None)
    report['preserves_affine_uv_mapping']=True
    return output,report
