"""Minecraft Java 1.21.1 generated item surfaces, reconstructed as JSON elements.

Reference: official 1.21.1 client SHA1 30c73b1c5da787909b2f73340419fdf13b9def88,
class gge (ItemModelGenerator), inspected with Vineflower 1.10.1. The geometry
uses one continuous front/back per layer and the game's direction/anchor spans.
This independently written implementation does not copy or execute Java code.

The callback supplies the current PIL texture frame. Optional
image.info['modbridge_frames'] supplies every animation frame for span union.
Animation timing/materials remain the caller's responsibility.
"""
from __future__ import annotations
from collections import OrderedDict
from typing import Callable
import numpy as np
from PIL import Image
from .resources import normalize_id

GENERATED_PARENTS = {'minecraft:item/generated', 'minecraft:item/handheld',
                     'minecraft:builtin/generated'}


def _resolve_layer(value, textures):
    seen=set()
    while str(value).startswith('#'):
        alias=value[1:]
        if alias in seen: raise ValueError('Ciclo de alias en sprite: #'+alias)
        seen.add(alias)
        if alias not in textures: raise ValueError('Alias de sprite sin resolver: #'+alias)
        value=textures[alias]
    return normalize_id(value)


def _spans(frames):
    """Java combines all transitions with equal direction and anchor, even gaps.

    Therefore a disconnected row is *not* divided into independent boxes; its
    alpha still masks the gap. This preserves the actual Java surface topology.
    """
    spans=OrderedDict()
    for image in frames:
        mask=np.asarray(image.convert('RGBA'))[:,:,3]>0
        h,w=mask.shape
        padded=np.pad(mask,1,constant_values=False)
        edge_masks={
            'up': mask & ~padded[0:h,1:w+1],
            'down': mask & ~padded[2:h+2,1:w+1],
            'left': mask & ~padded[1:h+1,0:w],
            'right': mask & ~padded[1:h+1,2:w+2],
        }
        # Row-major + UP,DOWN,LEFT,RIGHT is Java's stable creation order.
        for y,x in np.argwhere(mask):
            for direction in ('up','down','left','right'):
                if not edge_masks[direction][y,x]:continue
                anchor,position=(int(y),int(x)) if direction in ('up','down') else (int(x),int(y))
                key=(direction,anchor)
                if key not in spans:spans[key]=[position,position]
                else:
                    spans[key][0]=min(spans[key][0],position)
                    spans[key][1]=max(spans[key][1],position)
    return spans


def generated_elements(model:dict, load_texture:Callable[[str],Image.Image]):
    """Return ``(elements, warnings)`` for up to five sequential Java item layers.

    Base coordinates remain Java pixels [0,16]. Tint indices are retained;
    caller must decide how to handle runtime item-color providers. Builtin entity
    models are deliberately rejected: a renderer is not a texture extrusion.
    """
    parent=model.get('_generated')
    if parent and parent not in GENERATED_PARENTS:
        raise ValueError('El padre dinámico no es una extrusión de sprite: '+str(parent))
    textures=model.get('textures',{})
    elements=[];warnings=[]
    for layer in range(5):
        key='layer'+str(layer)
        if key not in textures:break  # Java stops at the first missing layer.
        identifier=_resolve_layer('#'+key,textures)
        image=load_texture(identifier)
        if not isinstance(image,Image.Image):raise TypeError('El cargador del sprite debe devolver PIL.Image.')
        w,h=image.size
        if w<=0 or h<=0:raise ValueError('Dimensiones del sprite inválidas.')
        if w*h>4_194_304:raise ValueError('Sprite demasiado grande para extrusión segura (>4 megapíxeles).')
        frames=image.info.get('modbridge_frames') or [image]
        if any(not isinstance(f,Image.Image) or f.size!=(w,h) for f in frames):
            raise ValueError('Todos los frames del sprite deben tener las mismas dimensiones.')
        def face(uv):
            return {'texture':'#'+key,'uv':uv,'tintindex':layer}
        elements.append({'name':'sprite_'+key+'_front_back','from':[0,0,7.5],
            'to':[16,16,8.5],'shade':True,'faces':{
                'south':face([0,0,16,16]),'north':face([16,0,0,16])}})
        sx,sy=16.0/w,16.0/h
        for (direction,anchor),(start,end) in _spans(frames).items():
            if direction in ('up','down'):
                x0,x1=start*sx,(end+1)*sx
                y=16-(anchor+(direction=='down'))*sy
                a,b=[x0,y,7.5],[x1,y,8.5]
                side=direction
                uv=[x0,anchor*sy,x1,(anchor+1)*sy]
            else:
                x=(anchor+(direction=='right'))*sx
                # Signed Y is deliberate and matches Java ItemModelGenerator.
                a,b=[x,16-start*sy,7.5],[x,16-(end+1)*sy,8.5]
                side='east' if direction=='left' else 'west'
                uv=[anchor*sx,(end+1)*sy,(anchor+1)*sx,start*sy]
            elements.append({'name':f'sprite_{key}_{direction}_{anchor}',
                'from':a,'to':b,'shade':True,'faces':{side:face(uv)}})
    if not elements:
        raise ValueError('El sprite generado no define layer0; no se inventa textura.')
    if any('layer'+str(i) in textures for i in range(5,20)):
        warnings.append('Java item/generated usa layer0..layer4; las capas superiores se conservan solo como referencia.')
    return elements,warnings
