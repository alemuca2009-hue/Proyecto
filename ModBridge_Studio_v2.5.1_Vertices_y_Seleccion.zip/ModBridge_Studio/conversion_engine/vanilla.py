"""Version-pinned original Minecraft resources used only as a fallback.

The bundled ZIP consists of untouched assets/minecraft entries from the Mojang
1.21.1 client, downloaded using its official manifest and SHA-1 checked against
that manifest. It contains no executable Minecraft classes. User-supplied
resources must always take precedence over this fallback.
"""
from __future__ import annotations
import copy
import json
import re
import zipfile
from functools import lru_cache
from pathlib import Path

BUNDLED_VERSION = '1.21.1'
OFFICIAL_CLIENT_SHA1 = '30c73b1c5da787909b2f73340419fdf13b9def88'
BUNDLED_RESOURCE_SHA256 = '495e83c541d92c6bb96716dfb931f18f02baf90ece54b6ecd29742ad6345e613'


def bundled_resource_path():
    """Return the exact fallback resource archive, or None if not installed."""
    path = Path(__file__).resolve().parent / 'data' / 'vanilla_1.21.1.zip'
    return path if path.is_file() else None


def provenance():
    """Return the recorded official version manifest/download evidence."""
    path = bundled_resource_path()
    if path is None:
        return {'version': BUNDLED_VERSION, 'available': False}
    with zipfile.ZipFile(path) as archive:
        data = json.loads(archive.read('MODBRIDGE_VANILLA_PROVENANCE.json'))
    return dict(data, available=True, fallback_version=BUNDLED_VERSION)


@lru_cache(maxsize=1024)
def _model(identifier):
    if ':' not in identifier:
        identifier = 'minecraft:' + identifier
    if not re.fullmatch(r'minecraft:[a-z0-9_./-]+', identifier):
        return None
    name = identifier.split(':', 1)[1]
    if any(part in ('', '..', '.') for part in name.split('/')):
        return None
    path = bundled_resource_path()
    if path is None:
        return None
    with zipfile.ZipFile(path) as archive:
        try:
            return json.loads(archive.read('assets/minecraft/models/' + name + '.json'))
        except KeyError:
            return None


def builtin_model(identifier):
    """Read an actual vanilla model; no guessed templates or generated textures.

    This helper is provided for callers resolving a single parent. The normal
    ResourcePack loader should index the entire fallback archive so referenced
    textures, parents and blockstates remain available and are copied intact.
    """
    return copy.deepcopy(_model(str(identifier)))
