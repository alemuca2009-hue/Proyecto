"""Java 1.21.1 paletted_permutations atlas sources, without executing Java.

Algorithm verified against gqw.class (PalettedPermutations) from official client
SHA1 30c73b1c5da787909b2f73340419fdf13b9def88 using Vineflower 1.10.1.
Virtual sprites are generated from actual template/key/output palette resources;
no source file is changed. Resource stacks are read directly to avoid recursion
when ResourcePack calls this module lazily after a missing lookup.
"""
from __future__ import annotations
import hashlib
import io
import json
import re
import zipfile
from pathlib import Path, PurePosixPath
import numpy as np
from PIL import Image

MAX_MEMBER=128*1024*1024
MAX_PIXELS=64*1024*1024


def _id(value):
    ns,name=str(value).split(':',1) if ':' in str(value) else ('minecraft',str(value))
    if not re.fullmatch('[a-z0-9_.-]+',ns) or not re.fullmatch('[a-z0-9_./-]+',name) or any(p in ('','..') for p in name.split('/')):
        raise ValueError('Identificador de textura inválido: '+str(value))
    return ns,name


def _texture_path(identifier):
    ns,name=_id(identifier)
    return f'assets/{ns}/textures/{name}.png'


def _read_source(source,path):
    pp=PurePosixPath(path)
    if pp.is_absolute() or '..' in pp.parts or '\\' in path:raise ValueError('Ruta de recurso insegura.')
    if isinstance(source,zipfile.ZipFile):
        if source.getinfo(path).file_size>MAX_MEMBER:raise ValueError('Recurso excesivamente grande.')
        return source.read(path)
    p=Path(source)/path
    if p.stat().st_size>MAX_MEMBER:raise ValueError('Recurso excesivamente grande.')
    return p.read_bytes()


def _rgba(raw):
    with Image.open(io.BytesIO(raw)) as opened:
        if opened.width*opened.height>MAX_PIXELS:raise ValueError('Textura excede 64 megapíxeles.')
        return np.asarray(opened.convert('RGBA'),dtype=np.uint8).copy()


def apply_palette(template, palette_key, palette_value):
    """RGBA-array implementation of the official integer palette mapping.

    Equal RGB entries with nonzero key alpha replace previous entries. Transparent
    template pixels retain their hidden RGB bytes. Colors without a key retain
    their original RGBA. Destination alpha multiplies the template alpha / 255.
    """
    source=np.asarray(template,dtype=np.uint8)
    keys=np.asarray(palette_key,dtype=np.uint8).reshape(-1,4)
    values=np.asarray(palette_value,dtype=np.uint8).reshape(-1,4)
    if len(keys)!=len(values):raise ValueError('La clave y la paleta tienen distinto número de píxeles.')
    if source.ndim!=3 or source.shape[2]!=4:raise ValueError('La plantilla debe ser RGBA.')
    mapping={tuple(int(x) for x in k[:3]):v.copy() for k,v in zip(keys,values) if k[3]!=0}
    result=source.copy();present=source[:,:,3]!=0
    for key,value in mapping.items():
        mask=present & np.all(source[:,:,:3]==key,axis=2)
        if not mask.any():continue
        result[mask,:3]=value[:3]
        result[mask,3]=(source[mask,3].astype(np.uint16)*int(value[3])//255).astype(np.uint8)
    return result


def build_paletted_resources(pack):
    """Return ``(virtual_png_bytes, provenance_by_virtual_path)``.

    pack must expose _index, _sources and optionally warnings/paths. Higher
    priority resources are earlier in _sources. All atlas versions contribute,
    processed low-to-high, matching the Java resource stack model. Provenance
    retains each actual atlas definition plus SHA256 and source index, including
    definitions shadowed by a higher-priority JSON at the same path.
    """
    virtual={};provenance={};cache={};failures=[]
    def read_actual(path):
        if path not in pack._index:raise FileNotFoundError(path)
        return _read_source(pack._sources[pack._index[path]],path)
    def texture(path):
        if path not in cache:
            raw=read_actual(path);cache[path]=(raw,_rgba(raw))
        return cache[path]
    for source_index in reversed(range(len(pack._sources))):
        source=pack._sources[source_index]
        names=source.namelist() if isinstance(source,zipfile.ZipFile) else [p.relative_to(source).as_posix() for p in Path(source).rglob('*.json') if p.is_file()]
        atlas_names=sorted(n for n in names if re.fullmatch(r'assets/[a-z0-9_.-]+/atlases/[^\\]+\.json',n))
        for atlas_path in atlas_names:
            try:
                atlas_raw=_read_source(source,atlas_path)
                atlas=json.loads(atlas_raw.decode('utf-8-sig'))
                definitions=atlas.get('sources',[])
                if not isinstance(definitions,list):raise ValueError('sources debe ser una lista.')
            except (ValueError,OSError,KeyError) as e:
                failures.append(f'Atlas {atlas_path}: {e}');continue
            for definition in definitions:
                if not isinstance(definition,dict) or definition.get('type') not in ('paletted_permutations','minecraft:paletted_permutations'):continue
                try:
                    key_path=_texture_path(definition['palette_key'])
                    key_raw,key=texture(key_path)
                    permutations=definition['permutations']
                    if not isinstance(permutations,dict):raise ValueError('permutations debe ser un objeto.')
                    templates=definition['textures']
                    if not isinstance(templates,list):raise ValueError('textures debe ser una lista.')
                except (ValueError,KeyError,OSError) as e:
                    failures.append(f'Paleta de {atlas_path}: {e}');continue
                for template_id in templates:
                    try:
                        ns,name=_id(template_id);template_path=_texture_path(template_id)
                        template_raw,template=texture(template_path)
                    except (ValueError,KeyError,OSError) as e:
                        failures.append(f'Plantilla de {atlas_path}: {e}');continue
                    for suffix,palette_id in permutations.items():
                        try:
                            # Java 1.21.1 uses the literal underscore separator.
                            virtual_path=_texture_path(ns+':'+name+'_'+str(suffix))
                            palette_path=_texture_path(palette_id)
                            palette_raw,palette=texture(palette_path)
                            generated=apply_palette(template,key,palette)
                            buffer=io.BytesIO();Image.fromarray(generated,'RGBA').save(buffer,format='PNG')
                            virtual[virtual_path]=buffer.getvalue()
                            deps=[template_path,key_path,palette_path,atlas_path]
                            provenance[virtual_path]={
                                'kind':'java_atlas_paletted_permutations','source_version':'1.21.1',
                                'dependencies':list(dict.fromkeys(deps)),
                                'template':template_path,'palette_key':key_path,'palette':palette_path,
                                'atlas_path':atlas_path,'atlas_source_index':source_index,
                                'atlas_source_name':Path(pack.paths[source_index]).name if hasattr(pack,'paths') else str(source_index),
                                'atlas_sha256':hashlib.sha256(atlas_raw).hexdigest(),
                                'atlas_definition':definition,
                                'source_sha256':{template_path:hashlib.sha256(template_raw).hexdigest(),
                                                  key_path:hashlib.sha256(key_raw).hexdigest(),
                                                  palette_path:hashlib.sha256(palette_raw).hexdigest()},
                                'generated_rgba_sha256':hashlib.sha256(generated.tobytes()).hexdigest(),
                                'dimensions':[int(generated.shape[1]),int(generated.shape[0])],
                                'alpha_rule':'source_alpha * palette_alpha // 255; alpha-zero source unchanged',
                                'original_files_modified':False}
                        except (ValueError,KeyError,OSError) as e:
                            failures.append(f'Permutación {template_id}_{suffix}: {e}')
    if hasattr(pack,'warnings'):
        for warning in dict.fromkeys(failures):
            if warning not in pack.warnings:pack.warnings.append(warning)
    return virtual,provenance
