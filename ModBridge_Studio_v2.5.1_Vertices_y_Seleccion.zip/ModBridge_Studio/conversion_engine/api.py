"""Only orchestration of conversion; rendering and UI stay outside this API."""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re

from . import ALGORITHM_VERSION, API_VERSION
from .control import cancellation, checkpoint, ConversionCancelled
from . import geometry, surface_adapter
from .pack import write_json
from .resources import ResourcePack
from .model_profile import finalize_model_profile
from .settings import SurfaceSettings, load_settings


def model_slug(model_id):
    readable = re.sub('[^a-z0-9_]+', '_', model_id.lower()).strip('_')[:72]
    return readable + '_' + hashlib.sha256(model_id.encode()).hexdigest()[:10]


def _code_hash():
    digest = hashlib.sha256()
    for path in sorted(Path(__file__).parent.glob('*.py')):
        digest.update(path.name.encode()); digest.update(path.read_bytes())
    return digest.hexdigest()


_CODE_SHA256 = _code_hash()


def engine_metadata(settings=None, mesh_mode='surface'):
    if mesh_mode not in ('surface', 'exact'):
        raise ValueError('mesh_mode debe ser surface o exact.')
    settings = load_settings() if settings is None else settings
    if not isinstance(settings, SurfaceSettings):
        raise TypeError('settings debe ser SurfaceSettings.')
    values = {'algorithm_version': ALGORITHM_VERSION, 'api_version': API_VERSION,
              'code_sha256': _CODE_SHA256, 'mesh_mode': mesh_mode,
              'settings': settings.to_dict()}
    values['signature'] = hashlib.sha256(json.dumps(values, sort_keys=True).encode()).hexdigest()
    return values


@dataclass
class ConversionResult:
    report: dict
    original_ir: dict
    target_ir: dict
    directory: Path


def _read_ir(path):
    if not path.exists():
        return {'faces': [], 'textures': {}}
    return json.loads(path.read_text(encoding='utf-8'))


def convert_in_pack(pack, model_id, destination, *, mesh_mode='surface', settings=None):
    """Convert one model using an already-open ResourcePack.

    Creates geometry, atlas, source backups, IR and the base report. A surface
    failure retains the real diagnostic mesh and marks it for review; exceptions
    from invalid input/settings remain explicit. No views or web files are built.
    """
    settings = load_settings() if settings is None else settings
    metadata = engine_metadata(settings, mesh_mode)
    checkpoint()
    destination = Path(destination).resolve()
    # Reusing an occupied directory could mix a previous successful surface
    # with a later unsupported model. Callers allocate one directory per model.
    if destination.exists() and any(destination.iterdir()):
        raise ValueError('La carpeta del modelo no está vacía; elige una salida nueva.')
    destination.mkdir(parents=True, exist_ok=True)
    report = geometry.convert_model(pack, model_id, destination)
    report.update(id=model_id, slug=model_slug(model_id))
    report.setdefault('warnings', []); report.setdefault('metrics', {})
    original = _read_ir(destination/'ir_original.json')
    target = _read_ir(destination/'ir_bedrock.json')
    checkpoint()
    if report.get('target_kind') == 'experimental_poly_mesh' and mesh_mode == 'surface':
        try:
            report, target = surface_adapter.adapt_surface(
                report, original, destination, model_slug(model_id), settings=settings)
        except ConversionCancelled:
            raise
        except Exception as error:
            report['warnings'].append('Adaptación superficial falló: ' + str(error))
    report['model_profile'] = finalize_model_profile(report, original, target, destination)
    report['conversion_engine'] = metadata
    write_json(destination/'report.json', report)
    return ConversionResult(report, original, target, destination)


def convert_file(source, model_id, destination, *, dependencies=None, mesh_mode='surface',
                 settings=None, cancel=None):
    """Convenience entry point for scripts and external applications."""
    settings = load_settings() if settings is None else settings
    with cancellation(cancel), ResourcePack(source, extra_paths=dependencies or []) as pack:
        return convert_in_pack(pack, model_id, destination, mesh_mode=mesh_mode, settings=settings)
