"""Explicit static assembly recipes. Source models remain unchanged."""
import json
import hashlib

ASSEMBLED_ID = 'modbridge:block/water_wheel/assembled'
ASSEMBLED_PATH = 'assets/modbridge/models/block/water_wheel/assembled.json'
PARTS = ['create:block/water_wheel/block', 'create:block/water_wheel/wheel']


def build_water_wheel_resources(pack):
    from .resources import asset_path
    paths = [asset_path(p) for p in PARTS]
    if not all(p in pack._index for p in paths): return {}, {}
    # Only expose the recipe for the known two-part layout, not arbitrary names.
    base, rotor = [pack.read_json(p) for p in paths]
    if not base.get('elements') or rotor.get('loader') not in ('forge:obj','neoforge:obj'):
        return {}, {}
    model = {'loader':'neoforge:composite', 'children':dict(zip(('base','rotor'), PARTS))}
    return {ASSEMBLED_PATH:json.dumps(model).encode()}, {ASSEMBLED_PATH:{
        'kind':'explicit_static_assembly', 'id':ASSEMBLED_ID,
        'dependencies':paths, 'parts':PARTS, 'original_files_modified':False,
        'source_sha256':{p:hashlib.sha256(pack.read_bytes(p)).hexdigest() for p in paths},
        'reason':'Receta explícita base + rotor en coordenadas Java originales. No interpreta automáticamente el renderer ni convierte la cinética.'}}
