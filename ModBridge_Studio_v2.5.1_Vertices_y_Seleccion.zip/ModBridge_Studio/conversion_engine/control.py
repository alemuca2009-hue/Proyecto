"""Cooperative checkpoints for CLI; the UI can also terminate its isolated worker."""
from contextvars import ContextVar
from contextlib import contextmanager

_cancel = ContextVar('modbridge_cancel', default=None)
_pause = ContextVar('modbridge_pause', default=None)
_activity = ContextVar('modbridge_activity', default=None)

class ConversionCancelled(RuntimeError):
    pass

def checkpoint():
    callback = _cancel.get()
    if callback is not None and callback():
        raise ConversionCancelled('Conversión detenida por el usuario.')
    pause = _pause.get()
    if pause is not None:
        pause()

@contextmanager
def cancellation(callback=None):
    token = _cancel.set(callback)
    try:
        yield
    finally:
        _cancel.reset(token)

@contextmanager
def pausing(callback=None):
    token = _pause.set(callback)
    try:
        yield
    finally:
        _pause.reset(token)

@contextmanager
def reporting(callback=None):
    token = _activity.set(callback)
    try:
        yield
    finally:
        _activity.reset(token)

def activity(message):
    checkpoint()
    callback = _activity.get()
    if callback is not None:callback(message)
