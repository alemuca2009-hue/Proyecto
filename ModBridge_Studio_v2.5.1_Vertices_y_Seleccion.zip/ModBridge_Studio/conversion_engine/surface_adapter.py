"""Explicit lossy fallback; cannot upgrade the exactness status of a mesh."""
import json, shutil
from pathlib import Path
from .geometry import decode_bedrock
from .pack import write_json


def adapt_surface(report, source_ir, modeldir, slug, *, settings=None):
    from .adaptive import convert_with_refinement
    md=Path(modeldir)
    from .settings import SurfaceSettings
    settings = SurfaceSettings() if settings is None else settings
    # Build/decode before moving the diagnostic files: successful geometry is
    # the original 2.4.4 output; an adaptation failure leaves the backup usable.
    result=convert_with_refinement(source_ir,md/'surface',settings)
    geometry=result['geometry']
    geometry['minecraft:geometry'][0]['description']['identifier']='geometry.modbridge.surface.'+slug
    target_atlas=Path(result['atlas_path'])
    target=decode_bedrock(geometry,target_atlas)
    # Keep the original mesh roundtrip separately for editing and audit.
    source_mesh=json.loads((md/'ir_bedrock.json').read_text())
    shutil.copy2(md/'atlas.png',md/'source_mesh_atlas.png')
    source_mesh['textures']={k:str(md/'source_mesh_atlas.png') for k in source_mesh['textures']}
    write_json(md/'ir_source_mesh.json',source_mesh)
    shutil.copy2(md/'model.geo.json',md/'experimental.poly_mesh.json')
    if (md/'atlas_map.json').exists():shutil.move(md/'atlas_map.json',md/'atlas_original_map.json')
    shutil.copy2(target_atlas,md/'atlas.png')
    target['textures']={key:str(md/'atlas.png') for key in target['textures']}
    # Outlines come from the union of the actual emitted rectangles, not from
    # the source polygon. Keep all rectangle faces for rendering and auditing.
    for face,edges in zip(target['faces'],result['wire_edges']):
        face['wire_edges']=edges
    write_json(md/'model.geo.json',geometry);write_json(md/'ir_bedrock.json',target)
    write_json(md/'surface_report.json',result.get('report',{}))
    write_json(md/'atlas_map.json',{'method':'surface_rasterization','lossless_rgba_copy':False,'details':result.get('report',{})})
    source_metrics=report.get('metrics',{})
    report['metrics']={'static_equivalence_passed':False,'rgba_texels_preserved':False,
        'surface_approximation':True,'source_mesh_diagnostic':source_metrics,'surface':result.get('report',{})}
    report.update(status='review',target_kind='surface_approximation',runtime_tested=False)
    report['warnings']=[w for w in report.get('warnings',[]) if not w.startswith('OBJ conserva')]
    report['warnings'].append('Las caras refinadas se convierten en franjas Bedrock contenidas dentro del contorno original, sin rectángulos salientes. Los bordes oblicuos y el atlas siguen siendo aproximados; no conserva conectividad poligonal ni todos los texels de destino 1:1. Los originales permanecen intactos.')
    fallback=result['report']['contour_refinement']['masked_fallback_polygon_count']
    if fallback:
        report['warnings'].append(f'{fallback} caras mantienen la máscara anterior para conservar al menos el {settings.minimum_coverage*100:g} % de su superficie y limitar las subdivisiones. Consulta contour_refinement para los contornos todavía pendientes.')
    report['preserved']=['Polígonos, UV y texturas originales en archivos fuente e IR de auditoría','Escala y ubicación de los planos sin voxelizar el volumen']
    report.setdefault('modified',[]).append('Polígonos sustituidos por planos rectangulares con máscara alpha; atlas de destino remuestreado.')
    report['paths']['surface_report']=str(md/'surface_report.json')
    adaptive=result['report'].get('adaptive_refinement')
    if adaptive:
        report['adaptive_refinement']=adaptive
        report['warnings'].append('Repaso automático: geometría coincidente comprobada.' if adaptive['geometry_coincident'] else
            'Repaso automático terminado: persisten diferencias geométricas. Se conserva el mejor resultado aceptado; no se fuerza la coincidencia.')
    return report,target
