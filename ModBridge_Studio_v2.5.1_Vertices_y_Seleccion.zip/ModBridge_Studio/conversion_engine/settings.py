"""Editable settings; 2.4.4 base with bounded 2.5.0 refinement by default.

settings.json overrides these defaults for both the application and the CLI.
Invalid or unknown settings fail explicitly instead of silently changing output.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass, fields
import json
import math
from pathlib import Path


@dataclass(frozen=True)
class SurfaceSettings:
    pixels_per_unit: float = 4
    max_atlas: int = 4096
    contour_tolerance: float = 1 / 32
    rectangle_budget: int = 3500
    max_slices: int = 128
    minimum_coverage: float = .99
    refinement_passes: int = 2
    refinement_rectangle_budget: int = 12000
    refinement_max_slices: int = 512

    def __post_init__(self):
        for name in ('pixels_per_unit', 'contour_tolerance', 'minimum_coverage'):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError(f'{name} debe ser un número finito.')
        if self.pixels_per_unit <= 0 or self.contour_tolerance <= 0:
            raise ValueError('pixels_per_unit y contour_tolerance deben ser positivos.')
        if not 0 < self.minimum_coverage <= 1:
            raise ValueError('minimum_coverage debe estar entre 0 (excluido) y 1.')
        for name in ('max_atlas', 'rectangle_budget', 'max_slices'):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f'{name} debe ser un entero positivo.')
        if not 16 <= self.max_atlas <= 8192 or self.max_atlas & (self.max_atlas - 1):
            raise ValueError('max_atlas debe ser potencia de dos entre 16 y 8192.')
        for name,low,high in (('refinement_passes',0,4),('refinement_rectangle_budget',1,50000),('refinement_max_slices',2,2048)):
            value=getattr(self,name)
            if isinstance(value,bool) or not isinstance(value,int) or not low<=value<=high:
                raise ValueError(f'{name} debe ser un entero entre {low} y {high}.')

    def to_dict(self):
        return asdict(self)


def load_settings(path=None):
    path = Path(path) if path is not None else Path(__file__).with_name('settings.json')
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        raise ValueError('La configuración debe ser un objeto JSON.')
    unknown = set(data) - {f.name for f in fields(SurfaceSettings)}
    if unknown:
        raise ValueError('Ajustes desconocidos: ' + ', '.join(sorted(unknown)))
    return SurfaceSettings(**data)
