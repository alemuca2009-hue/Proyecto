"""Independent proof of decoded surfaces (oriented boundaries and multiplicity).
Extracted from the existing verifier; never compares a source to itself.
"""
import math
import numpy as np
from .control import checkpoint
from .triangulation import _triangulate

def verify_surface(source,target,tolerance=1e-5):
    """Quick area rejection followed by oriented boundary proof when necessary."""
    sa,ta=_faces(source),_faces(target)
    source_area,target_area=_surface_area(source),_surface_area(target)
    error=abs(source_area-target_area)
    limit=tolerance*max(1.,math.sqrt(source_area),math.sqrt(target_area))
    if not sa or not ta or error>limit:
        return {'equal':False,'method':'decoded_area_mismatch','source_area':source_area,'target_area':target_area,'area_error':error}
    a=np.asarray([v for f in sa for v in f['vertices']],float)
    b=np.asarray([v for f in ta for v in f['vertices']],float)
    bounds_error=float(np.max(np.abs(np.array([a.min(axis=0),a.max(axis=0)])-np.array([b.min(axis=0),b.max(axis=0)]))))
    result=_oriented_surface_comparison(sa,ta,tolerance)
    result.update(equal=bool(result['equal'] and bounds_error<=tolerance),method='decoded_oriented_boundaries',
                  source_area=source_area,target_area=target_area,area_error=error,bounds_error=bounds_error)
    return result

def _faces(ir: dict) -> list[dict]:
    return ir.get("faces", [])

def _normal(face: dict) -> np.ndarray:
    value = face.get("normal")
    if value is not None:
        normal = np.asarray(value, dtype=float)
    else:
        verts = np.asarray(face.get("vertices", []), dtype=float)
        normal = np.cross(verts[1] - verts[0], verts[2] - verts[0]) if len(verts) >= 3 else np.zeros(3)
    length = np.linalg.norm(normal)
    return normal / length if length > 1e-15 else normal

def _surface_area(ir: dict) -> float:
    area = 0.0
    for f in _faces(ir):
        vertices = np.asarray(f.get("vertices", []), dtype=float)
        for indices in _triangulate(vertices):
            a, b, c = vertices[list(indices)]
            area += float(np.linalg.norm(np.cross(b - a, c - a))) / 2
    return area

def _oriented_surface_comparison(source_faces, target_faces, tolerance):
    """Compare bounded planar surface chains, independently of triangulation.

    For each oriented plane, cancel shared polygon edges as signed intervals
    on their supporting lines. Equal remaining boundaries imply equal planar
    coverage *with multiplicity*. Thus duplicate faces, holes, reversed normals
    and overhanging masked rectangles cannot disappear in a boolean union.
    """
    planes = []
    invalid = {"original": [], "translated": []}
    for side, faces, sign in (("original", source_faces, 1), ("translated", target_faces, -1)):
        for index, face in enumerate(faces):
            checkpoint()
            vertices = np.asarray(face.get("vertices", []), dtype=float)
            normal = _normal(face)
            if (vertices.ndim != 2 or vertices.shape[1:] != (3,) or len(vertices) < 3
                    or not np.isfinite(vertices).all() or not np.isfinite(normal).all()
                    or np.linalg.norm(normal) < .5):
                invalid[side].append(index)
                continue
            distance = float(vertices[0] @ normal)
            if np.max(np.abs(vertices @ normal - distance)) > tolerance:
                invalid[side].append(index)
                continue
            # Reject zero-area/invalid polygons; a boundary identity must not
            # silently approve faces the renderer could not triangulate.
            triangles = _triangulate(vertices)
            signed_area = sum(np.cross(a, b) for a, b in zip(vertices, np.roll(vertices, -1, axis=0)))
            triangle_area = sum(float(np.linalg.norm(np.cross(vertices[b]-vertices[a], vertices[c]-vertices[a])))
                                for a, b, c in triangles)
            if (not triangles or triangle_area <= 1e-12
                    or abs(abs(float(signed_area @ normal)) - triangle_area) > max(1e-10, triangle_area * 1e-9)):
                invalid[side].append(index)
                continue
            if float(signed_area @ normal) < 0:
                vertices = vertices[::-1]
            plane = next((g for g in planes if np.linalg.norm(g["normal"]-normal) <= tolerance
                          and np.max(np.abs(vertices @ g["normal"]-g["distance"])) <= tolerance), None)
            if plane is None:
                plane = {"normal":normal, "distance":distance,
                         "drop":int(np.argmax(np.abs(normal))), "lines":[]}
                planes.append(plane)
            xy = np.delete(vertices, plane["drop"], axis=1)
            for a, b in zip(xy, np.roll(xy, -1, axis=0)):
                delta = b-a
                length = float(np.linalg.norm(delta))
                if length <= tolerance:
                    continue
                direction = delta/length
                if direction[0] < -tolerance or (abs(direction[0]) <= tolerance and direction[1] < 0):
                    direction = -direction
                perpendicular = np.array([-direction[1], direction[0]])
                line = next((g for g in plane["lines"]
                             if np.linalg.norm(g["direction"]-direction) <= tolerance
                             and max(abs(float(a @ g["perpendicular"])-g["offset"]),
                                     abs(float(b @ g["perpendicular"])-g["offset"])) <= tolerance), None)
                if line is None:
                    line = {"direction":direction, "perpendicular":perpendicular,
                            "offset":float(a @ perpendicular), "events":[]}
                    plane["lines"].append(line)
                t0, t1 = float(a @ line["direction"]), float(b @ line["direction"])
                weight = sign if t1 > t0 else -sign
                line["events"].extend(((min(t0,t1),weight), (max(t0,t1),-weight)))
    unmatched = 0.0
    mismatched_intervals = 0
    for plane in planes:
        # Projection loses at most sqrt(3) in length; restore the actual 3D
        # length using the plane equation for each supporting direction.
        n = plane["normal"]
        kept = np.delete(n, plane["drop"])
        for line in plane["lines"]:
            events = sorted(line["events"])
            merged = []
            for coordinate, delta in events:
                if merged and coordinate-merged[-1][0] <= tolerance:
                    merged[-1][1] += delta
                else:
                    merged.append([coordinate,delta])
            balance = 0
            scale = math.sqrt(1+(float(kept @ line["direction"])/float(n[plane["drop"]]))**2)
            for i, (coordinate, delta) in enumerate(merged):
                balance += delta
                if i+1 < len(merged) and balance:
                    length = (merged[i+1][0]-coordinate)*scale
                    if length > tolerance:
                        unmatched += length*abs(balance)
                        mismatched_intervals += 1
    return {"equal":bool(source_faces and target_faces and not any(invalid.values()) and not mismatched_intervals),
            "oriented_plane_count":len(planes), "invalid_surface_faces":invalid,
            "unmatched_boundary_length_model_units":float(unmatched),
            "unmatched_boundary_interval_count":mismatched_intervals}
