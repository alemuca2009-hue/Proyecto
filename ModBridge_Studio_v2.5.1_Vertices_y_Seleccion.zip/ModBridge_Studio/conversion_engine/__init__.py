"""Standalone Java-to-Bedrock conversion engine. No GUI/server dependency."""
ALGORITHM_VERSION = '2.5.0'
API_VERSION = '1.1.0'

from .settings import SurfaceSettings, load_settings
from .api import ConversionResult, convert_in_pack, convert_file, engine_metadata, model_slug
from .resources import ResourcePack

__all__ = ['ALGORITHM_VERSION', 'API_VERSION', 'SurfaceSettings', 'load_settings',
           'ConversionResult', 'convert_in_pack', 'convert_file', 'engine_metadata',
           'model_slug', 'ResourcePack']
