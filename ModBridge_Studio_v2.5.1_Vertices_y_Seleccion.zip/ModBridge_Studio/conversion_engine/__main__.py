"""python -m conversion_engine --help"""
import argparse
import json
import sys
from . import ALGORITHM_VERSION, API_VERSION, ResourcePack, convert_file, load_settings


def main():
    parser = argparse.ArgumentParser(description='Motor modular ModBridge · base 2.4.4 + repaso 2.5.0')
    parser.add_argument('--version', action='version', version=f'Algoritmo {ALGORITHM_VERSION} / API {API_VERSION}')
    parser.add_argument('--input', required=True, help='JAR/ZIP/carpeta de recursos Java')
    parser.add_argument('--dependency', action='append', default=[], help='Dependencia adicional; repetible')
    parser.add_argument('--list', action='store_true', help='Mostrar los identificadores sin convertir')
    parser.add_argument('--model', help='Identificador, por ejemplo create:block/water_wheel/wheel')
    parser.add_argument('--output', help='Carpeta nueva para el modelo')
    parser.add_argument('--mode', choices=('surface', 'exact'), default='surface')
    parser.add_argument('--settings', help='Archivo JSON opcional; por defecto conversion_engine/settings.json')
    args = parser.parse_args()
    if not args.list and (not args.model or not args.output):
        parser.error('--model y --output son obligatorios salvo con --list')
    try:
        if args.list:
            with ResourcePack(args.input, extra_paths=args.dependency) as pack:
                print(json.dumps(pack.models(), ensure_ascii=False, indent=2))
            return 0
        result = convert_file(args.input, args.model, args.output, dependencies=args.dependency,
                              mesh_mode=args.mode, settings=load_settings(args.settings))
        print(json.dumps({'id': result.report['id'], 'directory': str(result.directory),
                          'status': result.report.get('status'),
                          'target_kind': result.report.get('target_kind'),
                          'conversion_engine': result.report['conversion_engine']},
                         ensure_ascii=False, indent=2))
        return 0 if result.target_ir.get('faces') else 2
    except Exception as error:
        print(type(error).__name__ + ': ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
