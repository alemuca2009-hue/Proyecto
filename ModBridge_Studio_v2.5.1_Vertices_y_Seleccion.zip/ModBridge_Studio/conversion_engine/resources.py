"""Read Minecraft resources without executing mod classes or extracting archives."""
from __future__ import annotations
import json
import re
import zipfile
from pathlib import Path, PurePosixPath
from collections import Counter, OrderedDict
from .vanilla import bundled_resource_path

MAX_MEMBER = 128 * 1024 * 1024
MAX_TOTAL = 2 * 1024 * 1024 * 1024


def normalize_id(value: str) -> str:
    value = str(value)
    ns, name = value.split(':', 1) if ':' in value else ('minecraft', value)
    if not re.fullmatch(r'[a-z0-9_.-]+', ns) or not re.fullmatch(r'[a-z0-9_./-]+', name) or any(x in ('..', '') for x in name.split('/')):
        raise ValueError(f'Identificador de recurso inválido: {value}')
    return f'{ns}:{name}'


def asset_path(identifier: str, folder: str = 'models', suffix: str = '.json') -> str:
    ns, name = normalize_id(identifier).split(':', 1)
    return f'assets/{ns}/{folder}/{name}{suffix}'


class ResourcePack:
    def __init__(self, path, extra_paths=None, include_vanilla=True):
        self.path = Path(path)
        self.paths = [self.path] + [Path(p) for p in (extra_paths or [])]
        fallback=bundled_resource_path() if include_vanilla else None
        self.bundled_vanilla_version='1.21.1' if fallback else None
        if fallback and fallback not in self.paths:self.paths.append(fallback)
        self.warnings = []
        self._sources = []
        self._index = {}
        self._primary_names = []
        self._json_cache = OrderedDict()
        self._json_cache_cost = {}
        self._json_cache_bytes = 0
        self.json_cache_limit = 8 * 1024 * 1024
        self.json_cache_entries = 128
        self._blockstate_index = None
        self._virtual = {}
        self._virtual_provenance = {}
        self._virtual_attempted = False
        self._assemblies_registered = False
        for i, source in enumerate(self.paths):
            if source.is_dir():
                entries = [p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()]
                opened = source
            else:
                opened = zipfile.ZipFile(source)
                infos = opened.infolist()
                if sum(x.file_size for x in infos) > MAX_TOTAL:
                    opened.close()
                    raise ValueError('Archivo descomprimido excesivo (>2 GiB).')
                if len(infos) > 200000:
                    opened.close()
                    raise ValueError('Demasiadas entradas ZIP.')
                entries = [x.filename for x in infos if not x.is_dir()]
            self._sources.append(opened)
            accepted = []
            for name in entries:
                p = PurePosixPath(name)
                if p.is_absolute() or '..' in p.parts or '\\' in name:
                    self.warnings.append(f'Ruta insegura ignorada: {name}')
                    continue
                accepted.append(name)
                if name not in self._index:
                    self._index[name] = i
            if i == 0:
                self._primary_names = accepted

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def close(self):
        self._json_cache.clear()
        self._json_cache_cost.clear()
        self._json_cache_bytes = 0
        self._virtual.clear()
        self._classification_catalogue = None
        for source in self._sources:
            if isinstance(source, zipfile.ZipFile):
                source.close()

    def _ensure_virtual(self):
        if self._virtual_attempted:return
        self._virtual_attempted=True
        try:
            from .palettes import build_paletted_resources
            generated, provenance = build_paletted_resources(self)
            self._virtual.update(generated)
            self._virtual_provenance.update(provenance)
        except Exception as error:
            self.warnings.append('No se pudieron generar paletas: '+str(error))
        self._ensure_assemblies()

    def _ensure_assemblies(self):
        if self._assemblies_registered:return
        self._assemblies_registered=True
        from .water_wheel import build_water_wheel_resources
        try:generated, provenance = build_water_wheel_resources(self)
        except (ValueError,KeyError,TypeError,OSError) as error:
            self.warnings.append('Ensamblaje Water Wheel no disponible: '+str(error))
            return
        self._virtual.update(generated)
        self._virtual_provenance.update(provenance)

    def exists(self, path):
        if str(path) in self._index:return True
        if str(path) in self._virtual:return True
        self._ensure_virtual()
        return str(path) in self._virtual

    def read_bytes(self, path):
        path = str(path)
        if path not in self._index:
            if path in self._virtual:return self._virtual[path]
            self._ensure_virtual()
            if path in self._virtual:return self._virtual[path]
            raise FileNotFoundError(path)
        source = self._sources[self._index[path]]
        if isinstance(source, zipfile.ZipFile):
            info = source.getinfo(path)
            if info.file_size > MAX_MEMBER:
                raise ValueError(f'Recurso demasiado grande: {path}')
            return source.read(path)
        file = source / path
        if file.stat().st_size > MAX_MEMBER:
            raise ValueError(f'Recurso demasiado grande: {path}')
        return file.read_bytes()

    def read_json(self, path):
        from .control import checkpoint
        checkpoint()
        if path in self._json_cache:
            self._json_cache.move_to_end(path)
            return self._json_cache[path]
        raw = self.read_bytes(path).decode('utf-8-sig')
        data = json.loads(raw)
        cost = len(raw.encode('utf-8')) * 6
        if cost <= self.json_cache_limit:
            while self._json_cache and (len(self._json_cache) >= self.json_cache_entries or self._json_cache_bytes + cost > self.json_cache_limit):
                key, _ = self._json_cache.popitem(last=False)
                self._json_cache_bytes -= self._json_cache_cost.pop(key)
            self._json_cache[path] = data
            self._json_cache_cost[path] = cost
            self._json_cache_bytes += cost
        return data

    def models(self):
        self._ensure_assemblies()
        result = []
        for name in self._primary_names + list(self._virtual):
            p = name.split('/')
            if len(p) > 3 and p[0] == 'assets' and p[2] == 'models' and name.endswith('.json'):
                result.append(p[1] + ':' + '/'.join(p[3:])[:-5])
        return sorted(set(result))

    def blockstates_for(self, model_id):
        """Source blockstates referencing this resource; retained, not reinterpreted."""
        if self._blockstate_index is None:
            self._blockstate_index = {}
            def visit(value, path):
                if isinstance(value, dict):
                    if isinstance(value.get('model'), str):
                        try:
                            identifier = normalize_id(value['model'])
                            self._blockstate_index.setdefault(identifier, set()).add(path)
                        except ValueError:
                            pass
                    for child in value.values():
                        visit(child, path)
                elif isinstance(value, list):
                    for child in value:
                        visit(child, path)
            for path in self._primary_names:
                if '/blockstates/' in path and path.endswith('.json'):
                    try:
                        visit(self.read_json(path), path)
                    except (ValueError, OSError):
                        pass
        return sorted(self._blockstate_index.get(normalize_id(model_id), set()))

    def inventory(self):
        names = self._primary_names
        loaders = Counter()
        parents = Counter()
        errors = []
        models = self.models()
        for model in models:
            try:
                data = self.read_json(asset_path(model))
                if data.get('loader'):
                    loaders[data['loader']] += 1
                if data.get('parent'):
                    parents[data['parent']] += 1
            except (ValueError, OSError) as error:
                errors.append({'model': model, 'error': str(error)})
        return {'generated_palette_textures':sum(p.endswith('.png') for p in self._virtual),'generated_assembly_models':sum(p.endswith('.json') for p in self._virtual),'bundled_vanilla_version':self.bundled_vanilla_version,'dependency_precedence':'primary, user dependencies, bundled vanilla', 'archive': self.path.name, 'files': len(names), 'models': len(models),
                'textures': sum(n.endswith('.png') and '/textures/' in n for n in names),
                'obj': sum(n.endswith('.obj') for n in names),
                'mtl': sum(n.endswith('.mtl') for n in names),
                'blockstates': sum('/blockstates/' in n and n.endswith('.json') for n in names),
                'classes': sum(n.endswith('.class') for n in names),
                'loaders': dict(loaders), 'parents': dict(parents), 'errors': errors,
                'warnings': list(self.warnings)}
