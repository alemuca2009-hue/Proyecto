"""Atomic JSON writes for model and report files."""
from __future__ import annotations
import json, tempfile, time
from pathlib import Path

def write_json(path, data):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    payload=json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)
    # Readers/antivirus can briefly prevent replacing a file on Windows.
    # Unique sibling files also let concurrent preview requests migrate safely.
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=path.parent,
                                         prefix=path.name+'.',suffix='.tmp',delete=False) as stream:
            temporary=Path(stream.name);stream.write(payload)
        for attempt in range(7):
            try:
                temporary.replace(path)
                break
            except PermissionError:
                if attempt==6:raise
                time.sleep(min(.01*2**attempt,.16))
    finally:
        if temporary is not None:
            try:temporary.unlink(missing_ok=True)
            except OSError:pass

