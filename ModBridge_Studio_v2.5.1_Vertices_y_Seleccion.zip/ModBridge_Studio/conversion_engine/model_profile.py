"""Geometry-only size diagnostics and visibility bounds; no game definitions."""
from __future__ import annotations
import json
import math
from pathlib import Path
from .pack import write_json


def size_profile(bounds):
    try:
        if len(bounds) != 2 or any(len(v) != 3 for v in bounds): raise ValueError()
        lo, hi = [[float(v) for v in row] for row in bounds]
        if not all(math.isfinite(v) for row in (lo,hi) for v in row): raise ValueError()
        ext = [b-a for a,b in zip(lo,hi)]
        if min(ext) < 0: raise ValueError()
    except (TypeError, ValueError, OverflowError):
        return {'valid':False, 'block_compatible':False}
    overlap = [min(b,v)-max(a,u) for a,b,u,v in zip(lo,hi,[-8,0,-8],[8,16,8])]
    reasons = []
    if any(v > 30+1e-7 for v in ext): reasons.append('extent_over_30')
    if any(a < -30-1e-7 or b > 30+1e-7 for a,b in zip(lo,hi)): reasons.append('outside_origin_bounds')
    if any(v < 1-1e-7 for v in overlap): reasons.append('insufficient_base_overlap')
    return {'valid':True, 'dimensions_pixels':ext, 'dimensions_blocks':[v/16 for v in ext],
            'bounds_pixels':[lo,hi], 'block_compatible':not reasons,
            'block_limit_pixels':30, 'reasons':reasons}


def describe_model(report, original, target):
    source = size_profile(original.get('bounds'))
    converted = size_profile(target.get('bounds'))
    missing = any(v.get('missing') for v in original.get('texture_metadata',{}).values())
    available = (report.get('status') in ('review','verified_static')
                 and report.get('target_kind') != 'experimental_poly_mesh'
                 and bool(target.get('faces')) and converted['valid'] and not missing)
    usage = ('block_or_entity_geometry' if converted['block_compatible'] else 'entity_geometry') if available else 'diagnostic_only'
    notes = ['16 unidades de modelo = 1 bloque. Coordenadas sin normalizar a una celda.',
             'Se exportan geometría, texturas y datos de auditoría; el perfil no crea entidades ni bloques.']
    if available and not converted['block_compatible']:
        notes.append('El tamaño requiere usar el archivo como geometría de entidad en Bedrock. El modelo mantiene su escala original.')
    if report.get('target_kind') == 'surface_approximation':
        notes.append('Las caras refinadas usan franjas interiores al contorno. Los bordes oblicuos y el atlas siguen siendo aproximados. Las caras que exceden el presupuesto conservan su máscara anterior; consulta contour_refinement en el reporte de superficies.')
    if report['id'] == 'create:block/water_wheel/block':
        notes.append('Este recurso es solo la base. El modelo modbridge:block/water_wheel/assembled reúne base y rotor de forma estática.')
    if report['id'] == 'create:block/water_wheel/wheel':
        notes.append('Este recurso contiene solo el rotor; la receta assembled añade la base sin modificar los recursos fuente.')
    return {'scope':'models_only', 'source':source, 'target':converted,
            'geometry_usage':usage, 'exportable_geometry':available,
            'global_scale':1.0, 'units_per_block':16,
            'creates_game_content':False, 'notes':notes}


def refresh_visible_bounds(geometry, bounds):
    """Change culling metadata only, never cubes, bones, pivots, UVs or scale.

    bounds are in ModBridge's Java-centred IR; Bedrock has reversed X.
    This describes the exported static pose, not an animation envelope.
    """
    profile = size_profile(bounds)
    if not profile['valid'] or not geometry.get('minecraft:geometry'): return None
    lo,hi = profile['bounds_pixels'];ext = profile['dimensions_pixels']
    centre = [(a+b)/2 for a,b in zip(lo,hi)]
    values = {'visible_bounds_width':max(ext[0],ext[2])/16+1,
              'visible_bounds_height':ext[1]/16+1,
              'visible_bounds_offset':[-centre[0]/16,centre[1]/16,centre[2]/16]}
    geometry['minecraft:geometry'][0]['description'].update(values)
    return values


def finalize_model_profile(report, original, target, modeldir):
    profile = describe_model(report, original, target)
    path = Path(modeldir)/'model.geo.json'
    if profile['exportable_geometry'] and path.is_file():
        geometry = json.loads(path.read_text(encoding='utf-8'))
        profile['visible_bounds'] = refresh_visible_bounds(geometry, target.get('bounds'))
        write_json(path, geometry)
    return profile
