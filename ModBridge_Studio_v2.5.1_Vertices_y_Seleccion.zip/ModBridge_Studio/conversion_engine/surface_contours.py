"""Interior-only rectangular strips for planar polygons, including concave ones.

Bedrock cubes cannot encode a trapezoid. Inscribed strips remove the old
bounding-box protrusions while declaring the remaining boundary approximation.
No source vertices or audit results are replaced with the target's values.
"""
from __future__ import annotations
import math
import numpy as np
from .control import checkpoint


def _crossings(polygon, y, probe):
    """Edges active inside an event-free band, evaluated at either endpoint."""
    values=[]
    for a,b in zip(polygon,np.roll(polygon,-1,axis=0)):
        if min(a[1],b[1]) < probe < max(a[1],b[1]):
            values.append(float(a[0]+(y-a[1])*(b[0]-a[0])/(b[1]-a[1])))
    return sorted(values)


def _subtract(interval, others, eps=1e-9):
    pieces=[interval]
    for lo,hi in others:
        next_pieces=[]
        for a,b in pieces:
            if hi<=a+eps or lo>=b-eps:next_pieces.append((a,b));continue
            if lo>a+eps:next_pieces.append((a,min(lo,b)))
            if hi<b-eps:next_pieces.append((max(hi,a),b))
        pieces=next_pieces
    return pieces


def rectangle_outlines(rectangles):
    """True boundaries of the emitted strip union, with interior seams removed."""
    result=[]
    # Each polygon has at most a few hundred strips; index coincident edges.
    edges={}
    def key(axis,value):return axis,round(float(value),9)
    for i,(x0,y0,x1,y1) in enumerate(rectangles):
        for axis,fixed,lo,hi,side in ((0,y0,x0,x1,-1),(0,y1,x0,x1,1),
                                      (1,x0,y0,y1,-1),(1,x1,y0,y1,1)):
            edges.setdefault(key(axis,fixed),[]).append((i,lo,hi,side))
    for i,(x0,y0,x1,y1) in enumerate(rectangles):
        segments=[]
        for axis,fixed,lo,hi,side in ((0,y0,x0,x1,-1),(0,y1,x0,x1,1),
                                      (1,x0,y0,y1,-1),(1,x1,y0,y1,1)):
            others=[(a,b) for j,a,b,s in edges[key(axis,fixed)] if j!=i and s!=side]
            for a,b in _subtract((lo,hi),others):
                segments.append([[a,fixed],[b,fixed]] if axis==0 else [[fixed,a],[fixed,b]])
        result.append(segments)
    return result


def contour_rectangles(polygon, tolerance=1/32, max_slices=128):
    """Return inscribed rectangles and measured area loss, never outside masks.

    Split at every vertex height, then intersect the horizontal sections at
    both ends of each strip. Within a band all edges are linear, so every
    rectangle is inside the polygon. Concavities keep separate intervals.
    The tolerance is a subdivision target, not a claim of exact geometry.
    """
    polygon=np.asarray(polygon,dtype=float)
    area=abs(float(np.sum(polygon[:,0]*np.roll(polygon[:,1],-1)
                          -polygon[:,1]*np.roll(polygon[:,0],-1))))/2
    heights=sorted(set(float(y) for y in polygon[:,1]))
    bands=[];total=0
    for y0,y1 in zip(heights,heights[1:]):
        if y1-y0<1e-10:continue
        probe=(y0+y1)/2
        a=_crossings(polygon,y0,probe);b=_crossings(polygon,y1,probe)
        if len(a)!=len(b) or len(a)%2:raise ValueError('Contorno no simple o intersecciones incoherentes.')
        movement=max((abs(x-y) for x,y in zip(a,b)),default=0)
        count=max(1,math.ceil(movement/tolerance))
        bands.append((y0,y1,a,b,count));total+=count
    budget_scale=min(1,max_slices/max(1,total))
    rectangles=[];max_inset=0.0
    for y0,y1,a,b,count in bands:
        count=max(2 if count>1 else 1,int(math.ceil(count*budget_scale)))
        for i in range(count):
            t0=i/count;t1=(i+1)/count
            lower=[x+(y-x)*t0 for x,y in zip(a,b)]
            upper=[x+(y-x)*t1 for x,y in zip(a,b)]
            for j in range(0,len(a),2):
                lo=max(lower[j],upper[j]);hi=min(lower[j+1],upper[j+1])
                max_inset=max(max_inset,abs(lower[j]-upper[j]),abs(lower[j+1]-upper[j+1]))
                if hi-lo>1e-10:
                    rectangles.append((lo,y0+(y1-y0)*t0,hi,y0+(y1-y0)*t1))
    if not rectangles:raise ValueError('No se pudo representar una cara sin sobresalir de su contorno.')
    target_area=sum((x1-x0)*(y1-y0) for x0,y0,x1,y1 in rectangles)
    return rectangles,{'source_area':area,'target_area':target_area,
                       'omitted_area':max(0.0,area-target_area),
                       'max_strip_boundary_inset':max_inset}


def refine_patches(patches, tolerance=1/32, budget=3500, *, max_slices=128, minimum_coverage=.99):
    # Plan at useful precision first. A global budget must never turn a large
    # mesh into a coarse staircase that discards 20-30% of its surface.
    plans=[]
    for i,patch in enumerate(patches):
        checkpoint()
        polygon=patch['local']
        area=abs(float(np.sum(polygon[:,0]*np.roll(polygon[:,1],-1)
                              -polygon[:,1]*np.roll(polygon[:,0],-1))))/2
        box_area=patch['width']*patch['height']
        if len(patches)>=budget:
            # A mesh already above the subdivision budget must not allocate
            # hundreds of candidate strips per face just to discard them.
            rectangles=[(0.0,0.0,patch['width'],patch['height'])]
            is_rectangle=abs(box_area-area)<=max(1e-10,area*1e-10)
            stats={'source_area':area,'target_area':area if is_rectangle else 0.0,
                   'omitted_area':0.0,'max_strip_boundary_inset':0.0}
        else:
            rectangles,stats=contour_rectangles(polygon,tolerance,max_slices)
        quality=stats['target_area']/stats['source_area'] if stats['source_area'] else 0
        extra=len(rectangles)-1
        excess=max(0.0,patch['width']*patch['height']-stats['source_area'])
        plans.append((rectangles,stats,quality,extra,excess))
    available=max(0,budget-len(patches));selected=set()
    priority=sorted(range(len(plans)),key=lambda i:plans[i][4]/max(1,plans[i][3]),reverse=True)
    for i in priority:
        rectangles,stats,quality,extra,excess=plans[i]
        if quality>=minimum_coverage and extra<=available:
            selected.add(i);available-=extra
    output=[];outlines=[];source_area=target_area=omitted=outside=max_inset=0.0
    refined=0;fallback=[]
    for i,patch in enumerate(patches):
        checkpoint()
        rectangles,stats,quality,extra,excess=plans[i]
        source_area+=stats['source_area']
        if i in selected:
            refined+=int(len(rectangles)>1)
            omitted+=stats['omitted_area']
            max_inset=max(max_inset,stats['max_strip_boundary_inset'])
        else:
            # Preserve the previous masked surface at its original quality
            # when refinement cannot meet both coverage and model budgets.
            rectangles=[(0.0,0.0,patch['width'],patch['height'])]
            outside+=excess;fallback.append(patch['source_index'])
        target_area+=sum((x1-x0)*(y1-y0) for x0,y0,x1,y1 in rectangles)
        boundaries=rectangle_outlines(rectangles)
        u=patch['basis_u'];v=patch['basis_v'];anchor=patch['anchor']
        for rect,segments in zip(rectangles,boundaries):
            x0,y0,x1,y1=rect
            child={**patch,'anchor':anchor+u*x0+v*y0,'width':x1-x0,'height':y1-y0,
                   'local':patch['local']-[x0,y0]}
            output.append(child)
            outlines.append([[(anchor+u*p[0]+v*p[1]).tolist() for p in segment] for segment in segments])
    return output,outlines,{'method':'interior_contour_strips','outside_source_area':outside,
                           'source_planar_area':source_area,'target_planar_area':target_area,
                           'omitted_planar_area':omitted,
                           'area_coverage_ratio':1-omitted/source_area if source_area else 0.0,
                           'max_strip_boundary_inset_model_units':max_inset,
                           'requested_boundary_step_model_units':tolerance,
                           'refined_polygon_count':refined,'input_planar_patches':len(patches),
                           'output_rectangles':len(output),'rectangle_budget':budget,
                           'per_polygon_slice_budget':max_slices,'minimum_refined_area_coverage':minimum_coverage,
                           'masked_fallback_polygon_count':len(fallback),
                           'masked_fallback_source_faces':sorted(set(fallback)),
                           'exact_polygon_geometry':False}
