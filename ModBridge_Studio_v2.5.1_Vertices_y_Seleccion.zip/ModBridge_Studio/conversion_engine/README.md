# Motor de conversión independiente · algoritmo 2.5.0

Esta carpeta contiene el motor que utiliza ModBridge Studio 2.5.0. La primera conversión usa la base recuperada del ZIP original **2.4.4**. La 2.5.0 añade repasos acotados que solo sustituyen el resultado si mejora la cobertura sin aumentar omisiones o superficie saliente ni reducir la densidad nominal del atlas. `refinement_passes: 0` desactiva esta capa y conserva el comportamiento base, probado contra la referencia 2.4.4.

La aplicación conserva biblioteca, controles, visor, comparación y exportación de renders. El motor no importa `app.py`, `bridge`, servidor, visor ni renderer. Se puede copiar **esta carpeta completa**, incluido `data/` y `settings.json`, a otro proyecto y usarlo allí.

## Por dónde empezar a modificar

| Archivo | Responsabilidad |
|---|---|
| `adaptive.py` | Coordina los repasos, la evaluación y la selección conservadora; primer archivo para modificar esta política. |
| `rectangle_recovery.py` | Recupera solo uniones rectangulares con UV afín continuo, orientación y multiplicidad comprobadas. |
| `surface_proof.py` | Comprueba superficie, bordes, multiplicidad y límites sobre la geometría Bedrock decodificada. |
| `settings.json` | Parámetros habituales; compartidos por aplicación, renders y terminal. |
| `surface_contours.py` | Subdivisión en franjas, cobertura, presupuesto y retorno a máscara. Es el primer lugar para estudiar la pérdida de superficie. |
| `mesh_surface.py` | Plano de cada cara, transformación a rectángulos, muestreo de UV, atlas y geometría Bedrock. |
| `geometry.py` | Lectura de modelos Java/OBJ, cubos, coordenadas, materiales, atlas original, IR y decodificación Bedrock. |
| `triangulation.py` | Triangulación usada por el motor y por el renderer de la aplicación. |
| `surface_adapter.py` | Sustitución del diagnóstico por la superficie y conservación de los originales. |
| `api.py` | Punto único para convertir: carga, elección del modo, adaptación y resultado. |
| `model_profile.py` | Escala, perfil de uso y límites de visibilidad del archivo exportado. No cambia el tamaño de los cubos. |
| `resources.py`, `vanilla.py`, `data/` | Resolución de padres, dependencias y recursos incluidos. |
| `sprites.py`, `palettes.py`, `water_wheel.py` | Ítems generados, paletas y ensamblaje estático explícito de la rueda. |
| `editable.py`, `pack.py`, `control.py` | Copias editables, escritura JSON, cancelación, pausa cooperativa y avisos de progreso. |

Los archivos homónimos de `bridge/` son enlaces de compatibilidad mediante alias de módulos. **Edita los archivos de `conversion_engine/`**; no hay una segunda copia activa del algoritmo. `bridge/pipeline.py` coordina comparaciones y exportación de la aplicación, pero llama a esta API para convertir. `render_worker.py` llama a la misma API al preparar modelos para renders.

## Parámetros editables

Los seis parámetros base conservan sus valores originales. Los tres parámetros `refinement_*` controlan los repasos posteriores:

| Ajuste | Predeterminado | Efecto |
|---|---:|---|
| `pixels_per_unit` | 4 | Densidad inicial del atlas superficial; el motor puede reducirla para que quepa. |
| `max_atlas` | 4096 | Lado máximo del atlas. Potencia de dos entre 16 y 8192. |
| `contour_tolerance` | 0.03125 | Paso objetivo para aproximar contornos oblicuos. |
| `rectangle_budget` | 3500 | Presupuesto de subdivisiones; conserva al menos un parche por cara, aunque las caras de entrada ya superen este valor. |
| `max_slices` | 128 | Máximo de franjas por polígono. |
| `minimum_coverage` | 0.99 | Cobertura mínima de la subdivisión de un polígono; si no se alcanza, conserva la máscara envolvente base. |
| `refinement_passes` | 2 | Número máximo de repasos (0–4); 0 los desactiva. |
| `refinement_rectangle_budget` | 12000 | Tope del presupuesto creciente de subdivisión de los repasos (1–50000). No reduce un presupuesto base mayor. |
| `refinement_max_slices` | 512 | Tope del número creciente de franjas por polígono en los repasos (2–2048). No reduce un límite base mayor. |

Edita el JSON, guarda y vuelve a convertir desde el JAR. Los cambios se cargan al iniciar cada lote. Si editas código Python, cierra y vuelve a abrir el programa. Una configuración inválida se comunica como error. Los resultados anteriores no se modifican automáticamente.

Cada reporte incluye `conversion_engine`: versión del algoritmo, versión de API, configuración, huella del código y firma conjunta. El generador de renders vuelve a preparar los modelos si su firma no coincide con el motor/modo/configuración actual, evitando reutilizar conversiones antiguas.

`SurfaceSettings(...)` permite pasar una configuración explícita desde Python sin editar el JSON. Modificar estos valores cambia los resultados. Para reproducir la base usa `SurfaceSettings(refinement_passes=0)`; para el comportamiento 2.5.0 usa `load_settings()` o los valores predeterminados.

## Uso desde Python

Desde una carpeta que contenga `conversion_engine/`:

```python
from conversion_engine import convert_file

result = convert_file(
    "create.jar",
    "create:block/water_wheel/wheel",
    "salida/rueda",  # Nueva o vacía; no sobrescribe una conversión anterior.
    mesh_mode="surface",
    dependencies=[],
)
print(result.report["status"])
print(result.report["conversion_engine"])
print(result.directory)
```

`result.original_ir` y `result.target_ir` contienen caras, vértices, UV y rutas de texturas. `result.report` contiene el reporte base de conversión. No contiene las seis vistas ni las comprobaciones visuales que añade la aplicación después.

Para varios modelos, reutiliza un solo lector de recursos:

```python
from conversion_engine import ResourcePack, convert_in_pack, load_settings, model_slug

settings = load_settings()
with ResourcePack("create.jar", extra_paths=[]) as pack:
    for model_id in pack.models():
        result = convert_in_pack(
            pack, model_id, "salida/" + model_slug(model_id), settings=settings
        )
```

Los nombres normalizados incluyen una huella para evitar colisiones. La cancelación cooperativa puede pasarse como `cancel=lambda: detener` a `convert_file`. La aplicación conserva su proceso separado y su botón Detener. `control.pausing(callback)` permite instalar una pausa cooperativa: el callback debe bloquear mientras se pide pausa y volver al continuar. `control.reporting(callback)` recibe mensajes de los repasos. Son contextos opcionales; el motor no depende del servidor para funcionar.

## Uso desde terminal

```bash
python -m pip install -r conversion_engine/requirements.txt
python -m conversion_engine --version
python -m conversion_engine --input create.jar --list
python -m conversion_engine --input create.jar --model create:block/water_wheel/wheel --output salida/rueda
python -m conversion_engine --input create.jar --model create:block/water_wheel/wheel --output salida/rueda_exact --mode exact
```

Opciones adicionales: `--dependency archivo.jar` (repetible) y `--settings ajustes.json`. Código de salida 0: se produjo geometría, incluida la de diagnóstico; 2: no hay caras destino; 1: error de ejecución. Consulta siempre `status` y `target_kind`; un código 0 no certifica compatibilidad con Minecraft.

## Criterio de aceptación y límites

La 2.4.4 convierte las caras por separado. Una cara oblicua puede pasar a franjas interiores o a un rectángulo envolvente con máscara alpha. La máscara afecta la textura, no recorta físicamente ese rectángulo. Por ello, vistas sólidas, alambre y textura pueden mostrar diferencias. El atlas se remuestrea; no se garantiza conservar cada texel.

Los vértices y UV originales se conservan en los recursos fuente y en `ir_original.json`. En cada repaso se reduce la tolerancia de contorno y crecen los presupuestos dentro de sus límites. `improves()` exige una suma de errores estrictamente menor, sin empeorar por separado área omitida, área saliente o densidad nominal de muestreo. Los intentos se preparan por separado y el atlas aceptado se sustituye de forma atómica.

La coincidencia no se deduce de la puntuación del planificador: `verify_surface()` examina la geometría decodificada. La aplicación realiza además su propia comparación independiente. El reporte `adaptive_refinement` conserva intentos, decisiones y prueba; `geometry_coincident` no certifica texturas ni funcionamiento en el juego. Si los intentos no consiguen igualdad, se conserva la mejor aproximación. Las superficies adaptadas siguen en revisión. El modo `exact` conserva las mallas no representables como diagnóstico `experimental_poly_mesh`, no como conversión Bedrock certificada.

## Pruebas para seguir editando

Desde `ModBridge_Studio/`:

```bash
python -m unittest discover -s tests -p test_conversion_engine.py -v
python -m unittest discover -s tests -p test_surface_contours.py -v
python -m unittest discover -s tests -v
```

La fixture `tests/fixtures/legacy244_fan_golden.json` proviene de una ejecución independiente del ZIP 2.4.4 sin modificar. Con `refinement_passes=0` verifica geometría, UV, IR, atlas y originales; no fue generada a partir del motor nuevo. Si después cambias intencionalmente el algoritmo, revisa esa diferencia y añade pruebas del comportamiento nuevo, sin reemplazar automáticamente la referencia.

La comparación completa con el programa antiguo puede repetirse con `tests/compare_engine_v244.py`. Las pruebas nuevas están en `tests/test_adaptive_v250.py`. Consulta `docs/VALIDACION_V250.md`; `docs/VALIDACION_V249.md` conserva la validación histórica de la extracción.
