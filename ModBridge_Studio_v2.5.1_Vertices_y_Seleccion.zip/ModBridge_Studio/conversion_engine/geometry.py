"""Static Java model conversion, lossless texture packing and independent Bedrock decode.

Canonical IR coordinates: Java X-8, Y, Z-8, pixel units. Face UV is pixel based.
Bedrock serialization follows Blockbench conventions (X mirror, X/Y angle sign,
up/down UV reversal). This module does NOT execute custom Java renderers.
"""
from __future__ import annotations
import copy
import hashlib
import io
import json
import math
import re
from pathlib import Path, PurePosixPath
import numpy as np
from PIL import Image
from .resources import ResourcePack, asset_path, normalize_id
from .sprites import generated_elements, GENERATED_PARENTS

DIRECTIONS = ('north', 'east', 'south', 'west', 'up', 'down')
EPSILON = 1e-7


class ModelUnsupported(ValueError):
    pass


def _save_json(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def _cube_parent(textures):
    return {'elements': [{'from': [0, 0, 0], 'to': [16, 16, 16],
                         'faces': {face: {'texture': '#' + textures.get(face, face), 'cullface': face}
                                   for face in DIRECTIONS}}]}


def _builtin(identifier):
    """Small explicit vanilla templates. Unknown parents must be supplied, never guessed."""
    if identifier in ('minecraft:block/block', 'minecraft:item/handheld', 'minecraft:item/generated',
                      'minecraft:builtin/generated', 'minecraft:builtin/entity'):
        return {} if identifier == 'minecraft:block/block' else {'_generated': identifier}
    if identifier == 'minecraft:block/cube':
        return _cube_parent({})
    if identifier == 'minecraft:block/cube_all':
        return _cube_parent({f: 'all' for f in DIRECTIONS})
    if identifier == 'minecraft:block/cube_bottom_top':
        return _cube_parent({f: ('top' if f == 'up' else 'bottom' if f == 'down' else 'side') for f in DIRECTIONS})
    if identifier == 'minecraft:block/cube_column':
        return _cube_parent({f: ('end' if f in ('up', 'down') else 'side') for f in DIRECTIONS})
    if identifier == 'minecraft:block/orientable':
        return _cube_parent({'north': 'front', 'east': 'side', 'south': 'side', 'west': 'side', 'up': 'top', 'down': 'top'})
    if identifier == 'minecraft:block/orientable_with_bottom':
        return _cube_parent({'north': 'front', 'east': 'side', 'south': 'side', 'west': 'side', 'up': 'top', 'down': 'bottom'})
    return None


def resolve_model(pack, identifier, dependencies=None, chain=None):
    dependencies = dependencies if dependencies is not None else set()
    chain = chain or []
    identifier = normalize_id(identifier)
    if identifier in chain or len(chain) >= 64:
        raise ModelUnsupported('Ciclo o exceso de profundidad en parent: ' + ' → '.join(chain + [identifier]))
    path = asset_path(identifier)
    if pack.exists(path):
        dependencies.add(path)
        child = copy.deepcopy(pack.read_json(path))
    else:
        child = _builtin(identifier)
        if child is None:
            raise ModelUnsupported(f'Falta parent {identifier}; agregue el JAR de Minecraft/dependencia como recurso adicional.')
        child = copy.deepcopy(child)
    if not isinstance(child, dict):
        raise ModelUnsupported('El modelo no es un objeto JSON.')
    if child.get('parent'):
        parent = resolve_model(pack, child['parent'], dependencies, chain + [identifier])
        merged = dict(parent)
        merged.update(child)
        merged['textures'] = dict(parent.get('textures', {})) | dict(child.get('textures', {}))
        merged['display'] = dict(parent.get('display', {})) | dict(child.get('display', {}))
        # Elements, overrides, children and loader follow child override, not concatenation.
        return merged
    return child


def _texture_id(reference, texture_map):
    seen = set()
    while str(reference).startswith('#'):
        key = str(reference)[1:]
        if key in seen:
            raise ModelUnsupported(f'Ciclo de alias de textura: {key}')
        seen.add(key)
        if key not in texture_map:
            raise ModelUnsupported(f'Alias de textura sin resolver: #{key}')
        reference = texture_map[key]
    return normalize_id(reference)


def _normal(vertices):
    a = np.asarray(vertices, dtype=float)
    if len(a) < 3:
        return [0.0, 0.0, 0.0]
    v = np.cross(a[1] - a[0], a[2] - a[0])
    length = float(np.linalg.norm(v))
    return (v / length).tolist() if length > 1e-12 else [0.0, 0.0, 0.0]


def _bounds(faces):
    if not faces:
        return [[0, 0, 0], [0, 0, 0]]
    vertices = np.asarray([v for face in faces for v in face['vertices']], dtype=float)
    return [vertices.min(axis=0).tolist(), vertices.max(axis=0).tolist()]


def _rotate(vertices, pivot, angles):
    """Right-handed Java-space Euler XYZ, degrees, around explicit pivot."""
    v = np.asarray(vertices, dtype=float) - np.asarray(pivot, dtype=float)
    for axis, angle in enumerate(angles):
        if not angle:
            continue
        c, s = math.cos(math.radians(angle)), math.sin(math.radians(angle))
        if axis == 0:
            matrix = np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
        elif axis == 1:
            matrix = np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
        else:
            matrix = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
        v = v @ matrix.T
    return v + np.asarray(pivot, dtype=float)


def _java_corners(a, b, direction):
    x0, y0, z0 = a
    x1, y1, z1 = b
    return {
        'north': [[x1, y1, z0], [x1, y0, z0], [x0, y0, z0], [x0, y1, z0]],
        'east': [[x1, y1, z1], [x1, y0, z1], [x1, y0, z0], [x1, y1, z0]],
        'south': [[x0, y1, z1], [x0, y0, z1], [x1, y0, z1], [x1, y1, z1]],
        'west': [[x0, y1, z0], [x0, y0, z0], [x0, y0, z1], [x0, y1, z1]],
        'up': [[x0, y1, z0], [x0, y1, z1], [x1, y1, z1], [x1, y1, z0]],
        'down': [[x0, y0, z1], [x0, y0, z0], [x1, y0, z0], [x1, y0, z1]],
    }[direction]


def _default_uv(a, b, face):
    x0, y0, z0 = a
    x1, y1, z1 = b
    return {
        'down': [x0, 16-z1, x1, 16-z0], 'up': [x0, z0, x1, z1],
        'north': [16-x1, 16-y1, 16-x0, 16-y0],
        'south': [x0, 16-y1, x1, 16-y0],
        'west': [z0, 16-y1, z1, 16-y0],
        'east': [16-z1, 16-y1, 16-z0, 16-y0],
    }[face]


def _uv_corners(rect, rotation=0):
    u0, v0, u1, v1 = rect
    coords = [[u0, v0], [u0, v1], [u1, v1], [u1, v0]]
    shift = int(rotation // 90) % 4
    return coords[shift:] + coords[:shift]


class _Scene:
    def __init__(self, pack, destination):
        self.pack = pack
        self.destination = destination
        self.dependencies = set()
        self.textures = {}
        self.images = {}
        self.texture_metadata = {}
        self.warnings = []
        self.faces = []
        self.units = []
        self.obj_present = False
        self.split_inverted = 0
        self.unresolved = False

    def warn(self, message):
        if message not in self.warnings:
            self.warnings.append(message)

    def texture(self, identifier):
        if identifier in self.images:
            return self.images[identifier]
        path = asset_path(identifier, 'textures', '.png')
        if not self.pack.exists(path):
            self.unresolved = True
            self.warn(f'Textura ausente: {identifier}. Se muestra magenta de diagnóstico, nunca se certifica equivalencia.')
            image = Image.new('RGBA', (16, 16), (255, 0, 255, 255))
            diag = self.destination / 'diagnostics' / (re.sub(r'[^a-zA-Z0-9_-]', '_', identifier) + '.png')
            diag.parent.mkdir(parents=True, exist_ok=True)
            image.save(diag)
            self.textures[identifier] = str(diag.resolve())
            self.images[identifier] = image
            self.texture_metadata[identifier] = {'missing': True, 'width':16, 'height':16}
            return image
        raw = self.pack.read_bytes(path)
        self.dependencies.add(path)
        generated_info=getattr(self.pack,'_virtual_provenance',{}).get(path)
        if generated_info:
            self.dependencies.update(generated_info.get('dependencies',[]))
        out = self.destination / 'originals' / path
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(raw)
        image = Image.open(io.BytesIO(raw)).convert('RGBA')
        if image.width * image.height > 67108864:
            raise ModelUnsupported('Textura excede límite de 64 megapíxeles.')
        meta = {'source':path, 'sha256': hashlib.sha256(raw).hexdigest(), 'width':image.width,
                'height':image.height, 'rgba_sha256': hashlib.sha256(image.tobytes()).hexdigest()}
        if generated_info:meta['generated_palette']=generated_info
        if self.pack.exists(path + '.mcmeta'):
            self.dependencies.add(path + '.mcmeta')
            animation = self.pack.read_json(path + '.mcmeta').get('animation')
            if animation is not None:
                w = int(animation.get('width', image.width))
                h = int(animation.get('height', w if 'width' not in animation else image.height))
                # Vanilla: absent both -> square min dimension; only width -> full height.
                if 'width' not in animation and 'height' not in animation:
                    w = h = min(image.size)
                elif 'height' in animation and 'width' not in animation:
                    w = image.width
                if w <= 0 or h <= 0 or image.width % w or image.height % h:
                    raise ModelUnsupported(f'Dimensiones de animación inválidas: {identifier}')
                sequence = animation.get('frames', [0]) or [0]
                index = sequence[0].get('index', 0) if isinstance(sequence[0], dict) else sequence[0]
                columns = image.width // w
                frame_count = columns * (image.height // h)
                if not isinstance(index, int) or index < 0 or index >= frame_count:
                    raise ModelUnsupported(f'Índice de cuadro inválido: {identifier}')
                x, y = (index % columns) * w, (index // columns) * h
                image = image.crop((x, y, x+w, y+h))
                frame = self.destination / 'frames' / (re.sub(r'[^a-zA-Z0-9_-]', '_', identifier) + '.png')
                frame.parent.mkdir(parents=True, exist_ok=True)
                image.save(frame)
                self.textures[identifier] = str(frame.resolve())
                meta.update({'animation':animation, 'preview_frame':index, 'frame_width':w, 'frame_height':h})
                self.warn(f'Textura animada {identifier}: comparación del cuadro inicial {index}; secuencia completa preservada como fuente, no convertida a animación Bedrock.')
        self.textures.setdefault(identifier, str(out.resolve()))
        self.images[identifier] = image
        self.texture_metadata[identifier] = meta
        return image

    def add_json(self, model, depth=0):
        if depth > 32:
            raise ModelUnsupported('Composite demasiado profundo.')
        loader = model.get('loader')
        if loader in ('neoforge:composite', 'forge:composite'):
            self.warn('Composite: se conserva la composición estática; visibilidad/materiales controlados por código necesitan integración manual.')
            children = model.get('children', {})
            visibility = model.get('visibility', {})
            for name, child in children.items():
                if visibility.get(name) is False:
                    continue
                if isinstance(child, str):
                    child = resolve_model(self.pack, child, self.dependencies)
                else:
                    child = copy.deepcopy(child)
                    if child.get('parent'):
                        parent = resolve_model(self.pack, child['parent'], self.dependencies)
                        inherited_textures = dict(parent.get('textures', {})) | dict(child.get('textures', {}))
                        parent.update(child)
                        parent['textures'] = inherited_textures
                        child = parent
                child['textures'] = dict(model.get('textures', {})) | dict(child.get('textures', {}))
                self.add_json(child, depth+1)
            return
        if loader in ('neoforge:obj', 'forge:obj'):
            self.add_obj(model)
            return
        if loader:
            raise ModelUnsupported(f'Loader personalizado no implementado: {loader}; requiere adaptador explícito.')
        if model.get('_generated') in GENERATED_PARENTS and not model.get('elements'):
            model=copy.deepcopy(model)
            model['elements'],sprite_warnings=generated_elements(model,self.texture)
            for warning in sprite_warnings:self.warn(warning)
        if model.get('_generated') and not model.get('elements'):
            raise ModelUnsupported(f"Modelo generado/dinámico {model['_generated']}; requiere extrusión de sprite o renderer específico.")
        texture_map = model.get('textures', {})
        for element in model.get('elements', []):
            a = np.asarray(element['from'], dtype=float)
            b = np.asarray(element['to'], dtype=float)
            if a.shape != (3,) or b.shape != (3,) or not np.isfinite(a).all() or not np.isfinite(b).all():
                raise ModelUnsupported('Coordenadas inválidas.')
            if np.any(b < a):
                self.split_inverted += 1
            rotation = element.get('rotation', {})
            pivot = np.asarray(rotation.get('origin', [8,8,8]), dtype=float)
            angles = [0.0, 0.0, 0.0]
            angle = float(rotation.get('angle', 0))
            axis = 'xyz'.index(rotation.get('axis', 'y'))
            angles[axis] = angle
            scaled_a, scaled_b = a.copy(), b.copy()
            if rotation.get('rescale') and angle:
                c = abs(math.cos(math.radians(angle)))
                if c < 1e-8:
                    raise ModelUnsupported('rescale singular a 90 grados.')
                scale = np.array([1/c if k != axis else 1 for k in range(3)])
                scaled_a = pivot + (a-pivot) * scale
                scaled_b = pivot + (b-pivot) * scale
            unit = {'from':scaled_a.tolist(), 'to':scaled_b.tolist(), 'pivot':pivot.tolist(),
                    'angles':angles, 'faces':{}, 'name':element.get('name', '')}
            for direction in DIRECTIONS:
                face = element.get('faces', {}).get(direction)
                if face is None:
                    continue
                texture_id = _texture_id(face['texture'], texture_map)
                texture = self.texture(texture_id)
                uv = face.get('uv', _default_uv(a, b, direction))
                uv = [float(uv[0])*texture.width/16, float(uv[1])*texture.height/16,
                      float(uv[2])*texture.width/16, float(uv[3])*texture.height/16]
                face_rotation = int(face.get('rotation', 0))
                if face_rotation not in (0,90,180,270):
                    raise ModelUnsupported(f'Rotación UV no rectangular: {face_rotation}')
                if 'tintindex' in face and face['tintindex'] >= 0:
                    self.warn('tintindex depende del contexto Java; se conserva textura base sin aplicar un color inventado.')
                if min(uv[0],uv[2]) < 0 or max(uv[0],uv[2]) > texture.width or min(uv[1],uv[3]) < 0 or max(uv[1],uv[3]) > texture.height:
                    self.warn('UV fuera del sprite: lectura del atlas Java vecino no reproducible sin contexto; revisar estas caras.')
                vertices = _rotate(_java_corners(scaled_a, scaled_b, direction), pivot, angles) - [8,0,8]
                record = {'vertices':vertices.tolist(), 'uv':_uv_corners(uv, face_rotation),
                          'texture':texture_id, 'normal':_normal(vertices), 'direction':direction,
                          'element':len(self.units)}
                self.faces.append(record)
                unit['faces'][direction] = {'uv':uv, 'rotation':face_rotation, 'texture':texture_id}
            self.units.append(unit)
        if model.get('overrides'):
            self.warn('Overrides de ítem dependen de predicados Java y no se transfieren a comportamiento Bedrock.')

    def add_obj(self, model):
        self.obj_present = True
        model_id = normalize_id(model['model'])
        ns, name = model_id.split(':',1)
        path = f'assets/{ns}/{name}'
        self.dependencies.add(path)
        data = self.pack.read_bytes(path).decode('utf-8-sig')
        vertices, uvs, normals, polygons = [], [], [], []
        materials, material = {}, None
        for line in data.splitlines():
            tokens = line.strip().split()
            if not tokens or tokens[0].startswith('#'):
                continue
            tag = tokens[0]
            if tag == 'v':
                vertices.append([float(v)*16 for v in tokens[1:4]])
            elif tag == 'vt':
                uvs.append([float(v) for v in tokens[1:3]])
            elif tag == 'vn':
                normals.append([float(v) for v in tokens[1:4]])
            elif tag == 'mtllib':
                for filename in tokens[1:]:
                    mtl_path = str(PurePosixPath(path).parent / filename)
                    if not self.pack.exists(mtl_path):
                        self.warn(f'MTL ausente: {mtl_path}')
                        continue
                    self.dependencies.add(mtl_path)
                    current = None
                    for ml in self.pack.read_bytes(mtl_path).decode('utf-8-sig').splitlines():
                        mt = ml.strip().split()
                        if not mt:
                            continue
                        if mt[0] == 'newmtl':
                            current = ' '.join(mt[1:])
                        elif mt[0] == 'map_Kd' and current:
                            materials[current] = ' '.join(mt[1:])
            elif tag == 'usemtl':
                material = ' '.join(tokens[1:])
            elif tag == 'f':
                corners=[]
                for token in tokens[1:]:
                    indices=token.split('/')
                    def idx(value, length):
                        n=int(value)
                        return n-1 if n>0 else length+n
                    corners.append((idx(indices[0],len(vertices)), idx(indices[1],len(uvs)) if len(indices)>1 and indices[1] else None,
                                    idx(indices[2],len(normals)) if len(indices)>2 and indices[2] else None))
                polygons.append((material,corners))
        # NeoForge 1.21.1 ObjModel.ModelMesh.addQuads/bake return immediately
        # when mat == null. Unassigned OBJ groups can be non-rendered bounds
        # helpers (Create mechanical_roller/wheel has 30 such faces).
        # Preserve them in the raw source, but do not invent missing textures
        # or let invisible helper vertices enlarge the visible model bounds.
        unassigned_faces = sum(material is None for material, _ in polygons)
        if unassigned_faces:
            self.warn(f'OBJ: {unassigned_faces} caras sin material asignado no se renderizan en NeoForge; permanecen en el archivo fuente.')
        for material,corners in polygons:
            if material is None:
                continue
            reference = materials.get(material)
            if not reference:
                self.unresolved=True
                self.warn(f'OBJ sin map_Kd para material {material}; color de diagnóstico.')
                reference='modbridge:missing_material'
            if reference.startswith('#'):
                texture_id=_texture_id(reference,model.get('textures',{}))
            else:
                reference=reference.replace('textures/','').removesuffix('.png')
                texture_id=normalize_id(reference)
            texture=self.texture(texture_id)
            transformed=[]; texcoords=[]; vertex_normals=[]
            for vi,ti,ni in corners:
                transformed.append((np.asarray(vertices[vi])-[8,0,8]).tolist())
                if ti is None:
                    self.warn('OBJ contiene vértices sin UV; no se certifica textura.')
                    texcoords.append([0,0])
                else:
                    u,v=uvs[ti]
                    # NeoForge flip_v maps OBJ convention to Minecraft top-left UV.
                    texcoords.append([u*texture.width,(1-v if model.get('flip_v',False) else v)*texture.height])
                vertex_normals.append(normals[ni] if ni is not None else [0,0,0])
            # Preserve quads; triangulate larger polygons as explicit diagnostic fan.
            groups=[list(range(len(corners)))] if len(corners)<=4 else [[0,i,i+1] for i in range(1,len(corners)-1)]
            if len(corners)>4:
                self.warn('OBJ con polígonos >4 vértices: triangulación fan para vista diagnóstica; concavidad requiere revisión.')
            for group in groups:
                vv=[transformed[i] for i in group]
                self.faces.append({'vertices':vv,'uv':[texcoords[i] for i in group], 'texture':texture_id,
                                   'normal':_normal(vv),'vertex_normals':[vertex_normals[i] for i in group], 'direction':'mesh'})
        self.warn('OBJ conserva malla/UV/normales en IR y poly_mesh experimental. Bedrock custom blocks restringe poly_mesh (GEOFMT101); necesita remodelado en cubos o renderer alternativo. No es conversión Bedrock runtime 1:1.')


def _atlas(scene):
    """Integer translated RGBA tiles. No resize, no rotation, no alpha compositing."""
    images = list(scene.images.items())
    if not images:
        images = [('__empty__',Image.new('RGBA',(1,1)))]
    width = max(im.width for _, im in images)
    height = sum(im.height for _, im in images)
    if width*height>67108864:
        raise ModelUnsupported('Atlas excede límite de 64 megapíxeles; se requiere dividir materiales.')
    atlas = Image.new('RGBA',(width,height),(0,0,0,0))
    placements={}; y=0
    for identifier,image in images:
        atlas.paste(image,(0,y))  # no mask: preserve RGB even under alpha=0
        placements[identifier]=(0,y)
        y+=image.height
    atlas.save(scene.destination/'atlas.png')
    return atlas,placements



def _positive_units(units):
    """Represent inverted cuboids as one-sided zero-thickness positive cuboids.

    Java accepts negative sizes (Create uses them for interior walls). A six-plane
    decomposition retains the exact surface set, winding and texel assignment,
    avoiding a negative Bedrock cube size. No volume is invented.
    """
    cardinal={'east':[1,0,0], 'west':[-1,0,0], 'up':[0,1,0], 'down':[0,-1,0],
              'south':[0,0,1], 'north':[0,0,-1]}
    for unit in units:
        a,b=np.asarray(unit['from']),np.asarray(unit['to'])
        if not np.any(b<a):
            yield unit
            continue
        for direction in DIRECTIONS:
            if direction not in unit['faces']:
                continue
            face=unit['faces'][direction]
            source_vertices=np.asarray(_java_corners(a,b,direction),dtype=float)
            normal=np.asarray(_normal(source_vertices))
            if np.linalg.norm(normal)<0.5:
                # A completely degenerate surface is retained in its original form.
                clone=copy.deepcopy(unit); clone['faces']={direction:face}
                yield clone
                continue
            target_direction=min(cardinal,key=lambda key:np.linalg.norm(normal-cardinal[key]))
            low=source_vertices.min(axis=0); high=source_vertices.max(axis=0)
            target_vertices=np.asarray(_java_corners(low,high,target_direction),dtype=float)
            source_uv=np.asarray(_uv_corners(face['uv'],face['rotation']))
            desired=[]
            for vertex in target_vertices:
                index=int(np.argmin(np.linalg.norm(source_vertices-vertex,axis=1)))
                desired.append(source_uv[index])
            desired=np.asarray(desired)
            left,top=desired.min(axis=0); right,bottom=desired.max(axis=0)
            chosen=None
            for u0,u1 in ((left,right),(right,left)):
                for v0,v1 in ((top,bottom),(bottom,top)):
                    for rotation in (0,90,180,270):
                        rect=[float(u0),float(v0),float(u1),float(v1)]
                        if np.allclose(_uv_corners(rect,rotation),desired,atol=1e-8,rtol=0):
                            chosen={'uv':rect,'rotation':rotation,'texture':face['texture']}
                            break
                    if chosen is not None: break
                if chosen is not None: break
            if chosen is None:
                raise ModelUnsupported('No se pudo representar UV de superficie invertida sin distorsión.')
            yield {'from':low.tolist(),'to':high.tolist(),'pivot':unit['pivot'],'angles':unit['angles'],
                   'name':unit['name'],'faces':{target_direction:chosen}}


def _export_geometry(scene, identifier, atlas, placements):
    cubes=[]
    for unit in _positive_units(scene.units):
        a,b,p=unit['from'],unit['to'],unit['pivot']
        size=(np.asarray(b)-a).tolist()
        cube={'origin':[8-b[0],a[1],a[2]-8], 'size':size,
              'pivot':[8-p[0],p[1],p[2]-8],
              'rotation':[-unit['angles'][0],-unit['angles'][1],unit['angles'][2]], 'uv':{}}
        for direction,face in unit['faces'].items():
            offset=placements[face['texture']]
            u0,v0,u1,v1=face['uv']
            uv=[u0+offset[0],v0+offset[1]]; uv_size=[u1-u0,v1-v0]
            if direction in ('up','down'):
                uv=[uv[0]+uv_size[0],uv[1]+uv_size[1]]
                uv_size=[-uv_size[0],-uv_size[1]]
            mapping={'uv':uv,'uv_size':uv_size}
            if face['rotation']:
                mapping['uv_rotation']=face['rotation']
            cube['uv'][direction]=mapping
        cubes.append(cube)
    bounds=_bounds(scene.faces)
    center=(np.asarray(bounds[0])+bounds[1])/2
    extent=np.asarray(bounds[1])-bounds[0]
    description={'identifier':'geometry.modbridge.'+re.sub('[^a-zA-Z0-9_.]','_',identifier).lower()+'.'+hashlib.sha256(identifier.encode()).hexdigest()[:10],
                 'texture_width':atlas.width,'texture_height':atlas.height,
                 'visible_bounds_width':max(float(extent[0]),float(extent[2]))/16+1,
                 'visible_bounds_height':float(extent[1])/16+1,
                 'visible_bounds_offset':[-float(center[0])/16,float(center[1])/16,float(center[2])/16]}
    bones=[{'name':'root','pivot':[0,0,0],'cubes':cubes}]
    if scene.obj_present:
        positions=[]; normals=[]; texcoords=[]; polys=[]
        # Mesh faces only; cubes remain separately encoded.
        for face in scene.faces:
            if face.get('direction')!='mesh':
                continue
            poly=[]
            for vi,(vertex,uv) in enumerate(zip(face['vertices'],face['uv'])):
                offset=placements[face['texture']]
                n=face.get('vertex_normals',[face['normal']]*len(face['vertices']))[vi]
                positions.append([-vertex[0],vertex[1],vertex[2]])
                normals.append([-n[0],n[1],n[2]])
                texcoords.append([uv[0]+offset[0],uv[1]+offset[1]])
                idx=len(positions)-1
                poly.append([idx,idx,idx])
            polys.append(poly)
        bones.append({'name':'experimental_mesh','parent':'root','pivot':[0,0,0],
                      'poly_mesh':{'normalized_uvs':False,'positions':positions,'normals':normals,'uvs':texcoords,'polys':polys}})
    return {'format_version':'1.21.0','minecraft:geometry':[{'description':description,'bones':bones}]}


def decode_bedrock(geometry, texture_path):
    """Decode serialized geometry without source elements or atlas placement metadata.

    Intended for authored cube geometry and diagnostic poly_mesh, not animation/Molang.
    Includes bone hierarchy; accepts geometry dict or JSON path.
    """
    if isinstance(geometry,(str,Path)):
        geometry=json.loads(Path(geometry).read_text(encoding='utf-8-sig'))
    geos=geometry.get('minecraft:geometry',[])
    if not geos:
        # Legacy geometry.identifier dictionary format.
        geos=[value for key,value in geometry.items() if key.startswith('geometry.')]
    if not geos:
        raise ValueError('Sin geometría Bedrock.')
    geo=geos[0]
    desc=geo.get('description',geo)
    with Image.open(texture_path) as opened:
        texture_width, texture_height = opened.size
    scale=np.array([texture_width/desc.get('texture_width',desc.get('texturewidth',texture_width)),
                    texture_height/desc.get('texture_height',desc.get('textureheight',texture_height))])
    faces=[]
    bones={bone['name']:bone for bone in geo.get('bones',[])}

    def bone_transform(points,bone_name,chain=None):
        chain=chain or []
        if bone_name in chain:
            raise ValueError('Ciclo de huesos.')
        bone=bones[bone_name]
        rotation=bone.get('rotation',[0,0,0]); pivot=bone.get('pivot',[0,0,0])
        pp=[-pivot[0],pivot[1],pivot[2]]
        rr=[-rotation[0],-rotation[1],rotation[2]]
        points=_rotate(points,pp,rr)
        if bone.get('parent') in bones:
            points=bone_transform(points,bone['parent'],chain+[bone_name])
        return points

    for bone in geo.get('bones',[]):
        for ci,cube in enumerate(bone.get('cubes',[])):
            x,y,z=cube['origin']; sx,sy,sz=cube['size']
            inflate=cube.get('inflate',bone.get('inflate',0))
            x-=inflate; y-=inflate; z-=inflate
            sx+=2*inflate; sy+=2*inflate; sz+=2*inflate
            # Stored Bedrock X increases opposite canonical Java X.
            corner_table={
                'north': [[x,y+sy,z],[x,y,z],[x+sx,y,z],[x+sx,y+sy,z]],
                'east': [[x,y+sy,z+sz],[x,y,z+sz],[x,y,z],[x,y+sy,z]],
                'south': [[x+sx,y+sy,z+sz],[x+sx,y,z+sz],[x,y,z+sz],[x,y+sy,z+sz]],
                'west': [[x+sx,y+sy,z],[x+sx,y,z],[x+sx,y,z+sz],[x+sx,y+sy,z+sz]],
                'up': [[x+sx,y+sy,z],[x+sx,y+sy,z+sz],[x,y+sy,z+sz],[x,y+sy,z]],
                'down': [[x+sx,y,z+sz],[x+sx,y,z],[x,y,z],[x,y,z+sz]],
            }
            uv_data=cube.get('uv',{})
            if isinstance(uv_data,list):
                u,v=uv_data
                # Standard Bedrock box UV layout, physical X/Y/Z sizes.
                uv_data={
                    'west':{'uv':[u,v+sz],'uv_size':[sz,sy]},
                    'north':{'uv':[u+sz,v+sz],'uv_size':[sx,sy]},
                    'east':{'uv':[u+sz+sx,v+sz],'uv_size':[sz,sy]},
                    'south':{'uv':[u+sz+sx+sz,v+sz],'uv_size':[sx,sy]},
                    'up':{'uv':[u+sz+sx,v+sz],'uv_size':[-sx,-sz]},
                    'down':{'uv':[u+sz+2*sx,v],'uv_size':[-sx,sz]},
                }
            for direction in DIRECTIONS:
                if direction not in uv_data:
                    continue
                mapping=uv_data[direction]
                if not isinstance(mapping,dict):
                    continue
                uv=np.asarray(mapping.get('uv',[0,0]),dtype=float)
                default_size={'north':[sx,sy],'south':[sx,sy],'east':[sz,sy],'west':[sz,sy],'up':[sx,sz],'down':[sx,sz]}[direction]
                size=np.asarray(mapping.get('uv_size',default_size),dtype=float)
                if direction in ('up','down'):
                    uv=uv+size; size=-size
                rect=[uv[0],uv[1],uv[0]+size[0],uv[1]+size[1]]
                u0,v0,u1,v1=rect
                coords=[[u0,v0],[u0,v1],[u1,v1],[u1,v0]]
                shift=(int(mapping.get('uv_rotation',0))//90)%4
                coords=coords[shift:]+coords[:shift]
                coords=(np.asarray(coords)*scale).tolist()
                vertices=np.asarray(corner_table[direction],dtype=float)*[-1,1,1]
                pivot=cube.get('pivot',[x+sx/2,y+sy/2,z+sz/2]); rotation=cube.get('rotation',[0,0,0])
                vertices=_rotate(vertices,[-pivot[0],pivot[1],pivot[2]],[-rotation[0],-rotation[1],rotation[2]])
                vertices=bone_transform(vertices,bone['name'])
                if cube.get('mirror',bone.get('mirror',False)):
                    # Box UV mirroring is handled conservatively: flag metadata to caller.
                    coords=[coords[3],coords[2],coords[1],coords[0]]
                faces.append({'vertices':vertices.tolist(),'uv':coords,'texture':'atlas','normal':_normal(vertices),
                              'direction':direction,'element':ci})
        mesh=bone.get('poly_mesh')
        if mesh:
            for poly in mesh.get('polys',[]):
                if not isinstance(poly,list):
                    continue
                vertices=[]; coords=[]; vertex_normals=[]
                for pi,ni,ti in poly:
                    p=mesh['positions'][pi]
                    vertices.append([-p[0],p[1],p[2]])
                    uv=mesh['uvs'][ti]
                    if mesh.get('normalized_uvs'):
                        coords.append([uv[0]*texture_width,uv[1]*texture_height])
                    else:
                        coords.append((np.asarray(uv)*scale).tolist())
                    n=mesh['normals'][ni]
                    vertex_normals.append([-n[0],n[1],n[2]])
                vertices=bone_transform(vertices,bone['name'])
                faces.append({'vertices':vertices.tolist(),'uv':coords,'texture':'atlas','normal':_normal(vertices),
                              'vertex_normals':vertex_normals,'direction':'mesh'})
    return {'faces':faces,'textures':{'atlas':str(Path(texture_path).resolve())},'bounds':_bounds(faces),
            'coordinate_system':'Java centered X/Z, Y up; pixels','runtime_validated':False}


def _validate(source,target,placements,scene,atlas):
    max_geometry=0.0; max_uv=0.0; normal_error=0.0
    same_count=len(source['faces'])==len(target['faces'])
    buckets={}
    def face_key(face):
        return tuple(sorted(tuple(round(float(c),6) for c in v) for v in face['vertices']))
    for tf in target['faces']:
        buckets.setdefault(face_key(tf),[]).append(tf)
    if same_count:
        for sf in source['faces']:
            candidates=buckets.get(face_key(sf),[])
            if not candidates:
                same_count=False; break
            expected_uv=np.asarray(sf['uv'])+placements[sf['texture']]
            best=None
            for ci,tf in enumerate(candidates):
                sv,tv=np.asarray(sf['vertices']),np.asarray(tf['vertices'])
                distances=np.linalg.norm(sv[:,None,:]-tv[None,:,:],axis=2)
                indices=np.argmin(distances,axis=1)
                ge=float(np.max(np.abs(sv-tv[indices])))
                ue=float(np.max(np.abs(expected_uv-np.asarray(tf['uv'])[indices])))
                ne=float(np.max(np.abs(np.asarray(sf['normal'])-tf['normal'])))
                score=ge+ue+ne
                if best is None or score<best[0]:
                    best=(score,ci,ge,ue,ne)
            _,ci,ge,ue,ne=best
            candidates.pop(ci)
            max_geometry=max(max_geometry,ge); max_uv=max(max_uv,ue); normal_error=max(normal_error,ne)
    pixels_exact=True
    for identifier,image in scene.images.items():
        x,y=placements[identifier]
        pixels_exact &= image.tobytes()==atlas.crop((x,y,x+image.width,y+image.height)).tobytes()
    bounds_error=float(np.max(np.abs(np.asarray(source['bounds'])-target['bounds'])))
    lo,hi=np.asarray(source['bounds'][0]),np.asarray(source['bounds'][1])
    ext=hi-lo
    # Creator custom-block constraints; preserve large models as entity candidates.
    intersects=bool(np.all(np.minimum(hi,[8,16,8])-np.maximum(lo,[-8,0,-8])>=1-1e-7))
    block_compatible=bool(np.all(ext<=30+1e-7) and np.all(lo>=-30-1e-7) and np.all(hi<=30+1e-7) and intersects and not scene.obj_present)
    verified=bool(same_count and max_geometry<EPSILON and max_uv<EPSILON and normal_error<EPSILON and pixels_exact and not scene.unresolved)
    return {'face_count_original':len(source['faces']),'face_count_bedrock':len(target['faces']),
            'face_count_equal':same_count,'max_vertex_error_pixels':max_geometry if same_count else None,
            'max_uv_error_pixels':max_uv if same_count else None,'max_normal_error':normal_error if same_count else None,
            'max_bounds_error_pixels':bounds_error,'rgba_texels_preserved':bool(pixels_exact),
            'static_equivalence_passed':verified,'dimensions_pixels':ext.tolist(),'block_compatible':block_compatible,
            'tolerance_pixels':EPSILON,'runtime_validated':False}


def convert_model(pack:ResourcePack, model_id:str, destination:Path):
    destination=Path(destination).resolve(); destination.mkdir(parents=True,exist_ok=True)
    model_id=normalize_id(model_id)
    scene=_Scene(pack,destination)
    report={'id':model_id,'status':'unsupported','warnings':[], 'metrics':{},'paths':{},
            'source_dependencies':[],'target_kind':None,'runtime_validated':False,
            'scope':'Geometría y texturas estáticas; no transporta lógica, contraptions, animación Java, blockstates ni shaders.'}
    try:
        path=asset_path(model_id)
        original=pack.read_bytes(path)
        (destination/'original.json').write_bytes(original)
        model=resolve_model(pack,model_id,scene.dependencies)
        report['blockstate_references']=pack.blockstates_for(model_id)
        scene.dependencies.update(report['blockstate_references'])
        _save_json(destination/'resolved.json',model)
        scene.add_json(model)
        if not scene.faces:
            raise ModelUnsupported('Recurso sin superficies estáticas: plantilla, renderer dinámico o modelo vacío.')
        atlas,placements=_atlas(scene)
        source={'id':model_id,'faces':scene.faces,'textures':scene.textures,'bounds':_bounds(scene.faces),
                'coordinate_system':'Java centered X/Z, Y up; pixels','texture_metadata':scene.texture_metadata}
        geometry=_export_geometry(scene,model_id,atlas,placements)
        target=decode_bedrock(geometry,destination/'atlas.png')
        report['metrics']=_validate(source,target,placements,scene,atlas)
        report['target_kind']='experimental_poly_mesh' if scene.obj_present else ('block_or_entity_geometry' if report['metrics']['block_compatible'] else 'entity_geometry')
        if not report['metrics']['block_compatible'] and not scene.obj_present:
            scene.warn('La geometría excede/rebasa límites de bloque personalizado o no intersecta 1 píxel por eje. Se conserva escala: integrar como entidad o componente de conjunto, no reducirla automáticamente.')
        if scene.obj_present:
            report['status']='unsupported'
        elif report['metrics']['static_equivalence_passed'] and not scene.warnings:
            report['status']='verified_static'
        else:
            report['status']='review'
        _save_json(destination/'model.geo.json',geometry)
        _save_json(destination/'ir_original.json',source)
        _save_json(destination/'ir_bedrock.json',target)
        _save_json(destination/'atlas_map.json',{'placements':placements,'textures':scene.texture_metadata,
                                               'lossless_rgba_copy':True,'animation_scope':'first specified frame'})
        report['paths']={name:str(destination/filename) for name,filename in [
            ('geometry','model.geo.json'),('atlas','atlas.png'),('original','original.json'),
            ('resolved','resolved.json'),('ir_original','ir_original.json'),('ir_bedrock','ir_bedrock.json'),('atlas_map','atlas_map.json')]}
        report['preserved']=['Coordenadas en unidades de píxel','Tamaño y proporciones sin reescalado global',
                             'Pivotes, rotaciones y rescale estáticos','Caras presentes/ausentes y UV individuales',
                             'RGBA original por texel en atlas; PNG fuente intacto','Dependencias y referencias originales']
        report['modified']=['Cambio de sistema de coordenadas X y centrado X/Z','Traslación entera de UV al atlas',
                            'Codificación de rotación y UV superior/inferior según Bedrock']
        if scene.split_inverted:
            report['modified'].append(f'{scene.split_inverted} cubo(s) invertido(s) descompuesto(s) en planos con tamaños no negativos y normales/UV preservadas.')
        report['metrics']['inverted_elements_split']=scene.split_inverted
    except ModelUnsupported as error:
        scene.warn(str(error)); report['status']='unsupported'
    except (OSError,ValueError,KeyError,IndexError,TypeError) as error:
        scene.warn(f'{type(error).__name__}: {error}'); report['status']='error'
    for dependency in sorted(scene.dependencies):
        if not pack.exists(dependency):
            continue
        out=destination/'originals'/dependency
        out.parent.mkdir(parents=True,exist_ok=True)
        if not out.exists():
            out.write_bytes(pack.read_bytes(dependency))
    report['source_dependencies']=sorted(scene.dependencies)
    report['warnings']=scene.warnings
    report['paths']['report']=str(destination/'report.json')
    _save_json(destination/'report.json',report)
    return report
