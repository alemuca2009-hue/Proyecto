"""Polygon triangulation from ModBridge 2.4.4, independent of renderers."""
from __future__ import annotations
import numpy as np

def _triangulate(vertices: np.ndarray) -> list[tuple[int, int, int]]:
    """Ear clipping on a planar polygon; handles concave OBJ polygons.

    Minecraft's ordinary quads remain a deterministic (0,1,2)/(0,2,3) pair.
    Degenerate and self-intersecting polygons are not silently convexified.
    """
    n = len(vertices)
    def cross2(a, b):
        return float(a[0] * b[1] - a[1] * b[0])
    if n < 3:
        return []
    if n == 3:
        return [(0, 1, 2)]
    if n == 4:
        # Cuboids dominate mod assets. Avoid ear clipping for convex quads.
        edges = np.roll(vertices, -1, axis=0) - vertices
        corners = np.cross(edges, np.roll(edges, -1, axis=0))
        ref = corners[np.argmax(np.linalg.norm(corners, axis=1))]
        if np.linalg.norm(ref) > 1e-14 and np.all(corners @ ref >= -1e-12):
            return [(0, 1, 2), (0, 2, 3)]
    normal = np.zeros(3)
    for i in range(n):
        normal += np.cross(vertices[i], vertices[(i + 1) % n])
    if np.linalg.norm(normal) < 1e-14:
        return []
    xy = np.delete(vertices, int(np.argmax(np.abs(normal))), axis=1)
    area = sum(float(xy[i, 0] * xy[(i + 1) % n, 1] - xy[(i + 1) % n, 0] * xy[i, 1]) for i in range(n))
    direction = 1.0 if area >= 0 else -1.0
    remaining = list(range(n))
    result = []
    for _ in range(n * n):
        if len(remaining) == 3:
            result.append(tuple(remaining))
            return result
        ear_found = False
        for j in range(len(remaining)):
            ia, ib, ic = remaining[j - 1], remaining[j], remaining[(j + 1) % len(remaining)]
            a, b, c = xy[[ia, ib, ic]]
            cross = cross2(b - a, c - b)
            if cross * direction <= 1e-12:
                continue
            valid = True
            for k in remaining:
                if k in (ia, ib, ic):
                    continue
                p = xy[k]
                e1 = cross2(b - a, p - a) * direction
                e2 = cross2(c - b, p - b) * direction
                e3 = cross2(a - c, p - c) * direction
                if min(e1, e2, e3) >= -1e-12:
                    valid = False
                    break
            if valid:
                result.append((ia, ib, ic))
                remaining.pop(j)
                ear_found = True
                break
        if not ear_found:
            # Degenerate quads can encode planes: fan only if polygon is convex.
            if len(remaining) == 4:
                return result + [(remaining[0], remaining[1], remaining[2]), (remaining[0], remaining[2], remaining[3])]
            return result
    return result
