"""Bedrock cube-only surface approximation for arbitrary static polygon meshes.

Refined polygons use oriented zero-thickness rectangles inside their contours.
Budget-limited faces keep their previous masked rectangle and are reported.
Boundary strips and sampled UVs remain an explicit approximation.
Original meshes/textures must be retained by the caller. No poly_mesh is emitted.
"""
from __future__ import annotations
import hashlib
import math
from pathlib import Path
import numpy as np
from PIL import Image
from .triangulation import _triangulate
from .control import checkpoint
from .surface_contours import refine_patches


def _euler_xyz(matrix):
    """Inverse of right-handed Rz @ Ry @ Rx (column vectors), degrees."""
    m=np.asarray(matrix,dtype=float)
    y=math.asin(float(np.clip(-m[2,0],-1,1)))
    if abs(math.cos(y))>1e-9:
        x=math.atan2(m[2,1],m[2,2]);z=math.atan2(m[1,0],m[0,0])
    else:
        x=math.atan2(-m[1,2],m[1,1]);z=0.0
    return [math.degrees(x),math.degrees(y),math.degrees(z)]


def _patch(vertices, uv, texture, source_index):
    vertices=np.asarray(vertices,dtype=float);uv=np.asarray(uv,dtype=float)
    if vertices.ndim!=2 or vertices.shape[1]!=3 or uv.shape!=(len(vertices),2):
        raise ValueError('La malla tiene vértices/UV inconsistentes.')
    if not np.isfinite(vertices).all() or not np.isfinite(uv).all():
        raise ValueError('La malla contiene valores no finitos.')
    triangles=_triangulate(vertices)
    if not triangles:return [],1
    # Geometric normal, not shading normal: it defines the actual plane.
    tri=max(triangles,key=lambda t:np.linalg.norm(np.cross(vertices[t[1]]-vertices[t[0]],vertices[t[2]]-vertices[t[0]])))
    n=np.cross(vertices[tri[1]]-vertices[tri[0]],vertices[tri[2]]-vertices[tri[0]])
    norm=np.linalg.norm(n)
    if norm<1e-12:return [],1
    n=n/norm
    edges=np.roll(vertices,-1,axis=0)-vertices
    u=edges[np.argmax(np.linalg.norm(edges,axis=1))]
    u=u/np.linalg.norm(u);v=np.cross(n,u);v=v/np.linalg.norm(v)
    base=vertices[0]
    if np.max(np.abs((vertices-base)@n))>1e-6 and len(vertices)>3:
        patches=[];degenerate=0
        for t in triangles:
            part,skipped=_patch(vertices[list(t)],uv[list(t)],texture,source_index)
            patches.extend(part);degenerate+=skipped
        return patches,degenerate
    local=np.stack(((vertices-base)@u,(vertices-base)@v),axis=1)
    lo=local.min(axis=0);hi=local.max(axis=0);extent=hi-lo
    if np.min(extent)<1e-10:return [],1
    anchor=base+u*lo[0]+v*lo[1]
    local=local-lo
    return [{'vertices':vertices,'local':local,'uv':uv,'triangles':triangles,
             'texture':texture,'width':float(extent[0]),'height':float(extent[1]),
             'anchor':anchor,'rotation':_euler_xyz(np.column_stack((u,v,n))),
             'normal':n,'basis_u':u,'basis_v':v,'source_index':source_index}],0


def _power_two(n):
    return 1 << (max(1,int(math.ceil(n)))-1).bit_length()


def _layout(patches, density, limit):
    dimensions=[(max(1,int(math.ceil(p['width']*density))),max(1,int(math.ceil(p['height']*density)))) for p in patches]
    maxwidth=max(w+2 for w,h in dimensions);maxheight=max(h+2 for w,h in dimensions)
    if max(maxwidth,maxheight)>limit:return None
    area=sum((w+2)*(h+2) for w,h in dimensions)
    width=_power_two(max(maxwidth,math.sqrt(area)))
    width=min(width,limit)
    order=sorted(range(len(patches)),key=lambda i:(-dimensions[i][1],-dimensions[i][0],i))
    for width in sorted(set([width,limit])):
        x=y=rowheight=0;placements={}
        for i in order:
            w,h=dimensions[i]
            if x+w+2>width:x=0;y+=rowheight;rowheight=0
            if y+h+2>limit:break
            placements[i]=(x+1,y+1,w,h)
            x+=w+2;rowheight=max(rowheight,h+2)
        if len(placements)==len(patches):
            return placements,width,_power_two(y+rowheight)
    return None


def _texture(value):
    if isinstance(value,Image.Image):return np.asarray(value.convert('RGBA'))
    if isinstance(value,np.ndarray):return np.asarray(Image.fromarray(value.astype('uint8')).convert('RGBA'))
    with Image.open(value) as image:return np.asarray(image.convert('RGBA'))


def _raster_patch(patch,width,height,texture):
    """Evaluate original piecewise-affine UV at output texel centers."""
    xx,yy=np.meshgrid((np.arange(width)+.5)*patch['width']/width,
                      patch['height']-(np.arange(height)+.5)*patch['height']/height)
    output=np.zeros((height,width,4),dtype=np.uint8)
    covered=np.zeros((height,width),dtype=bool)
    local=patch['local'];uv=patch['uv']
    for triangle in patch['triangles']:
        a,b,c=local[list(triangle)]
        denominator=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
        if abs(denominator)<1e-14:continue
        wa=((b[1]-c[1])*(xx-c[0])+(c[0]-b[0])*(yy-c[1]))/denominator
        wb=((c[1]-a[1])*(xx-c[0])+(a[0]-c[0])*(yy-c[1]))/denominator
        wc=1-wa-wb
        mask=(wa>=-1e-9)&(wb>=-1e-9)&(wc>=-1e-9)
        t=uv[list(triangle)]
        u=wa*t[0,0]+wb*t[1,0]+wc*t[2,0]
        v=wa*t[0,1]+wb*t[1,1]+wc*t[2,1]
        ix=np.clip(np.floor(u).astype(np.int64),0,texture.shape[1]-1)
        iy=np.clip(np.floor(v).astype(np.int64),0,texture.shape[0]-1)
        output[mask]=texture[iy[mask],ix[mask]];covered|=mask
    return output,covered


def convert_mesh_surface(source_ir, destination, pixels_per_unit=4, max_atlas=4096, *, settings=None):
    """Return cube-only geometry and a NEW sampled atlas, always review-required.

    The returned atlas is ``surface_atlas.png``; the caller may move/rename it
    with the geometry. Padding is transparent and is outside each UV rectangle.
    Entire source IR is processed, including cuboid components mixed with OBJ.
    Raises ValueError for unrepresentable/invalid input rather than dropping it.
    """
    destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
    density=float(pixels_per_unit)
    if not math.isfinite(density) or density<=0:raise ValueError('Resolución de superficies inválida.')
    limit=int(max_atlas)
    if limit<16 or limit>8192 or limit&(limit-1):raise ValueError('max_atlas debe ser potencia de dos entre 16 y 8192.')
    faces=source_ir.get('faces',[])
    if not faces:raise ValueError('La malla no contiene superficies.')
    if len(faces)>100000:raise ValueError('La malla supera el límite de 100.000 caras; no se descartan caras.')
    patches=[];degenerate=0
    for index,face in enumerate(faces):
        checkpoint()
        part,skipped=_patch(face['vertices'],face['uv'],face['texture'],index)
        patches.extend(part);degenerate+=skipped
    if not patches:raise ValueError('La malla solo contiene caras degeneradas.')
    options = {} if settings is None else dict(tolerance=settings.contour_tolerance,
        budget=settings.rectangle_budget, max_slices=settings.max_slices,
        minimum_coverage=settings.minimum_coverage)
    patches,wire_edges,contour_report=refine_patches(patches, **options)
    requested=density
    layout=None
    for _ in range(96):
        layout=_layout(patches,density,limit)
        if layout:break
        density*=.85
    if not layout:raise ValueError('No caben todas las superficies en el atlas; no se descartó ninguna cara.')
    placements,aw,ah=layout
    atlas=np.zeros((ah,aw,4),dtype=np.uint8)
    images={key:_texture(source_ir['textures'][key]) for key in {p['texture'] for p in patches}}
    cubes=[];uncovered=[];outside_uv=[]
    effective=[]
    for i,p in enumerate(patches):
        checkpoint()
        x,y,w,h=placements[i]
        rgba,covered=_raster_patch(p,w,h,images[p['texture']])
        if not covered.any():
            raise ValueError(f'La máscara de la cara {p["source_index"]} desaparece a esta resolución; aumentar max_atlas.')
        atlas[y:y+h,x:x+w]=rgba
        texture=images[p['texture']]
        if np.min(p['uv'])<0 or np.max(p['uv'][:,0])>texture.shape[1] or np.max(p['uv'][:,1])>texture.shape[0]:outside_uv.append(p['source_index'])
        anchor=p['anchor'];rx,ry,rz=p['rotation']
        cubes.append({'origin':[-float(anchor[0]+p['width']),float(anchor[1]),float(anchor[2])],
                      'size':[p['width'],p['height'],0],
                      'pivot':[-float(anchor[0]),float(anchor[1]),float(anchor[2])],
                      'rotation':[-rx,-ry,rz],
                      'uv':{'south':{'uv':[x,y],'uv_size':[w,h]}}})
        effective.append(min(w/p['width'],h/p['height']))
    vertices=np.asarray([v for f in faces for v in f['vertices']],dtype=float)
    lo=vertices.min(axis=0);hi=vertices.max(axis=0);center=(lo+hi)/2;extent=hi-lo
    name=str(source_ir.get('id','mesh'));digest=hashlib.sha256(name.encode()).hexdigest()[:16]
    geometry={'format_version':'1.21.0','minecraft:geometry':[{
        'description':{'identifier':'geometry.modbridge.surface.'+digest,'texture_width':aw,'texture_height':ah,
            'visible_bounds_width':float(max(extent[0],extent[2]))/16+1,
            'visible_bounds_height':float(extent[1])/16+1,
            'visible_bounds_offset':[-float(center[0])/16,float(center[1])/16,float(center[2])/16]},
        'bones':[{'name':'root','pivot':[0,0,0],'cubes':cubes}]}]}
    atlas_path=destination/'surface_atlas.png';Image.fromarray(atlas).save(atlas_path)
    warnings=[
        'Las caras refinadas usan franjas planas interiores al contorno: eliminan rectángulos salientes, con aproximación en los bordes oblicuos.',
        'El atlas de superficies es un derivado muestreado; no reemplaza las texturas originales conservadas.',
        'Los bordes de polígonos y las UV se rasterizan. El sombreado por normales de vértice, materiales y descarte de caras requieren revisión en Bedrock.',
        'La geometría usa cubos planos ordinarios; su carga y aspecto dentro del juego aún no se han probado.']
    if degenerate:warnings.append(f'{degenerate} caras de área cero no producen una superficie visible; se conservan en el IR fuente.')
    if density<requested:warnings.append('Se redujo la densidad del atlas derivado para conservar todas las caras dentro del límite configurado.')
    if outside_uv:warnings.append('Hay UV fuera de la textura: el muestreo derivado se limita al borde; revisar esas caras.')
    if contour_report['masked_fallback_polygon_count']:
        warnings.append(f"{contour_report['masked_fallback_polygon_count']} caras conservan su máscara anterior para no perder superficie ni exceder el presupuesto de subdivisión; sus contornos aún requieren revisión.")
    report={'status':'review','target_kind':'surface_approximation','exact_geometry':False,'static_equivalence_passed':False,
        'rgba_texels_preserved':False,'runtime_tested':False,'warnings':warnings,
        'source_face_count':len(faces),'surface_rectangles':len(cubes),'zero_area_faces':degenerate,
        'contour_refinement':contour_report,
        'requested_pixels_per_model_unit':requested,'effective_pixels_per_model_unit':min(effective),
        'atlas_size':[aw,ah],'out_of_bounds_uv_faces':sorted(set(outside_uv)),
        'mask_texel_diagonal_model_units':math.sqrt(2)/min(effective),
        'interpretation':'mask_texel_diagonal is spatial sampling scale, not a measured Hausdorff bound',
        'contains_poly_mesh':False}
    return {'geometry':geometry,'atlas_path':str(atlas_path.resolve()),'report':report,'wire_edges':wire_edges,
            'sampling_density':density}
