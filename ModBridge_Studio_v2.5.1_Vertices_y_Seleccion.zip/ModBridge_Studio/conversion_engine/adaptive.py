"""Bounded refinement on top of 2.4.4; never replace a result with a worse plan.

No hulls, no voxelization, no unrestricted coplanar reconstruction. Only proven
rectangles may combine faces; other polygons keep their source patch/UV basis.
"""
from dataclasses import replace
from pathlib import Path
import shutil
import tempfile
from .control import checkpoint, activity, ConversionCancelled
from .geometry import decode_bedrock
from .rectangle_recovery import recover_rectangles
from .surface_proof import verify_surface


def quality(result):
    report=result['report'];contour=report['contour_refinement']
    return {'omitted_area':float(contour['omitted_planar_area']),
            'outside_area':float(contour['outside_source_area']),
            # Compare the actual atlas sampling setting, not ceil(width*density)
            # rounding bonuses which vary when a polygon is subdivided.
            'density':float(result.get('sampling_density',report['effective_pixels_per_model_unit'])),
            'rectangles':report['surface_rectangles']}


def improves(old,new):
    epsilon=1e-9
    return (new['omitted_area']<=old['omitted_area']+epsilon
            and new['outside_area']<=old['outside_area']+epsilon
            and new['density']>=old['density']-epsilon
            and new['omitted_area']+new['outside_area']<old['omitted_area']+old['outside_area']-epsilon)


def convert_with_refinement(source,destination,settings):
    from .mesh_surface import convert_mesh_surface
    destination=Path(destination)
    def convert(ir,folder,options):
        return convert_mesh_surface(ir,folder,pixels_per_unit=options.pixels_per_unit,max_atlas=options.max_atlas,settings=options)
    best=convert(source,destination,settings)
    if not settings.refinement_passes:return best
    checkpoint()
    proof=verify_surface(source,decode_bedrock(best['geometry'],best['atlas_path']))
    baseline=quality(best);best_quality=baseline;attempts=[];selected=0;recovery={}
    if not proof['equal']:
        try:faces,recovery=recover_rectangles(source['faces'])
        except ConversionCancelled:raise
        except Exception as error:
            faces=source['faces'];recovery={'error':str(error),'original_faces_retained':True}
        candidate_source=dict(source,faces=faces)
        with tempfile.TemporaryDirectory(prefix='.repaso_',dir=destination) as temporary:
            for number in range(1,settings.refinement_passes+1):
                checkpoint()
                activity(f'Repaso geométrico {number} de {settings.refinement_passes}')
                options=replace(settings,contour_tolerance=settings.contour_tolerance/(2**number),
                    max_slices=max(settings.max_slices,min(settings.max_slices*(2**number),settings.refinement_max_slices)),
                    rectangle_budget=max(settings.rectangle_budget,min(settings.rectangle_budget*(2**number),settings.refinement_rectangle_budget)))
                row={'pass':number,'settings':options.to_dict(),'accepted':False}
                try:
                    candidate=convert(candidate_source,Path(temporary)/str(number),options)
                    score=quality(candidate);row['quality']=score
                    if not improves(best_quality,score):
                        row['reason']='No mejora simultáneamente la superficie omitida, la saliente y la densidad del atlas.'
                    else:
                        decoded=decode_bedrock(candidate['geometry'],candidate['atlas_path'])
                        candidate_proof=verify_surface(source,decoded)
                        row['proof']=candidate_proof
                        # An already coincident result is never replaced by an approximation.
                        if proof['equal'] and not candidate_proof['equal']:
                            row['reason']='La comprobación independiente no coincide.'
                        else:
                            pending=destination/'surface_atlas.pending.png'
                            shutil.copy2(candidate['atlas_path'],pending)
                            pending.replace(destination/'surface_atlas.png')
                            candidate['atlas_path']=str((destination/'surface_atlas.png').resolve())
                            best,best_quality,proof=candidate,score,candidate_proof
                            selected=number;row['accepted']=True;row['reason']='Mejora conservadora aceptada.'
                except ConversionCancelled:raise
                except Exception as error:
                    row['reason']='Se conserva el resultado anterior: '+str(error)
                attempts.append(row)
                if proof['equal']:break
    best['report']['adaptive_refinement']={'enabled':True,'base_algorithm':'2.4.4',
        'maximum_passes':settings.refinement_passes,'passes_performed':len(attempts),'selected_pass':selected,
        'baseline_quality':baseline,'selected_quality':best_quality,'geometry_coincident':proof['equal'],
        'independent_proof':proof,'rectangle_recovery':recovery,'attempts':attempts,
        'stop_reason':'geometry_coincident' if proof['equal'] else 'bounded_attempts_completed',
        'original_face_count':len(source['faces'])}
    best['report']['exact_geometry']=proof['equal']
    return best
